import { Routes, Route } from "react-router-dom";
import { Index } from "../pages/Index";
import { ProductDetail } from "../pages/ProductDetail";
import { Cart } from "../pages/Cart";
import { Checkout } from "../pages/Checkout";
import { Admin } from "../pages/Admin";
import { Category } from "../pages/Category";
import { Login } from "../pages/Login";
import { MLMPanel } from "../pages/MLMPanel";
import { Gelisim } from "../pages/Gelisim";
import { MemberPanel } from "../pages/MemberPanel";
import { SellerPanel } from "../pages/SellerPanel";
import { About } from "../pages/About";
import { Register } from "../pages/Register";
import { Notifications } from "../pages/Notifications";
import { NotFound } from "../pages/NotFound";

export function AppRoutes() {
  return (
    <Routes>
      <Route path="/" element={<Index />} />
      <Route path="/product/:id" element={<ProductDetail />} />
      <Route path="/cart" element={<Cart />} />
      <Route path="/checkout" element={<Checkout />} />
      <Route path="/admin" element={<Admin />} />
      <Route path="/category/:category" element={<Category />} />
      <Route path="/login" element={<Login />} />
      <Route path="/mlm" element={<MLMPanel />} />
      <Route path="/gelisim" element={<Gelisim />} />
      <Route path="/member-panel" element={<MemberPanel />} />
      <Route path="/seller-panel" element={<SellerPanel />} />
      <Route path="/about" element={<About />} />
      <Route path="/register" element={<Register />} />
      <Route path="/notifications" element={<Notifications />} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}
