import React, { createContext, useContext, useState, ReactNode } from "react";

interface User {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
  mlmLevel?: string;
  totalSales?: number;
  bonusEarnings?: number;
}

interface UserContextType {
  user: User | null;
  isLoggedIn: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  logout: () => void;
  register: (
    userData: Partial<User> & { password: string },
  ) => Promise<boolean>;
}

const UserContext = createContext<UserContextType | undefined>(undefined);

export function UserProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);

  const login = async (email: string, password: string): Promise<boolean> => {
    // Simulated login - in real app this would call an API
    if (email && password) {
      const mockUser: User = {
        id: "user-1",
        firstName: "Ahmet",
        lastName: "Yılmaz",
        email: email,
        phone: "0532 123 4567",
        mlmLevel: "Silver",
        totalSales: 15000,
        bonusEarnings: 2350,
      };
      setUser(mockUser);
      return true;
    }
    return false;
  };

  const logout = () => {
    setUser(null);
  };

  const register = async (
    userData: Partial<User> & { password: string },
  ): Promise<boolean> => {
    // Simulated registration
    if (userData.email && userData.password) {
      const newUser: User = {
        id: `user-${Date.now()}`,
        firstName: userData.firstName || "",
        lastName: userData.lastName || "",
        email: userData.email,
        phone: userData.phone,
        mlmLevel: "Bronze",
        totalSales: 0,
        bonusEarnings: 0,
      };
      setUser(newUser);
      return true;
    }
    return false;
  };

  return (
    <UserContext.Provider
      value={{
        user,
        isLoggedIn: !!user,
        login,
        logout,
        register,
      }}
    >
      {children}
    </UserContext.Provider>
  );
}

export function useUser() {
  const context = useContext(UserContext);
  if (context === undefined) {
    throw new Error("useUser must be used within a UserProvider");
  }
  return context;
}
