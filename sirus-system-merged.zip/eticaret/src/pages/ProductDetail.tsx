export function ProductDetail() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-4">Ürün Detayı</h1>
      <p>Bu sayfa yakında tamamlanacak...</p>
    </div>
  );
}

export function Checkout() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-4">Sipariş Ver</h1>
      <p>Bu sayfa yakında tamamlanacak...</p>
    </div>
  );
}

export function Admin() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-4">Admin Paneli</h1>
      <p>Bu sayfa yakında tamamlanacak...</p>
    </div>
  );
}

export function Category() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-4">Kategori</h1>
      <p>Bu sayfa yakında tamamlanacak...</p>
    </div>
  );
}

export function Login() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-4">Giriş Yap</h1>
      <p>Bu sayfa yakında tamamlanacak...</p>
    </div>
  );
}

export function MLMPanel() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-4">MLM Panel</h1>
      <p>Bu sayfa yakında tamamlanacak...</p>
    </div>
  );
}

export function Gelisim() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-4">Gelişim</h1>
      <p>Bu sayfa yakında tamamlanacak...</p>
    </div>
  );
}

export function MemberPanel() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-4">Üye Paneli</h1>
      <p>Bu sayfa yakında tamamlanacak...</p>
    </div>
  );
}

export function SellerPanel() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-4">Satıcı Paneli</h1>
      <p>Bu sayfa yakında tamamlanacak...</p>
    </div>
  );
}

export function About() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-4">Hakkımızda</h1>
      <p>Bu sayfa yakında tamamlanacak...</p>
    </div>
  );
}

export function Register() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-4">Üye Ol</h1>
      <p>Bu sayfa yakında tamamlanacak...</p>
    </div>
  );
}

export function Notifications() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-4">Bildirimler</h1>
      <p>Bu sayfa yakında tamamlanacak...</p>
    </div>
  );
}
