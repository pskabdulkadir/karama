import { HeroBanner } from "../components/HeroBanner";
import { ProductCard } from "../components/ProductCard";
import { CategoryCard } from "../components/CategoryCard";
import {
  sampleCategories,
  featuredProducts,
  discountedProducts,
} from "../constants/sampleData";
import { useUser } from "../auth/UserContext";
import { Button } from "../components/ui/button";
import { Gift, Star, Target } from "lucide-react";

export function Index() {
  const { user, isLoggedIn } = useUser();

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        {/* Hero Banner */}
        <HeroBanner />

        {/* Categories Section */}
        <section className="mt-16">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Kategoriler</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {sampleCategories.map((category) => (
              <CategoryCard key={category.id} category={category} />
            ))}
          </div>
        </section>

        {/* User-Specific Offers */}
        {isLoggedIn && (
          <section className="mt-16">
            <div className="bg-gradient-to-r from-mystical-purple to-purple-600 rounded-xl p-8 text-white">
              <div className="flex flex-col md:flex-row items-center justify-between">
                <div className="mb-6 md:mb-0">
                  <h2 className="text-2xl font-bold mb-2 flex items-center">
                    <Gift className="h-6 w-6 mr-2" />
                    Merhaba {user?.firstName}, Size Özel Teklifler!
                  </h2>
                  <p className="text-lg opacity-90">
                    Spiritüel yolculuğunuz için özel indirimler ve fırsatlar
                  </p>
                </div>
                <div className="flex flex-col sm:flex-row gap-3">
                  <Button variant="secondary" size="lg">
                    <Star className="h-4 w-4 mr-2" />
                    %15 Üye İndirimi
                  </Button>
                  <Button
                    variant="outline"
                    size="lg"
                    className="text-white border-white hover:bg-white hover:text-mystical-purple"
                  >
                    <Target className="h-4 w-4 mr-2" />
                    PDF Koleksiyonu
                  </Button>
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
                <div className="bg-white/10 rounded-lg p-4">
                  <h3 className="font-semibold mb-1">Dijital İçerikler</h3>
                  <p className="text-sm opacity-90">
                    PDF eğitimlerde %20 indirim
                  </p>
                </div>
                <div className="bg-white/10 rounded-lg p-4">
                  <h3 className="font-semibold mb-1">Ücretsiz Kargo</h3>
                  <p className="text-sm opacity-90">
                    200₺ ve üzeri alışverişlerde
                  </p>
                </div>
                <div className="bg-white/10 rounded-lg p-4">
                  <h3 className="font-semibold mb-1">Sadakat Puanları</h3>
                  <p className="text-sm opacity-90">
                    Her alışverişte puan kazanın
                  </p>
                </div>
              </div>
            </div>
          </section>
        )}

        {/* Featured Products */}
        <section className="mt-16">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">
            Öne Çıkan Ürünler
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {featuredProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </section>

        {/* Discounted Products */}
        <section className="mt-16">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">
            İndirimli Ürünler
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {discountedProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </section>

        {/* Newsletter Section */}
        <section className="mt-16 bg-primary/5 rounded-xl p-8 text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">
            Kampanyalardan Haberdar Olun
          </h2>
          <p className="text-gray-600 mb-6">
            Özel indirimler ve yeni ürünlerden ilk siz haberdar olun.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
            <input
              type="email"
              placeholder="E-posta adresiniz"
              className="flex-1 px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
            />
            <button className="px-6 py-2 bg-primary text-white rounded-lg hover:bg-primary/90 transition-colors">
              Abone Ol
            </button>
          </div>
        </section>
      </div>
    </div>
  );
}
