import { Product, Category } from "../../shared/ecommerce";

export const sampleCategories: Category[] = [
  {
    id: "1",
    name: "Kitaplar",
    slug: "kitaplar",
    image:
      "https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=400&h=300&fit=crop",
    productCount: 28,
  },
  {
    id: "2",
    name: "Tütsüler & Takılar",
    slug: "tutsular-takılar",
    image:
      "https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=400&h=300&fit=crop",
    productCount: 22,
  },
  {
    id: "3",
    name: "PDF Eğitimler",
    slug: "pdf-egitimler",
    image:
      "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=400&h=300&fit=crop",
    productCount: 15,
  },
  {
    id: "4",
    name: "Enerji Ürünleri",
    slug: "enerji-urunleri",
    image:
      "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400&h=300&fit=crop",
    productCount: 18,
  },
  {
    id: "5",
    name: "Ruhsal Setler",
    slug: "ruhsal-setler",
    image:
      "https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=400&h=300&fit=crop",
    productCount: 12,
  },
];

export const sampleProducts: Product[] = [
  {
    id: "1",
    name: "Spiritüel Gelişim Kitabı",
    description: "Ruhsal uyanış ve içsel gelişim için kapsamlı rehber kitap.",
    price: 85,
    originalPrice: 120,
    images: [
      "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=400&h=400&fit=crop",
    ],
    category: "kitaplar",
    stock: 25,
    featured: true,
    discount: 29,
    createdAt: "2024-01-15",
  },
  {
    id: "2",
    name: "Adaçayı Tütsü Seti",
    description: "Doğal adaçayı tütsü çubukları ve özel tutucu ile beraber.",
    price: 45,
    images: [
      "https://images.unsplash.com/photo-1585320806297-9794b3e4eeae?w=400&h=400&fit=crop",
    ],
    category: "tutsular-takılar",
    stock: 35,
    featured: true,
    createdAt: "2024-01-10",
  },
  {
    id: "3",
    name: "Çakra Balansı PDF Rehberi",
    description:
      "7 çakranızı dengelemek için detaylı egzersizler ve meditasyonlar (dijital).",
    price: 25,
    originalPrice: 35,
    images: [
      "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=400&h=400&fit=crop",
    ],
    category: "pdf-egitimler",
    stock: 999,
    featured: false,
    discount: 29,
    createdAt: "2024-01-12",
  },
  {
    id: "4",
    name: "Ametist Kristal Kolye",
    description: "Doğal ametist kristali ile yapılmış enerji kolyesi.",
    price: 150,
    images: [
      "https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=400&h=400&fit=crop",
    ],
    category: "tutsular-takılar",
    stock: 12,
    featured: true,
    createdAt: "2024-01-08",
  },
  {
    id: "5",
    name: "Himalaya Tuz Lambası",
    description: "Doğal Himalaya tuz kristalinden yapılmış enerji lambası.",
    price: 180,
    originalPrice: 220,
    images: [
      "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400&h=400&fit=crop",
    ],
    category: "enerji-urunleri",
    stock: 8,
    featured: false,
    discount: 18,
    createdAt: "2024-01-05",
  },
  {
    id: "6",
    name: "Meditasyon PDF Koleksiyonu",
    description: "20 farklı meditasyon tekniği ve rehberi (dijital download).",
    price: 50,
    images: [
      "https://images.unsplash.com/photo-1434030216411-0b793f4b4173?w=400&h=400&fit=crop",
    ],
    category: "pdf-egitimler",
    stock: 999,
    featured: true,
    createdAt: "2024-01-14",
  },
  {
    id: "7",
    name: "Tam Ruhsal Temizlik Seti",
    description:
      "Sage, palo santo, kristaller ve ritual araçları içeren kapsamlı set.",
    price: 350,
    images: [
      "https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=400&h=400&fit=crop",
    ],
    category: "ruhsal-setler",
    stock: 6,
    featured: true,
    createdAt: "2024-01-06",
  },
  {
    id: "8",
    name: "Selenit Temizlik Değneği",
    description:
      "Negatif enerjiyi temizlemek için doğal selenit kristal değnek.",
    price: 75,
    images: [
      "https://images.unsplash.com/photo-1618172193622-ae2d025f4032?w=400&h=400&fit=crop",
    ],
    category: "enerji-urunleri",
    stock: 20,
    featured: false,
    createdAt: "2024-01-03",
  },
  {
    id: "9",
    name: "Tarot Rehberi Kitabı",
    description: "Başlangıçtan ileri seviyeye tarot okuma teknikleri.",
    price: 95,
    originalPrice: 125,
    images: [
      "https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=400&h=400&fit=crop",
    ],
    category: "kitaplar",
    stock: 15,
    featured: false,
    discount: 24,
    createdAt: "2024-01-01",
  },
  {
    id: "10",
    name: "Başlangıç Ruhsal Gelişim Seti",
    description: "Yeni başlayanlar için kristal, tütsü ve rehber kitap seti.",
    price: 199,
    originalPrice: 250,
    images: [
      "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop",
    ],
    category: "ruhsal-setler",
    stock: 10,
    featured: true,
    discount: 20,
    createdAt: "2024-01-02",
  },
];

export const featuredProducts = sampleProducts.filter(
  (product) => product.featured,
);
export const discountedProducts = sampleProducts.filter(
  (product) => product.discount && product.discount > 0,
);
