import { Link, useLocation } from "react-router-dom";
import { ShoppingCart, Menu } from "lucide-react";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { useCart } from "../services/CartContext";
import { useUser } from "../auth/UserContext";

const guestLinks = [
  { name: "Ana Sayfa", href: "/" },
  { name: "Hakkımızda", href: "/about" },
  { name: "Giriş", href: "/login" },
  { name: "Üye Ol", href: "/register" },
];

const userLinks = [
  { name: "Profilim", href: "/member-panel" },
  { name: "Bildirimler", href: "/notifications" },
];

export function Header() {
  const location = useLocation();
  const { getTotalItems } = useCart();
  const { user, isLoggedIn, logout } = useUser();
  const totalItems = getTotalItems();

  return (
    <header className="bg-white shadow-md border-b sticky top-0 z-50">
      <div className="container mx-auto px-4">
        {/* Main navigation bar */}
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-2">
            <div className="text-3xl lg:text-4xl font-mystical font-bold text-mystical-purple">
              Kutbul Zaman
            </div>
          </Link>

          {/* Navigation Links */}
          <nav className="hidden md:flex items-center space-x-8">
            {!isLoggedIn ? (
              // Guest navigation
              guestLinks.map((link) => (
                <Link
                  key={link.name}
                  to={link.href}
                  className={`text-sm font-medium transition-colors hover:text-mystical-purple ${
                    location.pathname === link.href
                      ? "text-mystical-purple font-semibold"
                      : "text-gray-700"
                  }`}
                >
                  {link.name}
                </Link>
              ))
            ) : (
              // User navigation
              <>
                <Link
                  to="/"
                  className={`text-sm font-medium transition-colors hover:text-mystical-purple ${
                    location.pathname === "/"
                      ? "text-mystical-purple font-semibold"
                      : "text-gray-700"
                  }`}
                >
                  Ana Sayfa
                </Link>
                {userLinks.map((link) => (
                  <Link
                    key={link.name}
                    to={link.href}
                    className={`text-sm font-medium transition-colors hover:text-mystical-purple ${
                      location.pathname === link.href
                        ? "text-mystical-purple font-semibold"
                        : "text-gray-700"
                    }`}
                  >
                    {link.name}
                  </Link>
                ))}
                <button
                  onClick={logout}
                  className="text-sm font-medium text-gray-700 hover:text-mystical-purple transition-colors"
                >
                  Çıkış
                </button>
              </>
            )}
          </nav>

          {/* Cart and Mobile Menu */}
          <div className="flex items-center space-x-3">
            {/* Cart */}
            <Link to="/cart">
              <Button
                variant="outline"
                size="sm"
                className="flex items-center space-x-2 border-mystical-teal text-mystical-teal hover:bg-mystical-teal hover:text-white rounded-xl transition-all duration-200"
              >
                <ShoppingCart className="h-4 w-4" />
                <span className="hidden sm:inline">Sepetim</span>
                {totalItems > 0 && (
                  <Badge className="ml-1 bg-mystical-teal text-white hover:bg-mystical-teal">
                    {totalItems}
                  </Badge>
                )}
              </Button>
            </Link>

            {/* Mobile Menu Button */}
            <Button variant="ghost" size="icon" className="md:hidden">
              <Menu className="h-5 w-5" />
            </Button>
          </div>
        </div>

        {/* Mobile Navigation Menu */}
        <div className="md:hidden border-t py-4">
          <nav className="flex flex-col space-y-3">
            {!isLoggedIn ? (
              guestLinks.map((link) => (
                <Link
                  key={link.name}
                  to={link.href}
                  className={`text-sm font-medium transition-colors hover:text-mystical-purple ${
                    location.pathname === link.href
                      ? "text-mystical-purple font-semibold"
                      : "text-gray-700"
                  }`}
                >
                  {link.name}
                </Link>
              ))
            ) : (
              <>
                <Link
                  to="/"
                  className={`text-sm font-medium transition-colors hover:text-mystical-purple ${
                    location.pathname === "/"
                      ? "text-mystical-purple font-semibold"
                      : "text-gray-700"
                  }`}
                >
                  Ana Sayfa
                </Link>
                {userLinks.map((link) => (
                  <Link
                    key={link.name}
                    to={link.href}
                    className={`text-sm font-medium transition-colors hover:text-mystical-purple ${
                      location.pathname === link.href
                        ? "text-mystical-purple font-semibold"
                        : "text-gray-700"
                    }`}
                  >
                    {link.name}
                  </Link>
                ))}
                <button
                  onClick={logout}
                  className="text-sm font-medium text-gray-700 hover:text-mystical-purple transition-colors text-left"
                >
                  Çıkış
                </button>
              </>
            )}
          </nav>
        </div>
      </div>
    </header>
  );
}
