import { Heart, ShoppingCart } from "lucide-react";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Product } from "../../shared/ecommerce";
import { Link } from "react-router-dom";
import { useCart } from "../services/CartContext";

interface ProductCardProps {
  product: Product;
}

export function ProductCard({ product }: ProductCardProps) {
  const hasDiscount = product.discount && product.discount > 0;
  const { addToCart } = useCart();

  const handleAddToCart = () => {
    addToCart(product);
  };

  return (
    <div className="group bg-white rounded-xl border border-gray-100 shadow-sm hover:shadow-md transition-all duration-200 overflow-hidden">
      <div className="relative">
        <Link to={`/product/${product.id}`}>
          <img
            src={product.images[0]}
            alt={product.name}
            className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
          />
        </Link>

        {hasDiscount && (
          <Badge className="absolute top-2 left-2 bg-red-500 hover:bg-red-500">
            -{product.discount}%
          </Badge>
        )}

        <Button
          variant="ghost"
          size="icon"
          className="absolute top-2 right-2 bg-white/80 hover:bg-white"
        >
          <Heart className="h-4 w-4" />
        </Button>
      </div>

      <div className="p-4">
        <Link to={`/product/${product.id}`}>
          <h3 className="font-semibold text-gray-900 mb-2 group-hover:text-primary transition-colors line-clamp-2">
            {product.name}
          </h3>
        </Link>

        <p className="text-sm text-gray-600 mb-3 line-clamp-2">
          {product.description}
        </p>

        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <span className="text-lg font-bold text-primary">
              ₺{product.price}
            </span>
            {hasDiscount && product.originalPrice && (
              <span className="text-sm text-gray-500 line-through">
                ₺{product.originalPrice}
              </span>
            )}
          </div>

          <Button
            size="sm"
            className="flex items-center space-x-1"
            onClick={handleAddToCart}
          >
            <ShoppingCart className="h-4 w-4" />
            <span className="hidden sm:inline">Sepete Ekle</span>
          </Button>
        </div>

        {product.stock < 5 && (
          <p className="text-xs text-red-600 mt-2">
            Sadece {product.stock} adet kaldı!
          </p>
        )}
      </div>
    </div>
  );
}
