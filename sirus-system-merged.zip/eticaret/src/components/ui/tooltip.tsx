import { ReactNode } from "react";

// Placeholder TooltipProvider component
export function TooltipProvider({ children }: { children: ReactNode }) {
  return <>{children}</>;
}
