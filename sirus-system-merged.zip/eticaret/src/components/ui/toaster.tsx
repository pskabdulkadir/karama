// Placeholder Toaster component
export function Toaster() {
  return null;
}
