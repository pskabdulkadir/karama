// Placeholder Sonner component
export function Toaster() {
  return null;
}
