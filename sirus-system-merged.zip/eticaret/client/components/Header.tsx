import { Link, useLocation } from "react-router-dom";
import { ShoppingCart, Menu } from "lucide-react";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { useCart } from "../contexts/CartContext";
import { useAuth } from "../contexts/AuthContext";
import { getRoleDisplayName, getRoleBadgeColor } from "../utils/roleUtils";

const guestLinks = [
  { name: "Ana Sayfa", href: "/" },
  { name: "Alışveriş", href: "/shop" },
  { name: "Portal", href: "/portal" },
  { name: "Hakkımızda", href: "/about" },
  { name: "Giriş", href: "/login" },
  { name: "Üye Ol", href: "/register" },
];

const userLinks = [
  { name: "Panel", href: "/panel" },
  { name: "Bildirimler", href: "/panel/notifications" },
];

export function Header() {
  const location = useLocation();
  const { getTotalItems } = useCart();
  const { user, isAuthenticated, logout } = useAuth();
  const totalItems = getTotalItems();

  return (
    <header className="bg-white shadow-md border-b sticky top-0 z-50">
      <div className="container mx-auto px-4">
        {/* Main navigation bar */}
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-2">
            <div className="text-3xl lg:text-4xl font-bold text-navy">
              Kutbul Zaman
            </div>
          </Link>

          {/* Navigation Links */}
          <nav className="hidden md:flex items-center space-x-8">
            {!isAuthenticated ? (
              // Guest navigation
              guestLinks.map((link) => (
                <Link
                  key={link.name}
                  to={link.href}
                  className={`text-sm font-medium transition-colors hover:text-navy ${
                    location.pathname === link.href
                      ? "text-navy font-semibold"
                      : "text-gray-700"
                  }`}
                >
                  {link.name}
                </Link>
              ))
            ) : (
              // User navigation
              <>
                <Link
                  to="/"
                  className={`text-sm font-medium transition-colors hover:text-navy ${
                    location.pathname === "/"
                      ? "text-navy font-semibold"
                      : "text-gray-700"
                  }`}
                >
                  Ana Sayfa
                </Link>
                {userLinks.map((link) => (
                  <Link
                    key={link.name}
                    to={link.href}
                    className={`text-sm font-medium transition-colors hover:text-navy ${
                      location.pathname === link.href
                        ? "text-navy font-semibold"
                        : "text-gray-700"
                    }`}
                  >
                    {link.name}
                  </Link>
                ))}
                <div className="flex items-center space-x-3">
                  <span className="text-sm text-gray-600">{user?.name}</span>
                  <span
                    className={`px-2 py-1 text-xs rounded-full ${getRoleBadgeColor(user?.role || "guest")}`}
                  >
                    {getRoleDisplayName(user?.role || "guest")}
                  </span>
                  <button
                    onClick={logout}
                    className="text-sm font-medium text-gray-700 hover:text-navy transition-colors"
                  >
                    Çıkış
                  </button>
                </div>
              </>
            )}
          </nav>

          {/* Cart and Mobile Menu */}
          <div className="flex items-center space-x-3">
            {/* Cart */}
            <Link to="/shop/cart">
              <Button
                variant="outline"
                size="sm"
                className="flex items-center space-x-2 border-gold text-gold hover:bg-gold hover:text-navy hover:text-white rounded-xl transition-all duration-200"
              >
                <ShoppingCart className="h-4 w-4" />
                <span className="hidden sm:inline">Sepetim</span>
                {totalItems > 0 && (
                  <Badge className="ml-1 bg-gold text-navy hover:bg-gold-600">
                    {totalItems}
                  </Badge>
                )}
              </Button>
            </Link>

            {/* Mobile Menu Button */}
            <Button variant="ghost" size="icon" className="md:hidden">
              <Menu className="h-5 w-5" />
            </Button>
          </div>
        </div>

        {/* Mobile Navigation Menu */}
        <div className="md:hidden border-t py-4">
          <nav className="flex flex-col space-y-3">
            {!isAuthenticated ? (
              guestLinks.map((link) => (
                <Link
                  key={link.name}
                  to={link.href}
                  className={`text-sm font-medium transition-colors hover:text-navy ${
                    location.pathname === link.href
                      ? "text-navy font-semibold"
                      : "text-gray-700"
                  }`}
                >
                  {link.name}
                </Link>
              ))
            ) : (
              <>
                <Link
                  to="/"
                  className={`text-sm font-medium transition-colors hover:text-navy ${
                    location.pathname === "/"
                      ? "text-navy font-semibold"
                      : "text-gray-700"
                  }`}
                >
                  Ana Sayfa
                </Link>
                {userLinks.map((link) => (
                  <Link
                    key={link.name}
                    to={link.href}
                    className={`text-sm font-medium transition-colors hover:text-navy ${
                      location.pathname === link.href
                        ? "text-navy font-semibold"
                        : "text-gray-700"
                    }`}
                  >
                    {link.name}
                  </Link>
                ))}
                <button
                  onClick={logout}
                  className="text-sm font-medium text-gray-700 hover:text-navy transition-colors text-left"
                >
                  Çıkış
                </button>
              </>
            )}
          </nav>
        </div>
      </div>
    </header>
  );
}
