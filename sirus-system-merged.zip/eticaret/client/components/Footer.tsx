import { Link } from "react-router-dom";
import {
  Phone,
  Mail,
  MapPin,
  Facebook,
  Instagram,
  Twitter,
  Youtube,
  Heart,
} from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand Section */}
          <div className="space-y-4">
            <h3 className="text-2xl font-bold text-primary">
              Kutbul Zaman Market
            </h3>
            <p className="text-gray-300 text-sm leading-relaxed">
              Spiritüel gelişim ve ruhsal yolculuğunuz için en kaliteli ürünleri
              sunuyoruz. İç huzur ve bilgelik arayışınızda yanınızdayız.
            </p>
            <div className="flex space-x-4">
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center hover:bg-blue-700 transition-colors"
              >
                <Facebook className="h-5 w-5" />
              </a>
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 bg-pink-600 rounded-full flex items-center justify-center hover:bg-pink-700 transition-colors"
              >
                <Instagram className="h-5 w-5" />
              </a>
              <a
                href="https://twitter.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 bg-blue-400 rounded-full flex items-center justify-center hover:bg-blue-500 transition-colors"
              >
                <Twitter className="h-5 w-5" />
              </a>
              <a
                href="https://youtube.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 bg-red-600 rounded-full flex items-center justify-center hover:bg-red-700 transition-colors"
              >
                <Youtube className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Hızlı Linkler</h4>
            <ul className="space-y-2">
              <li>
                <Link
                  to="/shop/category/kitaplar"
                  className="text-gray-300 hover:text-primary transition-colors text-sm"
                >
                  Kitaplar
                </Link>
              </li>
              <li>
                <Link
                  to="/shop/category/tutsular-takılar"
                  className="text-gray-300 hover:text-primary transition-colors text-sm"
                >
                  Tütsüler & Takılar
                </Link>
              </li>
              <li>
                <Link
                  to="/shop/category/pdf-egitimler"
                  className="text-gray-300 hover:text-primary transition-colors text-sm"
                >
                  PDF Eğitimler
                </Link>
              </li>
              <li>
                <Link
                  to="/shop/category/enerji-urunleri"
                  className="text-gray-300 hover:text-primary transition-colors text-sm"
                >
                  Enerji Ürünleri
                </Link>
              </li>
              <li>
                <Link
                  to="/shop/category/ruhsal-setler"
                  className="text-gray-300 hover:text-primary transition-colors text-sm"
                >
                  Ruhsal Setler
                </Link>
              </li>
            </ul>
          </div>

          {/* Customer Service */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Müşteri Hizmetleri</h4>
            <ul className="space-y-2">
              <li>
                <Link
                  to="/panel"
                  className="text-gray-300 hover:text-primary transition-colors text-sm"
                >
                  Üye Paneli
                </Link>
              </li>
              <li>
                <Link
                  to="/shop/cart"
                  className="text-gray-300 hover:text-primary transition-colors text-sm"
                >
                  Sepetim
                </Link>
              </li>
              <li>
                <a
                  href="#"
                  className="text-gray-300 hover:text-primary transition-colors text-sm"
                >
                  Sipariş Takibi
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-gray-300 hover:text-primary transition-colors text-sm"
                >
                  İade ve Değişim
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-gray-300 hover:text-primary transition-colors text-sm"
                >
                  Yardım ve Destek
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-gray-300 hover:text-primary transition-colors text-sm"
                >
                  SSS
                </a>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-lg font-semibold mb-4">İletişim</h4>
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <Phone className="h-5 w-5 text-primary" />
                <div>
                  <p className="text-sm text-gray-300">+90 532 123 45 67</p>
                  <p className="text-xs text-gray-400">Hafta içi 09:00-18:00</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="h-5 w-5 text-primary" />
                <div>
                  <p className="text-sm text-gray-300">
                    info@kutbulzamanmarket.com
                  </p>
                  <p className="text-xs text-gray-400">7/24 online destek</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <MapPin className="h-5 w-5 text-primary mt-0.5" />
                <div>
                  <p className="text-sm text-gray-300">
                    Atatürk Mahallesi
                    <br />
                    Spiritüel Caddesi No: 108
                    <br />
                    34100 Fatih / İstanbul
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="border-t border-gray-700 mt-8 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="text-sm text-gray-400 mb-4 md:mb-0">
              <p>
                © 2024 Kutbul Zaman Market. Tüm hakları saklıdır. |{" "}
                <a href="#" className="hover:text-primary transition-colors">
                  Gizlilik Politikası
                </a>{" "}
                |{" "}
                <a href="#" className="hover:text-primary transition-colors">
                  Kullanım Şartları
                </a>
              </p>
            </div>
            <div className="flex items-center text-sm text-gray-400">
              <span>Made with</span>
              <Heart className="h-4 w-4 text-red-500 mx-1" />
              <span>for spiritual growth</span>
            </div>
          </div>
        </div>

        {/* Additional Info */}
        <div className="mt-6 pt-6 border-t border-gray-700">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
            <div className="bg-gray-800 rounded-lg p-4">
              <h5 className="font-semibold text-primary mb-2">
                ✨ Güvenli Ödeme
              </h5>
              <p className="text-xs text-gray-400">
                256-bit SSL güvenliği ile korumalı ödeme sistemi
              </p>
            </div>
            <div className="bg-gray-800 rounded-lg p-4">
              <h5 className="font-semibold text-primary mb-2">
                🚚 Hızlı Kargo
              </h5>
              <p className="text-xs text-gray-400">
                24 saat içinde kargoya teslim, Türkiye geneli teslimat
              </p>
            </div>
            <div className="bg-gray-800 rounded-lg p-4">
              <h5 className="font-semibold text-primary mb-2">🔄 Kolay İade</h5>
              <p className="text-xs text-gray-400">
                14 gün içinde koşulsuz iade ve değişim hakkı
              </p>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
