import { ReactNode } from "react";
import { Navigate, useLocation } from "react-router-dom";
import { useAuth, UserRole } from "../contexts/AuthContext";
import { canAccessRoute, getRedirectPath } from "../utils/roleUtils";

interface ProtectedRouteProps {
  children: ReactNode;
  allowedRoles?: UserRole[];
  requiresAuth?: boolean;
  fallback?: ReactNode;
}

export function ProtectedRoute({
  children,
  allowedRoles,
  requiresAuth = false,
  fallback,
}: ProtectedRouteProps) {
  const { user, isAuthenticated, isLoading } = useAuth();
  const location = useLocation();

  // Show loading state while auth is being determined
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-navy"></div>
      </div>
    );
  }

  // Check authentication requirement
  if (requiresAuth && !isAuthenticated) {
    return <Navigate to="/login" state={{ from: location.pathname }} replace />;
  }

  // Check role access if roles are specified
  if (allowedRoles && allowedRoles.length > 0) {
    const userRole = user?.role || "guest";

    if (!allowedRoles.includes(userRole)) {
      // Show fallback component or redirect to home
      if (fallback) {
        return <>{fallback}</>;
      }

      return <Navigate to="/" replace />;
    }
  }

  // Check using route configuration
  const hasAccess = canAccessRoute(
    location.pathname,
    user?.role || null,
    isAuthenticated,
  );

  if (!hasAccess) {
    const redirectPath = getRedirectPath(
      location.pathname,
      user?.role || null,
      isAuthenticated,
    );

    if (redirectPath) {
      return (
        <Navigate
          to={redirectPath}
          state={{ from: location.pathname }}
          replace
        />
      );
    }

    // Show access denied page
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-navy mb-4">
            Erişim Reddedildi
          </h1>
          <p className="text-gray-600 mb-6">
            Bu sayfaya erişim yetkiniz bulunmamaktadır.
          </p>
          <button
            onClick={() => window.history.back()}
            className="px-6 py-2 bg-navy text-white rounded-xl hover:bg-navy-800 transition-colors"
          >
            Geri Dön
          </button>
        </div>
      </div>
    );
  }

  return <>{children}</>;
}

// Convenience components for common use cases
export function AdminRoute({ children }: { children: ReactNode }) {
  return (
    <ProtectedRoute allowedRoles={["admin"]} requiresAuth={true}>
      {children}
    </ProtectedRoute>
  );
}

export function MLMRoute({ children }: { children: ReactNode }) {
  return (
    <ProtectedRoute allowedRoles={["mlm", "admin"]} requiresAuth={true}>
      {children}
    </ProtectedRoute>
  );
}

export function MerchantRoute({ children }: { children: ReactNode }) {
  return (
    <ProtectedRoute allowedRoles={["merchant", "admin"]} requiresAuth={true}>
      {children}
    </ProtectedRoute>
  );
}

export function PsychologistRoute({ children }: { children: ReactNode }) {
  return (
    <ProtectedRoute
      allowedRoles={["psychologist", "admin"]}
      requiresAuth={true}
    >
      {children}
    </ProtectedRoute>
  );
}

export function AuthenticatedRoute({ children }: { children: ReactNode }) {
  return <ProtectedRoute requiresAuth={true}>{children}</ProtectedRoute>;
}

export function GuestOnlyRoute({ children }: { children: ReactNode }) {
  return <ProtectedRoute allowedRoles={["guest"]}>{children}</ProtectedRoute>;
}
