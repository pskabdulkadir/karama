import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  ReactNode,
} from "react";

export type UserRole = "user" | "admin" | "mlm" | "psychologist" | "merchant";
export type SystemType = "mlm" | "ecommerce" | "development" | "panel";

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  isActive: boolean;
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  currentSystem: SystemType;
  isLoading: boolean;
}

interface AuthContextType extends AuthState {
  login: (email: string, password: string) => Promise<boolean>;
  logout: () => void;
  register: (userData: RegisterData) => Promise<boolean>;
  updateUser: (userData: Partial<User>) => void;
  hasRole: (role: UserRole | UserRole[]) => boolean;
  hasPermission: (permission: string) => boolean;
  refreshToken: () => Promise<boolean>;
  setCurrentSystem: (system: SystemType) => void;
}

interface RegisterData {
  name: string;
  email: string;
  password: string;
  role?: UserRole;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Role hierarchy and permissions
const ROLE_HIERARCHY: Record<UserRole, number> = {
  user: 1,
  mlm: 2,
  psychologist: 3,
  merchant: 4,
  admin: 5,
};

const ROLE_PERMISSIONS: Record<UserRole, string[]> = {
  user: [
    "view_products",
    "view_categories",
    "purchase",
    "view_profile",
    "manage_cart",
  ],
  mlm: [
    "view_products",
    "view_categories",
    "purchase",
    "view_profile",
    "manage_cart",
    "view_mlm_dashboard",
    "manage_team",
    "view_commissions",
  ],
  psychologist: [
    "view_products",
    "view_categories",
    "purchase",
    "view_profile",
    "manage_cart",
    "view_psychology_content",
    "create_content",
    "manage_sessions",
  ],
  merchant: [
    "view_products",
    "view_categories",
    "purchase",
    "view_profile",
    "manage_cart",
    "manage_products",
    "view_sales",
    "manage_inventory",
    "view_analytics",
  ],
  admin: ["*"], // All permissions
};

export function AuthProvider({ children }: { children: ReactNode }) {
  const [authState, setAuthState] = useState<AuthState>({
    user: null,
    isAuthenticated: false,
    currentSystem:
      (import.meta.env.VITE_SYSTEM_MODE as SystemType) || "ecommerce",
    isLoading: true,
  });

  // Load user from localStorage on mount
  useEffect(() => {
    const loadStoredAuth = () => {
      try {
        const storedUser = localStorage.getItem("auth_user");
        const storedToken = localStorage.getItem("auth_token");
        const storedSystem = localStorage.getItem(
          "current_system",
        ) as SystemType;

        if (storedUser && storedToken) {
          const user: User = JSON.parse(storedUser);
          setAuthState({
            user,
            isAuthenticated: true,
            currentSystem:
              storedSystem ||
              (import.meta.env.VITE_SYSTEM_MODE as SystemType) ||
              "ecommerce",
            isLoading: false,
          });
          return;
        }
      } catch (error) {
        console.error("Error loading stored auth:", error);
        // Clear invalid stored data
        localStorage.removeItem("auth_user");
        localStorage.removeItem("auth_token");
        localStorage.removeItem("current_system");
      }

      setAuthState({
        user: null,
        isAuthenticated: false,
        currentSystem:
          (import.meta.env.VITE_SYSTEM_MODE as SystemType) || "ecommerce",
        isLoading: false,
      });
    };

    loadStoredAuth();
  }, []);

  const login = async (email: string, password: string): Promise<boolean> => {
    try {
      // Simulate API call - in real app this would call your backend
      const mockApiResponse = await simulateLogin(email, password);

      if (mockApiResponse.success) {
        const user: User = mockApiResponse.user;

        // Store in localStorage
        localStorage.setItem("auth_user", JSON.stringify(user));
        localStorage.setItem("auth_token", mockApiResponse.token);

        setAuthState((prev) => ({
          ...prev,
          user,
          isAuthenticated: true,
          isLoading: false,
        }));

        return true;
      }

      return false;
    } catch (error) {
      console.error("Login error:", error);
      return false;
    }
  };

  const logout = () => {
    // Clear localStorage
    localStorage.removeItem("auth_user");
    localStorage.removeItem("auth_token");
    localStorage.removeItem("current_system");

    setAuthState({
      user: null,
      isAuthenticated: false,
      currentSystem:
        (import.meta.env.VITE_SYSTEM_MODE as SystemType) || "ecommerce",
      isLoading: false,
    });
  };

  const register = async (userData: RegisterData): Promise<boolean> => {
    try {
      // Simulate API call
      const mockApiResponse = await simulateRegister(userData);

      if (mockApiResponse.success) {
        const user: User = mockApiResponse.user;

        // Store in localStorage
        localStorage.setItem("auth_user", JSON.stringify(user));
        localStorage.setItem("auth_token", mockApiResponse.token);

        setAuthState((prev) => ({
          ...prev,
          user,
          isAuthenticated: true,
          isLoading: false,
        }));

        return true;
      }

      return false;
    } catch (error) {
      console.error("Register error:", error);
      return false;
    }
  };

  const updateUser = (userData: Partial<User>) => {
    if (authState.user) {
      const updatedUser = { ...authState.user, ...userData };
      localStorage.setItem("auth_user", JSON.stringify(updatedUser));

      setAuthState((prev) => ({
        ...prev,
        user: updatedUser,
      }));
    }
  };

  const hasRole = (role: UserRole | UserRole[]): boolean => {
    if (!authState.user) return false;

    const userRole = authState.user.role;

    if (Array.isArray(role)) {
      return role.includes(userRole);
    }

    return userRole === role;
  };

  const hasPermission = (permission: string): boolean => {
    if (!authState.user) return false;

    const userRole = authState.user.role;
    const rolePermissions = ROLE_PERMISSIONS[userRole] || [];

    // Admin has all permissions
    if (rolePermissions.includes("*")) return true;

    return rolePermissions.includes(permission);
  };

  const refreshToken = async (): Promise<boolean> => {
    try {
      if (!authState.user) return false;

      // Simulate token refresh API call
      const newToken = generateMockToken();

      localStorage.setItem("auth_token", newToken);

      return true;
    } catch (error) {
      console.error("Token refresh error:", error);
      logout();
      return false;
    }
  };

  const setCurrentSystem = (system: SystemType) => {
    localStorage.setItem("current_system", system);
    setAuthState((prev) => ({
      ...prev,
      currentSystem: system,
    }));
  };

  return (
    <AuthContext.Provider
      value={{
        ...authState,
        login,
        logout,
        register,
        updateUser,
        hasRole,
        hasPermission,
        refreshToken,
        setCurrentSystem,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}

// Mock API functions (replace with real API calls)
async function simulateLogin(email: string, password: string) {
  // Simulate network delay
  await new Promise((resolve) => setTimeout(resolve, 1000));

  // Mock user database
  const mockUsers = [
    {
      email: "admin@kutbulzaman.com",
      password: "admin123",
      role: "admin" as UserRole,
      name: "Admin User",
    },
    {
      email: "user@kutbulzaman.com",
      password: "user123",
      role: "user" as UserRole,
      name: "Ahmet Yılmaz",
    },
    {
      email: "mlm@kutbulzaman.com",
      password: "mlm123",
      role: "mlm" as UserRole,
      name: "MLM Manager",
    },
    {
      email: "psychologist@kutbulzaman.com",
      password: "psy123",
      role: "psychologist" as UserRole,
      name: "Dr. Ayşe Demir",
    },
    {
      email: "merchant@kutbulzaman.com",
      password: "merchant123",
      role: "merchant" as UserRole,
      name: "Satıcı Ahmet",
    },
  ];

  const foundUser = mockUsers.find(
    (u) => u.email === email && u.password === password,
  );

  if (foundUser) {
    const user: User = {
      id: `user_${Date.now()}`,
      email: foundUser.email,
      name: foundUser.name,
      role: foundUser.role,
      isActive: true,
    };

    return { success: true, user, token: generateMockToken() };
  }

  return { success: false, error: "Invalid credentials" };
}

async function simulateRegister(userData: RegisterData) {
  // Simulate network delay
  await new Promise((resolve) => setTimeout(resolve, 1000));

  const user: User = {
    id: `user_${Date.now()}`,
    email: userData.email,
    name: userData.name,
    role: userData.role || "user", // Default role for new registrations
    isActive: true,
  };

  return { success: true, user, token: generateMockToken() };
}

function generateMockToken(): string {
  return `token_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}

// Helper function to get role level for comparisons
export function getRoleLevel(role: UserRole): number {
  return ROLE_HIERARCHY[role] || 0;
}

// Helper function to check if user has minimum role level
export function hasMinimumRole(
  userRole: UserRole,
  minimumRole: UserRole,
): boolean {
  return getRoleLevel(userRole) >= getRoleLevel(minimumRole);
}
