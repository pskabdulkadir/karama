const API_BASE = import.meta.env.VITE_API_URL || "https://api.kutbulzaman.com";

export const login = (email: string, password: string) =>
  fetch(`${API_BASE}/auth/login`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ email, password }),
  });

export const fetchUser = (token: string) =>
  fetch(`${API_BASE}/auth/me`, {
    headers: { Authorization: `Bearer ${token}` },
  });
