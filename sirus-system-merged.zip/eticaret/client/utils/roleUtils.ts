import { UserRole } from "../contexts/AuthContext";

// Route access configuration
export interface RouteConfig {
  path: string;
  allowedRoles: UserRole[];
  requiresAuth: boolean;
  redirectTo?: string;
}

// Define route access rules
export const ROUTE_ACCESS: RouteConfig[] = [
  // Public routes
  {
    path: "/",
    allowedRoles: ["guest", "user", "admin", "mlm", "psychologist", "merchant"],
    requiresAuth: false,
  },
  {
    path: "/about",
    allowedRoles: ["guest", "user", "admin", "mlm", "psychologist", "merchant"],
    requiresAuth: false,
  },
  {
    path: "/category/*",
    allowedRoles: ["guest", "user", "admin", "mlm", "psychologist", "merchant"],
    requiresAuth: false,
  },
  {
    path: "/product/*",
    allowedRoles: ["guest", "user", "admin", "mlm", "psychologist", "merchant"],
    requiresAuth: false,
  },
  {
    path: "/login",
    allowedRoles: ["guest"],
    requiresAuth: false,
    redirectTo: "/", // Redirect logged-in users
  },
  {
    path: "/register",
    allowedRoles: ["guest"],
    requiresAuth: false,
    redirectTo: "/", // Redirect logged-in users
  },

  // User routes
  {
    path: "/cart",
    allowedRoles: ["user", "admin", "mlm", "psychologist", "merchant"],
    requiresAuth: true,
    redirectTo: "/login",
  },
  {
    path: "/checkout",
    allowedRoles: ["user", "admin", "mlm", "psychologist", "merchant"],
    requiresAuth: true,
    redirectTo: "/login",
  },
  {
    path: "/member-panel",
    allowedRoles: ["user", "admin", "mlm", "psychologist", "merchant"],
    requiresAuth: true,
    redirectTo: "/login",
  },
  {
    path: "/notifications",
    allowedRoles: ["user", "admin", "mlm", "psychologist", "merchant"],
    requiresAuth: true,
    redirectTo: "/login",
  },

  // MLM specific routes
  {
    path: "/mlm",
    allowedRoles: ["mlm", "admin"],
    requiresAuth: true,
    redirectTo: "/login",
  },
  {
    path: "/gelisim",
    allowedRoles: ["mlm", "psychologist", "admin"],
    requiresAuth: true,
    redirectTo: "/login",
  },

  // Merchant routes
  {
    path: "/seller-panel",
    allowedRoles: ["merchant", "admin"],
    requiresAuth: true,
    redirectTo: "/login",
  },

  // Admin routes
  {
    path: "/admin",
    allowedRoles: ["admin"],
    requiresAuth: true,
    redirectTo: "/login",
  },
];

// Feature access control
export interface FeatureConfig {
  feature: string;
  allowedRoles: UserRole[];
  requiresAuth: boolean;
}

export const FEATURE_ACCESS: FeatureConfig[] = [
  {
    feature: "view_products",
    allowedRoles: ["guest", "user", "admin", "mlm", "psychologist", "merchant"],
    requiresAuth: false,
  },
  {
    feature: "purchase",
    allowedRoles: ["user", "admin", "mlm", "psychologist", "merchant"],
    requiresAuth: true,
  },
  {
    feature: "manage_cart",
    allowedRoles: ["user", "admin", "mlm", "psychologist", "merchant"],
    requiresAuth: true,
  },
  {
    feature: "view_mlm_dashboard",
    allowedRoles: ["mlm", "admin"],
    requiresAuth: true,
  },
  {
    feature: "manage_team",
    allowedRoles: ["mlm", "admin"],
    requiresAuth: true,
  },
  {
    feature: "view_commissions",
    allowedRoles: ["mlm", "admin"],
    requiresAuth: true,
  },
  {
    feature: "view_psychology_content",
    allowedRoles: ["psychologist", "admin"],
    requiresAuth: true,
  },
  {
    feature: "create_content",
    allowedRoles: ["psychologist", "admin"],
    requiresAuth: true,
  },
  {
    feature: "manage_sessions",
    allowedRoles: ["psychologist", "admin"],
    requiresAuth: true,
  },
  {
    feature: "manage_products",
    allowedRoles: ["merchant", "admin"],
    requiresAuth: true,
  },
  {
    feature: "view_sales",
    allowedRoles: ["merchant", "admin"],
    requiresAuth: true,
  },
  {
    feature: "manage_inventory",
    allowedRoles: ["merchant", "admin"],
    requiresAuth: true,
  },
  {
    feature: "view_analytics",
    allowedRoles: ["merchant", "admin"],
    requiresAuth: true,
  },
  {
    feature: "admin_panel",
    allowedRoles: ["admin"],
    requiresAuth: true,
  },
];

// Utility functions
export function canAccessRoute(
  path: string,
  userRole: UserRole | null,
  isAuthenticated: boolean,
): boolean {
  const routeConfig = ROUTE_ACCESS.find((route) =>
    path.match(new RegExp(`^${route.path.replace("*", ".*")}$`)),
  );

  if (!routeConfig) {
    // Default: allow access if no specific rule found
    return true;
  }

  // Check authentication requirement
  if (routeConfig.requiresAuth && !isAuthenticated) {
    return false;
  }

  // Check role access
  const effectiveRole = userRole || "guest";
  return routeConfig.allowedRoles.includes(effectiveRole);
}

export function canAccessFeature(
  feature: string,
  userRole: UserRole | null,
  isAuthenticated: boolean,
): boolean {
  const featureConfig = FEATURE_ACCESS.find((f) => f.feature === feature);

  if (!featureConfig) {
    return false;
  }

  // Check authentication requirement
  if (featureConfig.requiresAuth && !isAuthenticated) {
    return false;
  }

  // Check role access
  const effectiveRole = userRole || "guest";
  return featureConfig.allowedRoles.includes(effectiveRole);
}

export function getRedirectPath(
  path: string,
  userRole: UserRole | null,
  isAuthenticated: boolean,
): string | null {
  const routeConfig = ROUTE_ACCESS.find((route) =>
    path.match(new RegExp(`^${route.path.replace("*", ".*")}$`)),
  );

  if (!routeConfig) {
    return null;
  }

  // If user doesn't have access and there's a redirect defined
  if (!canAccessRoute(path, userRole, isAuthenticated)) {
    return routeConfig.redirectTo || "/";
  }

  // Special case: redirect authenticated users away from login/register
  if (isAuthenticated && routeConfig.redirectTo && !routeConfig.requiresAuth) {
    const effectiveRole = userRole || "guest";
    if (!routeConfig.allowedRoles.includes(effectiveRole)) {
      return routeConfig.redirectTo;
    }
  }

  return null;
}

// Role display helpers
export function getRoleDisplayName(role: UserRole): string {
  const roleNames: Record<UserRole, string> = {
    guest: "Misafir",
    user: "Kullanıcı",
    admin: "Yönetici",
    mlm: "MLM Üyesi",
    psychologist: "Psikolog",
    merchant: "Satıcı",
  };

  return roleNames[role] || role;
}

export function getRoleBadgeColor(role: UserRole): string {
  const colors: Record<UserRole, string> = {
    guest: "bg-gray-100 text-gray-800",
    user: "bg-blue-100 text-blue-800",
    admin: "bg-red-100 text-red-800",
    mlm: "bg-purple-100 text-purple-800",
    psychologist: "bg-green-100 text-green-800",
    merchant: "bg-orange-100 text-orange-800",
  };

  return colors[role] || "bg-gray-100 text-gray-800";
}
