import "./global.css";

import { Toaster } from "@/components/ui/toaster";
import { createRoot } from "react-dom/client";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { CartProvider } from "./contexts/CartContext";
import { AuthProvider } from "./contexts/AuthContext";
import { Header } from "./components/Header";
import { Footer } from "./components/Footer";
import {
  ProtectedRoute,
  AdminRoute,
  MLMRoute,
  MerchantRoute,
  AuthenticatedRoute,
  GuestOnlyRoute,
} from "./components/ProtectedRoute";
import Index from "./pages/Index";
import { ProductDetail } from "./pages/ProductDetail";
import { Cart } from "./pages/Cart";
import { Checkout } from "./pages/Checkout";
import { Admin } from "./pages/Admin";
import { Category } from "./pages/Category";
import { Login } from "./pages/Login";
import { MLMPanel } from "./pages/MLMPanel";
import { Gelisim } from "./pages/Gelisim";
import { MemberPanel } from "./pages/MemberPanel";
import { SellerPanel } from "./pages/SellerPanel";
import { About } from "./pages/About";
import { Register } from "./pages/Register";
import { Notifications } from "./pages/Notifications";
import { Portal } from "./pages/Portal";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <AuthProvider>
        <CartProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <div className="min-h-screen bg-white flex flex-col">
              <Header />
              <main className="flex-1 page-transition">
                <Routes>
                  <Route path="/" element={<Index />} />
                  <Route path="/about" element={<About />} />

                  {/* Portal - Central routing */}
                  <Route path="/portal" element={<Portal />} />

                  {/* Guest only routes */}
                  <Route
                    path="/login"
                    element={
                      <GuestOnlyRoute>
                        <Login />
                      </GuestOnlyRoute>
                    }
                  />
                  <Route
                    path="/register"
                    element={
                      <GuestOnlyRoute>
                        <Register />
                      </GuestOnlyRoute>
                    }
                  />

                  {/* Shop routes */}
                  <Route path="/shop" element={<Index />} />
                  <Route path="/shop/product/:id" element={<ProductDetail />} />
                  <Route
                    path="/shop/category/:category"
                    element={<Category />}
                  />
                  <Route
                    path="/shop/cart"
                    element={
                      <AuthenticatedRoute>
                        <Cart />
                      </AuthenticatedRoute>
                    }
                  />
                  <Route
                    path="/shop/checkout"
                    element={
                      <AuthenticatedRoute>
                        <Checkout />
                      </AuthenticatedRoute>
                    }
                  />

                  {/* Panel - User panel */}
                  <Route
                    path="/panel"
                    element={
                      <AuthenticatedRoute>
                        <MemberPanel />
                      </AuthenticatedRoute>
                    }
                  />
                  <Route
                    path="/panel/notifications"
                    element={
                      <AuthenticatedRoute>
                        <Notifications />
                      </AuthenticatedRoute>
                    }
                  />

                  {/* MLM - Network system */}
                  <Route
                    path="/mlm"
                    element={
                      <MLMRoute>
                        <MLMPanel />
                      </MLMRoute>
                    }
                  />

                  {/* Self - Personal development */}
                  <Route
                    path="/self"
                    element={
                      <ProtectedRoute
                        allowedRoles={["mlm", "psychologist", "admin"]}
                        requiresAuth={true}
                      >
                        <Gelisim />
                      </ProtectedRoute>
                    }
                  />

                  {/* Merchant routes under panel */}
                  <Route
                    path="/panel/seller"
                    element={
                      <MerchantRoute>
                        <SellerPanel />
                      </MerchantRoute>
                    }
                  />

                  {/* Admin routes */}
                  <Route
                    path="/admin"
                    element={
                      <AdminRoute>
                        <Admin />
                      </AdminRoute>
                    }
                  />

                  {/* Legacy route redirects */}
                  <Route path="/product/:id" element={<ProductDetail />} />
                  <Route path="/category/:category" element={<Category />} />
                  <Route path="/cart" element={<Cart />} />
                  <Route path="/checkout" element={<Checkout />} />
                  <Route path="/member-panel" element={<MemberPanel />} />
                  <Route path="/notifications" element={<Notifications />} />
                  <Route path="/gelisim" element={<Gelisim />} />
                  <Route path="/seller-panel" element={<SellerPanel />} />

                  <Route path="*" element={<NotFound />} />
                </Routes>
              </main>
              <Footer />
            </div>
          </BrowserRouter>
        </CartProvider>
      </AuthProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

createRoot(document.getElementById("root")!).render(<App />);
