import { useState } from "react";
import { Link } from "react-router-dom";
import {
  ArrowLeft,
  CreditCard,
  Building2,
  Shield,
  CheckCircle,
  Lock,
} from "lucide-react";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { sampleProducts } from "../data/sampleData";
import { CartItem, CustomerInfo, PaymentMethod } from "@shared/ecommerce";

// Sample cart data (would normally come from cart state/context)
const sampleCartItems: CartItem[] = [
  {
    product: sampleProducts[0],
    quantity: 2,
  },
  {
    product: sampleProducts[1],
    quantity: 1,
  },
];

export function Checkout() {
  const [step, setStep] = useState<"info" | "payment" | "confirmation">("info");
  const [customerInfo, setCustomerInfo] = useState<Partial<CustomerInfo>>({});
  const [paymentMethod, setPaymentMethod] =
    useState<PaymentMethod["type"]>("credit_card");
  const [isProcessing, setIsProcessing] = useState(false);

  const subtotal = sampleCartItems.reduce(
    (total, item) => total + item.product.price * item.quantity,
    0,
  );
  const shipping = subtotal > 500 ? 0 : 30;
  const total = subtotal + shipping;

  const handleCustomerInfoSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStep("payment");
  };

  const handlePaymentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 2000));

    setIsProcessing(false);
    setStep("confirmation");
  };

  if (step === "confirmation") {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="container mx-auto px-4 py-8">
          <div className="max-w-md mx-auto text-center py-16">
            <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-6" />
            <h1 className="text-2xl font-bold mb-4">Siparişiniz Alındı!</h1>
            <p className="text-gray-600 mb-6">
              Sipariş numaranız: <strong>#12345</strong>
            </p>
            <p className="text-gray-600 mb-8">
              Siparişinizin detaylarını e-posta adresinize gönderdik. En kısa
              sürede kargoya verilecektir.
            </p>
            <Link to="/">
              <Button size="lg">Ana Sayfaya Dön</Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-2xl font-bold">Sipariş Ver</h1>
          <Link
            to="/shop/cart"
            className="text-primary hover:underline flex items-center"
          >
            <ArrowLeft className="h-4 w-4 mr-1" />
            Sepete Dön
          </Link>
        </div>

        {/* Progress Steps */}
        <div className="flex items-center justify-center mb-8">
          <div className="flex items-center space-x-4">
            <div
              className={`flex items-center space-x-2 ${
                step === "info" ? "text-primary" : "text-green-600"
              }`}
            >
              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center text-white text-sm ${
                  step === "info"
                    ? "bg-primary"
                    : step === "payment"
                      ? "bg-green-600"
                      : "bg-green-600"
                }`}
              >
                {step === "info" ? "1" : "✓"}
              </div>
              <span className="hidden sm:inline">Bilgiler</span>
            </div>
            <div className="w-8 h-0.5 bg-gray-300"></div>
            <div
              className={`flex items-center space-x-2 ${
                step === "payment" ? "text-primary" : "text-gray-400"
              }`}
            >
              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center text-white text-sm ${
                  step === "payment" ? "bg-primary" : "bg-gray-300"
                }`}
              >
                2
              </div>
              <span className="hidden sm:inline">Ödeme</span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Form */}
          <div className="lg:col-span-2">
            {step === "info" && (
              <div className="bg-white rounded-xl border border-gray-100 p-6 shadow-sm">
                <h2 className="text-xl font-bold mb-6">
                  Teslimat ve İletişim Bilgileri
                </h2>
                <form onSubmit={handleCustomerInfoSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-2">
                        Ad *
                      </label>
                      <input
                        type="text"
                        required
                        className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                        value={customerInfo.firstName || ""}
                        onChange={(e) =>
                          setCustomerInfo({
                            ...customerInfo,
                            firstName: e.target.value,
                          })
                        }
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">
                        Soyad *
                      </label>
                      <input
                        type="text"
                        required
                        className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                        value={customerInfo.lastName || ""}
                        onChange={(e) =>
                          setCustomerInfo({
                            ...customerInfo,
                            lastName: e.target.value,
                          })
                        }
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">
                      E-posta *
                    </label>
                    <input
                      type="email"
                      required
                      className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                      value={customerInfo.email || ""}
                      onChange={(e) =>
                        setCustomerInfo({
                          ...customerInfo,
                          email: e.target.value,
                        })
                      }
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">
                      Telefon *
                    </label>
                    <input
                      type="tel"
                      required
                      className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                      value={customerInfo.phone || ""}
                      onChange={(e) =>
                        setCustomerInfo({
                          ...customerInfo,
                          phone: e.target.value,
                        })
                      }
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">
                      Adres *
                    </label>
                    <textarea
                      required
                      rows={3}
                      className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                      value={customerInfo.address?.street || ""}
                      onChange={(e) =>
                        setCustomerInfo({
                          ...customerInfo,
                          address: {
                            ...customerInfo.address,
                            street: e.target.value,
                            city: customerInfo.address?.city || "",
                            state: customerInfo.address?.state || "",
                            zipCode: customerInfo.address?.zipCode || "",
                            country: customerInfo.address?.country || "Türkiye",
                          },
                        })
                      }
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-2">
                        Şehir *
                      </label>
                      <input
                        type="text"
                        required
                        className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                        value={customerInfo.address?.city || ""}
                        onChange={(e) =>
                          setCustomerInfo({
                            ...customerInfo,
                            address: {
                              ...customerInfo.address,
                              city: e.target.value,
                              street: customerInfo.address?.street || "",
                              state: customerInfo.address?.state || "",
                              zipCode: customerInfo.address?.zipCode || "",
                              country:
                                customerInfo.address?.country || "Türkiye",
                            },
                          })
                        }
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">
                        İlçe *
                      </label>
                      <input
                        type="text"
                        required
                        className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                        value={customerInfo.address?.state || ""}
                        onChange={(e) =>
                          setCustomerInfo({
                            ...customerInfo,
                            address: {
                              ...customerInfo.address,
                              state: e.target.value,
                              street: customerInfo.address?.street || "",
                              city: customerInfo.address?.city || "",
                              zipCode: customerInfo.address?.zipCode || "",
                              country:
                                customerInfo.address?.country || "Türkiye",
                            },
                          })
                        }
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">
                        Posta Kodu *
                      </label>
                      <input
                        type="text"
                        required
                        className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                        value={customerInfo.address?.zipCode || ""}
                        onChange={(e) =>
                          setCustomerInfo({
                            ...customerInfo,
                            address: {
                              ...customerInfo.address,
                              zipCode: e.target.value,
                              street: customerInfo.address?.street || "",
                              city: customerInfo.address?.city || "",
                              state: customerInfo.address?.state || "",
                              country:
                                customerInfo.address?.country || "Türkiye",
                            },
                          })
                        }
                      />
                    </div>
                  </div>

                  <Button type="submit" size="lg" className="w-full">
                    Ödeme Bilgilerine Geç
                  </Button>
                </form>
              </div>
            )}

            {step === "payment" && (
              <div className="bg-white rounded-xl border border-gray-100 p-6 shadow-sm">
                <h2 className="text-xl font-bold mb-6">Ödeme Yöntemi</h2>

                <div className="space-y-4 mb-6">
                  <div
                    className={`border rounded-lg p-4 cursor-pointer transition-colors ${
                      paymentMethod === "credit_card"
                        ? "border-primary bg-primary/5"
                        : "border-gray-200"
                    }`}
                    onClick={() => setPaymentMethod("credit_card")}
                  >
                    <div className="flex items-center space-x-3">
                      <CreditCard className="h-5 w-5 text-primary" />
                      <span className="font-medium">Kredi Kartı</span>
                      <Badge variant="secondary">Güvenli</Badge>
                    </div>
                  </div>

                  <div
                    className={`border rounded-lg p-4 cursor-pointer transition-colors ${
                      paymentMethod === "bank_transfer"
                        ? "border-primary bg-primary/5"
                        : "border-gray-200"
                    }`}
                    onClick={() => setPaymentMethod("bank_transfer")}
                  >
                    <div className="flex items-center space-x-3">
                      <Building2 className="h-5 w-5 text-primary" />
                      <span className="font-medium">Havale/EFT</span>
                    </div>
                  </div>
                </div>

                <form onSubmit={handlePaymentSubmit}>
                  {paymentMethod === "credit_card" && (
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium mb-2">
                          Kart Numarası *
                        </label>
                        <input
                          type="text"
                          placeholder="1234 5678 9012 3456"
                          required
                          className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium mb-2">
                            Son Kullanma *
                          </label>
                          <input
                            type="text"
                            placeholder="MM/YY"
                            required
                            className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium mb-2">
                            CVV *
                          </label>
                          <input
                            type="text"
                            placeholder="123"
                            required
                            className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-sm font-medium mb-2">
                          Kart Üzerindeki İsim *
                        </label>
                        <input
                          type="text"
                          required
                          className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                        />
                      </div>
                    </div>
                  )}

                  {paymentMethod === "bank_transfer" && (
                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                      <h3 className="font-semibold mb-2">Havale Bilgileri</h3>
                      <div className="text-sm space-y-1">
                        <p>
                          <strong>Banka:</strong> Türkiye İş Bankası
                        </p>
                        <p>
                          <strong>IBAN:</strong> TR12 0006 4000 0011 2345 6789
                          01
                        </p>
                        <p>
                          <strong>Hesap Sahibi:</strong> MarketPlace A.Ş.
                        </p>
                        <p className="text-gray-600 mt-2">
                          Havale açıklamasına sipariş numaranızı yazınız.
                        </p>
                      </div>
                    </div>
                  )}

                  <div className="flex space-x-4 mt-6">
                    <Button
                      type="button"
                      variant="outline"
                      size="lg"
                      onClick={() => setStep("info")}
                      className="flex-1"
                    >
                      Geri
                    </Button>
                    <Button
                      type="submit"
                      size="lg"
                      className="flex-1"
                      disabled={isProcessing}
                    >
                      {isProcessing ? (
                        <>
                          <div className="animate-spin h-4 w-4 border-2 border-white border-t-transparent rounded-full mr-2"></div>
                          İşleniyor...
                        </>
                      ) : (
                        "Siparişi Onayla"
                      )}
                    </Button>
                  </div>
                </form>
              </div>
            )}
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl border border-gray-100 p-6 shadow-sm sticky top-4">
              <h2 className="text-xl font-bold mb-4">Sipariş Özeti</h2>

              <div className="space-y-4 mb-6">
                {sampleCartItems.map((item) => (
                  <div key={item.product.id} className="flex space-x-3">
                    <img
                      src={item.product.images[0]}
                      alt={item.product.name}
                      className="w-12 h-12 object-cover rounded-lg"
                    />
                    <div className="flex-1 min-w-0">
                      <h4 className="text-sm font-medium line-clamp-2">
                        {item.product.name}
                      </h4>
                      <p className="text-sm text-gray-600">
                        {item.quantity} x ₺{item.product.price}
                      </p>
                    </div>
                    <span className="text-sm font-semibold">
                      ₺{(item.product.price * item.quantity).toLocaleString()}
                    </span>
                  </div>
                ))}
              </div>

              <div className="space-y-2 text-sm border-t pt-4">
                <div className="flex justify-between">
                  <span>Ara Toplam</span>
                  <span>₺{subtotal.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span>Kargo</span>
                  <span>{shipping === 0 ? "Ücretsiz" : `₺${shipping}`}</span>
                </div>
                <div className="flex justify-between text-lg font-bold pt-2 border-t">
                  <span>Toplam</span>
                  <span className="text-primary">
                    ₺{total.toLocaleString()}
                  </span>
                </div>
              </div>

              <div className="mt-6 pt-4 border-t">
                <div className="flex items-center space-x-2 text-sm text-gray-600">
                  <Shield className="h-4 w-4 text-green-500" />
                  <span>SSL ile korumalı ödeme</span>
                </div>
                <div className="flex items-center space-x-2 text-sm text-gray-600 mt-1">
                  <Lock className="h-4 w-4 text-green-500" />
                  <span>Güvenli veri aktarımı</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
