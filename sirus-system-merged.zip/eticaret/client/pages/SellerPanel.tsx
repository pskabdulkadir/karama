import { useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import {
  Plus,
  Package,
  Edit,
  Trash2,
  BarChart3,
  DollarSign,
  TrendingUp,
  Users,
  ArrowLeft,
  Upload,
} from "lucide-react";
import { sampleProducts } from "../data/sampleData";
import { Product } from "@shared/ecommerce";

type SellerTab = "overview" | "products" | "add-product" | "analytics";

export function SellerPanel() {
  const { user, isAuthenticated } = useAuth();
  const [activeTab, setActiveTab] = useState<SellerTab>("overview");
  const [products, setProducts] = useState<Product[]>(sampleProducts);
  const [newProduct, setNewProduct] = useState<Partial<Product>>({
    name: "",
    description: "",
    price: 0,
    originalPrice: 0,
    images: [""],
    category: "",
    stock: 0,
    featured: false,
    discount: 0,
  });

  // Check if user is a seller/dealer
  const isSeller = user?.mlmLevel === "Gold" || user?.mlmLevel === "Silver";

  if (!isAuthenticated || !isSeller) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="container mx-auto px-4 py-8">
          <div className="text-center py-16">
            <h1 className="text-2xl font-semibold mb-4">Satıcı Paneli</h1>
            <p className="text-gray-600 mb-6">
              {!isAuthenticated
                ? "Satıcı paneline erişim için giriş yapmanız gerekiyor."
                : "Bu panele erişim için satıcı yetkisine sahip olmanız gerekiyor."}
            </p>
            {!isAuthenticated ? (
              <Link to="/login">
                <Button size="lg">Giriş Yap</Button>
              </Link>
            ) : (
              <Link to="/panel">
                <Button size="lg">Üye Paneli</Button>
              </Link>
            )}
          </div>
        </div>
      </div>
    );
  }

  const handleAddProduct = (e: React.FormEvent) => {
    e.preventDefault();
    const product: Product = {
      ...newProduct,
      id: `prod-${Date.now()}`,
      createdAt: new Date().toISOString(),
    } as Product;

    setProducts([...products, product]);
    setNewProduct({
      name: "",
      description: "",
      price: 0,
      originalPrice: 0,
      images: [""],
      category: "",
      stock: 0,
      featured: false,
      discount: 0,
    });
    setActiveTab("products");
  };

  const handleDeleteProduct = (productId: string) => {
    setProducts(products.filter((p) => p.id !== productId));
  };

  const stats = {
    totalProducts: products.length,
    totalSales: 25680,
    monthlyRevenue: 5840,
    lowStockItems: products.filter((p) => p.stock < 5).length,
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold">Satıcı Paneli</h1>
            <p className="text-gray-600">
              Merhaba {user?.name}, ürünlerinizi yönetin
            </p>
          </div>
          <Link to="/">
            <Button variant="outline">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Market
            </Button>
          </Link>
        </div>

        {/* Navigation Tabs */}
        <div className="flex space-x-1 bg-white rounded-lg p-1 mb-8 border">
          {[
            { id: "overview", label: "Genel Bakış", icon: BarChart3 },
            { id: "products", label: "Ürünlerim", icon: Package },
            { id: "add-product", label: "Ürün Ekle", icon: Plus },
            { id: "analytics", label: "Analitik", icon: TrendingUp },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as SellerTab)}
              className={`flex items-center space-x-2 px-4 py-2 rounded-md transition-colors ${
                activeTab === tab.id
                  ? "bg-primary text-white"
                  : "text-gray-600 hover:text-gray-900"
              }`}
            >
              <tab.icon className="h-4 w-4" />
              <span>{tab.label}</span>
            </button>
          ))}
        </div>

        {/* Overview Tab */}
        {activeTab === "overview" && (
          <div className="space-y-6">
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-white rounded-xl border border-gray-100 p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Toplam Ürün</p>
                    <p className="text-2xl font-bold">{stats.totalProducts}</p>
                  </div>
                  <Package className="h-8 w-8 text-blue-500" />
                </div>
              </div>

              <div className="bg-white rounded-xl border border-gray-100 p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Toplam Satış</p>
                    <p className="text-2xl font-bold">
                      ₺{stats.totalSales.toLocaleString()}
                    </p>
                  </div>
                  <DollarSign className="h-8 w-8 text-green-500" />
                </div>
              </div>

              <div className="bg-white rounded-xl border border-gray-100 p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Aylık Gelir</p>
                    <p className="text-2xl font-bold">
                      ₺{stats.monthlyRevenue.toLocaleString()}
                    </p>
                  </div>
                  <TrendingUp className="h-8 w-8 text-purple-500" />
                </div>
              </div>

              <div className="bg-white rounded-xl border border-gray-100 p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Düşük Stok</p>
                    <p className="text-2xl font-bold text-red-600">
                      {stats.lowStockItems}
                    </p>
                  </div>
                  <Package className="h-8 w-8 text-red-500" />
                </div>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="bg-white rounded-xl border border-gray-100 p-6">
              <h2 className="text-xl font-bold mb-4">Hızlı İşlemler</h2>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <Button
                  onClick={() => setActiveTab("add-product")}
                  className="h-16 flex-col"
                >
                  <Plus className="h-6 w-6 mb-1" />
                  Yeni Ürün Ekle
                </Button>
                <Button
                  variant="outline"
                  onClick={() => setActiveTab("products")}
                  className="h-16 flex-col"
                >
                  <Package className="h-6 w-6 mb-1" />
                  Stok Güncelle
                </Button>
                <Button
                  variant="outline"
                  onClick={() => setActiveTab("analytics")}
                  className="h-16 flex-col"
                >
                  <BarChart3 className="h-6 w-6 mb-1" />
                  Raporlar Görüntüle
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Products Tab */}
        {activeTab === "products" && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-bold">Ürünlerim</h2>
              <Button onClick={() => setActiveTab("add-product")}>
                <Plus className="h-4 w-4 mr-2" />
                Yeni Ürün Ekle
              </Button>
            </div>

            <div className="bg-white rounded-xl border border-gray-100 overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="text-left py-4 px-6">Ürün</th>
                      <th className="text-left py-4 px-6">Kategori</th>
                      <th className="text-left py-4 px-6">Fiyat</th>
                      <th className="text-left py-4 px-6">Stok</th>
                      <th className="text-left py-4 px-6">Durum</th>
                      <th className="text-left py-4 px-6">İşlemler</th>
                    </tr>
                  </thead>
                  <tbody>
                    {products.map((product) => (
                      <tr key={product.id} className="border-b">
                        <td className="py-4 px-6">
                          <div className="flex items-center space-x-3">
                            <img
                              src={product.images[0]}
                              alt={product.name}
                              className="w-10 h-10 object-cover rounded-lg"
                            />
                            <div>
                              <div className="font-medium">{product.name}</div>
                              <div className="text-sm text-gray-600">
                                {product.description.slice(0, 50)}...
                              </div>
                            </div>
                          </div>
                        </td>
                        <td className="py-4 px-6 capitalize">
                          {product.category}
                        </td>
                        <td className="py-4 px-6">₺{product.price}</td>
                        <td className="py-4 px-6">
                          <span
                            className={product.stock < 5 ? "text-red-600" : ""}
                          >
                            {product.stock}
                          </span>
                        </td>
                        <td className="py-4 px-6">
                          {product.featured && (
                            <Badge variant="secondary">Öne Çıkan</Badge>
                          )}
                          {product.discount && product.discount > 0 && (
                            <Badge variant="destructive" className="ml-1">
                              İndirimli
                            </Badge>
                          )}
                        </td>
                        <td className="py-4 px-6">
                          <div className="flex space-x-2">
                            <Button variant="ghost" size="icon">
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleDeleteProduct(product.id)}
                              className="text-red-600 hover:text-red-700"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Add Product Tab */}
        {activeTab === "add-product" && (
          <div className="bg-white rounded-xl border border-gray-100 p-6">
            <h2 className="text-xl font-bold mb-6">Yeni Ürün Ekle</h2>
            <form onSubmit={handleAddProduct} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium mb-2">
                    Ürün Adı *
                  </label>
                  <input
                    type="text"
                    required
                    className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                    value={newProduct.name}
                    onChange={(e) =>
                      setNewProduct({ ...newProduct, name: e.target.value })
                    }
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">
                    Kategori *
                  </label>
                  <select
                    required
                    className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                    value={newProduct.category}
                    onChange={(e) =>
                      setNewProduct({ ...newProduct, category: e.target.value })
                    }
                  >
                    <option value="">Kategori Seçin</option>
                    <option value="kitaplar">Kitaplar</option>
                    <option value="tutsular-takılar">Tütsüler & Takılar</option>
                    <option value="pdf-egitimler">PDF Eğitimler</option>
                    <option value="enerji-urunleri">Enerji Ürünleri</option>
                    <option value="ruhsal-setler">Ruhsal Setler</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">
                    Fiyat (₺) *
                  </label>
                  <input
                    type="number"
                    required
                    min="0"
                    step="0.01"
                    className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                    value={newProduct.price}
                    onChange={(e) =>
                      setNewProduct({
                        ...newProduct,
                        price: Number(e.target.value),
                      })
                    }
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">
                    Eski Fiyat (₺)
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                    value={newProduct.originalPrice}
                    onChange={(e) =>
                      setNewProduct({
                        ...newProduct,
                        originalPrice: Number(e.target.value),
                      })
                    }
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">
                    Stok Adedi *
                  </label>
                  <input
                    type="number"
                    required
                    min="0"
                    className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                    value={newProduct.stock}
                    onChange={(e) =>
                      setNewProduct({
                        ...newProduct,
                        stock: Number(e.target.value),
                      })
                    }
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">
                    İndirim (%)
                  </label>
                  <input
                    type="number"
                    min="0"
                    max="100"
                    className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                    value={newProduct.discount}
                    onChange={(e) =>
                      setNewProduct({
                        ...newProduct,
                        discount: Number(e.target.value),
                      })
                    }
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">
                  Ürün Açıklaması *
                </label>
                <textarea
                  required
                  rows={4}
                  className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                  value={newProduct.description}
                  onChange={(e) =>
                    setNewProduct({
                      ...newProduct,
                      description: e.target.value,
                    })
                  }
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">
                  Ürün Görseli URL *
                </label>
                <input
                  type="url"
                  required
                  className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                  value={newProduct.images?.[0] || ""}
                  onChange={(e) =>
                    setNewProduct({
                      ...newProduct,
                      images: [e.target.value],
                    })
                  }
                />
              </div>

              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="featured"
                  checked={newProduct.featured}
                  onChange={(e) =>
                    setNewProduct({
                      ...newProduct,
                      featured: e.target.checked,
                    })
                  }
                  className="rounded border-gray-300 focus:ring-primary"
                />
                <label htmlFor="featured" className="text-sm font-medium">
                  Öne çıkan ürün
                </label>
              </div>

              <div className="flex space-x-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setActiveTab("products")}
                >
                  İptal
                </Button>
                <Button type="submit">Ürün Ekle</Button>
              </div>
            </form>
          </div>
        )}

        {/* Analytics Tab */}
        {activeTab === "analytics" && (
          <div className="space-y-6">
            <h2 className="text-xl font-bold">Satış Analitikleri</h2>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-white rounded-xl border border-gray-100 p-6">
                <h3 className="text-lg font-semibold mb-4">
                  En Çok Satan Ürünler
                </h3>
                <div className="space-y-3">
                  {products.slice(0, 5).map((product, index) => (
                    <div
                      key={product.id}
                      className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
                    >
                      <div className="flex items-center space-x-3">
                        <span className="w-6 h-6 bg-primary text-white rounded-full flex items-center justify-center text-sm">
                          {index + 1}
                        </span>
                        <span className="font-medium">{product.name}</span>
                      </div>
                      <span className="text-sm text-gray-600">
                        {Math.floor(Math.random() * 50) + 10} adet
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-white rounded-xl border border-gray-100 p-6">
                <h3 className="text-lg font-semibold mb-4">
                  Kategori Performansı
                </h3>
                <div className="space-y-3">
                  {[
                    { category: "Kitaplar", sales: 45, revenue: 3200 },
                    { category: "Ruhsal Setler", sales: 23, revenue: 4500 },
                    {
                      category: "Tütsüler & Takılar",
                      sales: 67,
                      revenue: 2100,
                    },
                    { category: "PDF Eğitimler", sales: 89, revenue: 1800 },
                    { category: "Enerji Ürünleri", sales: 34, revenue: 2400 },
                  ].map((item) => (
                    <div
                      key={item.category}
                      className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
                    >
                      <span className="font-medium">{item.category}</span>
                      <div className="text-right">
                        <p className="text-sm font-medium">
                          ₺{item.revenue.toLocaleString()}
                        </p>
                        <p className="text-xs text-gray-600">
                          {item.sales} satış
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
