import { useParams } from "react-router-dom";

export function Category() {
  const { category } = useParams();

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="text-center py-16">
        <h1 className="text-2xl font-semibold mb-4 capitalize">
          {category} Kategorisi
        </h1>
        <p className="text-gray-600">Bu sayfa yakında tamamlanacak</p>
      </div>
    </div>
  );
}
