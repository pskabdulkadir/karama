import { useState } from "react";
import {
  Plus,
  Edit,
  Trash2,
  Package,
  ShoppingCart,
  TrendingUp,
  DollarSign,
  Search,
  Filter,
  Eye,
  Calendar,
} from "lucide-react";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { sampleProducts } from "../data/sampleData";
import { Product, Order } from "@shared/ecommerce";

// Sample orders data
const sampleOrders: Order[] = [
  {
    id: "ORD-001",
    customerId: "cust-1",
    items: [
      { product: sampleProducts[0], quantity: 2 },
      { product: sampleProducts[1], quantity: 1 },
    ],
    customerInfo: {
      firstName: "Ahmet",
      lastName: "Yılmaz",
      email: "ahmet@example.com",
      phone: "0532 123 4567",
      address: {
        street: "Atatürk Cad. No: 123",
        city: "İstanbul",
        state: "Beşiktaş",
        zipCode: "34357",
        country: "Türkiye",
      },
    },
    paymentMethod: { type: "credit_card" },
    total: 797,
    status: "pending",
    createdAt: "2024-01-15T10:30:00Z",
    updatedAt: "2024-01-15T10:30:00Z",
  },
  {
    id: "ORD-002",
    customerId: "cust-2",
    items: [{ product: sampleProducts[2], quantity: 5 }],
    customerInfo: {
      firstName: "Fatma",
      lastName: "Demir",
      email: "fatma@example.com",
      phone: "0533 987 6543",
      address: {
        street: "İnönü Sok. No: 45",
        city: "Ankara",
        state: "Çankaya",
        zipCode: "06100",
        country: "Türkiye",
      },
    },
    paymentMethod: { type: "bank_transfer" },
    total: 445,
    status: "confirmed",
    createdAt: "2024-01-14T15:45:00Z",
    updatedAt: "2024-01-14T16:00:00Z",
  },
  {
    id: "ORD-003",
    customerId: "cust-3",
    items: [{ product: sampleProducts[4], quantity: 1 }],
    customerInfo: {
      firstName: "Mehmet",
      lastName: "Kaya",
      email: "mehmet@example.com",
      phone: "0534 555 7890",
      address: {
        street: "Cumhuriyet Bulv. No: 78",
        city: "İzmir",
        state: "Konak",
        zipCode: "35220",
        country: "Türkiye",
      },
    },
    paymentMethod: { type: "credit_card" },
    total: 350,
    status: "shipped",
    createdAt: "2024-01-13T09:15:00Z",
    updatedAt: "2024-01-13T14:30:00Z",
  },
];

type AdminTab = "overview" | "products" | "orders" | "add-product";

export function Admin() {
  const [activeTab, setActiveTab] = useState<AdminTab>("overview");
  const [products, setProducts] = useState<Product[]>(sampleProducts);
  const [orders, setOrders] = useState<Order[]>(sampleOrders);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  // New product form state
  const [newProduct, setNewProduct] = useState<Partial<Product>>({
    name: "",
    description: "",
    price: 0,
    originalPrice: 0,
    images: [""],
    category: "",
    stock: 0,
    featured: false,
    discount: 0,
  });

  const handleDeleteProduct = (productId: string) => {
    setProducts(products.filter((p) => p.id !== productId));
  };

  const handleUpdateOrderStatus = (
    orderId: string,
    status: Order["status"],
  ) => {
    setOrders(
      orders.map((order) =>
        order.id === orderId
          ? { ...order, status, updatedAt: new Date().toISOString() }
          : order,
      ),
    );
  };

  const handleAddProduct = (e: React.FormEvent) => {
    e.preventDefault();
    const product: Product = {
      ...newProduct,
      id: `prod-${Date.now()}`,
      createdAt: new Date().toISOString(),
    } as Product;

    setProducts([...products, product]);
    setNewProduct({
      name: "",
      description: "",
      price: 0,
      originalPrice: 0,
      images: [""],
      category: "",
      stock: 0,
      featured: false,
      discount: 0,
    });
    setActiveTab("products");
  };

  const getStatusColor = (status: Order["status"]) => {
    switch (status) {
      case "pending":
        return "bg-yellow-100 text-yellow-800";
      case "confirmed":
        return "bg-blue-100 text-blue-800";
      case "shipped":
        return "bg-purple-100 text-purple-800";
      case "delivered":
        return "bg-green-100 text-green-800";
      case "cancelled":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getStatusText = (status: Order["status"]) => {
    switch (status) {
      case "pending":
        return "Bekliyor";
      case "confirmed":
        return "Onaylandı";
      case "shipped":
        return "Kargoda";
      case "delivered":
        return "Teslim Edildi";
      case "cancelled":
        return "İptal Edildi";
      default:
        return status;
    }
  };

  const stats = {
    totalOrders: orders.length,
    totalRevenue: orders.reduce((sum, order) => sum + order.total, 0),
    totalProducts: products.length,
    pendingOrders: orders.filter((o) => o.status === "pending").length,
  };

  const filteredProducts = products.filter((product) =>
    product.name.toLowerCase().includes(searchTerm.toLowerCase()),
  );

  const filteredOrders = orders.filter(
    (order) =>
      order.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.customerInfo.firstName
        .toLowerCase()
        .includes(searchTerm.toLowerCase()) ||
      order.customerInfo.lastName
        .toLowerCase()
        .includes(searchTerm.toLowerCase()),
  );

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-bold">Admin Paneli</h1>
          <Button onClick={() => setActiveTab("add-product")}>
            <Plus className="h-4 w-4 mr-2" />
            Yeni Ürün Ekle
          </Button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex space-x-1 bg-white rounded-lg p-1 mb-8 border">
          {[
            { id: "overview", label: "Genel Bakış", icon: TrendingUp },
            { id: "products", label: "Ürünler", icon: Package },
            { id: "orders", label: "Siparişler", icon: ShoppingCart },
            { id: "add-product", label: "Ürün Ekle", icon: Plus },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as AdminTab)}
              className={`flex items-center space-x-2 px-4 py-2 rounded-md transition-colors ${
                activeTab === tab.id
                  ? "bg-primary text-white"
                  : "text-gray-600 hover:text-gray-900"
              }`}
            >
              <tab.icon className="h-4 w-4" />
              <span>{tab.label}</span>
            </button>
          ))}
        </div>

        {/* Overview Tab */}
        {activeTab === "overview" && (
          <div className="space-y-6">
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-white rounded-xl border border-gray-100 p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Toplam Sipariş</p>
                    <p className="text-2xl font-bold">{stats.totalOrders}</p>
                  </div>
                  <ShoppingCart className="h-8 w-8 text-blue-500" />
                </div>
              </div>

              <div className="bg-white rounded-xl border border-gray-100 p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Toplam Gelir</p>
                    <p className="text-2xl font-bold">
                      ₺{stats.totalRevenue.toLocaleString()}
                    </p>
                  </div>
                  <DollarSign className="h-8 w-8 text-green-500" />
                </div>
              </div>

              <div className="bg-white rounded-xl border border-gray-100 p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Toplam Ürün</p>
                    <p className="text-2xl font-bold">{stats.totalProducts}</p>
                  </div>
                  <Package className="h-8 w-8 text-purple-500" />
                </div>
              </div>

              <div className="bg-white rounded-xl border border-gray-100 p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Bekleyen Sipariş</p>
                    <p className="text-2xl font-bold">{stats.pendingOrders}</p>
                  </div>
                  <Calendar className="h-8 w-8 text-orange-500" />
                </div>
              </div>
            </div>

            {/* Recent Orders */}
            <div className="bg-white rounded-xl border border-gray-100 p-6">
              <h2 className="text-xl font-bold mb-4">Son Siparişler</h2>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-2">Sipariş No</th>
                      <th className="text-left py-2">Müşteri</th>
                      <th className="text-left py-2">Tutar</th>
                      <th className="text-left py-2">Durum</th>
                      <th className="text-left py-2">Tarih</th>
                    </tr>
                  </thead>
                  <tbody>
                    {orders.slice(0, 5).map((order) => (
                      <tr key={order.id} className="border-b">
                        <td className="py-2 font-medium">{order.id}</td>
                        <td className="py-2">
                          {order.customerInfo.firstName}{" "}
                          {order.customerInfo.lastName}
                        </td>
                        <td className="py-2">
                          ₺{order.total.toLocaleString()}
                        </td>
                        <td className="py-2">
                          <Badge
                            className={`${getStatusColor(order.status)} hover:${getStatusColor(order.status)}`}
                          >
                            {getStatusText(order.status)}
                          </Badge>
                        </td>
                        <td className="py-2">
                          {new Date(order.createdAt).toLocaleDateString(
                            "tr-TR",
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Products Tab */}
        {activeTab === "products" && (
          <div className="space-y-6">
            {/* Search */}
            <div className="bg-white rounded-xl border border-gray-100 p-6">
              <div className="flex items-center space-x-4">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Ürün ara..."
                    className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
                <Button variant="outline">
                  <Filter className="h-4 w-4 mr-2" />
                  Filtrele
                </Button>
              </div>
            </div>

            {/* Products List */}
            <div className="bg-white rounded-xl border border-gray-100 overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="text-left py-4 px-6">Ürün</th>
                      <th className="text-left py-4 px-6">Kategori</th>
                      <th className="text-left py-4 px-6">Fiyat</th>
                      <th className="text-left py-4 px-6">Stok</th>
                      <th className="text-left py-4 px-6">Durum</th>
                      <th className="text-left py-4 px-6">İşlemler</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredProducts.map((product) => (
                      <tr key={product.id} className="border-b">
                        <td className="py-4 px-6">
                          <div className="flex items-center space-x-3">
                            <img
                              src={product.images[0]}
                              alt={product.name}
                              className="w-10 h-10 object-cover rounded-lg"
                            />
                            <div>
                              <div className="font-medium">{product.name}</div>
                              <div className="text-sm text-gray-600">
                                {product.description.slice(0, 50)}...
                              </div>
                            </div>
                          </div>
                        </td>
                        <td className="py-4 px-6 capitalize">
                          {product.category}
                        </td>
                        <td className="py-4 px-6">₺{product.price}</td>
                        <td className="py-4 px-6">
                          <span
                            className={product.stock < 5 ? "text-red-600" : ""}
                          >
                            {product.stock}
                          </span>
                        </td>
                        <td className="py-4 px-6">
                          {product.featured && (
                            <Badge variant="secondary">Öne Çıkan</Badge>
                          )}
                          {product.discount && product.discount > 0 && (
                            <Badge variant="destructive" className="ml-1">
                              İndirimli
                            </Badge>
                          )}
                        </td>
                        <td className="py-4 px-6">
                          <div className="flex space-x-2">
                            <Button variant="ghost" size="icon">
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleDeleteProduct(product.id)}
                              className="text-red-600 hover:text-red-700"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Orders Tab */}
        {activeTab === "orders" && (
          <div className="space-y-6">
            {/* Search */}
            <div className="bg-white rounded-xl border border-gray-100 p-6">
              <div className="flex items-center space-x-4">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Sipariş ara..."
                    className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
              </div>
            </div>

            {/* Orders List */}
            <div className="bg-white rounded-xl border border-gray-100 overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="text-left py-4 px-6">Sipariş No</th>
                      <th className="text-left py-4 px-6">Müşteri</th>
                      <th className="text-left py-4 px-6">Ürünler</th>
                      <th className="text-left py-4 px-6">Tutar</th>
                      <th className="text-left py-4 px-6">Durum</th>
                      <th className="text-left py-4 px-6">Tarih</th>
                      <th className="text-left py-4 px-6">İşlemler</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredOrders.map((order) => (
                      <tr key={order.id} className="border-b">
                        <td className="py-4 px-6 font-medium">{order.id}</td>
                        <td className="py-4 px-6">
                          <div>
                            <div className="font-medium">
                              {order.customerInfo.firstName}{" "}
                              {order.customerInfo.lastName}
                            </div>
                            <div className="text-sm text-gray-600">
                              {order.customerInfo.email}
                            </div>
                          </div>
                        </td>
                        <td className="py-4 px-6">
                          <div className="text-sm">
                            {order.items.map((item, index) => (
                              <div key={index}>
                                {item.quantity}x {item.product.name}
                              </div>
                            ))}
                          </div>
                        </td>
                        <td className="py-4 px-6 font-medium">
                          ₺{order.total.toLocaleString()}
                        </td>
                        <td className="py-4 px-6">
                          <select
                            value={order.status}
                            onChange={(e) =>
                              handleUpdateOrderStatus(
                                order.id,
                                e.target.value as Order["status"],
                              )
                            }
                            className={`px-2 py-1 rounded text-xs font-medium border-0 ${getStatusColor(order.status)}`}
                          >
                            <option value="pending">Bekliyor</option>
                            <option value="confirmed">Onaylandı</option>
                            <option value="shipped">Kargoda</option>
                            <option value="delivered">Teslim Edildi</option>
                            <option value="cancelled">İptal Edildi</option>
                          </select>
                        </td>
                        <td className="py-4 px-6">
                          {new Date(order.createdAt).toLocaleDateString(
                            "tr-TR",
                          )}
                        </td>
                        <td className="py-4 px-6">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => setSelectedOrder(order)}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Add Product Tab */}
        {activeTab === "add-product" && (
          <div className="bg-white rounded-xl border border-gray-100 p-6">
            <h2 className="text-xl font-bold mb-6">Yeni Ürün Ekle</h2>
            <form onSubmit={handleAddProduct} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium mb-2">
                    Ürün Adı *
                  </label>
                  <input
                    type="text"
                    required
                    className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                    value={newProduct.name}
                    onChange={(e) =>
                      setNewProduct({ ...newProduct, name: e.target.value })
                    }
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">
                    Kategori *
                  </label>
                  <select
                    required
                    className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                    value={newProduct.category}
                    onChange={(e) =>
                      setNewProduct({ ...newProduct, category: e.target.value })
                    }
                  >
                    <option value="">Kategori Seçin</option>
                    <option value="kozmetik">Kozmetik</option>
                    <option value="gida">Gıda</option>
                    <option value="spirituel">Spiritüel</option>
                    <option value="kitap">Kitap</option>
                    <option value="taki">Takı</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">
                    Fiyat (₺) *
                  </label>
                  <input
                    type="number"
                    required
                    min="0"
                    step="0.01"
                    className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                    value={newProduct.price}
                    onChange={(e) =>
                      setNewProduct({
                        ...newProduct,
                        price: Number(e.target.value),
                      })
                    }
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">
                    Eski Fiyat (₺)
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                    value={newProduct.originalPrice}
                    onChange={(e) =>
                      setNewProduct({
                        ...newProduct,
                        originalPrice: Number(e.target.value),
                      })
                    }
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">
                    Stok Adedi *
                  </label>
                  <input
                    type="number"
                    required
                    min="0"
                    className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                    value={newProduct.stock}
                    onChange={(e) =>
                      setNewProduct({
                        ...newProduct,
                        stock: Number(e.target.value),
                      })
                    }
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">
                    İndirim (%)
                  </label>
                  <input
                    type="number"
                    min="0"
                    max="100"
                    className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                    value={newProduct.discount}
                    onChange={(e) =>
                      setNewProduct({
                        ...newProduct,
                        discount: Number(e.target.value),
                      })
                    }
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">
                  Ürün Açıklaması *
                </label>
                <textarea
                  required
                  rows={4}
                  className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                  value={newProduct.description}
                  onChange={(e) =>
                    setNewProduct({
                      ...newProduct,
                      description: e.target.value,
                    })
                  }
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">
                  Ürün Görseli URL *
                </label>
                <input
                  type="url"
                  required
                  className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                  value={newProduct.images?.[0] || ""}
                  onChange={(e) =>
                    setNewProduct({
                      ...newProduct,
                      images: [e.target.value],
                    })
                  }
                />
              </div>

              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="featured"
                  checked={newProduct.featured}
                  onChange={(e) =>
                    setNewProduct({
                      ...newProduct,
                      featured: e.target.checked,
                    })
                  }
                  className="rounded border-gray-300 focus:ring-primary"
                />
                <label htmlFor="featured" className="text-sm font-medium">
                  Öne çıkan ürün
                </label>
              </div>

              <div className="flex space-x-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setActiveTab("products")}
                >
                  İptal
                </Button>
                <Button type="submit">Ürün Ekle</Button>
              </div>
            </form>
          </div>
        )}

        {/* Order Detail Modal */}
        {selectedOrder && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
              <div className="p-6 border-b">
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-bold">
                    Sipariş Detayı - {selectedOrder.id}
                  </h2>
                  <Button
                    variant="ghost"
                    onClick={() => setSelectedOrder(null)}
                  >
                    ✕
                  </Button>
                </div>
              </div>

              <div className="p-6 space-y-6">
                {/* Customer Info */}
                <div>
                  <h3 className="font-semibold mb-2">Müşteri Bilgileri</h3>
                  <div className="bg-gray-50 rounded-lg p-4">
                    <p>
                      <strong>Ad Soyad:</strong>{" "}
                      {selectedOrder.customerInfo.firstName}{" "}
                      {selectedOrder.customerInfo.lastName}
                    </p>
                    <p>
                      <strong>E-posta:</strong>{" "}
                      {selectedOrder.customerInfo.email}
                    </p>
                    <p>
                      <strong>Telefon:</strong>{" "}
                      {selectedOrder.customerInfo.phone}
                    </p>
                    <p>
                      <strong>Adres:</strong>{" "}
                      {selectedOrder.customerInfo.address.street},{" "}
                      {selectedOrder.customerInfo.address.state}/{" "}
                      {selectedOrder.customerInfo.address.city}
                    </p>
                  </div>
                </div>

                {/* Order Items */}
                <div>
                  <h3 className="font-semibold mb-2">Sipariş Ürünleri</h3>
                  <div className="space-y-2">
                    {selectedOrder.items.map((item, index) => (
                      <div
                        key={index}
                        className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
                      >
                        <div className="flex items-center space-x-3">
                          <img
                            src={item.product.images[0]}
                            alt={item.product.name}
                            className="w-12 h-12 object-cover rounded-lg"
                          />
                          <div>
                            <p className="font-medium">{item.product.name}</p>
                            <p className="text-sm text-gray-600">
                              {item.quantity} x ₺{item.product.price}
                            </p>
                          </div>
                        </div>
                        <p className="font-semibold">
                          ₺
                          {(
                            item.product.price * item.quantity
                          ).toLocaleString()}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Order Total */}
                <div className="border-t pt-4">
                  <div className="flex justify-between text-lg font-bold">
                    <span>Toplam Tutar:</span>
                    <span className="text-primary">
                      ₺{selectedOrder.total.toLocaleString()}
                    </span>
                  </div>
                </div>

                {/* Payment Method */}
                <div>
                  <h3 className="font-semibold mb-2">Ödeme Yöntemi</h3>
                  <p className="capitalize">
                    {selectedOrder.paymentMethod.type === "credit_card"
                      ? "Kredi Kartı"
                      : "Havale/EFT"}
                  </p>
                </div>

                {/* Status */}
                <div>
                  <h3 className="font-semibold mb-2">Sipariş Durumu</h3>
                  <Badge
                    className={`${getStatusColor(selectedOrder.status)} hover:${getStatusColor(selectedOrder.status)}`}
                  >
                    {getStatusText(selectedOrder.status)}
                  </Badge>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
