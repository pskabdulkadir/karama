import { Link } from "react-router-dom";
import { Button } from "../components/ui/button";
import {
  BookOpen,
  Video,
  Users,
  Calendar,
  Award,
  Target,
  ArrowLeft,
  Clock,
  Star,
} from "lucide-react";

const courses = [
  {
    id: 1,
    title: "Kişisel Gelişim Temelleri",
    description:
      "Yaşamınızda pozitif değişiklikler yaratmanın temel prensipleri",
    duration: "4 hafta",
    level: "Başlangıç",
    rating: 4.8,
    price: 199,
    image:
      "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&h=200&fit=crop",
  },
  {
    id: 2,
    title: "Ruhsal Gelişim ve Maneviyat",
    description: "İç huzur ve ruhsal denge için manevi pratikler",
    duration: "6 hafta",
    level: "Orta",
    rating: 4.9,
    price: 299,
    image:
      "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=300&h=200&fit=crop",
  },
  {
    id: 3,
    title: "Liderlik ve İletişim",
    description: "Etkili liderlik ve iletişim becerilerini geliştirin",
    duration: "8 hafta",
    level: "İleri",
    rating: 4.7,
    price: 399,
    image:
      "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=300&h=200&fit=crop",
  },
  {
    id: 4,
    title: "MLM Başarı Stratejileri",
    description: "Network marketing'de başarılı olmak için stratejiler",
    duration: "5 hafta",
    level: "Orta",
    rating: 4.6,
    price: 249,
    image:
      "https://images.unsplash.com/photo-1542744173-8e7e53415bb0?w=300&h=200&fit=crop",
  },
];

const webinars = [
  {
    id: 1,
    title: "Günlük Motivasyon ve Hedef Belirleme",
    date: "15 Ocak 2024",
    time: "20:00",
    speaker: "Dr. Mehmet Yılmaz",
  },
  {
    id: 2,
    title: "Stres Yönetimi ve İç Huzur",
    date: "22 Ocak 2024",
    time: "19:30",
    speaker: "Prof. Ayşe Kaya",
  },
  {
    id: 3,
    title: "MLM'de Etik Satış Teknikleri",
    date: "29 Ocak 2024",
    time: "20:30",
    speaker: "Uzman Fatma Demir",
  },
];

export function Gelisim() {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold">Gelişim Sayfası</h1>
            <p className="text-gray-600">
              Kişisel ve ruhsal gelişiminiz için eğitim programları
            </p>
          </div>
          <Link to="/">
            <Button variant="outline">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Ana Sayfa
            </Button>
          </Link>
        </div>

        {/* Hero Section */}
        <div className="bg-gradient-to-r from-primary to-purple-600 rounded-xl p-8 mb-12 text-white">
          <div className="max-w-2xl">
            <h2 className="text-2xl md:text-3xl font-bold mb-4">
              Kendinizi Geliştirin, Hayatınızı Dönüştürün
            </h2>
            <p className="text-lg opacity-90 mb-6">
              Uzman eğitmenlerimizle kişisel gelişim, maneviyat ve liderlik
              alanlarında kendinizi geliştirin. MLM kariyerinizde de başarıya
              ulaşın.
            </p>
            <Button size="lg" variant="secondary">
              <BookOpen className="h-5 w-5 mr-2" />
              Kurslara Göz Atın
            </Button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
          <div className="bg-white rounded-xl border border-gray-100 p-6 text-center">
            <BookOpen className="h-8 w-8 text-primary mx-auto mb-2" />
            <p className="text-2xl font-bold">50+</p>
            <p className="text-sm text-gray-600">Eğitim Kursu</p>
          </div>
          <div className="bg-white rounded-xl border border-gray-100 p-6 text-center">
            <Users className="h-8 w-8 text-green-500 mx-auto mb-2" />
            <p className="text-2xl font-bold">1,200+</p>
            <p className="text-sm text-gray-600">Aktif Öğrenci</p>
          </div>
          <div className="bg-white rounded-xl border border-gray-100 p-6 text-center">
            <Award className="h-8 w-8 text-yellow-500 mx-auto mb-2" />
            <p className="text-2xl font-bold">95%</p>
            <p className="text-sm text-gray-600">Başarı Oranı</p>
          </div>
          <div className="bg-white rounded-xl border border-gray-100 p-6 text-center">
            <Target className="h-8 w-8 text-purple-500 mx-auto mb-2" />
            <p className="text-2xl font-bold">24/7</p>
            <p className="text-sm text-gray-600">Destek</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Courses */}
          <div className="lg:col-span-2">
            <h2 className="text-2xl font-bold mb-6">Popüler Kurslar</h2>
            <div className="space-y-6">
              {courses.map((course) => (
                <div
                  key={course.id}
                  className="bg-white rounded-xl border border-gray-100 p-6 hover:shadow-md transition-shadow"
                >
                  <div className="flex flex-col md:flex-row gap-4">
                    <img
                      src={course.image}
                      alt={course.title}
                      className="w-full md:w-48 h-32 object-cover rounded-lg"
                    />
                    <div className="flex-1">
                      <div className="flex items-start justify-between mb-2">
                        <h3 className="text-lg font-semibold">
                          {course.title}
                        </h3>
                        <span className="text-xl font-bold text-primary">
                          ₺{course.price}
                        </span>
                      </div>
                      <p className="text-gray-600 text-sm mb-3">
                        {course.description}
                      </p>
                      <div className="flex items-center gap-4 text-sm text-gray-500 mb-4">
                        <span className="flex items-center">
                          <Clock className="h-4 w-4 mr-1" />
                          {course.duration}
                        </span>
                        <span className="flex items-center">
                          <Target className="h-4 w-4 mr-1" />
                          {course.level}
                        </span>
                        <span className="flex items-center">
                          <Star className="h-4 w-4 mr-1 text-yellow-500" />
                          {course.rating}
                        </span>
                      </div>
                      <Button size="sm">Kursa Katıl</Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Upcoming Webinars */}
            <div className="bg-white rounded-xl border border-gray-100 p-6">
              <h3 className="text-lg font-bold mb-4 flex items-center">
                <Video className="h-5 w-5 mr-2" />
                Yaklaşan Webinarlar
              </h3>
              <div className="space-y-4">
                {webinars.map((webinar) => (
                  <div
                    key={webinar.id}
                    className="border-l-4 border-primary pl-4"
                  >
                    <h4 className="font-medium text-sm">{webinar.title}</h4>
                    <p className="text-xs text-gray-600">{webinar.speaker}</p>
                    <div className="flex items-center text-xs text-gray-500 mt-1">
                      <Calendar className="h-3 w-3 mr-1" />
                      {webinar.date} - {webinar.time}
                    </div>
                  </div>
                ))}
              </div>
              <Button variant="outline" size="sm" className="w-full mt-4">
                Tüm Webinarları Gör
              </Button>
            </div>

            {/* Quick Links */}
            <div className="bg-white rounded-xl border border-gray-100 p-6">
              <h3 className="text-lg font-bold mb-4">Hızlı Erişim</h3>
              <div className="space-y-2">
                <Button
                  variant="ghost"
                  className="w-full justify-start"
                  size="sm"
                >
                  <BookOpen className="h-4 w-4 mr-2" />
                  Kurslarım
                </Button>
                <Button
                  variant="ghost"
                  className="w-full justify-start"
                  size="sm"
                >
                  <Award className="h-4 w-4 mr-2" />
                  Sertifikalarım
                </Button>
                <Button
                  variant="ghost"
                  className="w-full justify-start"
                  size="sm"
                >
                  <Target className="h-4 w-4 mr-2" />
                  Hedeflerim
                </Button>
                <Link to="/mlm" className="block">
                  <Button
                    variant="ghost"
                    className="w-full justify-start"
                    size="sm"
                  >
                    <Users className="h-4 w-4 mr-2" />
                    MLM Panel
                  </Button>
                </Link>
              </div>
            </div>

            {/* Progress Tracker */}
            <div className="bg-white rounded-xl border border-gray-100 p-6">
              <h3 className="text-lg font-bold mb-4">İlerleme Durumu</h3>
              <div className="space-y-3">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Tamamlanan Kurslar</span>
                    <span>3/5</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-primary h-2 rounded-full"
                      style={{ width: "60%" }}
                    ></div>
                  </div>
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Elde Edilen Sertifikalar</span>
                    <span>2</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-green-500 h-2 rounded-full"
                      style={{ width: "40%" }}
                    ></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
