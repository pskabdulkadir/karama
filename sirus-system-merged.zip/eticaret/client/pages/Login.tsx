import { useState } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { Button } from "../components/ui/button";
import { useAuth } from "../contexts/AuthContext";

export function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");
  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  // Get the page user was trying to access before login
  const from = (location.state as any)?.from || "/";

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError("");

    try {
      const success = await login(email, password);
      if (success) {
        // Redirect to the page they were trying to access, or home
        navigate(from, { replace: true });
      } else {
        setError("E-posta veya şifre hatalı");
      }
    } catch (err) {
      setError("Giriş sırasında bir hata oluştu");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8">
        <div>
          <h2 className="mt-6 text-center text-3xl font-bold text-navy">
            Kutbul Zaman
          </h2>
          <p className="mt-2 text-center text-sm text-gray-600">
            Spiritüel yolculuğunuza devam etmek için giriş yapın
          </p>
        </div>
        <div className="bg-white rounded-xl shadow-md p-8">
          <form className="space-y-6" onSubmit={handleSubmit}>
            <div>
              <label htmlFor="email" className="block text-sm font-medium mb-2">
                E-posta
              </label>
              <input
                id="email"
                name="email"
                type="email"
                autoComplete="email"
                required
                className="w-full px-3 py-2 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-navy/20 focus:border-navy"
                placeholder="E-posta adresiniz"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
            <div>
              <label
                htmlFor="password"
                className="block text-sm font-medium mb-2"
              >
                Şifre
              </label>
              <input
                id="password"
                name="password"
                type="password"
                autoComplete="current-password"
                required
                className="w-full px-3 py-2 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-navy/20 focus:border-navy"
                placeholder="Şifreniz"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>

            {error && (
              <div className="text-red-600 text-sm text-center">{error}</div>
            )}

            <div>
              <Button
                type="submit"
                className="w-full bg-navy hover:bg-navy-800 text-white rounded-xl"
                size="lg"
                disabled={isLoading}
              >
                {isLoading ? "Giriş yapılıyor..." : "Giriş Yap"}
              </Button>
            </div>

            <div className="text-center">
              <p className="text-sm text-gray-600">
                Hesabınız yok mu?{" "}
                <Link
                  to="/register"
                  className="text-navy hover:text-navy-700 font-medium"
                >
                  Üye olun
                </Link>
              </p>
            </div>

            <div className="border-t pt-6">
              <div className="text-center text-sm text-gray-600">
                <p className="mb-4 font-semibold">Demo hesapları:</p>
                <div className="grid grid-cols-1 gap-2 text-xs">
                  <div className="bg-red-50 p-2 rounded">
                    <strong>Admin:</strong> admin@kutbulzaman.com / admin123
                  </div>
                  <div className="bg-blue-50 p-2 rounded">
                    <strong>Kullanıcı:</strong> user@kutbulzaman.com / user123
                  </div>
                  <div className="bg-purple-50 p-2 rounded">
                    <strong>MLM:</strong> mlm@kutbulzaman.com / mlm123
                  </div>
                  <div className="bg-green-50 p-2 rounded">
                    <strong>Psikolog:</strong> psychologist@kutbulzaman.com /
                    psy123
                  </div>
                  <div className="bg-orange-50 p-2 rounded">
                    <strong>Satıcı:</strong> merchant@kutbulzaman.com /
                    merchant123
                  </div>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
