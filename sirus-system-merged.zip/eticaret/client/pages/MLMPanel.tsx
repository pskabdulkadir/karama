import { useAuth } from "../contexts/AuthContext";
import { Link } from "react-router-dom";
import { Button } from "../components/ui/button";
import {
  Trophy,
  Users,
  DollarSign,
  TrendingUp,
  Gift,
  Star,
  Target,
  ArrowLeft,
} from "lucide-react";

export function MLMPanel() {
  const { user, isAuthenticated } = useAuth();

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="container mx-auto px-4 py-8">
          <div className="text-center py-16">
            <h1 className="text-2xl font-semibold mb-4">MLM Paneline Erişim</h1>
            <p className="text-gray-600 mb-6">
              MLM paneline erişim için giriş yapmanız gerekiyor.
            </p>
            <Link to="/login">
              <Button size="lg">Giriş Yap</Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const stats = {
    totalEarnings: user?.bonusEarnings || 0,
    totalSales: user?.totalSales || 0,
    currentLevel: user?.mlmLevel || "Bronze",
    teamMembers: 12,
    monthlyBonus: 850,
    nextLevelTarget: 25000,
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold">MLM Panel</h1>
            <p className="text-gray-600">
              Merhaba {user?.name}, kazanç ve performans bilgileriniz
            </p>
          </div>
          <Link to="/">
            <Button variant="outline">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Ana Sayfa
            </Button>
          </Link>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-xl border border-gray-100 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Toplam Kazancım</p>
                <p className="text-2xl font-bold text-green-600">
                  ₺{stats.totalEarnings.toLocaleString()}
                </p>
              </div>
              <DollarSign className="h-8 w-8 text-green-500" />
            </div>
          </div>

          <div className="bg-white rounded-xl border border-gray-100 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Toplam Satışlarım</p>
                <p className="text-2xl font-bold text-blue-600">
                  ₺{stats.totalSales.toLocaleString()}
                </p>
              </div>
              <TrendingUp className="h-8 w-8 text-blue-500" />
            </div>
          </div>

          <div className="bg-white rounded-xl border border-gray-100 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Seviyem</p>
                <p className="text-2xl font-bold text-purple-600">
                  {stats.currentLevel}
                </p>
              </div>
              <Trophy className="h-8 w-8 text-purple-500" />
            </div>
          </div>

          <div className="bg-white rounded-xl border border-gray-100 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Ekip Üyelerim</p>
                <p className="text-2xl font-bold text-orange-600">
                  {stats.teamMembers}
                </p>
              </div>
              <Users className="h-8 w-8 text-orange-500" />
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Level Progress */}
          <div className="bg-white rounded-xl border border-gray-100 p-6">
            <h2 className="text-xl font-bold mb-4 flex items-center">
              <Target className="h-5 w-5 mr-2" />
              Seviye İlerlemesi
            </h2>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">
                  Mevcut Seviye: {stats.currentLevel}
                </span>
                <span className="text-sm text-primary">Sonraki: Gold</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className="bg-primary h-2 rounded-full"
                  style={{
                    width: `${(stats.totalSales / stats.nextLevelTarget) * 100}%`,
                  }}
                ></div>
              </div>
              <div className="flex justify-between text-sm text-gray-600">
                <span>₺{stats.totalSales.toLocaleString()}</span>
                <span>₺{stats.nextLevelTarget.toLocaleString()}</span>
              </div>
              <p className="text-sm text-gray-600">
                Gold seviyesine ulaşmak için{" "}
                <strong>
                  ₺{(stats.nextLevelTarget - stats.totalSales).toLocaleString()}
                </strong>{" "}
                daha satış yapmanız gerekiyor.
              </p>
            </div>
          </div>

          {/* Monthly Bonus */}
          <div className="bg-white rounded-xl border border-gray-100 p-6">
            <h2 className="text-xl font-bold mb-4 flex items-center">
              <Gift className="h-5 w-5 mr-2" />
              Bu Ay Bonuslarım
            </h2>
            <div className="space-y-3">
              <div className="flex justify-between items-center p-3 bg-green-50 rounded-lg">
                <span className="text-sm">Satış Bonusu</span>
                <span className="font-semibold text-green-600">₺650</span>
              </div>
              <div className="flex justify-between items-center p-3 bg-blue-50 rounded-lg">
                <span className="text-sm">Ekip Bonusu</span>
                <span className="font-semibold text-blue-600">₺200</span>
              </div>
              <div className="flex justify-between items-center p-3 bg-purple-50 rounded-lg">
                <span className="text-sm">Seviye Bonusu</span>
                <span className="font-semibold text-purple-600">₺0</span>
              </div>
              <div className="border-t pt-3">
                <div className="flex justify-between items-center">
                  <span className="font-semibold">Toplam Bonus</span>
                  <span className="font-bold text-primary text-lg">
                    ₺{stats.monthlyBonus}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Commission Structure */}
          <div className="bg-white rounded-xl border border-gray-100 p-6">
            <h2 className="text-xl font-bold mb-4 flex items-center">
              <Star className="h-5 w-5 mr-2" />
              Komisyon Yapısı
            </h2>
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 border rounded-lg">
                <div>
                  <span className="font-medium">Bronze</span>
                  <p className="text-sm text-gray-600">Satış komisyonu: %5</p>
                </div>
                <div className="text-right">
                  <span className="text-sm text-gray-500">Mevcut</span>
                </div>
              </div>
              <div className="flex items-center justify-between p-3 border rounded-lg">
                <div>
                  <span className="font-medium">Silver</span>
                  <p className="text-sm text-gray-600">Satış komisyonu: %8</p>
                </div>
                <div className="text-right">
                  <span className="text-sm text-primary">Yakında</span>
                </div>
              </div>
              <div className="flex items-center justify-between p-3 border rounded-lg">
                <div>
                  <span className="font-medium">Gold</span>
                  <p className="text-sm text-gray-600">Satış komisyonu: %12</p>
                </div>
                <div className="text-right">
                  <span className="text-sm text-gray-400">Hedef</span>
                </div>
              </div>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="bg-white rounded-xl border border-gray-100 p-6">
            <h2 className="text-xl font-bold mb-4">Hızlı İşlemler</h2>
            <div className="space-y-3">
              <Link to="/" className="block">
                <Button variant="outline" className="w-full justify-start">
                  <Gift className="h-4 w-4 mr-2" />
                  Ürün Satışı Yap
                </Button>
              </Link>
              <Button variant="outline" className="w-full justify-start">
                <Users className="h-4 w-4 mr-2" />
                Ekip Üyelerini Gör
              </Button>
              <Button variant="outline" className="w-full justify-start">
                <TrendingUp className="h-4 w-4 mr-2" />
                Performans Raporu
              </Button>
              <Link to="/self" className="block">
                <Button variant="outline" className="w-full justify-start">
                  <Target className="h-4 w-4 mr-2" />
                  Gelişim Programları
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
