import { useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import {
  Package,
  Gift,
  Bell,
  User,
  CreditCard,
  MapPin,
  ArrowLeft,
  Eye,
  Download,
  CheckCircle,
  Clock,
  Truck,
} from "lucide-react";

type MemberTab = "orders" | "discounts" | "notifications" | "profile";

interface Order {
  id: string;
  date: string;
  status: "delivered" | "shipped" | "processing" | "cancelled";
  total: number;
  items: { name: string; quantity: number; price: number }[];
}

interface DiscountCode {
  id: string;
  code: string;
  description: string;
  discount: number;
  expiryDate: string;
  used: boolean;
}

interface Notification {
  id: string;
  title: string;
  message: string;
  date: string;
  read: boolean;
  type: "order" | "discount" | "general";
}

const sampleOrders: Order[] = [
  {
    id: "KZ001",
    date: "2024-01-15",
    status: "delivered",
    total: 285,
    items: [
      { name: "Spiritüel Gelişim Kitabı", quantity: 1, price: 85 },
      { name: "Adaçayı Tütsü Seti", quantity: 2, price: 45 },
      { name: "Ametist Kristal Kolye", quantity: 1, price: 150 },
    ],
  },
  {
    id: "KZ002",
    date: "2024-01-10",
    status: "shipped",
    total: 50,
    items: [{ name: "Meditasyon PDF Koleksiyonu", quantity: 1, price: 50 }],
  },
  {
    id: "KZ003",
    date: "2024-01-08",
    status: "processing",
    total: 350,
    items: [{ name: "Tam Ruhsal Temizlik Seti", quantity: 1, price: 350 }],
  },
];

const sampleDiscounts: DiscountCode[] = [
  {
    id: "1",
    code: "RUHSAL20",
    description: "Ruhsal ürünlerde %20 indirim",
    discount: 20,
    expiryDate: "2024-02-15",
    used: false,
  },
  {
    id: "2",
    code: "YENIUYE15",
    description: "Yeni üye indirimi",
    discount: 15,
    expiryDate: "2024-01-30",
    used: true,
  },
  {
    id: "3",
    code: "KRISTAL30",
    description: "Kristal ürünlerde özel indirim",
    discount: 30,
    expiryDate: "2024-03-01",
    used: false,
  },
];

const sampleNotifications: Notification[] = [
  {
    id: "1",
    title: "Siparişiniz Teslim Edildi",
    message: "KZ001 numaralı siparişiniz başarıyla teslim edilmiştir.",
    date: "2024-01-15",
    read: true,
    type: "order",
  },
  {
    id: "2",
    title: "Yeni İndirim Kodu",
    message: "Size özel RUHSAL20 indirim kodunuz aktif edildi.",
    date: "2024-01-14",
    read: false,
    type: "discount",
  },
  {
    id: "3",
    title: "Yeni Ürünler Eklendi",
    message: "Kristal koleksiyonumuza yeni ürünler eklendi.",
    date: "2024-01-12",
    read: false,
    type: "general",
  },
];

export function MemberPanel() {
  const { user, isAuthenticated } = useAuth();
  const [activeTab, setActiveTab] = useState<MemberTab>("orders");

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="container mx-auto px-4 py-8">
          <div className="text-center py-16">
            <h1 className="text-2xl font-semibold mb-4">Üye Paneli</h1>
            <p className="text-gray-600 mb-6">
              Üye paneline erişim için giriş yapmanız gerekiyor.
            </p>
            <Link to="/login">
              <Button size="lg">Giriş Yap</Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const getStatusIcon = (status: Order["status"]) => {
    switch (status) {
      case "delivered":
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case "shipped":
        return <Truck className="h-4 w-4 text-blue-500" />;
      case "processing":
        return <Clock className="h-4 w-4 text-orange-500" />;
      case "cancelled":
        return <Eye className="h-4 w-4 text-red-500" />;
      default:
        return <Clock className="h-4 w-4 text-gray-500" />;
    }
  };

  const getStatusText = (status: Order["status"]) => {
    switch (status) {
      case "delivered":
        return "Teslim Edildi";
      case "shipped":
        return "Kargoda";
      case "processing":
        return "Hazırlanıyor";
      case "cancelled":
        return "İptal Edildi";
      default:
        return status;
    }
  };

  const getStatusColor = (status: Order["status"]) => {
    switch (status) {
      case "delivered":
        return "bg-green-100 text-green-800";
      case "shipped":
        return "bg-blue-100 text-blue-800";
      case "processing":
        return "bg-orange-100 text-orange-800";
      case "cancelled":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold">Üye Paneli</h1>
            <p className="text-gray-600">
              Merhaba {user?.name}, hesap bilgilerinizi yönetin
            </p>
          </div>
          <Link to="/">
            <Button variant="outline">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Market
            </Button>
          </Link>
        </div>

        {/* Navigation Tabs */}
        <div className="flex space-x-1 bg-white rounded-lg p-1 mb-8 border">
          {[
            { id: "orders", label: "Siparişlerim", icon: Package },
            { id: "discounts", label: "İndirim Kodlarım", icon: Gift },
            { id: "notifications", label: "Bildirimlerim", icon: Bell },
            { id: "profile", label: "Profil Bilgileri", icon: User },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as MemberTab)}
              className={`flex items-center space-x-2 px-4 py-2 rounded-md transition-colors ${
                activeTab === tab.id
                  ? "bg-primary text-white"
                  : "text-gray-600 hover:text-gray-900"
              }`}
            >
              <tab.icon className="h-4 w-4" />
              <span>{tab.label}</span>
            </button>
          ))}
        </div>

        {/* Orders Tab */}
        {activeTab === "orders" && (
          <div className="space-y-6">
            <h2 className="text-xl font-bold">Siparişlerim</h2>
            <div className="space-y-4">
              {sampleOrders.map((order) => (
                <div
                  key={order.id}
                  className="bg-white rounded-xl border border-gray-100 p-6"
                >
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-3">
                      <span className="font-semibold text-lg">#{order.id}</span>
                      <Badge
                        className={`${getStatusColor(order.status)} hover:${getStatusColor(order.status)}`}
                      >
                        <span className="flex items-center space-x-1">
                          {getStatusIcon(order.status)}
                          <span>{getStatusText(order.status)}</span>
                        </span>
                      </Badge>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-gray-600">
                        {new Date(order.date).toLocaleDateString("tr-TR")}
                      </p>
                      <p className="text-lg font-bold text-primary">
                        ₺{order.total}
                      </p>
                    </div>
                  </div>

                  <div className="space-y-2">
                    {order.items.map((item, index) => (
                      <div
                        key={index}
                        className="flex justify-between items-center text-sm"
                      >
                        <span>
                          {item.quantity}x {item.name}
                        </span>
                        <span className="font-medium">
                          ₺{(item.quantity * item.price).toLocaleString()}
                        </span>
                      </div>
                    ))}
                  </div>

                  <div className="flex justify-between items-center mt-4 pt-4 border-t">
                    <Button variant="outline" size="sm">
                      <Eye className="h-4 w-4 mr-2" />
                      Detayları Görüntüle
                    </Button>
                    {order.status === "delivered" && (
                      <Button variant="outline" size="sm">
                        <Package className="h-4 w-4 mr-2" />
                        Tekrar Sipariş Et
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Discounts Tab */}
        {activeTab === "discounts" && (
          <div className="space-y-6">
            <h2 className="text-xl font-bold">İndirim Kodlarım</h2>
            <div className="space-y-4">
              {sampleDiscounts.map((discount) => (
                <div
                  key={discount.id}
                  className="bg-white rounded-xl border border-gray-100 p-6"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-2">
                        <span className="text-2xl font-bold text-primary bg-primary/10 px-3 py-1 rounded-lg">
                          {discount.code}
                        </span>
                        <Badge
                          variant={discount.used ? "secondary" : "default"}
                        >
                          {discount.used ? "Kullanıldı" : "Aktif"}
                        </Badge>
                      </div>
                      <p className="text-gray-600 mb-1">
                        {discount.description}
                      </p>
                      <p className="text-sm text-gray-500">
                        Son kullanma:{" "}
                        {new Date(discount.expiryDate).toLocaleDateString(
                          "tr-TR",
                        )}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-3xl font-bold text-green-600">
                        %{discount.discount}
                      </p>
                      <p className="text-sm text-gray-500">indirim</p>
                    </div>
                  </div>
                  {!discount.used && (
                    <div className="mt-4 pt-4 border-t">
                      <Button size="sm" className="w-full">
                        <Gift className="h-4 w-4 mr-2" />
                        Şimdi Kullan
                      </Button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Notifications Tab */}
        {activeTab === "notifications" && (
          <div className="space-y-6">
            <h2 className="text-xl font-bold">Bildirimlerim</h2>
            <div className="space-y-4">
              {sampleNotifications.map((notification) => (
                <div
                  key={notification.id}
                  className={`bg-white rounded-xl border border-gray-100 p-6 ${
                    !notification.read ? "border-l-4 border-l-primary" : ""
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-2">
                        <h3
                          className={`font-semibold ${
                            !notification.read
                              ? "text-primary"
                              : "text-gray-900"
                          }`}
                        >
                          {notification.title}
                        </h3>
                        {!notification.read && (
                          <div className="w-2 h-2 bg-primary rounded-full"></div>
                        )}
                      </div>
                      <p className="text-gray-600 mb-2">
                        {notification.message}
                      </p>
                      <p className="text-sm text-gray-500">
                        {new Date(notification.date).toLocaleDateString(
                          "tr-TR",
                        )}
                      </p>
                    </div>
                    <div className="flex items-center space-x-2">
                      {notification.type === "order" && (
                        <Package className="h-5 w-5 text-blue-500" />
                      )}
                      {notification.type === "discount" && (
                        <Gift className="h-5 w-5 text-green-500" />
                      )}
                      {notification.type === "general" && (
                        <Bell className="h-5 w-5 text-purple-500" />
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Profile Tab */}
        {activeTab === "profile" && (
          <div className="space-y-6">
            <h2 className="text-xl font-bold">Profil Bilgileri</h2>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-white rounded-xl border border-gray-100 p-6">
                <h3 className="text-lg font-semibold mb-4 flex items-center">
                  <User className="h-5 w-5 mr-2" />
                  Kişisel Bilgiler
                </h3>
                <div className="space-y-3">
                  <div>
                    <label className="block text-sm font-medium mb-1">
                      Ad Soyad
                    </label>
                    <p className="text-gray-900">{user?.name}</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">
                      E-posta
                    </label>
                    <p className="text-gray-900">{user?.email}</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">
                      Telefon
                    </label>
                    <p className="text-gray-900">{user?.phone}</p>
                  </div>
                </div>
                <Button variant="outline" className="w-full mt-4">
                  Bilgileri Düzenle
                </Button>
              </div>

              <div className="bg-white rounded-xl border border-gray-100 p-6">
                <h3 className="text-lg font-semibold mb-4 flex items-center">
                  <MapPin className="h-5 w-5 mr-2" />
                  Adres Bilgileri
                </h3>
                <div className="space-y-3">
                  <div>
                    <label className="block text-sm font-medium mb-1">
                      Teslimat Adresi
                    </label>
                    <p className="text-gray-900">
                      Atatürk Cad. No: 123
                      <br />
                      Beşiktaş / İstanbul
                      <br />
                      34357 Türkiye
                    </p>
                  </div>
                </div>
                <Button variant="outline" className="w-full mt-4">
                  Adresi Düzenle
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
