import { useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import {
  Bell,
  Package,
  Gift,
  Star,
  ArrowLeft,
  Check,
  CheckCheck,
} from "lucide-react";

interface Notification {
  id: string;
  title: string;
  message: string;
  date: string;
  read: boolean;
  type: "order" | "discount" | "general" | "spiritual";
}

const sampleNotifications: Notification[] = [
  {
    id: "1",
    title: "Siparişiniz Hazırlanıyor",
    message:
      "KZ001 numaralı siparişiniz hazırlık aşamasında. Kargo bilgileri size e-posta ile iletilecektir.",
    date: "2024-01-15T10:30:00Z",
    read: false,
    type: "order",
  },
  {
    id: "2",
    title: "Yeni Spiritüel İçerik",
    message:
      "Meditasyon ve çakra balansı üzerine yeni PDF rehberimiz yayınlandı. Hemen inceleyin!",
    date: "2024-01-14T15:45:00Z",
    read: false,
    type: "spiritual",
  },
  {
    id: "3",
    title: "Size Özel İndirim Kodu",
    message:
      "RUHSAL20 kodu ile ruhsal gelişim ürünlerinde %20 indirim fırsatı. Son 3 gün!",
    date: "2024-01-13T09:15:00Z",
    read: true,
    type: "discount",
  },
  {
    id: "4",
    title: "Yeni Kristal Koleksiyonu",
    message:
      "Himalaya kristalleri koleksiyonumuz yenilendi. Enerji temizliği için özel fırsatlar.",
    date: "2024-01-12T14:20:00Z",
    read: true,
    type: "general",
  },
  {
    id: "5",
    title: "Tam Ay Ritüeli Rehberi",
    message:
      "Bu gece tam ay! Özel tam ay ritüeli rehberimizi inceleyerek enerji çalışmalarınızı güçlendirin.",
    date: "2024-01-11T18:00:00Z",
    read: true,
    type: "spiritual",
  },
  {
    id: "6",
    title: "Siparişiniz Teslim Edildi",
    message:
      "KZ002 numaralı siparişiniz başarıyla teslim edilmiştir. Deneyiminizi bizimle paylaşın!",
    date: "2024-01-10T12:30:00Z",
    read: true,
    type: "order",
  },
];

export function Notifications() {
  const { user, isAuthenticated } = useAuth();
  const [notifications, setNotifications] =
    useState<Notification[]>(sampleNotifications);

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="container mx-auto px-4 py-8">
          <div className="text-center py-16">
            <h1 className="text-2xl font-semibold mb-4">Bildirimler</h1>
            <p className="text-gray-600 mb-6">
              Bildirimleri görüntülemek için giriş yapmanız gerekiyor.
            </p>
            <Link to="/login">
              <Button size="lg" className="bg-navy hover:bg-navy-800">
                Giriş Yap
              </Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const markAsRead = (notificationId: string) => {
    setNotifications(
      notifications.map((notif) =>
        notif.id === notificationId ? { ...notif, read: true } : notif,
      ),
    );
  };

  const markAllAsRead = () => {
    setNotifications(notifications.map((notif) => ({ ...notif, read: true })));
  };

  const getNotificationIcon = (type: Notification["type"]) => {
    switch (type) {
      case "order":
        return <Package className="h-5 w-5 text-blue-500" />;
      case "discount":
        return <Gift className="h-5 w-5 text-green-500" />;
      case "spiritual":
        return <Star className="h-5 w-5 text-purple-500" />;
      default:
        return <Bell className="h-5 w-5 text-gray-500" />;
    }
  };

  const getNotificationTypeText = (type: Notification["type"]) => {
    switch (type) {
      case "order":
        return "Sipariş";
      case "discount":
        return "İndirim";
      case "spiritual":
        return "Spiritüel";
      default:
        return "Genel";
    }
  };

  const unreadCount = notifications.filter((n) => !n.read).length;

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-navy">Bildirimler</h1>
            <p className="text-gray-600">
              Merhaba {user?.name}, size özel bildirimleriniz
            </p>
          </div>
          <Link to="/">
            <Button variant="outline" className="rounded-xl">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Ana Sayfa
            </Button>
          </Link>
        </div>

        {/* Stats and Actions */}
        <div className="bg-white rounded-xl shadow-md p-6 mb-8">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between">
            <div className="flex items-center space-x-4 mb-4 sm:mb-0">
              <div className="flex items-center space-x-2">
                <Bell className="h-5 w-5 text-navy" />
                <span className="font-semibold">
                  Toplam {notifications.length} bildirim
                </span>
              </div>
              {unreadCount > 0 && (
                <Badge className="bg-red-500 text-white">
                  {unreadCount} okunmamış
                </Badge>
              )}
            </div>
            {unreadCount > 0 && (
              <Button
                variant="outline"
                size="sm"
                onClick={markAllAsRead}
                className="rounded-xl"
              >
                <CheckCheck className="h-4 w-4 mr-2" />
                Tümünü Okundu İşaretle
              </Button>
            )}
          </div>
        </div>

        {/* Notifications List */}
        <div className="space-y-4">
          {notifications.map((notification) => (
            <div
              key={notification.id}
              className={`bg-white rounded-xl shadow-md p-6 transition-all duration-200 hover:shadow-lg ${
                !notification.read
                  ? "border-l-4 border-l-gold"
                  : "border-l-4 border-l-transparent"
              }`}
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start space-x-4 flex-1">
                  <div className="mt-1">
                    {getNotificationIcon(notification.type)}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2">
                      <h3
                        className={`font-semibold ${
                          !notification.read ? "text-navy" : "text-gray-900"
                        }`}
                      >
                        {notification.title}
                      </h3>
                      <Badge
                        variant="outline"
                        className="text-xs"
                        style={{
                          borderColor:
                            notification.type === "order"
                              ? "#3B82F6"
                              : notification.type === "discount"
                                ? "#10B981"
                                : notification.type === "spiritual"
                                  ? "#8B5CF6"
                                  : "#6B7280",
                        }}
                      >
                        {getNotificationTypeText(notification.type)}
                      </Badge>
                      {!notification.read && (
                        <div className="w-2 h-2 bg-gold rounded-full"></div>
                      )}
                    </div>
                    <p className="text-gray-600 mb-3">{notification.message}</p>
                    <p className="text-sm text-gray-500">
                      {new Date(notification.date).toLocaleDateString("tr-TR", {
                        year: "numeric",
                        month: "long",
                        day: "numeric",
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </p>
                  </div>
                </div>
                <div className="flex items-center space-x-2 ml-4">
                  {!notification.read && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => markAsRead(notification.id)}
                      className="text-gold hover:text-gold-600"
                    >
                      <Check className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>

        {notifications.length === 0 && (
          <div className="bg-white rounded-xl shadow-md p-12 text-center">
            <Bell className="h-16 w-16 text-gray-300 mx-auto mb-4" />
            <h2 className="text-xl font-semibold text-gray-900 mb-2">
              Henüz bildiriminiz bulunmuyor
            </h2>
            <p className="text-gray-600">
              Yeni bildirimler burada görünecektir.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
