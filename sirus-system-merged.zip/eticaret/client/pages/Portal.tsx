import { Link } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import { Button } from "../components/ui/button";
import { ShoppingBag, Users, User, Settings, Heart, Star } from "lucide-react";

export function Portal() {
  const { user, isAuthenticated, hasRole } = useAuth();

  const sections = [
    {
      title: "Alışveriş",
      description: "Ürünleri inceleyin ve satın alın",
      icon: ShoppingBag,
      path: "/shop",
      color: "bg-blue-500",
      available: true,
    },
    {
      title: "Kullanıcı Paneli",
      description: "Hesabınızı ve siparişlerinizi yönetin",
      icon: User,
      path: "/panel",
      color: "bg-green-500",
      available: isAuthenticated,
    },
    {
      title: "Network Sistemi",
      description: "MLM paneli ve ekip yönetimi",
      icon: Users,
      path: "/mlm",
      color: "bg-purple-500",
      available: isAuthenticated && hasRole(["mlm", "admin"]),
    },
    {
      title: "Kişisel Gelişim",
      description: "Ruhsal gelişim ve eğitim içerikleri",
      icon: Heart,
      path: "/self",
      color: "bg-pink-500",
      available: isAuthenticated && hasRole(["mlm", "psychologist", "admin"]),
    },
    {
      title: "Yönetici Paneli",
      description: "Sistem yönetimi ve raporlar",
      icon: Settings,
      path: "/admin",
      color: "bg-red-500",
      available: isAuthenticated && hasRole("admin"),
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50 animate-fade-in">
      <div className="container mx-auto px-4 py-12">
        <div className="text-center mb-16">
          <h1 className="text-4xl lg:text-5xl font-bold text-navy mb-6">
            Kutbul Zaman Portal
          </h1>
          <p className="text-xl text-gray-700 max-w-3xl mx-auto leading-relaxed">
            {isAuthenticated
              ? `Merhaba ${user?.name}, hangi sisteme erişmek istiyorsunuz?`
              : "Lütfen giriş yapın veya sistemi seçin"}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {sections.map((section) => {
            const Icon = section.icon;

            if (!section.available && section.path !== "/shop") {
              return (
                <div
                  key={section.path}
                  className="bg-white rounded-xl shadow-md p-8 opacity-50 cursor-not-allowed"
                >
                  <div
                    className={`w-16 h-16 ${section.color} rounded-full flex items-center justify-center mx-auto mb-6`}
                  >
                    <Icon className="h-8 w-8 text-white" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-400 text-center mb-4">
                    {section.title}
                  </h3>
                  <p className="text-gray-400 text-center mb-6">
                    {section.description}
                  </p>
                  <div className="text-center">
                    <Button disabled className="w-full">
                      Erişim Yok
                    </Button>
                  </div>
                </div>
              );
            }

            return (
              <Link
                key={section.path}
                to={section.path}
                className="bg-white rounded-xl shadow-md hover:shadow-lg transition-all duration-300 transform hover:scale-105 p-8 group"
              >
                <div
                  className={`w-16 h-16 ${section.color} rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform`}
                >
                  <Icon className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-navy text-center mb-4 group-hover:text-gold transition-colors">
                  {section.title}
                </h3>
                <p className="text-gray-600 text-center mb-6">
                  {section.description}
                </p>
                <div className="text-center">
                  <Button className="w-full bg-navy hover:bg-navy-800 text-white">
                    Erişim
                  </Button>
                </div>
              </Link>
            );
          })}
        </div>

        {!isAuthenticated && (
          <div className="text-center mt-16">
            <div className="bg-white rounded-xl shadow-md p-8 max-w-md mx-auto">
              <Star className="h-16 w-16 text-gold mx-auto mb-6" />
              <h3 className="text-2xl font-bold text-navy mb-4">
                Hesabınız Yok mu?
              </h3>
              <p className="text-gray-600 mb-6">
                Tüm özelliklere erişim için üye olun
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link to="/login" className="flex-1">
                  <Button className="w-full bg-navy hover:bg-navy-800">
                    Giriş Yap
                  </Button>
                </Link>
                <Link to="/register" className="flex-1">
                  <Button
                    variant="outline"
                    className="w-full border-navy text-navy hover:bg-navy hover:text-white"
                  >
                    Üye Ol
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
