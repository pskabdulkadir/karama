import { useState } from "react";
import { Link } from "react-router-dom";
import {
  Trash2,
  Plus,
  Minus,
  ShoppingBag,
  ArrowLeft,
  Heart,
  Truck,
} from "lucide-react";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { useCart } from "../contexts/CartContext";

export function Cart() {
  const {
    items: cartItems,
    updateQuantity,
    removeFromCart,
    getTotalPrice,
    getTotalItems,
  } = useCart();

  const subtotal = getTotalPrice();
  const shipping = subtotal > 500 ? 0 : 30;
  const total = subtotal + shipping;

  if (cartItems.length === 0) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="container mx-auto px-4 py-8">
          <div className="text-center py-16">
            <ShoppingBag className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h1 className="text-2xl font-semibold mb-4">Sepetiniz Boş</h1>
            <p className="text-gray-600 mb-6">
              Sepetinizde henüz ürün bulunmuyor. Alışverişe başlamak için
              ürünlerimizi inceleyin.
            </p>
            <Link to="/">
              <Button size="lg">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Alışverişe Devam Et
              </Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-2xl font-bold">
            Sepetim ({getTotalItems()} ürün)
          </h1>
          <Link
            to="/"
            className="text-primary hover:underline flex items-center"
          >
            <ArrowLeft className="h-4 w-4 mr-1" />
            Alışverişe Devam Et
          </Link>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2 space-y-4">
            {cartItems.map((item) => {
              const hasDiscount =
                item.product.discount && item.product.discount > 0;

              return (
                <div
                  key={item.product.id}
                  className="bg-white rounded-xl border border-gray-100 p-6 shadow-sm"
                >
                  <div className="flex flex-col sm:flex-row gap-4">
                    {/* Product Image */}
                    <div className="flex-shrink-0">
                      <Link to={`/shop/product/${item.product.id}`}>
                        <img
                          src={item.product.images[0]}
                          alt={item.product.name}
                          className="w-full sm:w-24 h-24 object-cover rounded-lg"
                        />
                      </Link>
                    </div>

                    {/* Product Info */}
                    <div className="flex-1 min-w-0">
                      <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between">
                        <div className="flex-1">
                          <Link
                            to={`/shop/product/${item.product.id}`}
                            className="block"
                          >
                            <h3 className="font-semibold text-gray-900 hover:text-primary transition-colors">
                              {item.product.name}
                            </h3>
                          </Link>
                          <p className="text-sm text-gray-600 mt-1 line-clamp-2">
                            {item.product.description}
                          </p>

                          <div className="flex items-center mt-2 space-x-2">
                            <span className="font-bold text-primary">
                              ₺{item.product.price}
                            </span>
                            {hasDiscount && item.product.originalPrice && (
                              <span className="text-sm text-gray-500 line-through">
                                ₺{item.product.originalPrice}
                              </span>
                            )}
                            {hasDiscount && (
                              <Badge variant="destructive" className="text-xs">
                                -{item.product.discount}%
                              </Badge>
                            )}
                          </div>
                        </div>

                        {/* Actions */}
                        <div className="flex items-center space-x-2 mt-4 sm:mt-0">
                          {/* Quantity Controls */}
                          <div className="flex items-center space-x-2 border rounded-lg">
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8"
                              onClick={() =>
                                updateQuantity(
                                  item.product.id,
                                  item.quantity - 1,
                                )
                              }
                            >
                              <Minus className="h-3 w-3" />
                            </Button>
                            <span className="text-sm font-semibold w-8 text-center">
                              {item.quantity}
                            </span>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8"
                              onClick={() =>
                                updateQuantity(
                                  item.product.id,
                                  item.quantity + 1,
                                )
                              }
                              disabled={item.quantity >= item.product.stock}
                            >
                              <Plus className="h-3 w-3" />
                            </Button>
                          </div>

                          {/* Remove & Favorite */}
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-gray-400 hover:text-red-500"
                            onClick={() => removeFromCart(item.product.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>

                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-gray-400 hover:text-red-500"
                          >
                            <Heart className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>

                      {/* Stock Warning */}
                      {item.product.stock < 5 && (
                        <p className="text-xs text-red-600 mt-2">
                          Sadece {item.product.stock} adet kaldı!
                        </p>
                      )}

                      {/* Subtotal */}
                      <div className="flex justify-between items-center mt-4 pt-4 border-t">
                        <span className="text-sm text-gray-600">
                          Ara Toplam:
                        </span>
                        <span className="font-bold text-lg">
                          ₺
                          {(
                            item.product.price * item.quantity
                          ).toLocaleString()}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl border border-gray-100 p-6 shadow-sm sticky top-4">
              <h2 className="text-xl font-bold mb-6">Sipariş Özeti</h2>

              <div className="space-y-4">
                <div className="flex justify-between">
                  <span>Ara Toplam ({getTotalItems()} ürün)</span>
                  <span className="font-semibold">
                    ₺{subtotal.toLocaleString()}
                  </span>
                </div>

                <div className="flex justify-between">
                  <span className="flex items-center">
                    <Truck className="h-4 w-4 mr-1" />
                    Kargo
                  </span>
                  <span
                    className={`font-semibold ${shipping === 0 ? "text-green-600" : ""}`}
                  >
                    {shipping === 0 ? "Ücretsiz" : `₺${shipping}`}
                  </span>
                </div>

                {subtotal < 500 && (
                  <div className="text-sm text-gray-600 bg-blue-50 p-3 rounded-lg">
                    ₺{(500 - subtotal).toLocaleString()} daha alışveriş yapın,
                    kargo bedava!
                  </div>
                )}

                <div className="border-t pt-4">
                  <div className="flex justify-between text-lg font-bold">
                    <span>Toplam</span>
                    <span className="text-primary">
                      ₺{total.toLocaleString()}
                    </span>
                  </div>
                </div>

                <Link to="/shop/checkout" className="block w-full">
                  <Button size="lg" className="w-full">
                    Satın Al
                  </Button>
                </Link>

                <div className="text-center">
                  <Link to="/" className="text-primary hover:underline text-sm">
                    Alışverişe Devam Et
                  </Link>
                </div>
              </div>

              {/* Security Info */}
              <div className="mt-6 pt-6 border-t">
                <div className="text-xs text-gray-600 space-y-2">
                  <div className="flex items-center">
                    <span className="w-2 h-2 bg-green-500 rounded-full mr-2"></span>
                    SSL güvenli ödeme
                  </div>
                  <div className="flex items-center">
                    <span className="w-2 h-2 bg-green-500 rounded-full mr-2"></span>
                    14 gün değişim garantisi
                  </div>
                  <div className="flex items-center">
                    <span className="w-2 h-2 bg-green-500 rounded-full mr-2"></span>
                    Hızlı teslimat
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
