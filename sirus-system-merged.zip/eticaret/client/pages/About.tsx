import { Link } from "react-router-dom";
import { Button } from "../components/ui/button";
import { ArrowLeft, Heart, Star, Users, Award } from "lucide-react";

export function About() {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-12">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl lg:text-5xl font-bold text-navy mb-6">
            Kutbul Zaman Hakkında
          </h1>
          <p className="text-xl text-gray-700 max-w-3xl mx-auto leading-relaxed">
            Spiritüel gelişim ve ruhsal uyanış yolculuğunuzda size eşlik etmek
            için kurulmuş bir platform. İç huzur, bilgelik ve aydınlanma
            arayışınızda yanınızdayız.
          </p>
        </div>

        {/* Story Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
          <div className="bg-white rounded-xl shadow-md p-8">
            <h2 className="text-2xl font-bold text-navy mb-6">Hikayemiz</h2>
            <p className="text-gray-700 leading-relaxed mb-4">
              Kutbul Zaman, spiritüel arayış içindeki insanlara kaliteli ve
              otantik ürünler sunmak amacıyla doğdu. Modern yaşamın karmaşası
              içinde kaybolmuş ruhları, kadim bilgelik ve manevi pratiklerle
              buluşturmak misyonumuz.
            </p>
            <p className="text-gray-700 leading-relaxed mb-4">
              Her ürün, dikkatli bir şekilde seçilmiş ve ruhsal gelişimi
              desteklemek için tasarlanmıştır. Kristallerden tütsülere, manevi
              kitaplardan meditasyon araçlarına kadar geniş ürün yelpazemizle,
              kendi içsel yolculuğunuzu destekliyoruz.
            </p>
            <p className="text-gray-700 leading-relaxed">
              Kutbul Zaman, sadece bir alışveriş platformu değil; aynı zamanda
              spiritüel gelişim ve bilinç genişletme konularında bir rehber ve
              topluluktur.
            </p>
          </div>

          <div className="bg-gradient-to-br from-navy to-navy-800 rounded-xl shadow-md p-8 text-white">
            <h2 className="text-2xl font-bold mb-6">Misyonumuz</h2>
            <div className="space-y-4">
              <div className="flex items-start space-x-3">
                <Heart className="h-6 w-6 text-gold mt-1" />
                <div>
                  <h3 className="font-semibold mb-1">İç Huzuru Destekleme</h3>
                  <p className="text-purple-100 text-sm">
                    Her bireyin iç huzurunu bulmasına yardımcı olmak
                  </p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <Star className="h-6 w-6 text-gold mt-1" />
                <div>
                  <h3 className="font-semibold mb-1">Kaliteli Ürünler</h3>
                  <p className="text-purple-100 text-sm">
                    En kaliteli spiritüel ürünleri özenle seçmek
                  </p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <Users className="h-6 w-6 text-gold mt-1" />
                <div>
                  <h3 className="font-semibold mb-1">Topluluk Oluşturma</h3>
                  <p className="text-purple-100 text-sm">
                    Spiritüel gelişim yolunda birliktelik sağlamak
                  </p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <Award className="h-6 w-6 text-gold mt-1" />
                <div>
                  <h3 className="font-semibold mb-1">Güvenilir Hizmet</h3>
                  <p className="text-purple-100 text-sm">
                    Müşterilerimize güvenilir ve samimi hizmet sunmak
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Values Section */}
        <div className="bg-white rounded-xl shadow-md p-8 mb-16">
          <h2 className="text-2xl font-bold text-navy text-center mb-8">
            Değerlerimiz
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-gold rounded-full flex items-center justify-center mx-auto mb-4">
                <Heart className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-lg font-semibold text-navy mb-2">
                Samimiyet
              </h3>
              <p className="text-gray-600 text-sm">
                Her müşterimizle samimi ve içten bir bağ kurarak, onların
                spiritüel yolculuğuna saygı duyuyoruz.
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-gold rounded-full flex items-center justify-center mx-auto mb-4">
                <Star className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-lg font-semibold text-navy mb-2">Kalite</h3>
              <p className="text-gray-600 text-sm">
                Sunduğumuz her üründe en yüksek kalite standartlarını koruyarak,
                güvenilir bir hizmet anlayışını benimsiyor.
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-gold rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-lg font-semibold text-navy mb-2">Topluluk</h3>
              <p className="text-gray-600 text-sm">
                Spiritüel gelişim yolunda yalnız olmadığınızı hissettiren,
                destekleyici bir topluluk oluşturuyoruz.
              </p>
            </div>
          </div>
        </div>

        {/* Contact Section */}
        <div className="bg-gradient-to-r from-navy to-navy-800 rounded-xl shadow-md p-8 text-white text-center">
          <h2 className="text-2xl font-bold mb-4">Bizimle İletişime Geçin</h2>
          <p className="text-purple-100 mb-6 max-w-2xl mx-auto">
            Spiritüel yolculuğunuzda size nasıl yardımcı olabileceğimizi merak
            ediyorsanız, bizimle iletişime geçmekten çekinmeyin.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/contact">
              <Button
                size="lg"
                className="bg-gold hover:bg-gold-600 text-white rounded-xl"
              >
                İletişim
              </Button>
            </Link>
            <Link to="/">
              <Button
                variant="outline"
                size="lg"
                className="border-white text-white hover:bg-white hover:text-navy rounded-xl"
              >
                Ürünleri İncele
              </Button>
            </Link>
          </div>
        </div>

        {/* Back to Home */}
        <div className="mt-12 text-center">
          <Link to="/">
            <Button variant="outline" className="rounded-xl">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Ana Sayfaya Dön
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
