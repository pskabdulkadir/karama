import { useState, useEffect } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Calendar,
  CreditCard,
  DollarSign,
  Clock,
  CheckCircle,
  AlertTriangle,
  Gift,
  Star,
  Coins,
} from "lucide-react";
import { ActivityPayment, KutbulZamanConfig } from "../../shared/mlm-types";

const mockConfig: KutbulZamanConfig = {
  entryFee: 100,
  monthlyFee: 20,
  annualFee: 200,
  annualDiscount: 0.15,
  bonusDistributionRate: 0.4,
  systemFundRate: 0.6,
  sponsorBonusRate: 0.1,
  careerBonusAllocation: 0.25,
};

const mockPayments: ActivityPayment[] = [
  {
    id: "1",
    userId: "user1",
    type: "entry",
    amount: 100,
    currency: "USD",
    dueDate: "2024-01-01",
    paidDate: "2024-01-01",
    status: "paid",
  },
  {
    id: "2",
    userId: "user1",
    type: "monthly",
    amount: 20,
    currency: "USD",
    dueDate: "2024-02-01",
    paidDate: "2024-02-01",
    status: "paid",
  },
  {
    id: "3",
    userId: "user1",
    type: "monthly",
    amount: 20,
    currency: "USD",
    dueDate: "2024-03-01",
    status: "pending",
  },
];

export function ActivityManager() {
  const [payments, setPayments] = useState<ActivityPayment[]>(mockPayments);
  const [userStatus, setUserStatus] = useState<
    "active" | "passive" | "pending"
  >("active");
  const [showAnnualOption, setShowAnnualOption] = useState(false);

  const calculateNextPayment = () => {
    const today = new Date();
    const nextMonth = new Date(today.getFullYear(), today.getMonth() + 1, 1);
    return nextMonth.toISOString().split("T")[0];
  };

  const calculateAnnualSavings = () => {
    const monthlyTotal = mockConfig.monthlyFee * 12;
    const savings = monthlyTotal - mockConfig.annualFee;
    const percentage = (savings / monthlyTotal) * 100;
    return { savings, percentage };
  };

  const handleMonthlyPayment = () => {
    const newPayment: ActivityPayment = {
      id: Date.now().toString(),
      userId: "user1",
      type: "monthly",
      amount: mockConfig.monthlyFee,
      currency: "USD",
      dueDate: calculateNextPayment(),
      paidDate: new Date().toISOString().split("T")[0],
      status: "paid",
    };
    setPayments([...payments, newPayment]);
    setUserStatus("active");
  };

  const handleAnnualPayment = () => {
    const newPayment: ActivityPayment = {
      id: Date.now().toString(),
      userId: "user1",
      type: "annual",
      amount: mockConfig.annualFee,
      currency: "USD",
      dueDate: new Date(
        new Date().getFullYear() + 1,
        new Date().getMonth(),
        new Date().getDate(),
      )
        .toISOString()
        .split("T")[0],
      paidDate: new Date().toISOString().split("T")[0],
      status: "paid",
      discountApplied: mockConfig.monthlyFee * 12 - mockConfig.annualFee,
    };
    setPayments([...payments, newPayment]);
    setUserStatus("active");
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "active":
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case "passive":
        return <AlertTriangle className="h-4 w-4 text-yellow-500" />;
      case "pending":
        return <Clock className="h-4 w-4 text-orange-500" />;
      default:
        return <Clock className="h-4 w-4 text-gray-500" />;
    }
  };

  const getStatusBadge = (status: string) => {
    const variants = {
      active: "bg-green-100 text-green-800",
      passive: "bg-yellow-100 text-yellow-800",
      pending: "bg-orange-100 text-orange-800",
    };

    const labels = {
      active: "Aktif",
      passive: "Pasif",
      pending: "Beklemede",
    };

    return (
      <Badge className={variants[status as keyof typeof variants]}>
        {getStatusIcon(status)}
        <span className="ml-1">{labels[status as keyof typeof labels]}</span>
      </Badge>
    );
  };

  const pendingPayments = payments.filter((p) => p.status === "pending");
  const annualSavings = calculateAnnualSavings();

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Star className="h-5 w-5 text-purple-600" />
            Üyelik Durumu
          </CardTitle>
          <CardDescription>
            Kutbul Zaman Network aktiflik durumunuz ve ödeme bilgileriniz
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="text-2xl font-bold">Durum:</div>
              {getStatusBadge(userStatus)}
            </div>
            <div className="text-right">
              <div className="text-sm text-gray-600">Son Ödeme</div>
              <div className="font-semibold">01 Şubat 2024</div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="payments" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="payments">Ödemeler</TabsTrigger>
          <TabsTrigger value="annual">Yıllık Paket</TabsTrigger>
          <TabsTrigger value="history">Geçmiş</TabsTrigger>
        </TabsList>

        <TabsContent value="payments" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CreditCard className="h-5 w-5" />
                Aktiflik Ödemeleri
              </CardTitle>
              <CardDescription>
                Aylık aktiflik ücretinizi ödeyin ve sisteme devam edin
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {pendingPayments.length > 0 ? (
                <div className="border rounded-lg p-4 bg-orange-50">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-semibold text-orange-800">
                        Bekleyen Ödeme
                      </h4>
                      <p className="text-sm text-orange-600">
                        ${mockConfig.monthlyFee} - Mart 2024 aktiflik ücreti
                      </p>
                    </div>
                    <Button
                      onClick={handleMonthlyPayment}
                      className="bg-purple-600 hover:bg-purple-700"
                    >
                      <DollarSign className="h-4 w-4 mr-2" />
                      Öde
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="border rounded-lg p-4 bg-green-50">
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-5 w-5 text-green-600" />
                    <span className="text-green-800 font-semibold">
                      Tüm ödemeleriniz güncel!
                    </span>
                  </div>
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card className="border-purple-200">
                  <CardContent className="p-4">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-purple-600">
                        ${mockConfig.entryFee}
                      </div>
                      <div className="text-sm text-gray-600">Giriş Paketi</div>
                      <Badge className="mt-2 bg-green-100 text-green-800">
                        <CheckCircle className="h-3 w-3 mr-1" />
                        Tamamlandı
                      </Badge>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-blue-200">
                  <CardContent className="p-4">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-blue-600">
                        ${mockConfig.monthlyFee}
                      </div>
                      <div className="text-sm text-gray-600">
                        Aylık Aktiflik
                      </div>
                      <div className="text-xs text-gray-500 mt-1">
                        Her ay 1'inde
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-yellow-200">
                  <CardContent className="p-4">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-yellow-600">
                        ${mockConfig.annualFee}
                      </div>
                      <div className="text-sm text-gray-600">Yıllık Paket</div>
                      <div className="text-xs text-green-600 mt-1">
                        %{annualSavings.percentage.toFixed(0)} tasarruf
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="annual" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Gift className="h-5 w-5 text-yellow-600" />
                Yıllık Paket Avantajları
              </CardTitle>
              <CardDescription>
                12 ay peşin ödeyerek %15 indirim kazanın
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="bg-gradient-to-r from-yellow-50 to-yellow-100 rounded-xl p-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="text-lg font-semibold text-yellow-800 mb-4">
                      Aylık vs Yıllık Karşılaştırma
                    </h3>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span>Aylık Ödeme (12 ay):</span>
                        <span className="font-semibold">
                          ${mockConfig.monthlyFee * 12}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span>Yıllık Paket:</span>
                        <span className="font-semibold">
                          ${mockConfig.annualFee}
                        </span>
                      </div>
                      <div className="flex justify-between text-green-600 font-bold">
                        <span>Tasarruf:</span>
                        <span>${annualSavings.savings}</span>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-semibold text-yellow-800 mb-4">
                      Ek Avantajlar
                    </h3>
                    <ul className="space-y-2 text-sm">
                      <li className="flex items-center gap-2">
                        <CheckCircle className="h-4 w-4 text-green-600" />
                        <span>%15 indirim</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle className="h-4 w-4 text-green-600" />
                        <span>Safiye üyeler için ek %1 bonus</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle className="h-4 w-4 text-green-600" />
                        <span>Ödeme hatırlatması yok</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle className="h-4 w-4 text-green-600" />
                        <span>Sürekli aktif statü</span>
                      </li>
                    </ul>
                  </div>
                </div>

                <div className="mt-6 text-center">
                  <Button
                    onClick={handleAnnualPayment}
                    className="bg-yellow-600 hover:bg-yellow-700 text-white px-8 py-3"
                  >
                    <Coins className="h-4 w-4 mr-2" />
                    Yıllık Paketi Satın Al - ${mockConfig.annualFee}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Ödeme Geçmişi
              </CardTitle>
              <CardDescription>
                Tüm aktiflik ödemelerinizin geçmişi
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {payments.map((payment) => (
                  <div
                    key={payment.id}
                    className="flex items-center justify-between p-3 border rounded-lg"
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-3 h-3 rounded-full ${
                          payment.status === "paid"
                            ? "bg-green-500"
                            : payment.status === "pending"
                              ? "bg-orange-500"
                              : "bg-red-500"
                        }`}
                      />
                      <div>
                        <div className="font-medium">
                          {payment.type === "entry"
                            ? "Giriş Paketi"
                            : payment.type === "monthly"
                              ? "Aylık Aktiflik"
                              : "Yıllık Paket"}
                        </div>
                        <div className="text-sm text-gray-600">
                          {payment.paidDate
                            ? `Ödendi: ${payment.paidDate}`
                            : `Vade: ${payment.dueDate}`}
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-semibold">${payment.amount}</div>
                      {payment.discountApplied && (
                        <div className="text-sm text-green-600">
                          ${payment.discountApplied} tasarruf
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
