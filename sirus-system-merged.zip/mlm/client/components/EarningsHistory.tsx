import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  DollarSign,
  TrendingUp,
  TrendingDown,
  Calendar,
  Filter,
  Download,
  Search,
  Eye,
  BarChart3,
  PieChart,
  LineChart,
  RefreshCw,
  AlertCircle,
  CheckCircle,
  Clock,
  ArrowUpRight,
  ArrowDownRight,
  Users,
  Crown,
  Gift,
  Activity,
  Target,
  Zap,
  Info,
  Trophy,
} from "lucide-react";
import { User, Transaction, Bonus } from "@shared/mlm-types";

interface EarningsHistoryProps {
  user: User;
  transactions: Transaction[];
}

export default function EarningsHistory({
  user,
  transactions,
}: EarningsHistoryProps) {
  const [selectedPeriod, setSelectedPeriod] = useState("all");
  const [selectedType, setSelectedType] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [sortBy, setSortBy] = useState("date");
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("desc");

  // Extended sample data for comprehensive history
  const extendedTransactions: Transaction[] = [
    ...transactions,
    {
      id: "4",
      userId: user.id,
      type: "bonus",
      subType: "binary",
      amount: 420.25,
      currency: "TRY",
      description: "Binary bonus - Eşleşme bonusu",
      status: "completed",
      date: "2024-01-10T14:30:00Z",
    },
    {
      id: "5",
      userId: user.id,
      type: "bonus",
      subType: "leadership",
      amount: 180.0,
      currency: "TRY",
      description: "Liderlik bonusu - Takım performansı",
      status: "completed",
      date: "2024-01-08T09:15:00Z",
    },
    {
      id: "6",
      userId: user.id,
      type: "commission",
      amount: 75.5,
      currency: "TRY",
      description: "Komisyon - Satış bonusu",
      status: "completed",
      date: "2024-01-05T16:45:00Z",
    },
    {
      id: "7",
      userId: user.id,
      type: "bonus",
      subType: "rank",
      amount: 1500.0,
      currency: "TRY",
      description: "Rütbe bonusu - Gümüş seviye ödülü",
      status: "completed",
      date: "2024-01-01T00:00:00Z",
    },
    {
      id: "8",
      userId: user.id,
      type: "withdrawal",
      amount: -1000.0,
      currency: "TRY",
      description: "Banka çekimi - Ziraat Bankası",
      status: "completed",
      date: "2023-12-28T11:20:00Z",
    },
    {
      id: "9",
      userId: user.id,
      type: "bonus",
      subType: "sponsor",
      amount: 320.0,
      currency: "TRY",
      description: "Sponsor bonus - Mehmet Demir",
      status: "completed",
      date: "2023-12-25T13:10:00Z",
    },
    {
      id: "10",
      userId: user.id,
      type: "purchase",
      amount: -250.0,
      currency: "TRY",
      description: "Ürün satın alma - Starter paket",
      status: "completed",
      date: "2023-12-20T10:30:00Z",
    },
  ];

  const periods = [
    { value: "all", label: "Tüm Zamanlar" },
    { value: "2024-01", label: "Ocak 2024" },
    { value: "2023-12", label: "Aralık 2023" },
    { value: "2023-11", label: "Kasım 2023" },
    { value: "2023-10", label: "Ekim 2023" },
  ];

  const transactionTypes = [
    { value: "all", label: "Tüm İşlemler" },
    { value: "bonus", label: "Bonuslar" },
    { value: "commission", label: "Komisyonlar" },
    { value: "withdrawal", label: "Para Çekme" },
    { value: "purchase", label: "Satın Alma" },
  ];

  const getFilteredTransactions = () => {
    let filtered = extendedTransactions;

    // Period filter
    if (selectedPeriod !== "all") {
      filtered = filtered.filter((t) => t.date.startsWith(selectedPeriod));
    }

    // Type filter
    if (selectedType !== "all") {
      filtered = filtered.filter((t) => t.type === selectedType);
    }

    // Search filter
    if (searchTerm) {
      filtered = filtered.filter((t) =>
        t.description.toLowerCase().includes(searchTerm.toLowerCase()),
      );
    }

    // Sort
    filtered.sort((a, b) => {
      const aValue = sortBy === "date" ? new Date(a.date) : Math.abs(a.amount);
      const bValue = sortBy === "date" ? new Date(b.date) : Math.abs(b.amount);

      if (sortOrder === "desc") {
        return aValue > bValue ? -1 : 1;
      } else {
        return aValue < bValue ? -1 : 1;
      }
    });

    return filtered;
  };

  const calculatePeriodStats = () => {
    const filtered = getFilteredTransactions();
    const totalIncome = filtered
      .filter((t) => t.amount > 0)
      .reduce((sum, t) => sum + t.amount, 0);
    const totalExpenses = Math.abs(
      filtered
        .filter((t) => t.amount < 0)
        .reduce((sum, t) => sum + t.amount, 0),
    );
    const netEarnings = totalIncome - totalExpenses;
    const transactionCount = filtered.length;

    return {
      totalIncome,
      totalExpenses,
      netEarnings,
      transactionCount,
    };
  };

  const getTransactionIcon = (transaction: Transaction) => {
    if (transaction.type === "bonus") {
      switch (transaction.subType) {
        case "binary":
          return <BarChart3 className="w-4 h-4 text-blue-500" />;
        case "sponsor":
          return <Users className="w-4 h-4 text-green-500" />;
        case "leadership":
          return <Crown className="w-4 h-4 text-purple-500" />;
        case "rank":
          return <Trophy className="w-4 h-4 text-yellow-500" />;
        default:
          return <Gift className="w-4 h-4 text-accent" />;
      }
    } else if (transaction.type === "withdrawal") {
      return <ArrowUpRight className="w-4 h-4 text-warning" />;
    } else if (transaction.type === "purchase") {
      return <ArrowDownRight className="w-4 h-4 text-info" />;
    } else {
      return <DollarSign className="w-4 h-4 text-primary" />;
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <CheckCircle className="w-4 h-4 text-success" />;
      case "pending":
        return <Clock className="w-4 h-4 text-warning" />;
      case "failed":
        return <AlertCircle className="w-4 h-4 text-destructive" />;
      default:
        return <Clock className="w-4 h-4 text-muted-foreground" />;
    }
  };

  const stats = calculatePeriodStats();
  const filteredTransactions = getFilteredTransactions();

  return (
    <div className="space-y-6">
      {/* Header and Controls */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Activity className="w-5 h-5 text-primary" />
                Kazanç Geçmişi ve Analizi
              </CardTitle>
              <CardDescription>
                Tüm gelir, gider ve bonus geçmişinizi detaylı analiz edin
              </CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline">
                <Download className="w-4 h-4 mr-2" />
                Export
              </Button>
              <Button variant="outline">
                <RefreshCw className="w-4 h-4 mr-2" />
                Yenile
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-4 mb-6">
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
                <SelectTrigger className="w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {periods.map((period) => (
                    <SelectItem key={period.value} value={period.value}>
                      {period.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4" />
              <Select value={selectedType} onValueChange={setSelectedType}>
                <SelectTrigger className="w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {transactionTypes.map((type) => (
                    <SelectItem key={type.value} value={type.value}>
                      {type.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center gap-2">
              <Search className="w-4 h-4" />
              <Input
                placeholder="İşlem ara..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="flex items-center gap-2">
              <Select
                value={`${sortBy}-${sortOrder}`}
                onValueChange={(value) => {
                  const [field, order] = value.split("-");
                  setSortBy(field);
                  setSortOrder(order as "asc" | "desc");
                }}
              >
                <SelectTrigger className="w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="date-desc">Tarih (Yeni → Eski)</SelectItem>
                  <SelectItem value="date-asc">Tarih (Eski → Yeni)</SelectItem>
                  <SelectItem value="amount-desc">
                    Tutar (Yüksek → Düşük)
                  </SelectItem>
                  <SelectItem value="amount-asc">
                    Tutar (Düşük → Yüksek)
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Summary Statistics */}
          <div className="grid gap-4 md:grid-cols-4">
            <div className="text-center p-4 bg-success/10 rounded-lg">
              <div className="text-2xl font-bold text-success">
                ₺{stats.totalIncome.toLocaleString("tr-TR")}
              </div>
              <div className="text-sm text-muted-foreground">Toplam Gelir</div>
            </div>
            <div className="text-center p-4 bg-warning/10 rounded-lg">
              <div className="text-2xl font-bold text-warning">
                ₺{stats.totalExpenses.toLocaleString("tr-TR")}
              </div>
              <div className="text-sm text-muted-foreground">Toplam Gider</div>
            </div>
            <div className="text-center p-4 bg-primary/10 rounded-lg">
              <div className="text-2xl font-bold text-primary">
                ₺{stats.netEarnings.toLocaleString("tr-TR")}
              </div>
              <div className="text-sm text-muted-foreground">Net Kazanç</div>
            </div>
            <div className="text-center p-4 bg-info/10 rounded-lg">
              <div className="text-2xl font-bold text-info">
                {stats.transactionCount}
              </div>
              <div className="text-sm text-muted-foreground">İşlem Sayısı</div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="transactions" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="transactions">İşlemler</TabsTrigger>
          <TabsTrigger value="analytics">Analiz</TabsTrigger>
          <TabsTrigger value="monthly">Aylık Rapor</TabsTrigger>
          <TabsTrigger value="trends">Trendler</TabsTrigger>
        </TabsList>

        <TabsContent value="transactions" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>İşlem Geçmişi</CardTitle>
              <CardDescription>
                {filteredTransactions.length} işlem bulundu
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Tarih</TableHead>
                    <TableHead>Tip</TableHead>
                    <TableHead>Açıklama</TableHead>
                    <TableHead>Tutar</TableHead>
                    <TableHead>Durum</TableHead>
                    <TableHead>Detay</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredTransactions.map((transaction) => (
                    <TableRow key={transaction.id}>
                      <TableCell>
                        <div className="text-sm">
                          {new Date(transaction.date).toLocaleDateString(
                            "tr-TR",
                          )}
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {new Date(transaction.date).toLocaleTimeString(
                            "tr-TR",
                            { hour: "2-digit", minute: "2-digit" },
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          {getTransactionIcon(transaction)}
                          <span className="capitalize">
                            {transaction.subType || transaction.type}
                          </span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="max-w-xs truncate">
                          {transaction.description}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div
                          className={`font-semibold ${
                            transaction.amount > 0
                              ? "text-success"
                              : "text-warning"
                          }`}
                        >
                          {transaction.amount > 0 ? "+" : ""}₺
                          {Math.abs(transaction.amount).toLocaleString(
                            "tr-TR",
                            {
                              minimumFractionDigits: 2,
                            },
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          {getStatusIcon(transaction.status)}
                          <Badge
                            variant={
                              transaction.status === "completed"
                                ? "default"
                                : transaction.status === "pending"
                                  ? "secondary"
                                  : "destructive"
                            }
                          >
                            {transaction.status === "completed"
                              ? "Tamamlandı"
                              : transaction.status === "pending"
                                ? "Bekliyor"
                                : "İptal"}
                          </Badge>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button variant="ghost" size="sm">
                              <Eye className="w-4 h-4" />
                            </Button>
                          </DialogTrigger>
                          <DialogContent>
                            <DialogHeader>
                              <DialogTitle>İşlem Detayları</DialogTitle>
                              <DialogDescription>
                                #{transaction.id} - İşlem bilgileri
                              </DialogDescription>
                            </DialogHeader>
                            <div className="space-y-4">
                              <div className="grid grid-cols-2 gap-4">
                                <div>
                                  <Label>İşlem ID</Label>
                                  <div className="font-mono text-sm">
                                    {transaction.id}
                                  </div>
                                </div>
                                <div>
                                  <Label>Tarih</Label>
                                  <div>
                                    {new Date(transaction.date).toLocaleString(
                                      "tr-TR",
                                    )}
                                  </div>
                                </div>
                                <div>
                                  <Label>Tip</Label>
                                  <div className="capitalize">
                                    {transaction.subType || transaction.type}
                                  </div>
                                </div>
                                <div>
                                  <Label>Para Birimi</Label>
                                  <div>{transaction.currency}</div>
                                </div>
                              </div>
                              <div>
                                <Label>Açıklama</Label>
                                <div>{transaction.description}</div>
                              </div>
                              <div>
                                <Label>Tutar</Label>
                                <div
                                  className={`text-lg font-semibold ${
                                    transaction.amount > 0
                                      ? "text-success"
                                      : "text-warning"
                                  }`}
                                >
                                  {transaction.amount > 0 ? "+" : ""}₺
                                  {Math.abs(transaction.amount).toLocaleString(
                                    "tr-TR",
                                    { minimumFractionDigits: 2 },
                                  )}
                                </div>
                              </div>
                            </div>
                          </DialogContent>
                        </Dialog>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics">
          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <PieChart className="w-5 h-5" />
                  Gelir Dağılımı
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64 flex items-center justify-center bg-muted/50 rounded-lg">
                  <div className="text-center">
                    <PieChart className="w-12 h-12 text-muted-foreground mx-auto mb-2" />
                    <p className="text-muted-foreground">
                      Gelir dağılım grafiği burada görüntülenecek
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <LineChart className="w-5 h-5" />
                  Aylık Trend
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64 flex items-center justify-center bg-muted/50 rounded-lg">
                  <div className="text-center">
                    <LineChart className="w-12 h-12 text-muted-foreground mx-auto mb-2" />
                    <p className="text-muted-foreground">
                      Aylık trend grafiği burada görüntülenecek
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="monthly">
          <Card>
            <CardHeader>
              <CardTitle>Aylık Performans Raporu</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {periods.slice(1, 4).map((period) => {
                  const monthTransactions = extendedTransactions.filter((t) =>
                    t.date.startsWith(period.value),
                  );
                  const monthIncome = monthTransactions
                    .filter((t) => t.amount > 0)
                    .reduce((sum, t) => sum + t.amount, 0);
                  const monthExpenses = Math.abs(
                    monthTransactions
                      .filter((t) => t.amount < 0)
                      .reduce((sum, t) => sum + t.amount, 0),
                  );

                  return (
                    <div
                      key={period.value}
                      className="flex items-center justify-between p-4 border rounded-lg"
                    >
                      <div>
                        <div className="font-medium">{period.label}</div>
                        <div className="text-sm text-muted-foreground">
                          {monthTransactions.length} işlem
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-semibold text-success">
                          +₺{monthIncome.toLocaleString("tr-TR")}
                        </div>
                        <div className="text-sm text-warning">
                          -₺{monthExpenses.toLocaleString("tr-TR")}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="trends">
          <Card>
            <CardHeader>
              <CardTitle>Performans Trendleri</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-3">
                <div className="text-center p-4 bg-muted/50 rounded-lg">
                  <TrendingUp className="w-8 h-8 text-success mx-auto mb-2" />
                  <div className="font-semibold">+15%</div>
                  <div className="text-sm text-muted-foreground">
                    Bu ay gelir artışı
                  </div>
                </div>
                <div className="text-center p-4 bg-muted/50 rounded-lg">
                  <Target className="w-8 h-8 text-info mx-auto mb-2" />
                  <div className="font-semibold">68%</div>
                  <div className="text-sm text-muted-foreground">
                    Hedef tamamlanma
                  </div>
                </div>
                <div className="text-center p-4 bg-muted/50 rounded-lg">
                  <Zap className="w-8 h-8 text-accent mx-auto mb-2" />
                  <div className="font-semibold">42</div>
                  <div className="text-sm text-muted-foreground">
                    Aktif gün sayısı
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
