import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  User,
  Users,
  TrendingUp,
  DollarSign,
  Eye,
  Plus,
  Search,
  Filter,
  Download,
  RotateCcw,
  ZoomIn,
  ZoomOut,
  Maximize,
  GitBranch,
  Star,
  Crown,
  Target,
  Award,
  Activity,
} from "lucide-react";
import {
  User as UserType,
  BinaryTree as BinaryTreeType,
} from "@shared/mlm-types";

interface BinaryTreeProps {
  user: UserType;
}

interface TreeNode {
  id: string;
  name: string;
  username: string;
  email: string;
  rank: string;
  personalVolume: number;
  groupVolume: number;
  directReferrals: number;
  joinDate: string;
  isActive: boolean;
  position: "left" | "right" | "root";
  sponsorId?: string;
  level: number;
  leftChild?: TreeNode;
  rightChild?: TreeNode;
}

export default function BinaryTree({ user }: BinaryTreeProps) {
  const [viewMode, setViewMode] = useState<"2d" | "3d">("2d");
  const [selectedNode, setSelectedNode] = useState<TreeNode | null>(null);
  const [zoomLevel, setZoomLevel] = useState(100);
  const [showInactive, setShowInactive] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [showAddMemberDialog, setShowAddMemberDialog] = useState(false);
  const [showSearchDialog, setShowSearchDialog] = useState(false);
  const [showFilterDialog, setShowFilterDialog] = useState(false);
  const [memberSearchTerm, setMemberSearchTerm] = useState("");
  const [filterCriteria, setFilterCriteria] = useState({
    rank: "all",
    status: "all",
    performance: "all",
  });

  // Sample binary tree data - in real app this would come from API
  const sampleTreeData: TreeNode = {
    id: "1",
    name: user.name,
    username: user.username,
    email: user.email,
    rank: user.rank,
    personalVolume: user.personalVolume,
    groupVolume: user.groupVolume,
    directReferrals: user.directReferrals,
    joinDate: user.joinDate,
    isActive: user.isActive,
    position: "root",
    level: 0,
    leftChild: {
      id: "2",
      name: "Ahmet Yılmaz",
      username: "ahmet_y",
      email: "ahmet@email.com",
      rank: "Bronz",
      personalVolume: 1250,
      groupVolume: 8500,
      directReferrals: 3,
      joinDate: "2023-07-20T00:00:00Z",
      isActive: true,
      position: "left",
      level: 1,
      leftChild: {
        id: "4",
        name: "Elif Kaya",
        username: "elif_k",
        email: "elif@email.com",
        rank: "Başlangıç",
        personalVolume: 750,
        groupVolume: 2100,
        directReferrals: 2,
        joinDate: "2023-08-15T00:00:00Z",
        isActive: true,
        position: "left",
        level: 2,
      },
      rightChild: {
        id: "5",
        name: "Mehmet Özkan",
        username: "mehmet_o",
        email: "mehmet@email.com",
        rank: "Başlangıç",
        personalVolume: 500,
        groupVolume: 1200,
        directReferrals: 1,
        joinDate: "2023-09-01T00:00:00Z",
        isActive: false,
        position: "right",
        level: 2,
      },
    },
    rightChild: {
      id: "3",
      name: "Zeynep Demir",
      username: "zeynep_d",
      email: "zeynep@email.com",
      rank: "Gümüş",
      personalVolume: 3200,
      groupVolume: 15800,
      directReferrals: 5,
      joinDate: "2023-06-30T00:00:00Z",
      isActive: true,
      position: "right",
      level: 1,
      leftChild: {
        id: "6",
        name: "Can Aslan",
        username: "can_a",
        email: "can@email.com",
        rank: "Bronz",
        personalVolume: 1800,
        groupVolume: 4500,
        directReferrals: 2,
        joinDate: "2023-08-10T00:00:00Z",
        isActive: true,
        position: "left",
        level: 2,
      },
      rightChild: {
        id: "7",
        name: "Seda Yıldız",
        username: "seda_y",
        email: "seda@email.com",
        rank: "Başlangıç",
        personalVolume: 650,
        groupVolume: 1800,
        directReferrals: 1,
        joinDate: "2023-09-05T00:00:00Z",
        isActive: true,
        position: "right",
        level: 2,
      },
    },
  };

  const getRankColor = (rank: string) => {
    switch (rank) {
      case "Elmas":
        return "bg-gradient-to-br from-blue-500 to-purple-600 text-white";
      case "Platin":
        return "bg-gradient-to-br from-gray-400 to-gray-600 text-white";
      case "Altın":
        return "bg-gradient-to-br from-yellow-400 to-yellow-600 text-white";
      case "Gümüş":
        return "bg-gradient-to-br from-gray-300 to-gray-500 text-white";
      case "Bronz":
        return "bg-gradient-to-br from-orange-400 to-orange-600 text-white";
      default:
        return "bg-gradient-to-br from-gray-200 to-gray-400 text-gray-800";
    }
  };

  const renderTreeNode = (node: TreeNode, isRoot = false) => {
    if (!showInactive && !node.isActive) return null;

    return (
      <div className="flex flex-col items-center" key={node.id}>
        <Dialog>
          <DialogTrigger asChild>
            <div
              className={`relative cursor-pointer transform transition-all duration-200 hover:scale-105 ${
                isRoot ? "mb-8" : "mb-6"
              }`}
            >
              <div
                className={`w-32 h-40 rounded-lg border-2 ${
                  node.isActive ? "border-primary" : "border-gray-300"
                } bg-card shadow-lg p-3 ${getRankColor(node.rank)}`}
              >
                <div className="flex flex-col items-center text-center h-full">
                  <Avatar className="w-12 h-12 mb-2 border-2 border-white">
                    <AvatarImage src="/placeholder.svg" />
                    <AvatarFallback className="bg-white text-gray-800 font-semibold">
                      {node.name
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </AvatarFallback>
                  </Avatar>
                  <div className="text-xs font-semibold mb-1 truncate w-full">
                    {node.name}
                  </div>
                  <Badge
                    variant="secondary"
                    className="text-xs mb-1 bg-white/20 text-white border-white/30"
                  >
                    {node.rank}
                  </Badge>
                  <div className="text-xs">
                    ₺
                    {node.personalVolume.toLocaleString("tr-TR", {
                      maximumFractionDigits: 0,
                    })}
                  </div>
                </div>
              </div>
              {isRoot && (
                <div className="absolute -top-2 -right-2 w-6 h-6 bg-accent rounded-full flex items-center justify-center">
                  <Crown className="w-3 h-3 text-accent-foreground" />
                </div>
              )}
              {!node.isActive && (
                <div className="absolute inset-0 bg-gray-500/50 rounded-lg flex items-center justify-center">
                  <div className="text-white text-xs font-semibold bg-gray-700 px-2 py-1 rounded">
                    Pasif
                  </div>
                </div>
              )}
            </div>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Avatar className="w-8 h-8">
                  <AvatarImage src="/placeholder.svg" />
                  <AvatarFallback>
                    {node.name
                      .split(" ")
                      .map((n) => n[0])
                      .join("")}
                  </AvatarFallback>
                </Avatar>
                {node.name}
              </DialogTitle>
              <DialogDescription>
                Üye detayları ve performans bilgileri
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-muted-foreground">
                    Kullanıcı Adı
                  </label>
                  <div className="font-semibold">{node.username}</div>
                </div>
                <div>
                  <label className="text-sm font-medium text-muted-foreground">
                    Rütbe
                  </label>
                  <div>
                    <Badge variant="secondary">{node.rank}</Badge>
                  </div>
                </div>
                <div>
                  <label className="text-sm font-medium text-muted-foreground">
                    Kişisel Hacim
                  </label>
                  <div className="font-semibold">
                    ₺{node.personalVolume.toLocaleString("tr-TR")}
                  </div>
                </div>
                <div>
                  <label className="text-sm font-medium text-muted-foreground">
                    Grup Hacmi
                  </label>
                  <div className="font-semibold">
                    ₺{node.groupVolume.toLocaleString("tr-TR")}
                  </div>
                </div>
                <div>
                  <label className="text-sm font-medium text-muted-foreground">
                    Direkt Referanslar
                  </label>
                  <div className="font-semibold">{node.directReferrals}</div>
                </div>
                <div>
                  <label className="text-sm font-medium text-muted-foreground">
                    Durum
                  </label>
                  <div>
                    <Badge variant={node.isActive ? "default" : "secondary"}>
                      {node.isActive ? "Aktif" : "Pasif"}
                    </Badge>
                  </div>
                </div>
              </div>
              <div>
                <label className="text-sm font-medium text-muted-foreground">
                  Katılım Tarihi
                </label>
                <div className="font-semibold">
                  {new Date(node.joinDate).toLocaleDateString("tr-TR")}
                </div>
              </div>
              <div>
                <label className="text-sm font-medium text-muted-foreground">
                  Pozisyon
                </label>
                <div className="font-semibold capitalize">
                  {node.position === "root"
                    ? "Ana Kullanıcı"
                    : node.position === "left"
                      ? "Sol Bacak"
                      : "Sağ Bacak"}
                </div>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Connection Lines */}
        {(node.leftChild || node.rightChild) && (
          <div className="relative">
            <div className="w-px h-6 bg-border mx-auto"></div>
            <div className="flex items-center justify-center">
              <div className="w-16 h-px bg-border"></div>
              <div className="w-2 h-2 bg-border rounded-full"></div>
              <div className="w-16 h-px bg-border"></div>
            </div>
            <div className="flex justify-between w-32">
              <div className="w-px h-6 bg-border"></div>
              <div className="w-px h-6 bg-border"></div>
            </div>
          </div>
        )}

        {/* Child Nodes */}
        {(node.leftChild || node.rightChild) && (
          <div className="flex justify-between space-x-8">
            <div className="flex flex-col items-center">
              {node.leftChild ? (
                renderTreeNode(node.leftChild)
              ) : (
                <div className="w-32 h-40 rounded-lg border-2 border-dashed border-gray-300 bg-gray-50 flex flex-col items-center justify-center cursor-pointer hover:bg-gray-100 transition-colors">
                  <Plus className="w-8 h-8 text-gray-400 mb-2" />
                  <span className="text-xs text-gray-500">Sol Pozisyon</span>
                  <span className="text-xs text-gray-500">Boş</span>
                </div>
              )}
            </div>
            <div className="flex flex-col items-center">
              {node.rightChild ? (
                renderTreeNode(node.rightChild)
              ) : (
                <div className="w-32 h-40 rounded-lg border-2 border-dashed border-gray-300 bg-gray-50 flex flex-col items-center justify-center cursor-pointer hover:bg-gray-100 transition-colors">
                  <Plus className="w-8 h-8 text-gray-400 mb-2" />
                  <span className="text-xs text-gray-500">Sağ Pozisyon</span>
                  <span className="text-xs text-gray-500">Boş</span>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    );
  };

  const calculateTreeStats = (node: TreeNode): any => {
    let totalNodes = 1;
    let activeNodes = node.isActive ? 1 : 0;
    let totalVolume = node.personalVolume;
    let leftVolume = 0;
    let rightVolume = 0;
    let maxDepth = 0;

    const traverse = (currentNode: TreeNode, depth: number) => {
      maxDepth = Math.max(maxDepth, depth);

      if (currentNode.leftChild) {
        totalNodes++;
        if (currentNode.leftChild.isActive) activeNodes++;
        leftVolume += currentNode.leftChild.personalVolume;
        traverse(currentNode.leftChild, depth + 1);
      }

      if (currentNode.rightChild) {
        totalNodes++;
        if (currentNode.rightChild.isActive) activeNodes++;
        rightVolume += currentNode.rightChild.personalVolume;
        traverse(currentNode.rightChild, depth + 1);
      }
    };

    traverse(node, 0);

    return {
      totalNodes,
      activeNodes,
      totalVolume: totalVolume + leftVolume + rightVolume,
      leftVolume,
      rightVolume,
      maxDepth,
      balanceRatio:
        leftVolume > 0 && rightVolume > 0
          ? Math.min(leftVolume, rightVolume) /
            Math.max(leftVolume, rightVolume)
          : 0,
    };
  };

  const treeStats = calculateTreeStats(sampleTreeData);

  return (
    <div className="space-y-6">
      {/* Tree Controls */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <GitBranch className="w-5 h-5 text-primary" />
                Binary Ağaç Yönetimi
              </CardTitle>
              <CardDescription>
                Ekibinizi görüntüleyin ve yönetin
              </CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setViewMode(viewMode === "2d" ? "3d" : "2d")}
              >
                {viewMode === "2d" ? "3D Görünüm" : "2D Görünüm"}
              </Button>
              <Button variant="outline" size="sm">
                <Download className="w-4 h-4 mr-2" />
                Export
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setZoomLevel(Math.max(50, zoomLevel - 10))}
                  disabled={zoomLevel <= 50}
                >
                  <ZoomOut className="w-4 h-4" />
                </Button>
                <span className="text-sm font-medium">{zoomLevel}%</span>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setZoomLevel(Math.min(200, zoomLevel + 10))}
                  disabled={zoomLevel >= 200}
                >
                  <ZoomIn className="w-4 h-4" />
                </Button>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowInactive(!showInactive)}
              >
                {showInactive ? "Pasifleri Gizle" : "Pasifleri Göster"}
              </Button>
            </div>
          </div>

          {/* Tree Statistics */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            <div className="text-center p-3 bg-primary/10 rounded-lg">
              <div className="text-2xl font-bold text-primary">
                {treeStats.totalNodes}
              </div>
              <div className="text-sm text-muted-foreground">Toplam Üye</div>
            </div>
            <div className="text-center p-3 bg-success/10 rounded-lg">
              <div className="text-2xl font-bold text-success">
                {treeStats.activeNodes}
              </div>
              <div className="text-sm text-muted-foreground">Aktif Üye</div>
            </div>
            <div className="text-center p-3 bg-accent/10 rounded-lg">
              <div className="text-2xl font-bold text-accent">
                ₺{treeStats.totalVolume.toLocaleString("tr-TR")}
              </div>
              <div className="text-sm text-muted-foreground">Toplam Hacim</div>
            </div>
            <div className="text-center p-3 bg-info/10 rounded-lg">
              <div className="text-2xl font-bold text-info">
                {treeStats.maxDepth}
              </div>
              <div className="text-sm text-muted-foreground">Max Derinlik</div>
            </div>
          </div>

          {/* Binary Balance */}
          <div className="grid grid-cols-3 gap-4 mb-6">
            <div className="text-center p-4 bg-info/10 rounded-lg">
              <div className="text-xl font-bold text-info">
                ₺{treeStats.leftVolume.toLocaleString("tr-TR")}
              </div>
              <div className="text-sm text-muted-foreground">
                Sol Bacak Hacmi
              </div>
            </div>
            <div className="text-center p-4 bg-accent/10 rounded-lg">
              <div className="text-xl font-bold text-accent">
                %{Math.round(treeStats.balanceRatio * 100)}
              </div>
              <div className="text-sm text-muted-foreground">Denge Oranı</div>
            </div>
            <div className="text-center p-4 bg-warning/10 rounded-lg">
              <div className="text-xl font-bold text-warning">
                ₺{treeStats.rightVolume.toLocaleString("tr-TR")}
              </div>
              <div className="text-sm text-muted-foreground">
                Sağ Bacak Hacmi
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Binary Tree Visualization */}
      <Card>
        <CardContent className="p-6">
          <div
            className="overflow-auto max-h-[800px] bg-gradient-to-br from-blue-50 to-indigo-50 rounded-lg p-6"
            style={{
              transform: `scale(${zoomLevel / 100})`,
              transformOrigin: "top center",
            }}
          >
            {renderTreeNode(sampleTreeData, true)}
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center gap-2">
              <Users className="w-5 h-5 text-primary" />
              Hızlı İşlemler
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <Button
              variant="outline"
              className="w-full justify-start"
              onClick={() => setShowAddMemberDialog(true)}
            >
              <Plus className="w-4 h-4 mr-2" />
              Yeni Üye Ekle
            </Button>
            <Button
              variant="outline"
              className="w-full justify-start"
              onClick={() => setShowSearchDialog(true)}
            >
              <Search className="w-4 h-4 mr-2" />
              Üye Ara
            </Button>
            <Button
              variant="outline"
              className="w-full justify-start"
              onClick={() => setShowFilterDialog(true)}
            >
              <Filter className="w-4 h-4 mr-2" />
              Filtrele
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-success" />
              Performans
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between">
              <span className="text-sm text-muted-foreground">
                Bu Ay Büyüme
              </span>
              <span className="text-sm font-semibold text-success">+12%</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-muted-foreground">
                Eşleşen Hacim
              </span>
              <span className="text-sm font-semibold">
                ₺
                {Math.min(
                  treeStats.leftVolume,
                  treeStats.rightVolume,
                ).toLocaleString("tr-TR")}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-muted-foreground">
                Potansiyel Bonus
              </span>
              <span className="text-sm font-semibold text-accent">₺1,245</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center gap-2">
              <Target className="w-5 h-5 text-warning" />
              Hedefler
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>Sol Bacak Hedefi</span>
                <span>
                  ₺{treeStats.leftVolume.toLocaleString("tr-TR")} / ₺25,000
                </span>
              </div>
              <div className="w-full bg-muted rounded-full h-2">
                <div
                  className="bg-info h-2 rounded-full"
                  style={{
                    width: `${Math.min(100, (treeStats.leftVolume / 25000) * 100)}%`,
                  }}
                ></div>
              </div>
            </div>
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>Sağ Bacak Hedefi</span>
                <span>
                  ₺{treeStats.rightVolume.toLocaleString("tr-TR")} / ₺25,000
                </span>
              </div>
              <div className="w-full bg-muted rounded-full h-2">
                <div
                  className="bg-warning h-2 rounded-full"
                  style={{
                    width: `${Math.min(100, (treeStats.rightVolume / 25000) * 100)}%`,
                  }}
                ></div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Add Member Dialog */}
      <Dialog open={showAddMemberDialog} onOpenChange={setShowAddMemberDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Plus className="w-5 h-5 text-primary" />
              Yeni Üye Ekle
            </DialogTitle>
            <DialogDescription>
              Ekibinize yeni üye ekleyin ve binary pozisyonunu belirleyin
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Ad Soyad</label>
              <input
                type="text"
                placeholder="Üye adı ve soyadı"
                className="w-full px-3 py-2 border border-border rounded-md"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">E-posta</label>
              <input
                type="email"
                placeholder="uye@email.com"
                className="w-full px-3 py-2 border border-border rounded-md"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Telefon</label>
              <input
                type="tel"
                placeholder="+90 555 123 4567"
                className="w-full px-3 py-2 border border-border rounded-md"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Binary Pozisyon</label>
              <select className="w-full px-3 py-2 border border-border rounded-md">
                <option value="">Pozisyon seçin</option>
                <option value="left">Sol Bacak</option>
                <option value="right">Sağ Bacak</option>
              </select>
            </div>
          </div>
          <div className="flex justify-end space-x-2 mt-6">
            <Button
              variant="outline"
              onClick={() => setShowAddMemberDialog(false)}
            >
              İptal
            </Button>
            <Button
              onClick={() => {
                // Here you would normally call an API to add the member
                alert("Yeni üye ekleme işlemi simüle edildi!");
                setShowAddMemberDialog(false);
              }}
            >
              Üye Ekle
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Search Member Dialog */}
      <Dialog open={showSearchDialog} onOpenChange={setShowSearchDialog}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Search className="w-5 h-5 text-primary" />
              Üye Ara
            </DialogTitle>
            <DialogDescription>
              Ekibinizdeki üyeleri arayın ve bilgilerini görüntüleyin
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Arama</label>
              <input
                type="text"
                placeholder="Ad, soyad, kullanıcı adı veya e-posta ile arayın"
                value={memberSearchTerm}
                onChange={(e) => setMemberSearchTerm(e.target.value)}
                className="w-full px-3 py-2 border border-border rounded-md"
              />
            </div>
            <div className="max-h-64 overflow-y-auto space-y-2">
              <div className="text-sm text-muted-foreground mb-2">
                Arama sonuçları:
              </div>
              {memberSearchTerm ? (
                // Sample search results
                [
                  {
                    name: "Ahmet Yılmaz",
                    username: "ahmet_y",
                    rank: "Bronz",
                    status: "Aktif",
                  },
                  {
                    name: "Zeynep Demir",
                    username: "zeynep_d",
                    rank: "Gümüş",
                    status: "Aktif",
                  },
                  {
                    name: "Mehmet Özkan",
                    username: "mehmet_o",
                    rank: "Başlangıç",
                    status: "Pasif",
                  },
                ]
                  .filter(
                    (member) =>
                      member.name
                        .toLowerCase()
                        .includes(memberSearchTerm.toLowerCase()) ||
                      member.username
                        .toLowerCase()
                        .includes(memberSearchTerm.toLowerCase()),
                  )
                  .map((member, index) => (
                    <div
                      key={index}
                      className="flex items-center justify-between p-3 border rounded-lg hover:bg-muted/50"
                    >
                      <div>
                        <div className="font-medium">{member.name}</div>
                        <div className="text-sm text-muted-foreground">
                          @{member.username}
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-sm font-medium">{member.rank}</div>
                        <div
                          className={`text-xs ${member.status === "Aktif" ? "text-success" : "text-warning"}`}
                        >
                          {member.status}
                        </div>
                      </div>
                    </div>
                  ))
              ) : (
                <div className="text-center text-muted-foreground py-4">
                  Aramaya başlamak için yukarıdaki alana yazın
                </div>
              )}
            </div>
          </div>
          <div className="flex justify-end space-x-2 mt-6">
            <Button
              variant="outline"
              onClick={() => setShowSearchDialog(false)}
            >
              Kapat
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Filter Dialog */}
      <Dialog open={showFilterDialog} onOpenChange={setShowFilterDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Filter className="w-5 h-5 text-primary" />
              Üye Filtrele
            </DialogTitle>
            <DialogDescription>
              Ekip üyelerinizi belirli kriterlere göre filtreleyin
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Rütbe</label>
              <select
                value={filterCriteria.rank}
                onChange={(e) =>
                  setFilterCriteria({ ...filterCriteria, rank: e.target.value })
                }
                className="w-full px-3 py-2 border border-border rounded-md"
              >
                <option value="all">Tüm Rütbeler</option>
                <option value="Başlangıç">Başlangıç</option>
                <option value="Bronz">Bronz</option>
                <option value="Gümüş">Gümüş</option>
                <option value="Altın">Altın</option>
                <option value="Platin">Platin</option>
                <option value="Elmas">Elmas</option>
              </select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Durum</label>
              <select
                value={filterCriteria.status}
                onChange={(e) =>
                  setFilterCriteria({
                    ...filterCriteria,
                    status: e.target.value,
                  })
                }
                className="w-full px-3 py-2 border border-border rounded-md"
              >
                <option value="all">Tüm Durumlar</option>
                <option value="active">Aktif Üyeler</option>
                <option value="inactive">Pasif Üyeler</option>
              </select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Performans</label>
              <select
                value={filterCriteria.performance}
                onChange={(e) =>
                  setFilterCriteria({
                    ...filterCriteria,
                    performance: e.target.value,
                  })
                }
                className="w-full px-3 py-2 border border-border rounded-md"
              >
                <option value="all">Tüm Performanslar</option>
                <option value="high">Yüksek Performans</option>
                <option value="medium">Orta Performans</option>
                <option value="low">Düşük Performans</option>
              </select>
            </div>
            <div className="p-3 bg-info/10 rounded-lg">
              <div className="text-sm">
                <strong>Aktif Filtreler:</strong>
                <ul className="mt-1 space-y-1">
                  {filterCriteria.rank !== "all" && (
                    <li>• Rütbe: {filterCriteria.rank}</li>
                  )}
                  {filterCriteria.status !== "all" && (
                    <li>
                      • Durum:{" "}
                      {filterCriteria.status === "active" ? "Aktif" : "Pasif"}
                    </li>
                  )}
                  {filterCriteria.performance !== "all" && (
                    <li>
                      • Performans:{" "}
                      {filterCriteria.performance === "high"
                        ? "Yüksek"
                        : filterCriteria.performance === "medium"
                          ? "Orta"
                          : "Düşük"}
                    </li>
                  )}
                </ul>
                {filterCriteria.rank === "all" &&
                  filterCriteria.status === "all" &&
                  filterCriteria.performance === "all" && (
                    <span>Hiçbir filtre uygulanmadı</span>
                  )}
              </div>
            </div>
          </div>
          <div className="flex justify-end space-x-2 mt-6">
            <Button
              variant="outline"
              onClick={() => {
                setFilterCriteria({
                  rank: "all",
                  status: "all",
                  performance: "all",
                });
              }}
            >
              Temizle
            </Button>
            <Button
              onClick={() => {
                // Here you would apply the filters to the tree display
                alert("Filtreler uygulandı! Ekip ağacı güncellenecek.");
                setShowFilterDialog(false);
              }}
            >
              Filtreleri Uygula
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
