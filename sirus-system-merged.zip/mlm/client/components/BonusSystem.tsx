import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  TrendingUp,
  DollarSign,
  Users,
  Crown,
  Gift,
  Zap,
  Target,
  Award,
  Calculator,
  Calendar,
  Filter,
  Download,
  Info,
  Star,
  Network,
  Infinity,
  TrendingDown,
  BarChart3,
  PieChart,
  Activity,
  RefreshCw,
} from "lucide-react";
import { User, Bonus, RANKS } from "@shared/mlm-types";

interface BonusSystemProps {
  user: User;
}

export default function BonusSystem({ user }: BonusSystemProps) {
  const [selectedPeriod, setSelectedPeriod] = useState("2024-01");
  const [selectedBonusType, setSelectedBonusType] = useState("all");
  const [showCalculator, setShowCalculator] = useState(false);

  // Sample bonus data - in real app this would come from API
  const sampleBonuses: Bonus[] = [
    {
      id: "1",
      userId: user.id,
      type: "binary",
      amount: 1250.5,
      percentage: 12,
      period: "2024-01",
      date: "2024-01-31T00:00:00Z",
      status: "paid",
      calculationData: {
        leftLeg: 15000,
        rightLeg: 18000,
        matched: 15000,
        rate: 0.12,
      },
    },
    {
      id: "2",
      userId: user.id,
      type: "sponsor",
      amount: 850.0,
      percentage: 20,
      fromUserId: "user2",
      fromUserName: "Ahmet Yılmaz",
      period: "2024-01",
      date: "2024-01-15T00:00:00Z",
      status: "paid",
      calculationData: {
        referralVolume: 4250,
        rate: 0.2,
      },
    },
    {
      id: "3",
      userId: user.id,
      type: "leadership",
      amount: 425.0,
      percentage: 5,
      period: "2024-01",
      date: "2024-01-31T00:00:00Z",
      status: "paid",
      calculationData: {
        teamVolume: 8500,
        rate: 0.05,
        generations: 3,
      },
    },
    {
      id: "4",
      userId: user.id,
      type: "sales",
      amount: 320.0,
      percentage: 8,
      period: "2024-01",
      date: "2024-01-20T00:00:00Z",
      status: "paid",
      calculationData: {
        personalSales: 4000,
        rate: 0.08,
      },
    },
    {
      id: "5",
      userId: user.id,
      type: "rank",
      amount: 1500.0,
      percentage: 0,
      period: "2024-01",
      date: "2024-01-31T00:00:00Z",
      status: "paid",
      calculationData: {
        rank: "Gümüş",
        rankBonus: 1500,
      },
    },
    {
      id: "6",
      userId: user.id,
      type: "binary",
      amount: 980.25,
      percentage: 12,
      period: "2024-02",
      date: "2024-02-15T00:00:00Z",
      status: "pending",
      calculationData: {
        leftLeg: 12500,
        rightLeg: 14200,
        matched: 12500,
        rate: 0.12,
      },
    },
  ];

  const bonusTypes = [
    {
      id: "binary",
      name: "Binary Bonus",
      description: "Eşleşme bonusu - Sol ve sağ bacak hacmi eşleşmesi",
      icon: BarChart3,
      color: "text-blue-600",
      bgColor: "bg-blue-100",
    },
    {
      id: "sponsor",
      name: "Sponsor Bonus",
      description:
        "Direkt referans bonusu - Doğrudan davet ettiğiniz üyelerden",
      icon: Users,
      color: "text-green-600",
      bgColor: "bg-green-100",
    },
    {
      id: "leadership",
      name: "Leadership Bonus",
      description: "Liderlik bonusu - Ekibinizin performansından",
      icon: Crown,
      color: "text-purple-600",
      bgColor: "bg-purple-100",
    },
    {
      id: "sales",
      name: "Sales Bonus",
      description: "Satış bonusu - Kişisel satış hacminizden",
      icon: TrendingUp,
      color: "text-orange-600",
      bgColor: "bg-orange-100",
    },
    {
      id: "rank",
      name: "Rank Bonus",
      description: "Rütbe bonusu - Aylık rütbe ödülü",
      icon: Award,
      color: "text-yellow-600",
      bgColor: "bg-yellow-100",
    },
    {
      id: "matching",
      name: "Matching Bonus",
      description: "Eşleştirme bonusu - Alt seviye binary bonuslarından",
      icon: Target,
      color: "text-indigo-600",
      bgColor: "bg-indigo-100",
    },
  ];

  const periods = [
    { value: "2024-02", label: "Şubat 2024" },
    { value: "2024-01", label: "Ocak 2024" },
    { value: "2023-12", label: "Aralık 2023" },
    { value: "2023-11", label: "Kasım 2023" },
  ];

  const filteredBonuses = sampleBonuses.filter((bonus) => {
    const periodMatch = bonus.period === selectedPeriod;
    const typeMatch =
      selectedBonusType === "all" || bonus.type === selectedBonusType;
    return periodMatch && typeMatch;
  });

  const calculateTotalBonuses = () => {
    return filteredBonuses.reduce((total, bonus) => total + bonus.amount, 0);
  };

  const getBonusTypeStats = () => {
    const stats = bonusTypes.map((type) => {
      const typeBonuses = filteredBonuses.filter(
        (bonus) => bonus.type === type.id,
      );
      const total = typeBonuses.reduce((sum, bonus) => sum + bonus.amount, 0);
      const count = typeBonuses.length;
      return { ...type, total, count };
    });
    return stats;
  };

  const getCurrentRank = () => {
    return RANKS.find((rank) => rank.name === user.rank) || RANKS[0];
  };

  const renderBonusCalculator = () => {
    const currentRank = getCurrentRank();
    return (
      <Dialog open={showCalculator} onOpenChange={setShowCalculator}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Calculator className="w-5 h-5" />
              Bonus Hesaplayıcı
            </DialogTitle>
            <DialogDescription>
              Potansiyel bonuslarınızı hesaplayın
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-6">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-4">
                <h4 className="font-semibold">Binary Bonus</h4>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Sol Bacak Hacmi:</span>
                    <span>₺{user.leftLegVolume.toLocaleString("tr-TR")}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Sağ Bacak Hacmi:</span>
                    <span>₺{user.rightLegVolume.toLocaleString("tr-TR")}</span>
                  </div>
                  <div className="flex justify-between text-sm font-semibold">
                    <span>Eşleşen Hacim:</span>
                    <span>
                      ₺
                      {Math.min(
                        user.leftLegVolume,
                        user.rightLegVolume,
                      ).toLocaleString("tr-TR")}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Bonus Oranı ({user.rank}):</span>
                    <span>%{currentRank.benefits.binaryBonusRate * 100}</span>
                  </div>
                  <div className="flex justify-between font-semibold text-blue-600">
                    <span>Tahmini Binary Bonus:</span>
                    <span>
                      ₺
                      {(
                        Math.min(user.leftLegVolume, user.rightLegVolume) *
                        currentRank.benefits.binaryBonusRate
                      ).toLocaleString("tr-TR", { maximumFractionDigits: 2 })}
                    </span>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <h4 className="font-semibold">Sponsor Bonus</h4>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Direkt Referanslar:</span>
                    <span>{user.directReferrals}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Ortalama Hacim/Kişi:</span>
                    <span>
                      ₺
                      {user.directReferrals > 0
                        ? Math.round(
                            user.personalVolume / user.directReferrals,
                          ).toLocaleString("tr-TR")
                        : "0"}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Bonus Oranı:</span>
                    <span>%{currentRank.benefits.sponsorBonusRate * 100}</span>
                  </div>
                  <div className="flex justify-between font-semibold text-green-600">
                    <span>Tahmini Sponsor Bonus:</span>
                    <span>
                      ₺
                      {(
                        user.personalVolume *
                        currentRank.benefits.sponsorBonusRate
                      ).toLocaleString("tr-TR", { maximumFractionDigits: 2 })}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="font-semibold">Rütbe Bonus Bilgileri</h4>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="text-sm text-muted-foreground mb-2">
                    Mevcut Rütbe: {user.rank}
                  </div>
                  <div className="space-y-1 text-sm">
                    <div className="flex justify-between">
                      <span>Aylık Rütbe Bonusu:</span>
                      <span className="font-semibold">
                        ₺
                        {currentRank.benefits.rankBonus.toLocaleString("tr-TR")}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>Liderlik Bonus Oranı:</span>
                      <span>
                        %{currentRank.benefits.leadershipBonusRate * 100}
                      </span>
                    </div>
                    {currentRank.benefits.carBonus && (
                      <div className="flex justify-between">
                        <span>Araç Bonusu:</span>
                        <span className="font-semibold">
                          ₺
                          {currentRank.benefits.carBonus.toLocaleString(
                            "tr-TR",
                          )}
                        </span>
                      </div>
                    )}
                  </div>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground mb-2">
                    Toplam Aylık Potansiyel
                  </div>
                  <div className="text-2xl font-bold text-primary">
                    ₺
                    {(
                      Math.min(user.leftLegVolume, user.rightLegVolume) *
                        currentRank.benefits.binaryBonusRate +
                      user.personalVolume *
                        currentRank.benefits.sponsorBonusRate +
                      user.groupVolume *
                        currentRank.benefits.leadershipBonusRate +
                      currentRank.benefits.rankBonus
                    ).toLocaleString("tr-TR", { maximumFractionDigits: 2 })}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    );
  };

  return (
    <div className="space-y-6">
      {/* Header and Controls */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-primary" />
                Bonus Yönetim Sistemi
              </CardTitle>
              <CardDescription>
                Binary MLM bonus sisteminizdeki tüm kazançlarınız
              </CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline" onClick={() => setShowCalculator(true)}>
                <Calculator className="w-4 h-4 mr-2" />
                Hesaplayıcı
              </Button>
              <Button variant="outline">
                <Download className="w-4 h-4 mr-2" />
                Export
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4 mb-6">
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {periods.map((period) => (
                    <SelectItem key={period.value} value={period.value}>
                      {period.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4" />
              <Select
                value={selectedBonusType}
                onValueChange={setSelectedBonusType}
              >
                <SelectTrigger className="w-48">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tüm Bonuslar</SelectItem>
                  {bonusTypes.map((type) => (
                    <SelectItem key={type.id} value={type.id}>
                      {type.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Summary Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center p-4 bg-primary/10 rounded-lg">
              <div className="text-2xl font-bold text-primary">
                ₺{calculateTotalBonuses().toLocaleString("tr-TR")}
              </div>
              <div className="text-sm text-muted-foreground">Toplam Bonus</div>
            </div>
            <div className="text-center p-4 bg-success/10 rounded-lg">
              <div className="text-2xl font-bold text-success">
                {filteredBonuses.filter((b) => b.status === "paid").length}
              </div>
              <div className="text-sm text-muted-foreground">
                Ödenen Bonuslar
              </div>
            </div>
            <div className="text-center p-4 bg-warning/10 rounded-lg">
              <div className="text-2xl font-bold text-warning">
                {filteredBonuses.filter((b) => b.status === "pending").length}
              </div>
              <div className="text-sm text-muted-foreground">
                Bekleyen Bonuslar
              </div>
            </div>
            <div className="text-center p-4 bg-accent/10 rounded-lg">
              <div className="text-2xl font-bold text-accent">
                ₺
                {(
                  calculateTotalBonuses() / Math.max(filteredBonuses.length, 1)
                ).toLocaleString("tr-TR", { maximumFractionDigits: 0 })}
              </div>
              <div className="text-sm text-muted-foreground">
                Ortalama Bonus
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Genel Bakış</TabsTrigger>
          <TabsTrigger value="details">Detaylar</TabsTrigger>
          <TabsTrigger value="calculator">Hesaplayıcı</TabsTrigger>
          <TabsTrigger value="history">Geçmiş</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {/* Bonus Types Overview */}
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {getBonusTypeStats().map((type) => {
              const Icon = type.icon;
              return (
                <Card key={type.id} className="relative overflow-hidden">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <div className={`p-2 rounded-lg ${type.bgColor}`}>
                        <Icon className={`w-5 h-5 ${type.color}`} />
                      </div>
                      <Badge variant="outline">{type.count} işlem</Badge>
                    </div>
                    <CardTitle className="text-lg">{type.name}</CardTitle>
                    <CardDescription className="text-sm">
                      {type.description}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold mb-2">
                      ₺{type.total.toLocaleString("tr-TR")}
                    </div>
                    <div className="flex items-center justify-between text-sm text-muted-foreground">
                      <span>Bu dönem</span>
                      <span>
                        %
                        {calculateTotalBonuses() > 0
                          ? Math.round(
                              (type.total / calculateTotalBonuses()) * 100,
                            )
                          : 0}{" "}
                        pay
                      </span>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* Performance Chart Placeholder */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <PieChart className="w-5 h-5" />
                Bonus Dağılımı
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64 flex items-center justify-center bg-muted/50 rounded-lg">
                <div className="text-center">
                  <Activity className="w-12 h-12 text-muted-foreground mx-auto mb-2" />
                  <p className="text-muted-foreground">
                    Bonus dağılım grafiği burada görüntülenecek
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="details" className="space-y-6">
          {/* Detailed Bonus Table */}
          <Card>
            <CardHeader>
              <CardTitle>Detaylı Bonus Listesi</CardTitle>
              <CardDescription>
                {selectedPeriod} dönemine ait bonus detayları
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Tarih</TableHead>
                    <TableHead>Tip</TableHead>
                    <TableHead>Açıklama</TableHead>
                    <TableHead>Miktar</TableHead>
                    <TableHead>Durum</TableHead>
                    <TableHead>Detay</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredBonuses.map((bonus) => {
                    const bonusType = bonusTypes.find(
                      (t) => t.id === bonus.type,
                    );
                    const Icon = bonusType?.icon || DollarSign;
                    return (
                      <TableRow key={bonus.id}>
                        <TableCell>
                          {new Date(bonus.date).toLocaleDateString("tr-TR")}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Icon className="w-4 h-4" />
                            {bonusType?.name}
                          </div>
                        </TableCell>
                        <TableCell>
                          {bonus.fromUserName ||
                            bonusType?.description.split(" - ")[0]}
                        </TableCell>
                        <TableCell className="font-semibold">
                          ₺{bonus.amount.toLocaleString("tr-TR")}
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant={
                              bonus.status === "paid"
                                ? "default"
                                : bonus.status === "pending"
                                  ? "secondary"
                                  : "destructive"
                            }
                          >
                            {bonus.status === "paid"
                              ? "Ödendi"
                              : bonus.status === "pending"
                                ? "Bekliyor"
                                : "İptal"}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button variant="ghost" size="sm">
                                <Info className="w-4 h-4" />
                              </Button>
                            </DialogTrigger>
                            <DialogContent>
                              <DialogHeader>
                                <DialogTitle>
                                  Bonus Hesaplama Detayı
                                </DialogTitle>
                                <DialogDescription>
                                  {bonusType?.name} hesaplama bilgileri
                                </DialogDescription>
                              </DialogHeader>
                              <div className="space-y-3">
                                <div className="bg-muted p-3 rounded-lg">
                                  <pre className="text-sm">
                                    {JSON.stringify(
                                      bonus.calculationData,
                                      null,
                                      2,
                                    )}
                                  </pre>
                                </div>
                                <div className="text-sm text-muted-foreground">
                                  Bu bonus, {bonusType?.description} kuralları
                                  kapsamında hesaplanmıştır.
                                </div>
                              </div>
                            </DialogContent>
                          </Dialog>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="calculator">
          <Card>
            <CardContent className="p-6">
              <div className="text-center">
                <Calculator className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">
                  Bonus Hesaplayıcı
                </h3>
                <p className="text-muted-foreground mb-4">
                  Potansiyel bonuslarınızı hesaplamak için hesaplayıcıyı açın
                </p>
                <Button onClick={() => setShowCalculator(true)}>
                  <Calculator className="w-4 h-4 mr-2" />
                  Hesaplayıcıyı Aç
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history">
          <Card>
            <CardHeader>
              <CardTitle>Bonus Geçmişi</CardTitle>
              <CardDescription>
                Tüm dönemlere ait bonus geçmişiniz
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {periods.map((period) => {
                  const periodBonuses = sampleBonuses.filter(
                    (b) => b.period === period.value,
                  );
                  const total = periodBonuses.reduce(
                    (sum, b) => sum + b.amount,
                    0,
                  );
                  return (
                    <div
                      key={period.value}
                      className="flex items-center justify-between p-4 border rounded-lg"
                    >
                      <div>
                        <div className="font-medium">{period.label}</div>
                        <div className="text-sm text-muted-foreground">
                          {periodBonuses.length} bonus işlemi
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-semibold">
                          ₺{total.toLocaleString("tr-TR")}
                        </div>
                        <div className="text-sm text-muted-foreground">
                          Toplam kazanç
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {renderBonusCalculator()}
    </div>
  );
}
