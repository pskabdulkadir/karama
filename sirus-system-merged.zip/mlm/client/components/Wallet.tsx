import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Wallet as WalletIcon,
  CreditCard,
  ArrowUpRight,
  ArrowDownRight,
  Send,
  Download,
  History,
  DollarSign,
  TrendingUp,
  TrendingDown,
  Copy,
  Check,
  AlertCircle,
  Shield,
  Zap,
  Building,
  QrCode,
  RefreshCw,
  Eye,
  EyeOff,
  Banknote,
  Coins,
  Star,
  Gift,
} from "lucide-react";
import { Wallet as WalletType, Transaction } from "@shared/mlm-types";

interface WalletProps {
  wallet: WalletType;
  transactions: Transaction[];
}

export default function Wallet({ wallet, transactions }: WalletProps) {
  const [withdrawAmount, setWithdrawAmount] = useState("");
  const [depositAmount, setDepositAmount] = useState("");
  const [selectedCurrency, setSelectedCurrency] = useState("TRY");
  const [bankAccount, setBankAccount] = useState("");
  const [showBalance, setShowBalance] = useState(true);
  const [qrCodeCopied, setQrCodeCopied] = useState(false);

  const currencies = [
    { code: "TRY", symbol: "₺", name: "Türk Lirası", flag: "🇹🇷" },
    { code: "USD", symbol: "$", name: "US Dollar", flag: "🇺🇸" },
    { code: "EUR", symbol: "€", name: "Euro", flag: "🇪🇺" },
  ];

  const withdrawalMethods = [
    {
      id: "bank",
      name: "Banka Transferi",
      icon: Building,
      fee: "₺5",
      time: "1-3 iş günü",
    },
    {
      id: "card",
      name: "Kredi/Banka Kartı",
      icon: CreditCard,
      fee: "%2",
      time: "Anında",
    },
    {
      id: "crypto",
      name: "Kripto Para",
      icon: Coins,
      fee: "₺10",
      time: "5-15 dakika",
    },
  ];

  const depositMethods = [
    {
      id: "bank",
      name: "Banka Transferi",
      icon: Building,
      fee: "Ücretsiz",
      time: "1-2 saat",
    },
    {
      id: "card",
      name: "Kredi/Banka Kartı",
      icon: CreditCard,
      fee: "%1.5",
      time: "Anında",
    },
    {
      id: "crypto",
      name: "Kripto Para",
      icon: Coins,
      fee: "Network fee",
      time: "5-30 dakika",
    },
  ];

  const quickAmounts = [100, 250, 500, 1000, 2500, 5000];

  const handleQuickAmount = (amount: number, type: "withdraw" | "deposit") => {
    if (type === "withdraw") {
      setWithdrawAmount(amount.toString());
    } else {
      setDepositAmount(amount.toString());
    }
  };

  const formatCurrency = (amount: number, currency: string) => {
    const currencyData = currencies.find((c) => c.code === currency);
    return `${currencyData?.symbol}${amount.toLocaleString("tr-TR", {
      minimumFractionDigits: 2,
    })}`;
  };

  const copyWalletAddress = async () => {
    const walletAddress = "0x742d35Cc6531C0532C5a29B85a11567D56Baea52";
    await navigator.clipboard.writeText(walletAddress);
    setQrCodeCopied(true);
    setTimeout(() => setQrCodeCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Wallet Overview */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card className="border-2 border-primary/20 bg-gradient-to-br from-primary/5 to-primary/10">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Toplam Bakiye</CardTitle>
            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowBalance(!showBalance)}
                className="p-1 h-6 w-6"
              >
                {showBalance ? (
                  <Eye className="h-3 w-3" />
                ) : (
                  <EyeOff className="h-3 w-3" />
                )}
              </Button>
              <WalletIcon className="h-4 w-4 text-primary" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-primary">
              {showBalance
                ? formatCurrency(wallet.totalBalance, "TRY")
                : "****"}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Son güncelleme:{" "}
              {new Date(wallet.lastUpdated).toLocaleString("tr-TR")}
            </p>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-success">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Kullanılabilir Bakiye
            </CardTitle>
            <TrendingUp className="h-4 w-4 text-success" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-success">
              {showBalance
                ? formatCurrency(wallet.availableBalance, "TRY")
                : "****"}
            </div>
            <p className="text-xs text-muted-foreground">Çekilebilir miktar</p>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-warning">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Bekleyen Bakiye
            </CardTitle>
            <AlertCircle className="h-4 w-4 text-warning" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-warning">
              {showBalance
                ? formatCurrency(wallet.pendingBalance, "TRY")
                : "****"}
            </div>
            <p className="text-xs text-muted-foreground">
              İşleme alınacak tutar
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Multi-Currency Balances */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Coins className="w-5 h-5 text-accent" />
            Çoklu Para Birimi Bakiyeleri
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-3">
            {currencies.map((currency) => {
              const balance =
                wallet.currencies[
                  currency.code as keyof typeof wallet.currencies
                ];
              return (
                <div
                  key={currency.code}
                  className="flex items-center justify-between p-4 bg-muted/50 rounded-lg"
                >
                  <div className="flex items-center gap-3">
                    <div className="text-2xl">{currency.flag}</div>
                    <div>
                      <div className="font-medium">{currency.name}</div>
                      <div className="text-sm text-muted-foreground">
                        {currency.code}
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-semibold">
                      {showBalance
                        ? formatCurrency(balance, currency.code)
                        : "****"}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {currency.code === "TRY"
                        ? "Ana para birimi"
                        : `~₺${(balance * (currency.code === "USD" ? 30 : 32)).toLocaleString("tr-TR")}`}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <div className="grid gap-4 md:grid-cols-2">
        {/* Withdraw */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <ArrowUpRight className="w-5 h-5 text-warning" />
              Para Çekme
            </CardTitle>
            <CardDescription>
              Bakiyenizi banka hesabınıza veya karta transfer edin
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <Label htmlFor="withdraw-amount">Çekilecek Tutar</Label>
                <div className="flex gap-2 mt-1">
                  <Input
                    id="withdraw-amount"
                    type="number"
                    placeholder="0.00"
                    value={withdrawAmount}
                    onChange={(e) => setWithdrawAmount(e.target.value)}
                    className="flex-1"
                  />
                  <Select
                    value={selectedCurrency}
                    onValueChange={setSelectedCurrency}
                  >
                    <SelectTrigger className="w-20">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {currencies.map((currency) => (
                        <SelectItem key={currency.code} value={currency.code}>
                          {currency.code}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label>Hızlı Seçim</Label>
                <div className="grid grid-cols-3 gap-2 mt-1">
                  {quickAmounts.map((amount) => (
                    <Button
                      key={amount}
                      variant="outline"
                      size="sm"
                      onClick={() => handleQuickAmount(amount, "withdraw")}
                      className="text-xs"
                    >
                      ₺{amount}
                    </Button>
                  ))}
                </div>
              </div>

              <Dialog>
                <DialogTrigger asChild>
                  <Button className="w-full" disabled={!withdrawAmount}>
                    <Send className="w-4 h-4 mr-2" />
                    Para Çek
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Para Çekme Yöntemi Seçin</DialogTitle>
                    <DialogDescription>
                      Paranızı almak istediğiniz yöntemi seçin
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-3">
                    {withdrawalMethods.map((method) => {
                      const Icon = method.icon;
                      return (
                        <div
                          key={method.id}
                          className="flex items-center justify-between p-3 border rounded-lg hover:bg-muted/50 cursor-pointer"
                        >
                          <div className="flex items-center gap-3">
                            <Icon className="w-5 h-5" />
                            <div>
                              <div className="font-medium">{method.name}</div>
                              <div className="text-sm text-muted-foreground">
                                {method.time}
                              </div>
                            </div>
                          </div>
                          <Badge variant="outline">{method.fee}</Badge>
                        </div>
                      );
                    })}
                  </div>
                  <DialogFooter>
                    <Button variant="outline">İptal</Button>
                    <Button>Devam Et</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
          </CardContent>
        </Card>

        {/* Deposit */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <ArrowDownRight className="w-5 h-5 text-success" />
              Para Yatırma
            </CardTitle>
            <CardDescription>
              Hesabınıza para yatırın ve bonusları artırın
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <Label htmlFor="deposit-amount">Yatırılacak Tutar</Label>
                <div className="flex gap-2 mt-1">
                  <Input
                    id="deposit-amount"
                    type="number"
                    placeholder="0.00"
                    value={depositAmount}
                    onChange={(e) => setDepositAmount(e.target.value)}
                    className="flex-1"
                  />
                  <Select
                    value={selectedCurrency}
                    onValueChange={setSelectedCurrency}
                  >
                    <SelectTrigger className="w-20">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {currencies.map((currency) => (
                        <SelectItem key={currency.code} value={currency.code}>
                          {currency.code}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label>Hızlı Seçim</Label>
                <div className="grid grid-cols-3 gap-2 mt-1">
                  {quickAmounts.map((amount) => (
                    <Button
                      key={amount}
                      variant="outline"
                      size="sm"
                      onClick={() => handleQuickAmount(amount, "deposit")}
                      className="text-xs"
                    >
                      ₺{amount}
                    </Button>
                  ))}
                </div>
              </div>

              <Dialog>
                <DialogTrigger asChild>
                  <Button className="w-full" disabled={!depositAmount}>
                    <Download className="w-4 h-4 mr-2" />
                    Para Yatır
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Para Yatırma Yöntemi Seçin</DialogTitle>
                    <DialogDescription>
                      Para yatırmak istediğiniz yöntemi seçin
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-3">
                    {depositMethods.map((method) => {
                      const Icon = method.icon;
                      return (
                        <div
                          key={method.id}
                          className="flex items-center justify-between p-3 border rounded-lg hover:bg-muted/50 cursor-pointer"
                        >
                          <div className="flex items-center gap-3">
                            <Icon className="w-5 h-5" />
                            <div>
                              <div className="font-medium">{method.name}</div>
                              <div className="text-sm text-muted-foreground">
                                {method.time}
                              </div>
                            </div>
                          </div>
                          <Badge variant="outline">{method.fee}</Badge>
                        </div>
                      );
                    })}
                  </div>
                  <DialogFooter>
                    <Button variant="outline">İptal</Button>
                    <Button>Devam Et</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Crypto Wallet Address */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <QrCode className="w-5 h-5 text-info" />
            Kripto Cüzdan Adresi
          </CardTitle>
          <CardDescription>
            BTC, ETH ve diğer kripto paralar için cüzdan adresiniz
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center gap-2 p-3 bg-muted rounded-lg">
              <code className="flex-1 text-sm font-mono">
                0x742d35Cc6531C0532C5a29B85a11567D56Baea52
              </code>
              <Button
                variant="outline"
                size="sm"
                onClick={copyWalletAddress}
                className="shrink-0"
              >
                {qrCodeCopied ? (
                  <Check className="w-4 h-4" />
                ) : (
                  <Copy className="w-4 h-4" />
                )}
              </Button>
            </div>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Shield className="w-4 h-4" />
              Bu adres sadece Ethereum ve ERC-20 tokenları içindir
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Recent Transactions */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <History className="w-5 h-5 text-primary" />
            Son İşlemler
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {transactions.slice(0, 10).map((transaction) => (
              <div
                key={transaction.id}
                className="flex items-center justify-between p-3 bg-muted/50 rounded-lg hover:bg-muted transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-10 h-10 rounded-full flex items-center justify-center ${
                      transaction.type === "bonus"
                        ? "bg-success/20 text-success"
                        : transaction.type === "withdrawal"
                          ? "bg-warning/20 text-warning"
                          : "bg-info/20 text-info"
                    }`}
                  >
                    {transaction.type === "bonus" ? (
                      <Gift className="w-4 h-4" />
                    ) : transaction.type === "withdrawal" ? (
                      <ArrowUpRight className="w-4 h-4" />
                    ) : (
                      <ArrowDownRight className="w-4 h-4" />
                    )}
                  </div>
                  <div>
                    <div className="font-medium">{transaction.description}</div>
                    <div className="text-sm text-muted-foreground">
                      {new Date(transaction.date).toLocaleDateString("tr-TR")} •{" "}
                      {new Date(transaction.date).toLocaleTimeString("tr-TR", {
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div
                    className={`font-semibold ${transaction.amount > 0 ? "text-success" : "text-warning"}`}
                  >
                    {transaction.amount > 0 ? "+" : ""}
                    {formatCurrency(
                      Math.abs(transaction.amount),
                      transaction.currency,
                    )}
                  </div>
                  <Badge
                    variant={
                      transaction.status === "completed"
                        ? "default"
                        : transaction.status === "pending"
                          ? "secondary"
                          : "destructive"
                    }
                    className="text-xs"
                  >
                    {transaction.status === "completed"
                      ? "Tamamlandı"
                      : transaction.status === "pending"
                        ? "Bekliyor"
                        : "İptal"}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
