import { useState, useEffect } from "react";
import { useNavigate, Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Bell, User, LogOut, Menu, X, Crown, Network } from "lucide-react";

interface User {
  username: string;
  role: string;
  name: string;
}

interface HeaderProps {
  showAuthButtons?: boolean;
  transparent?: boolean;
}

export default function Header({
  showAuthButtons = true,
  transparent = false,
}: HeaderProps) {
  const [user, setUser] = useState<User | null>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const userData = localStorage.getItem("mlm_user");
    if (userData) {
      setUser(JSON.parse(userData));
    }
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("mlm_user");
    setUser(null);
    navigate("/");
  };

  const loggedOutMenuItems = [
    { label: "Ana Sayfa", href: "/" },
    { label: "Hakkımızda", href: "/hakkimizda" },
    { label: "Giriş", action: "login" },
    { label: "Üye Ol", action: "register" },
  ];

  const loggedInMenuItems = [
    { label: "Profilim", href: "/dashboard" },
    { label: "Bildirimler", action: "notifications" },
    { label: "Çıkış", action: "logout" },
  ];

  const menuItems = user ? loggedInMenuItems : loggedOutMenuItems;

  const handleMenuAction = (action: string) => {
    switch (action) {
      case "login":
        navigate("/login");
        break;
      case "register":
        navigate("/register");
        break;
      case "notifications":
        navigate("/dashboard");
        // You could add specific logic to open notifications tab
        break;
      case "logout":
        handleLogout();
        break;
    }
    setMobileMenuOpen(false);
  };

  return (
    <header
      className={`sticky top-0 z-50 border-b ${
        transparent ? "bg-white/95 backdrop-blur-sm" : "bg-white"
      } shadow-sm`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-r from-[#2D1E5F] to-[#00A9A5] rounded-xl flex items-center justify-center">
              <Network className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-[#2D1E5F] mystical-font">
                Kutbul Zaman
              </h1>
              <p className="text-xs text-gray-500">Network</p>
            </div>
          </Link>

          {/* Desktop Menu */}
          <nav className="hidden md:flex items-center space-x-8">
            {menuItems.map((item, index) => (
              <div key={index}>
                {item.href ? (
                  <Link
                    to={item.href}
                    className="text-gray-700 hover:text-[#2D1E5F] font-medium transition-colors"
                  >
                    {item.label}
                  </Link>
                ) : (
                  <button
                    onClick={() => handleMenuAction(item.action!)}
                    className="text-gray-700 hover:text-[#2D1E5F] font-medium transition-colors"
                  >
                    {item.label}
                  </button>
                )}
              </div>
            ))}
          </nav>

          {/* User Menu or Auth Buttons */}
          <div className="hidden md:flex items-center space-x-4">
            {user ? (
              <div className="flex items-center space-x-4">
                {/* Notifications */}
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => navigate("/dashboard")}
                  className="relative"
                >
                  <Bell className="w-5 h-5" />
                  <span className="absolute -top-1 -right-1 w-3 h-3 bg-[#00A9A5] rounded-full text-xs text-white flex items-center justify-center">
                    3
                  </span>
                </Button>

                {/* User Menu */}
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button
                      variant="ghost"
                      className="relative h-8 w-8 rounded-full"
                    >
                      <Avatar className="h-8 w-8">
                        <AvatarImage src="/placeholder.svg" />
                        <AvatarFallback className="bg-[#2D1E5F] text-white">
                          {user.name.charAt(0)}
                        </AvatarFallback>
                      </Avatar>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent
                    className="w-56 rounded-xl shadow-md"
                    align="end"
                  >
                    <div className="flex items-center justify-start gap-2 p-2">
                      <div className="flex flex-col space-y-1 leading-none">
                        <p className="font-medium">{user.name}</p>
                        <Badge
                          variant={
                            user.role === "admin" ? "default" : "secondary"
                          }
                          className="text-xs w-fit"
                        >
                          {user.role === "admin" ? "Yönetici" : "Üye"}
                        </Badge>
                      </div>
                    </div>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={() => navigate("/dashboard")}>
                      <User className="mr-2 h-4 w-4" />
                      Profilim
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => navigate("/dashboard")}>
                      <Bell className="mr-2 h-4 w-4" />
                      Bildirimler
                    </DropdownMenuItem>
                    {user.role === "admin" && (
                      <DropdownMenuItem onClick={() => navigate("/admin")}>
                        <Crown className="mr-2 h-4 w-4" />
                        Admin Panel
                      </DropdownMenuItem>
                    )}
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={handleLogout}>
                      <LogOut className="mr-2 h-4 w-4" />
                      Çıkış
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            ) : showAuthButtons ? (
              <div className="flex items-center space-x-3">
                <Button
                  onClick={() => navigate("/login")}
                  variant="outline"
                  className="border-[#2D1E5F] text-[#2D1E5F] hover:bg-[#2D1E5F] hover:text-white rounded-xl"
                >
                  Giriş
                </Button>
                <Button
                  onClick={() => navigate("/register")}
                  className="bg-[#00A9A5] hover:bg-[#008b87] text-white rounded-xl"
                >
                  Üye Ol
                </Button>
              </div>
            ) : null}
          </div>

          {/* Mobile menu button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2"
          >
            {mobileMenuOpen ? <X /> : <Menu />}
          </button>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t py-4">
            <div className="flex flex-col space-y-3">
              {menuItems.map((item, index) => (
                <div key={index}>
                  {item.href ? (
                    <Link
                      to={item.href}
                      className="block px-4 py-2 text-gray-700 hover:bg-gray-50 rounded-xl"
                      onClick={() => setMobileMenuOpen(false)}
                    >
                      {item.label}
                    </Link>
                  ) : (
                    <button
                      onClick={() => handleMenuAction(item.action!)}
                      className="block w-full text-left px-4 py-2 text-gray-700 hover:bg-gray-50 rounded-xl"
                    >
                      {item.label}
                    </button>
                  )}
                </div>
              ))}

              {user && (
                <div className="px-4 pt-2 border-t">
                  <div className="flex items-center space-x-3 mb-3">
                    <Avatar className="h-8 w-8">
                      <AvatarImage src="/placeholder.svg" />
                      <AvatarFallback className="bg-[#2D1E5F] text-white">
                        {user.name.charAt(0)}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium text-sm">{user.name}</p>
                      <Badge
                        variant={
                          user.role === "admin" ? "default" : "secondary"
                        }
                        className="text-xs"
                      >
                        {user.role === "admin" ? "Yönetici" : "Üye"}
                      </Badge>
                    </div>
                  </div>
                  {user.role === "admin" && (
                    <Button
                      onClick={() => navigate("/admin")}
                      variant="outline"
                      className="w-full mb-2"
                    >
                      <Crown className="w-4 h-4 mr-2" />
                      Admin Panel
                    </Button>
                  )}
                </div>
              )}

              {!user && showAuthButtons && (
                <div className="px-4 space-y-2">
                  <Button
                    onClick={() => navigate("/login")}
                    variant="outline"
                    className="w-full border-[#2D1E5F] text-[#2D1E5F] rounded-xl"
                  >
                    Giriş
                  </Button>
                  <Button
                    onClick={() => navigate("/register")}
                    className="w-full bg-[#00A9A5] hover:bg-[#008b87] text-white rounded-xl"
                  >
                    Üye Ol
                  </Button>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
