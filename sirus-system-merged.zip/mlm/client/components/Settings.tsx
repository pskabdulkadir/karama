import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Settings as SettingsIcon,
  User as UserIcon,
  Bell,
  Shield,
  CreditCard,
  Globe,
  Moon,
  Sun,
  Eye,
  EyeOff,
  Save,
  RefreshCw,
  Download,
  Upload,
  Key,
  Smartphone,
  Mail,
  Lock,
  AlertTriangle,
  CheckCircle,
  Camera,
  Edit,
  Trash2,
  Plus,
  Phone,
  MapPin,
  Calendar,
  Building,
  Languages,
  Palette,
} from "lucide-react";
import { User } from "@shared/mlm-types";

interface SettingsProps {
  user: User;
}

export default function Settings({ user }: SettingsProps) {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [smsNotifications, setSmsNotifications] = useState(false);
  const [twoFactorAuth, setTwoFactorAuth] = useState(false);
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [language, setLanguage] = useState("tr");
  const [timezone, setTimezone] = useState("Europe/Istanbul");

  const [profileData, setProfileData] = useState({
    name: user.name,
    email: user.email,
    phone: "+90 555 123 4567",
    address: "İstanbul, Türkiye",
    birthDate: "1985-06-15",
    company: "MLM Business Corp.",
    bio: "Network Marketing uzmanı ve takım lideri.",
  });

  const [passwordData, setPasswordData] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  });

  const [bankData, setBankData] = useState({
    bankName: "Garanti BBVA",
    accountHolder: user.name,
    iban: "TR33 0006 1005 1978 6457 8413 26",
    swiftCode: "TGBATRIS",
  });

  const handleProfileUpdate = () => {
    // In real app, this would call an API
    console.log("Profile updated:", profileData);
    // Show success notification
  };

  const handlePasswordChange = () => {
    if (passwordData.newPassword !== passwordData.confirmPassword) {
      alert("Yeni şifreler eşleşmiyor!");
      return;
    }
    // In real app, this would call an API
    console.log("Password change requested");
    setPasswordData({
      currentPassword: "",
      newPassword: "",
      confirmPassword: "",
    });
    // Show success notification
  };

  const handleBankUpdate = () => {
    // In real app, this would call an API
    console.log("Bank details updated:", bankData);
    // Show success notification
  };

  const notificationSettings = [
    {
      id: "bonus",
      title: "Bonus Bildirimleri",
      description: "Yeni bonus kazandığınızda bildirim alın",
      enabled: true,
    },
    {
      id: "team",
      title: "Takım Bildirimleri",
      description: "Yeni üye eklendiğinde veya takım etkinliklerinde bildirim",
      enabled: true,
    },
    {
      id: "rank",
      title: "Rütbe Bildirimleri",
      description: "Rütbe değişikliklerinde bildirim alın",
      enabled: true,
    },
    {
      id: "withdrawal",
      title: "Para Çekme Bildirimleri",
      description: "Para çekme işlemlerinizin durumu hakkında bildirim",
      enabled: true,
    },
    {
      id: "marketing",
      title: "Pazarlama Bildirimleri",
      description: "Yeni ürünler ve kampanyalar hakkında bildirim",
      enabled: false,
    },
  ];

  const securitySettings = [
    {
      id: "login_alerts",
      title: "Giriş Uyarıları",
      description: "Hesabınıza yeni bir cihazdan giriş yapıldığında uyarı",
      enabled: true,
    },
    {
      id: "unusual_activity",
      title: "Olağandışı Aktivite",
      description: "Hesabınızda olağandışı aktivite tespit edildiğinde uyarı",
      enabled: true,
    },
    {
      id: "session_timeout",
      title: "Oturum Zaman Aşımı",
      description: "Güvenlik için otomatik oturum sonlandırma",
      enabled: true,
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <SettingsIcon className="w-5 h-5 text-primary" />
            Hesap Ayarları ve Güvenlik
          </CardTitle>
          <CardDescription>
            Kişisel bilgilerinizi, güvenlik ayarlarınızı ve tercihlerinizi
            yönetin
          </CardDescription>
        </CardHeader>
      </Card>

      <Tabs defaultValue="profile" className="space-y-6">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="profile">Profil</TabsTrigger>
          <TabsTrigger value="security">Güvenlik</TabsTrigger>
          <TabsTrigger value="notifications">Bildirimler</TabsTrigger>
          <TabsTrigger value="payment">Ödeme</TabsTrigger>
          <TabsTrigger value="preferences">Tercihler</TabsTrigger>
          <TabsTrigger value="privacy">Gizlilik</TabsTrigger>
        </TabsList>

        {/* Profile Settings */}
        <TabsContent value="profile" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <UserIcon className="w-5 h-5" />
                Kişisel Bilgiler
              </CardTitle>
              <CardDescription>
                Profil bilgilerinizi güncelleyin
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Profile Picture */}
              <div className="flex items-center gap-4">
                <Avatar className="w-20 h-20">
                  <AvatarImage src="/placeholder.svg" />
                  <AvatarFallback className="text-lg">
                    {user.name
                      .split(" ")
                      .map((n) => n[0])
                      .join("")}
                  </AvatarFallback>
                </Avatar>
                <div className="space-y-2">
                  <Button variant="outline" size="sm">
                    <Camera className="w-4 h-4 mr-2" />
                    Fotoğraf Değiştir
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-destructive"
                  >
                    <Trash2 className="w-4 h-4 mr-2" />
                    Fotoğrafı Kaldır
                  </Button>
                </div>
              </div>

              {/* Personal Information Form */}
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="name">Ad Soyad</Label>
                  <Input
                    id="name"
                    value={profileData.name}
                    onChange={(e) =>
                      setProfileData({ ...profileData, name: e.target.value })
                    }
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">E-posta</Label>
                  <Input
                    id="email"
                    type="email"
                    value={profileData.email}
                    onChange={(e) =>
                      setProfileData({ ...profileData, email: e.target.value })
                    }
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone">Telefon</Label>
                  <Input
                    id="phone"
                    value={profileData.phone}
                    onChange={(e) =>
                      setProfileData({ ...profileData, phone: e.target.value })
                    }
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="birthDate">Doğum Tarihi</Label>
                  <Input
                    id="birthDate"
                    type="date"
                    value={profileData.birthDate}
                    onChange={(e) =>
                      setProfileData({
                        ...profileData,
                        birthDate: e.target.value,
                      })
                    }
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="company">Şirket</Label>
                  <Input
                    id="company"
                    value={profileData.company}
                    onChange={(e) =>
                      setProfileData({
                        ...profileData,
                        company: e.target.value,
                      })
                    }
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="address">Adres</Label>
                  <Input
                    id="address"
                    value={profileData.address}
                    onChange={(e) =>
                      setProfileData({
                        ...profileData,
                        address: e.target.value,
                      })
                    }
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="bio">Biyografi</Label>
                <Textarea
                  id="bio"
                  value={profileData.bio}
                  onChange={(e) =>
                    setProfileData({ ...profileData, bio: e.target.value })
                  }
                  placeholder="Kendiniz hakkında kısa bir açıklama yazın..."
                />
              </div>

              <Button onClick={handleProfileUpdate} className="w-full">
                <Save className="w-4 h-4 mr-2" />
                Profil Bilgilerini Kaydet
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Security Settings */}
        <TabsContent value="security" className="space-y-6">
          {/* Password Change */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Lock className="w-5 h-5" />
                Şifre Değiştir
              </CardTitle>
              <CardDescription>
                Hesabınızın güvenliği için güçlü bir şifre kullanın
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="currentPassword">Mevcut Şifre</Label>
                <div className="relative">
                  <Input
                    id="currentPassword"
                    type={showCurrentPassword ? "text" : "password"}
                    value={passwordData.currentPassword}
                    onChange={(e) =>
                      setPasswordData({
                        ...passwordData,
                        currentPassword: e.target.value,
                      })
                    }
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-0 top-0 h-full px-3"
                    onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                  >
                    {showCurrentPassword ? (
                      <EyeOff className="h-4 w-4" />
                    ) : (
                      <Eye className="h-4 w-4" />
                    )}
                  </Button>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="newPassword">Yeni Şifre</Label>
                <div className="relative">
                  <Input
                    id="newPassword"
                    type={showNewPassword ? "text" : "password"}
                    value={passwordData.newPassword}
                    onChange={(e) =>
                      setPasswordData({
                        ...passwordData,
                        newPassword: e.target.value,
                      })
                    }
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-0 top-0 h-full px-3"
                    onClick={() => setShowNewPassword(!showNewPassword)}
                  >
                    {showNewPassword ? (
                      <EyeOff className="h-4 w-4" />
                    ) : (
                      <Eye className="h-4 w-4" />
                    )}
                  </Button>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="confirmPassword">Yeni Şifre Tekrar</Label>
                <Input
                  id="confirmPassword"
                  type="password"
                  value={passwordData.confirmPassword}
                  onChange={(e) =>
                    setPasswordData({
                      ...passwordData,
                      confirmPassword: e.target.value,
                    })
                  }
                />
              </div>
              <Button onClick={handlePasswordChange} className="w-full">
                <Key className="w-4 h-4 mr-2" />
                Şifreyi Değiştir
              </Button>
            </CardContent>
          </Card>

          {/* Two-Factor Authentication */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Smartphone className="w-5 h-5" />
                İki Faktörlü Doğrulama
              </CardTitle>
              <CardDescription>
                Hesabınızın güvenliğini artırmak için 2FA'yı etkinleştirin
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-medium">SMS Doğrulama</div>
                  <div className="text-sm text-muted-foreground">
                    Giriş yaparken SMS ile kod doğrulama
                  </div>
                </div>
                <Switch
                  checked={twoFactorAuth}
                  onCheckedChange={setTwoFactorAuth}
                />
              </div>
              {twoFactorAuth && (
                <div className="p-4 bg-info/10 rounded-lg">
                  <div className="flex items-center gap-2 text-info mb-2">
                    <CheckCircle className="w-4 h-4" />
                    <span className="font-medium">
                      İki faktörlü doğrulama aktif
                    </span>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Hesabınız artık ek güvenlik ile korunuyor. Giriş yaparken
                    telefonunuza gönderilen kodu girmeniz gerekecek.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Security Settings */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="w-5 h-5" />
                Güvenlik Tercihleri
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {securitySettings.map((setting) => (
                <div
                  key={setting.id}
                  className="flex items-center justify-between"
                >
                  <div>
                    <div className="font-medium">{setting.title}</div>
                    <div className="text-sm text-muted-foreground">
                      {setting.description}
                    </div>
                  </div>
                  <Switch defaultChecked={setting.enabled} />
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Notification Settings */}
        <TabsContent value="notifications" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bell className="w-5 h-5" />
                Bildirim Tercihleri
              </CardTitle>
              <CardDescription>
                Hangi bildirimleri almak istediğinizi seçin
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-medium">E-posta Bildirimleri</div>
                    <div className="text-sm text-muted-foreground">
                      E-posta ile bildirim almak için etkinleştirin
                    </div>
                  </div>
                  <Switch
                    checked={emailNotifications}
                    onCheckedChange={setEmailNotifications}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-medium">SMS Bildirimleri</div>
                    <div className="text-sm text-muted-foreground">
                      SMS ile bildirim almak için etkinleştirin
                    </div>
                  </div>
                  <Switch
                    checked={smsNotifications}
                    onCheckedChange={setSmsNotifications}
                  />
                </div>
              </div>

              <div className="border-t pt-4">
                <h4 className="font-medium mb-4">Bildirim Kategorileri</h4>
                <div className="space-y-4">
                  {notificationSettings.map((setting) => (
                    <div
                      key={setting.id}
                      className="flex items-center justify-between"
                    >
                      <div>
                        <div className="font-medium">{setting.title}</div>
                        <div className="text-sm text-muted-foreground">
                          {setting.description}
                        </div>
                      </div>
                      <Switch defaultChecked={setting.enabled} />
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Payment Settings */}
        <TabsContent value="payment" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CreditCard className="w-5 h-5" />
                Banka Bilgileri
              </CardTitle>
              <CardDescription>
                Para çekme işlemleri için banka bilgilerinizi güncelleyin
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="bankName">Banka Adı</Label>
                  <Input
                    id="bankName"
                    value={bankData.bankName}
                    onChange={(e) =>
                      setBankData({ ...bankData, bankName: e.target.value })
                    }
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="accountHolder">Hesap Sahibi</Label>
                  <Input
                    id="accountHolder"
                    value={bankData.accountHolder}
                    onChange={(e) =>
                      setBankData({
                        ...bankData,
                        accountHolder: e.target.value,
                      })
                    }
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="iban">IBAN</Label>
                  <Input
                    id="iban"
                    value={bankData.iban}
                    onChange={(e) =>
                      setBankData({ ...bankData, iban: e.target.value })
                    }
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="swiftCode">Swift Kodu</Label>
                  <Input
                    id="swiftCode"
                    value={bankData.swiftCode}
                    onChange={(e) =>
                      setBankData({ ...bankData, swiftCode: e.target.value })
                    }
                  />
                </div>
              </div>
              <Button onClick={handleBankUpdate} className="w-full">
                <Save className="w-4 h-4 mr-2" />
                Banka Bilgilerini Kaydet
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Preferences */}
        <TabsContent value="preferences" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Palette className="w-5 h-5" />
                Görünüm ve Dil Tercihleri
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-medium">Karanlık Mod</div>
                  <div className="text-sm text-muted-foreground">
                    Koyu tema kullanmak için etkinleştirin
                  </div>
                </div>
                <Switch checked={isDarkMode} onCheckedChange={setIsDarkMode} />
              </div>

              <div className="space-y-2">
                <Label htmlFor="language">Dil</Label>
                <Select value={language} onValueChange={setLanguage}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="tr">Türkçe</SelectItem>
                    <SelectItem value="en">English</SelectItem>
                    <SelectItem value="de">Deutsch</SelectItem>
                    <SelectItem value="fr">Français</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="timezone">Saat Dilimi</Label>
                <Select value={timezone} onValueChange={setTimezone}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Europe/Istanbul">
                      İstanbul (GMT+3)
                    </SelectItem>
                    <SelectItem value="Europe/London">
                      London (GMT+0)
                    </SelectItem>
                    <SelectItem value="America/New_York">
                      New York (GMT-5)
                    </SelectItem>
                    <SelectItem value="Asia/Tokyo">Tokyo (GMT+9)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Privacy Settings */}
        <TabsContent value="privacy" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Eye className="w-5 h-5" />
                Gizlilik Ayarları
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-medium">Profil Görünürlüğü</div>
                  <div className="text-sm text-muted-foreground">
                    Profilinizi diğer üyelerin görmesine izin ver
                  </div>
                </div>
                <Switch defaultChecked={true} />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <div className="font-medium">Kazanç Bilgilerini Gizle</div>
                  <div className="text-sm text-muted-foreground">
                    Kazanç bilgilerinizi gizleyerek gizliliğinizi koruyun
                  </div>
                </div>
                <Switch defaultChecked={false} />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <div className="font-medium">Ekip Bilgilerini Paylaş</div>
                  <div className="text-sm text-muted-foreground">
                    Ekip bilgilerinizi diğer liderlerle paylaşma
                  </div>
                </div>
                <Switch defaultChecked={true} />
              </div>

              <div className="pt-4 border-t">
                <Button variant="destructive" className="w-full">
                  <AlertTriangle className="w-4 h-4 mr-2" />
                  Hesabı Sil
                </Button>
                <p className="text-xs text-muted-foreground mt-2 text-center">
                  Bu işlem geri alınamaz. Tüm verileriniz kalıcı olarak
                  silinecektir.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
