import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Bell,
  Star,
  AlertCircle,
  CheckCircle,
  Info,
  Gift,
  TrendingUp,
  Users,
  Crown,
  Calendar,
  Eye,
  Trash2,
  Mail,
  Volume2,
  VolumeX,
  Filter,
  Search,
  RefreshCw,
  Settings,
} from "lucide-react";
import { User } from "@shared/mlm-types";

interface NotificationsProps {
  user: User;
}

interface Notification {
  id: string;
  title: string;
  message: string;
  type: "info" | "success" | "warning" | "error" | "announcement" | "bonus";
  from: "admin" | "system" | "user";
  date: string;
  isRead: boolean;
  priority: "low" | "medium" | "high";
  category: string;
  actionRequired?: boolean;
}

export default function Notifications({ user }: NotificationsProps) {
  const [selectedFilter, setSelectedFilter] = useState("all");
  const [selectedType, setSelectedType] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");

  // Sample notifications data
  const [notifications, setNotifications] = useState<Notification[]>([
    {
      id: "1",
      title: "Hoş Geldiniz!",
      message: `Sayın ${user.name}, kutbulzaman panel'e hoş geldiniz! Sistemimizde başarılı bir şekilde kayıt oldunuz. Ekibinizi büyütmek için referans linkinizi kullanabilirsiniz.`,
      type: "announcement",
      from: "admin",
      date: "2024-01-20T10:00:00Z",
      isRead: false,
      priority: "high",
      category: "Genel",
      actionRequired: false,
    },
    {
      id: "2",
      title: "Yeni Bonus Kazandınız!",
      message:
        "Binary bonus hesaplaması tamamlandı. ₺1,250.50 tutarında bonus hesabınıza eklenmiştir.",
      type: "bonus",
      from: "system",
      date: "2024-01-19T15:30:00Z",
      isRead: true,
      priority: "medium",
      category: "Bonuslar",
      actionRequired: false,
    },
    {
      id: "3",
      title: "Rütbe Terfisi Tebrikler!",
      message:
        "Tebrikler! Başarılı performansınız sayesinde Gümüş rütbesine terfi ettiniz. Yeni rütbenizle birlikte bonus oranlarınız arttı.",
      type: "success",
      from: "admin",
      date: "2024-01-18T09:15:00Z",
      isRead: true,
      priority: "high",
      category: "Kariyer",
      actionRequired: false,
    },
    {
      id: "4",
      title: "Önemli Sistem Güncellemesi",
      message:
        "Sistem bakımı nedeniyle 22 Ocak 2024 saat 02:00-04:00 arası geçici hizmet kesintisi yaşanabilir. Anlayışınız için teşekkürler.",
      type: "warning",
      from: "admin",
      date: "2024-01-17T14:45:00Z",
      isRead: false,
      priority: "medium",
      category: "Sistem",
      actionRequired: false,
    },
    {
      id: "5",
      title: "Yeni Ekip Üyesi",
      message:
        "Ahmet Yılmaz adlı kullanıcı sizin referansınızla sisteme katıldı. Sponsor bonusunuz hesaplanmıştır.",
      type: "info",
      from: "system",
      date: "2024-01-16T11:20:00Z",
      isRead: true,
      priority: "low",
      category: "Ekip",
      actionRequired: false,
    },
    {
      id: "6",
      title: "Aylık Hedef Tamamlandı",
      message:
        "Bu ay belirlenen satış hedefini %120 oranında aştınız! Ek bonus için profilinizi kontrol edin.",
      type: "success",
      from: "system",
      date: "2024-01-15T16:00:00Z",
      isRead: false,
      priority: "medium",
      category: "Hedefler",
      actionRequired: true,
    },
    {
      id: "7",
      title: "Banka Bilgilerinizi Güncelleyin",
      message:
        "Para çekme işlemlerinizin kesintisiz devam edebilmesi için banka bilgilerinizi güncel tutmanız önemlidir.",
      type: "warning",
      from: "admin",
      date: "2024-01-14T08:30:00Z",
      isRead: false,
      priority: "high",
      category: "Hesap",
      actionRequired: true,
    },
  ]);

  const notificationTypes = [
    { value: "all", label: "Tüm Bildirimler" },
    { value: "announcement", label: "Duyurular" },
    { value: "bonus", label: "Bonus Bildirimleri" },
    { value: "success", label: "Başarılar" },
    { value: "warning", label: "Uyarılar" },
    { value: "info", label: "Bilgilendirme" },
  ];

  const filterOptions = [
    { value: "all", label: "Tümü" },
    { value: "unread", label: "Okunmamış" },
    { value: "read", label: "Okunmuş" },
    { value: "priority", label: "Öncelikli" },
    { value: "action", label: "Aksiyon Gerekli" },
  ];

  const getFilteredNotifications = () => {
    let filtered = notifications;

    // Type filter
    if (selectedType !== "all") {
      filtered = filtered.filter((n) => n.type === selectedType);
    }

    // Status filter
    if (selectedFilter === "unread") {
      filtered = filtered.filter((n) => !n.isRead);
    } else if (selectedFilter === "read") {
      filtered = filtered.filter((n) => n.isRead);
    } else if (selectedFilter === "priority") {
      filtered = filtered.filter((n) => n.priority === "high");
    } else if (selectedFilter === "action") {
      filtered = filtered.filter((n) => n.actionRequired);
    }

    // Search filter
    if (searchTerm) {
      filtered = filtered.filter(
        (n) =>
          n.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
          n.message.toLowerCase().includes(searchTerm.toLowerCase()),
      );
    }

    return filtered.sort(
      (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime(),
    );
  };

  const markAsRead = (id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, isRead: true } : n)),
    );
  };

  const markAsUnread = (id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, isRead: false } : n)),
    );
  };

  const deleteNotification = (id: string) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id));
  };

  const markAllAsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
  };

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case "announcement":
        return <Bell className="w-5 h-5 text-primary" />;
      case "bonus":
        return <Gift className="w-5 h-5 text-success" />;
      case "success":
        return <CheckCircle className="w-5 h-5 text-success" />;
      case "warning":
        return <AlertCircle className="w-5 h-5 text-warning" />;
      case "error":
        return <AlertCircle className="w-5 h-5 text-destructive" />;
      default:
        return <Info className="w-5 h-5 text-info" />;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "border-l-destructive";
      case "medium":
        return "border-l-warning";
      default:
        return "border-l-info";
    }
  };

  const filteredNotifications = getFilteredNotifications();
  const unreadCount = notifications.filter((n) => !n.isRead).length;
  const actionRequiredCount = notifications.filter(
    (n) => n.actionRequired,
  ).length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Bell className="w-5 h-5 text-primary" />
                Bildirimler
                {unreadCount > 0 && (
                  <Badge variant="destructive" className="ml-2">
                    {unreadCount}
                  </Badge>
                )}
              </CardTitle>
              <CardDescription>
                Admin'den gelen mesajlar ve sistem bildirimleri
              </CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline" onClick={markAllAsRead}>
                <CheckCircle className="w-4 h-4 mr-2" />
                Tümünü Okundu İşaretle
              </Button>
              <Button variant="outline">
                <RefreshCw className="w-4 h-4 mr-2" />
                Yenile
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-4 mb-6">
            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4" />
              <Select value={selectedFilter} onValueChange={setSelectedFilter}>
                <SelectTrigger className="w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {filterOptions.map((option) => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center gap-2">
              <Bell className="w-4 h-4" />
              <Select value={selectedType} onValueChange={setSelectedType}>
                <SelectTrigger className="w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {notificationTypes.map((type) => (
                    <SelectItem key={type.value} value={type.value}>
                      {type.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="col-span-2 flex items-center gap-2">
              <Search className="w-4 h-4" />
              <input
                type="text"
                placeholder="Bildirim ara..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="flex-1 px-3 py-2 text-sm border border-border rounded-md"
              />
            </div>
          </div>

          {/* Summary Stats */}
          <div className="grid gap-4 md:grid-cols-4">
            <div className="text-center p-3 bg-primary/10 rounded-lg">
              <div className="text-2xl font-bold text-primary">
                {notifications.length}
              </div>
              <div className="text-sm text-muted-foreground">
                Toplam Bildirim
              </div>
            </div>
            <div className="text-center p-3 bg-warning/10 rounded-lg">
              <div className="text-2xl font-bold text-warning">
                {unreadCount}
              </div>
              <div className="text-sm text-muted-foreground">Okunmamış</div>
            </div>
            <div className="text-center p-3 bg-destructive/10 rounded-lg">
              <div className="text-2xl font-bold text-destructive">
                {actionRequiredCount}
              </div>
              <div className="text-sm text-muted-foreground">
                Aksiyon Gerekli
              </div>
            </div>
            <div className="text-center p-3 bg-success/10 rounded-lg">
              <div className="text-2xl font-bold text-success">
                {filteredNotifications.length}
              </div>
              <div className="text-sm text-muted-foreground">Gösterilen</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Notifications List */}
      <div className="space-y-4">
        {filteredNotifications.length === 0 ? (
          <Card>
            <CardContent className="flex items-center justify-center h-32">
              <div className="text-center">
                <Bell className="w-12 h-12 text-muted-foreground mx-auto mb-2" />
                <p className="text-muted-foreground">
                  Seçilen kriterlere uygun bildirim bulunamadı
                </p>
              </div>
            </CardContent>
          </Card>
        ) : (
          filteredNotifications.map((notification) => (
            <Card
              key={notification.id}
              className={`border-l-4 ${getPriorityColor(notification.priority)} ${
                !notification.isRead ? "bg-muted/30" : ""
              }`}
            >
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-3">
                    {getNotificationIcon(notification.type)}
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <CardTitle className="text-lg">
                          {notification.title}
                        </CardTitle>
                        {!notification.isRead && (
                          <div className="w-2 h-2 bg-primary rounded-full"></div>
                        )}
                        {notification.actionRequired && (
                          <Badge variant="destructive" className="text-xs">
                            Aksiyon Gerekli
                          </Badge>
                        )}
                      </div>
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <span>
                          {notification.from === "admin" ? "Admin" : "Sistem"}
                        </span>
                        <span>{notification.category}</span>
                        <span>
                          {new Date(notification.date).toLocaleDateString(
                            "tr-TR",
                          )}
                        </span>
                        <Badge
                          variant="outline"
                          className={
                            notification.priority === "high"
                              ? "border-destructive text-destructive"
                              : notification.priority === "medium"
                                ? "border-warning text-warning"
                                : "border-info text-info"
                          }
                        >
                          {notification.priority === "high"
                            ? "Yüksek"
                            : notification.priority === "medium"
                              ? "Orta"
                              : "Düşük"}
                        </Badge>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-1">
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => markAsRead(notification.id)}
                        >
                          <Eye className="w-4 h-4" />
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle className="flex items-center gap-2">
                            {getNotificationIcon(notification.type)}
                            {notification.title}
                          </DialogTitle>
                          <DialogDescription>
                            {notification.from === "admin" ? "Admin" : "Sistem"}{" "}
                            •{" "}
                            {new Date(notification.date).toLocaleDateString(
                              "tr-TR",
                            )}
                          </DialogDescription>
                        </DialogHeader>
                        <div className="space-y-4">
                          <p className="text-sm leading-relaxed">
                            {notification.message}
                          </p>
                          {notification.actionRequired && (
                            <div className="p-4 bg-warning/10 border border-warning/20 rounded-lg">
                              <div className="flex items-center gap-2 text-warning font-medium mb-2">
                                <AlertCircle className="w-4 h-4" />
                                Aksiyon Gerekli
                              </div>
                              <p className="text-sm">
                                Bu bildirim için belirli bir aksiyona ihtiyaç
                                vardır. Lütfen gerekli işlemleri yapın.
                              </p>
                            </div>
                          )}
                        </div>
                      </DialogContent>
                    </Dialog>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() =>
                        notification.isRead
                          ? markAsUnread(notification.id)
                          : markAsRead(notification.id)
                      }
                    >
                      <Mail className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => deleteNotification(notification.id)}
                      className="text-destructive hover:text-destructive"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="pt-0">
                <p className="text-sm text-muted-foreground line-clamp-2">
                  {notification.message}
                </p>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}
