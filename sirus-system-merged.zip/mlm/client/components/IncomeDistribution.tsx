import { useState, useEffect } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  PieChart,
  DollarSign,
  TrendingUp,
  Users,
  Coins,
  BarChart3,
  Target,
  Award,
  ArrowRight,
  Building2,
} from "lucide-react";
import {
  IncomeDistribution as IIncomeDistribution,
  KutbulZamanConfig,
} from "../../shared/mlm-types";

const mockConfig: KutbulZamanConfig = {
  entryFee: 100,
  monthlyFee: 20,
  annualFee: 200,
  annualDiscount: 0.15,
  bonusDistributionRate: 0.4, // 40%
  systemFundRate: 0.6, // 60%
  sponsorBonusRate: 0.1, // 10%
  careerBonusAllocation: 0.25, // 25% of bonus pool
};

const mockDistribution: IIncomeDistribution = {
  totalAmount: 10000,
  bonusPool: 4000, // 40%
  systemFund: 6000, // 60%
  distributionDate: "2024-03-01",
  beneficiaries: [
    {
      userId: "user1",
      bonusType: "sponsor",
      amount: 500,
      percentage: 12.5,
    },
    {
      userId: "user2",
      bonusType: "infinite_team",
      amount: 300,
      percentage: 7.5,
    },
    {
      userId: "user3",
      bonusType: "career_bonus",
      amount: 800,
      percentage: 20,
    },
  ],
};

export function IncomeDistribution() {
  const [currentDistribution, setCurrentDistribution] =
    useState<IIncomeDistribution>(mockDistribution);
  const [monthlyStats, setMonthlyStats] = useState({
    totalInvestments: 15000,
    bonusesDistributed: 6000,
    systemDevelopment: 9000,
    activeMembers: 248,
  });

  const calculateDistributionBreakdown = (amount: number) => {
    const bonusPool = amount * mockConfig.bonusDistributionRate;
    const systemFund = amount * mockConfig.systemFundRate;

    // Bonus pool breakdown
    const sponsorBonuses = bonusPool * 0.25; // 25% of bonus pool for sponsor bonuses
    const careerBonuses = bonusPool * mockConfig.careerBonusAllocation; // 25% for career bonuses
    const infiniteTeamBonuses = bonusPool * 0.125; // 12.5% for infinite team
    const systemReserve = bonusPool * 0.375; // Remaining 37.5%

    return {
      bonusPool,
      systemFund,
      sponsorBonuses,
      careerBonuses,
      infiniteTeamBonuses,
      systemReserve,
    };
  };

  const distributionBreakdown = calculateDistributionBreakdown(
    monthlyStats.totalInvestments,
  );

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <PieChart className="h-5 w-5 text-purple-600" />
            Gelir Dağıtım Modeli
          </CardTitle>
          <CardDescription>
            Kutbul Zaman Network gelir dağıtım sistemi ve fon yönetimi
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Ana Dağıtım</h3>
              <div className="space-y-3">
                <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className="w-4 h-4 bg-blue-500 rounded"></div>
                    <span className="font-medium">Bonus Havuzu</span>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-blue-600">40%</div>
                    <div className="text-sm text-gray-600">
                      ${distributionBreakdown.bonusPool.toLocaleString()}
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between p-3 bg-purple-50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className="w-4 h-4 bg-purple-500 rounded"></div>
                    <span className="font-medium">Sistem Fonu</span>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-purple-600">60%</div>
                    <div className="text-sm text-gray-600">
                      ${distributionBreakdown.systemFund.toLocaleString()}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Bonus Havuzu Detayı</h3>
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm">Sponsor Bonusları</span>
                  <span className="font-medium">
                    ${distributionBreakdown.sponsorBonuses.toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm">Kariyer Bonusları</span>
                  <span className="font-medium">
                    ${distributionBreakdown.careerBonuses.toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm">Sonsuz Ekip</span>
                  <span className="font-medium">
                    $
                    {distributionBreakdown.infiniteTeamBonuses.toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm">Sistem Rezervi</span>
                  <span className="font-medium">
                    ${distributionBreakdown.systemReserve.toLocaleString()}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Genel Bakış</TabsTrigger>
          <TabsTrigger value="bonuses">Bonuslar</TabsTrigger>
          <TabsTrigger value="system">Sistem Fonu</TabsTrigger>
          <TabsTrigger value="calculator">Hesaplayıcı</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2">
                  <DollarSign className="h-4 w-4 text-green-600" />
                  <span className="text-sm font-medium">Toplam Yatırım</span>
                </div>
                <div className="text-2xl font-bold text-green-600">
                  ${monthlyStats.totalInvestments.toLocaleString()}
                </div>
                <div className="text-xs text-gray-600">Bu ay</div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2">
                  <TrendingUp className="h-4 w-4 text-blue-600" />
                  <span className="text-sm font-medium">Dağıtılan Bonus</span>
                </div>
                <div className="text-2xl font-bold text-blue-600">
                  ${monthlyStats.bonusesDistributed.toLocaleString()}
                </div>
                <div className="text-xs text-gray-600">%40 bonus havuzu</div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Building2 className="h-4 w-4 text-purple-600" />
                  <span className="text-sm font-medium">Sistem Fonu</span>
                </div>
                <div className="text-2xl font-bold text-purple-600">
                  ${monthlyStats.systemDevelopment.toLocaleString()}
                </div>
                <div className="text-xs text-gray-600">%60 geliştirme</div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Users className="h-4 w-4 text-orange-600" />
                  <span className="text-sm font-medium">Aktif Üyeler</span>
                </div>
                <div className="text-2xl font-bold text-orange-600">
                  {monthlyStats.activeMembers}
                </div>
                <div className="text-xs text-gray-600">Bonus alan</div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Dağıtım Akışı</CardTitle>
              <CardDescription>
                Her 100$ yatırımın nasıl dağıtıldığını görün
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col md:flex-row items-center justify-center gap-4">
                <div className="text-center">
                  <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mb-2">
                    <DollarSign className="h-8 w-8 text-green-600" />
                  </div>
                  <div className="font-bold">$100</div>
                  <div className="text-sm text-gray-600">Yatırım</div>
                </div>

                <ArrowRight className="h-6 w-6 text-gray-400" />

                <div className="text-center">
                  <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center mb-2">
                    <Award className="h-8 w-8 text-blue-600" />
                  </div>
                  <div className="font-bold">$40</div>
                  <div className="text-sm text-gray-600">Bonus Havuzu</div>
                </div>

                <ArrowRight className="h-6 w-6 text-gray-400" />

                <div className="text-center">
                  <div className="w-20 h-20 bg-purple-100 rounded-full flex items-center justify-center mb-2">
                    <Building2 className="h-8 w-8 text-purple-600" />
                  </div>
                  <div className="font-bold">$60</div>
                  <div className="text-sm text-gray-600">Sistem Fonu</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="bonuses" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Sponsor Bonusu</CardTitle>
                <CardDescription>%10 direkt sponsor bonusu</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span>Her $100 için:</span>
                    <span className="font-bold">$10</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Kariyer bonusu:</span>
                    <span className="font-bold">+%25</span>
                  </div>
                  <div className="text-sm text-gray-600">
                    Sadece aktif sponsorlar alır
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Sonsuz Ekip</CardTitle>
                <CardDescription>Pasif gelir sistemi</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Levvame:</span>
                    <span className="font-bold">%0.5</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Mülhime:</span>
                    <span className="font-bold">%1</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Safiye:</span>
                    <span className="font-bold">%4</span>
                  </div>
                  <div className="text-xs text-gray-600 mt-2">
                    Sonsuz derinlik, bir üst kariyere kadar
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Kariyer Bonusları</CardTitle>
                <CardDescription>Seviye bazlı primler</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Emmare:</span>
                    <span className="font-bold">%2</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Radiyye:</span>
                    <span className="font-bold">%6</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Safiye:</span>
                    <span className="font-bold">%12</span>
                  </div>
                  <div className="text-xs text-gray-600 mt-2">
                    Bonus havuzunun %25'i bu alana ayrılır
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="system" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Sistem Fonu Kullanımı (%60)</CardTitle>
              <CardDescription>
                Sürdürülebilirlik ve geliştirme için ayrılan fonların kullanımı
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h4 className="font-semibold">Teknoloji & Geliştirme</h4>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm">Platform geliştirme</span>
                      <span className="text-sm font-medium">%25</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Güvenlik & altyapı</span>
                      <span className="text-sm font-medium">%15</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Mobil uygulama</span>
                      <span className="text-sm font-medium">%10</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h4 className="font-semibold">Operasyonel Giderler</h4>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm">Pazarlama & eğitim</span>
                      <span className="text-sm font-medium">%20</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Müşteri desteği</span>
                      <span className="text-sm font-medium">%15</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Yasal & uyumluluk</span>
                      <span className="text-sm font-medium">%15</span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="calculator" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Gelir Dağıtım Hesaplayıcısı</CardTitle>
              <CardDescription>
                Farklı yatırım miktarları için dağıtım hesaplayın
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {[100, 500, 1000].map((amount) => {
                    const breakdown = calculateDistributionBreakdown(amount);
                    return (
                      <Card key={amount} className="border-dashed">
                        <CardContent className="p-4">
                          <div className="text-center mb-4">
                            <div className="text-2xl font-bold text-purple-600">
                              ${amount}
                            </div>
                            <div className="text-sm text-gray-600">Yatırım</div>
                          </div>
                          <div className="space-y-2">
                            <div className="flex justify-between">
                              <span className="text-sm">Bonus Havuzu:</span>
                              <span className="font-medium">
                                ${breakdown.bonusPool}
                              </span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-sm">Sistem Fonu:</span>
                              <span className="font-medium">
                                ${breakdown.systemFund}
                              </span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-sm">Sponsor Bonus:</span>
                              <span className="font-medium">
                                ${breakdown.sponsorBonuses}
                              </span>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
