import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  TrendingUp,
  DollarSign,
  Users,
  Crown,
  Gift,
  Zap,
  Target,
  Award,
  Calculator,
  Calendar,
  Filter,
  Download,
  Info,
  Star,
  Network,
  Infinity,
  TrendingDown,
  BarChart3,
  PieChart,
  Activity,
  RefreshCw,
} from "lucide-react";
import { User, Bonus, KUTBUL_ZAMAN_RANKS } from "../../shared/mlm-types";

interface KutbulZamanBonusSystemProps {
  user: User;
}

export default function KutbulZamanBonusSystem({
  user,
}: KutbulZamanBonusSystemProps) {
  const [selectedPeriod, setSelectedPeriod] = useState("2024-03");
  const [selectedBonusType, setSelectedBonusType] = useState("all");
  const [showCalculator, setShowCalculator] = useState(false);

  // Kutbul Zaman specific bonus data
  const kutbulZamanBonuses: Bonus[] = [
    {
      id: "1",
      userId: user.id,
      type: "sponsor",
      amount: 125.0, // $100 * 10% * 1.25 (career bonus)
      percentage: 12.5,
      fromUserId: "user2",
      fromUserName: "Ahmet Yılmaz",
      period: "2024-03",
      date: "2024-03-15T00:00:00Z",
      status: "paid",
      calculationData: {
        investmentAmount: 100,
        baseRate: 0.1,
        careerBonus: 0.25,
        finalRate: 0.125,
      },
      investmentAmount: 100,
      careerLevel: "Safiye",
    },
    {
      id: "2",
      userId: user.id,
      type: "infinite_team",
      amount: 80.0,
      percentage: 4,
      period: "2024-03",
      date: "2024-03-20T00:00:00Z",
      status: "paid",
      calculationData: {
        totalTeamInvestments: 2000,
        infiniteRate: 0.04,
        careerLevel: "Safiye",
        depth: "unlimited",
      },
      careerLevel: "Safiye",
    },
    {
      id: "3",
      userId: user.id,
      type: "career_bonus",
      amount: 240.0,
      percentage: 12,
      period: "2024-03",
      date: "2024-03-31T00:00:00Z",
      status: "paid",
      calculationData: {
        bonusPool: 2000,
        careerPercentage: 0.12,
        careerLevel: "Safiye",
        qualifiedInvestments: 2000,
      },
      careerLevel: "Safiye",
    },
    {
      id: "4",
      userId: user.id,
      type: "sponsor",
      amount: 10.0,
      percentage: 10,
      fromUserId: "user3",
      fromUserName: "Ayşe Kaya",
      period: "2024-03",
      date: "2024-03-25T00:00:00Z",
      status: "pending",
      calculationData: {
        investmentAmount: 100,
        baseRate: 0.1,
        careerBonus: 0,
        finalRate: 0.1,
      },
      investmentAmount: 100,
      careerLevel: "Emmare",
    },
  ];

  const calculateTotalBonuses = () => {
    return kutbulZamanBonuses.reduce((total, bonus) => total + bonus.amount, 0);
  };

  const getBonusTypeLabel = (type: string) => {
    const labels = {
      sponsor: "Sponsor Bonusu",
      infinite_team: "Sonsuz Ekip",
      career_bonus: "Kariyer Bonusu",
      binary: "Binary Bonus",
      leadership: "Liderlik",
      sales: "Satış",
      rank: "Derece",
    };
    return labels[type as keyof typeof labels] || type;
  };

  const getBonusTypeIcon = (type: string) => {
    const icons = {
      sponsor: <Users className="h-4 w-4" />,
      infinite_team: <Infinity className="h-4 w-4" />,
      career_bonus: <Crown className="h-4 w-4" />,
      binary: <TrendingUp className="h-4 w-4" />,
      leadership: <Award className="h-4 w-4" />,
      sales: <DollarSign className="h-4 w-4" />,
      rank: <Star className="h-4 w-4" />,
    };
    return icons[type as keyof typeof icons] || <Gift className="h-4 w-4" />;
  };

  const getBonusTypeColor = (type: string) => {
    const colors = {
      sponsor: "bg-blue-100 text-blue-800",
      infinite_team: "bg-purple-100 text-purple-800",
      career_bonus: "bg-yellow-100 text-yellow-800",
      binary: "bg-green-100 text-green-800",
      leadership: "bg-orange-100 text-orange-800",
      sales: "bg-red-100 text-red-800",
      rank: "bg-indigo-100 text-indigo-800",
    };
    return colors[type as keyof typeof colors] || "bg-gray-100 text-gray-800";
  };

  const getCareerRankInfo = (careerLevel: string) => {
    const rank = KUTBUL_ZAMAN_RANKS.find((r) => r.name === careerLevel);
    return rank || KUTBUL_ZAMAN_RANKS[0];
  };

  const calculateSponsorBonus = (investment: number, careerLevel: string) => {
    const rank = getCareerRankInfo(careerLevel);
    const baseBonus = investment * 0.1; // 10%
    return baseBonus * rank.benefits.sponsorBonusRate;
  };

  const calculateInfiniteTeamBonus = (
    teamInvestment: number,
    careerLevel: string,
  ) => {
    const rank = getCareerRankInfo(careerLevel);
    return teamInvestment * rank.benefits.infiniteTeamRate;
  };

  const filteredBonuses = kutbulZamanBonuses.filter((bonus) => {
    if (selectedBonusType !== "all" && bonus.type !== selectedBonusType) {
      return false;
    }
    return bonus.period === selectedPeriod;
  });

  const bonusStats = {
    totalEarned: calculateTotalBonuses(),
    sponsorBonuses: kutbulZamanBonuses
      .filter((b) => b.type === "sponsor")
      .reduce((sum, b) => sum + b.amount, 0),
    infiniteTeamBonuses: kutbulZamanBonuses
      .filter((b) => b.type === "infinite_team")
      .reduce((sum, b) => sum + b.amount, 0),
    careerBonuses: kutbulZamanBonuses
      .filter((b) => b.type === "career_bonus")
      .reduce((sum, b) => sum + b.amount, 0),
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-purple-800">
            Kutbul Zaman Bonus Sistemi
          </h2>
          <p className="text-gray-600">
            Sponsor, Sonsuz Ekip ve Kariyer bonuslarınızı takip edin
          </p>
        </div>
        <div className="flex gap-2">
          <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="2024-01">Ocak 2024</SelectItem>
              <SelectItem value="2024-02">Şubat 2024</SelectItem>
              <SelectItem value="2024-03">Mart 2024</SelectItem>
            </SelectContent>
          </Select>
          <Dialog open={showCalculator} onOpenChange={setShowCalculator}>
            <DialogTrigger asChild>
              <Button variant="outline">
                <Calculator className="h-4 w-4 mr-2" />
                Hesaplayıcı
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Bonus Hesaplayıcısı</DialogTitle>
                <DialogDescription>
                  Farklı senaryolar için bonus hesaplayın
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium">Yatırım ($)</label>
                    <input
                      type="number"
                      className="w-full p-2 border rounded"
                      placeholder="100"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Kariyer</label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Seçin" />
                      </SelectTrigger>
                      <SelectContent>
                        {KUTBUL_ZAMAN_RANKS.map((rank) => (
                          <SelectItem key={rank.name} value={rank.name}>
                            {rank.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="p-4 bg-gray-50 rounded-lg">
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Sponsor Bonusu:</span>
                      <span className="font-medium">$12.50</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Kariyer Bonusu:</span>
                      <span className="font-medium">$12.00</span>
                    </div>
                    <div className="flex justify-between font-bold">
                      <span>Toplam:</span>
                      <span>$24.50</span>
                    </div>
                  </div>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <DollarSign className="h-4 w-4 text-green-600" />
              <span className="text-sm font-medium">Toplam Kazanç</span>
            </div>
            <div className="text-2xl font-bold text-green-600">
              ${bonusStats.totalEarned.toFixed(2)}
            </div>
            <div className="text-xs text-gray-600">Bu ay</div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <Users className="h-4 w-4 text-blue-600" />
              <span className="text-sm font-medium">Sponsor Bonusu</span>
            </div>
            <div className="text-2xl font-bold text-blue-600">
              ${bonusStats.sponsorBonuses.toFixed(2)}
            </div>
            <div className="text-xs text-gray-600">%10 + kariyer bonusu</div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <Infinity className="h-4 w-4 text-purple-600" />
              <span className="text-sm font-medium">Sonsuz Ekip</span>
            </div>
            <div className="text-2xl font-bold text-purple-600">
              ${bonusStats.infiniteTeamBonuses.toFixed(2)}
            </div>
            <div className="text-xs text-gray-600">Pasif gelir</div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <Crown className="h-4 w-4 text-yellow-600" />
              <span className="text-sm font-medium">Kariyer Bonusu</span>
            </div>
            <div className="text-2xl font-bold text-yellow-600">
              ${bonusStats.careerBonuses.toFixed(2)}
            </div>
            <div className="text-xs text-gray-600">%12 Safiye seviyesi</div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="bonuses" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="bonuses">Bonuslar</TabsTrigger>
          <TabsTrigger value="structure">Yapı</TabsTrigger>
          <TabsTrigger value="career">Kariyer</TabsTrigger>
          <TabsTrigger value="analytics">Analiz</TabsTrigger>
        </TabsList>

        <TabsContent value="bonuses" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <Award className="h-5 w-5" />
                  Bonus Geçmişi
                </CardTitle>
                <Select
                  value={selectedBonusType}
                  onValueChange={setSelectedBonusType}
                >
                  <SelectTrigger className="w-48">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Tüm Bonuslar</SelectItem>
                    <SelectItem value="sponsor">Sponsor Bonusu</SelectItem>
                    <SelectItem value="infinite_team">Sonsuz Ekip</SelectItem>
                    <SelectItem value="career_bonus">Kariyer Bonusu</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <CardDescription>
                Kutbul Zaman Network bonus sistemi geçmişiniz
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {filteredBonuses.map((bonus) => (
                  <div
                    key={bonus.id}
                    className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50"
                  >
                    <div className="flex items-center gap-4">
                      <div className="flex-shrink-0">
                        <Badge className={getBonusTypeColor(bonus.type)}>
                          {getBonusTypeIcon(bonus.type)}
                          <span className="ml-1">
                            {getBonusTypeLabel(bonus.type)}
                          </span>
                        </Badge>
                      </div>
                      <div>
                        <div className="font-medium">
                          ${bonus.amount.toFixed(2)}
                        </div>
                        <div className="text-sm text-gray-600">
                          {bonus.fromUserName
                            ? `${bonus.fromUserName} tarafından`
                            : new Date(bonus.date).toLocaleDateString("tr-TR")}
                        </div>
                        {bonus.careerLevel && (
                          <div className="text-xs text-purple-600">
                            {bonus.careerLevel} seviyesi
                          </div>
                        )}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm text-gray-600">
                        %{bonus.percentage}
                      </div>
                      <Badge
                        variant={
                          bonus.status === "paid" ? "default" : "secondary"
                        }
                      >
                        {bonus.status === "paid" ? "Ödendi" : "Beklemede"}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="structure" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Network className="h-5 w-5" />
                Kutbul Zaman Bonus Yapısı
              </CardTitle>
              <CardDescription>
                Üç ana bonus kategorisi ve nasıl hesaplandıkları
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card className="border-blue-200">
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center gap-2">
                      <Users className="h-5 w-5 text-blue-600" />
                      Sponsor Bonusu
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="text-sm">
                      <div className="font-medium">Temel Oran: %10</div>
                      <div className="text-gray-600">
                        Her yeni üyenin ilk yatırımından
                      </div>
                    </div>
                    <div className="text-sm">
                      <div className="font-medium">Kariyer Bonusu: +%25</div>
                      <div className="text-gray-600">
                        Yüksek kariyer seviyesi için ek bonus
                      </div>
                    </div>
                    <div className="p-2 bg-blue-50 rounded text-sm">
                      <div className="font-medium">Örnek:</div>
                      <div>$100 yatırım = $12.50 bonus</div>
                      <div className="text-xs text-gray-600">
                        (Safiye seviyesi için)
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-purple-200">
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center gap-2">
                      <Infinity className="h-5 w-5 text-purple-600" />
                      Sonsuz Ekip
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="text-sm">
                      <div className="font-medium">Pasif Gelir Sistemi</div>
                      <div className="text-gray-600">
                        Tüm alt ekipten sonsuz derinlik
                      </div>
                    </div>
                    <div className="space-y-1 text-xs">
                      <div className="flex justify-between">
                        <span>Levvame:</span>
                        <span className="font-medium">%0.5</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Mülhime:</span>
                        <span className="font-medium">%1</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Safiye:</span>
                        <span className="font-medium">%4</span>
                      </div>
                    </div>
                    <div className="p-2 bg-purple-50 rounded text-sm">
                      <div className="font-medium">Sınır:</div>
                      <div className="text-xs">
                        Sadece bir üst kariyer seviyesine kadar
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-yellow-200">
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center gap-2">
                      <Crown className="h-5 w-5 text-yellow-600" />
                      Kariyer Bonusu
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="text-sm">
                      <div className="font-medium">Bonus Havuzundan %25</div>
                      <div className="text-gray-600">
                        Kariyer seviyesine göre dağıtım
                      </div>
                    </div>
                    <div className="space-y-1 text-xs">
                      <div className="flex justify-between">
                        <span>Emmare:</span>
                        <span className="font-medium">%2</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Radiyye:</span>
                        <span className="font-medium">%6</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Safiye:</span>
                        <span className="font-medium">%12</span>
                      </div>
                    </div>
                    <div className="p-2 bg-yellow-50 rounded text-sm">
                      <div className="font-medium">Hesaplama:</div>
                      <div className="text-xs">
                        Aylık toplam yatırımların %40'ının %25'i
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="career" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Star className="h-5 w-5" />
                Kariyer Mertebeleri
              </CardTitle>
              <CardDescription>
                Kutbul Zaman Network kariyer sistemi ve gereksinimleri
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {KUTBUL_ZAMAN_RANKS.map((rank, index) => (
                  <div
                    key={rank.name}
                    className={`p-4 border rounded-lg ${
                      rank.name === user.rank
                        ? "border-purple-300 bg-purple-50"
                        : "border-gray-200"
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-3">
                        <div className="text-lg font-bold text-purple-800">
                          {rank.name}
                        </div>
                        {rank.name === user.rank && (
                          <Badge className="bg-purple-100 text-purple-800">
                            Mevcut Seviye
                          </Badge>
                        )}
                      </div>
                      <div className="text-right">
                        <div className="text-sm text-gray-600">
                          Kariyer Bonusu
                        </div>
                        <div className="font-bold text-purple-600">
                          %
                          {(rank.benefits.leadershipBonusRate * 100).toFixed(0)}
                        </div>
                      </div>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                      <div>
                        <div className="font-medium mb-1">Gereksinimler:</div>
                        <ul className="space-y-1 text-gray-600">
                          <li>
                            • Yatırım: ${rank.requirements.personalVolume}
                          </li>
                          <li>
                            • Direkt Referans:{" "}
                            {rank.requirements.directReferrals}
                          </li>
                          {rank.requirements.leaderCount && (
                            <li>
                              • Lider Sayısı: {rank.requirements.leaderCount}
                            </li>
                          )}
                          {rank.requirements.totalDownlineCount && (
                            <li>
                              • Toplam Ekip:{" "}
                              {rank.requirements.totalDownlineCount}
                            </li>
                          )}
                        </ul>
                      </div>
                      <div>
                        <div className="font-medium mb-1">Faydalar:</div>
                        <ul className="space-y-1 text-gray-600">
                          <li>
                            • Sponsor: %
                            {(rank.benefits.sponsorBonusRate * 100).toFixed(0)}
                          </li>
                          <li>
                            • Sonsuz Ekip: %
                            {(rank.benefits.infiniteTeamRate * 100).toFixed(1)}
                          </li>
                          {rank.benefits.annualBonusExtra && (
                            <li>
                              • Yıllık Ek: +%
                              {(rank.benefits.annualBonusExtra * 100).toFixed(
                                0,
                              )}
                            </li>
                          )}
                        </ul>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Bonus Dağılımı</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Sponsor Bonusları</span>
                    <div className="flex items-center gap-2">
                      <Progress
                        value={
                          (bonusStats.sponsorBonuses / bonusStats.totalEarned) *
                          100
                        }
                        className="w-20"
                      />
                      <span className="text-sm font-medium">
                        %
                        {(
                          (bonusStats.sponsorBonuses / bonusStats.totalEarned) *
                          100
                        ).toFixed(0)}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Sonsuz Ekip</span>
                    <div className="flex items-center gap-2">
                      <Progress
                        value={
                          (bonusStats.infiniteTeamBonuses /
                            bonusStats.totalEarned) *
                          100
                        }
                        className="w-20"
                      />
                      <span className="text-sm font-medium">
                        %
                        {(
                          (bonusStats.infiniteTeamBonuses /
                            bonusStats.totalEarned) *
                          100
                        ).toFixed(0)}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Kariyer Bonusları</span>
                    <div className="flex items-center gap-2">
                      <Progress
                        value={
                          (bonusStats.careerBonuses / bonusStats.totalEarned) *
                          100
                        }
                        className="w-20"
                      />
                      <span className="text-sm font-medium">
                        %
                        {(
                          (bonusStats.careerBonuses / bonusStats.totalEarned) *
                          100
                        ).toFixed(0)}
                      </span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Performans Metrikleri</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span className="text-sm">Aylık Ortalama</span>
                    <span className="font-medium">
                      ${(bonusStats.totalEarned / 1).toFixed(2)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">En Yüksek Bonus</span>
                    <span className="font-medium">
                      $
                      {Math.max(
                        ...kutbulZamanBonuses.map((b) => b.amount),
                      ).toFixed(2)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Aktif Bonus Türü</span>
                    <span className="font-medium">3/3</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Sonraki Seviye</span>
                    <span className="font-medium text-purple-600">
                      Safiye (Mevcut)
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
