import { useState, useEffect } from "react";
import { useNavigate, Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import Header from "@/components/Header";
import {
  Users,
  TrendingUp,
  Target,
  Star,
  Crown,
  DollarSign,
  Eye,
  EyeOff,
  Play,
  ChevronRight,
  CheckCircle,
  ArrowRight,
  Zap,
  Shield,
  Globe,
  Award,
  BarChart3,
  Network,
  Sparkles,
  Heart,
  Lightbulb,
  Menu,
  X,
  UserPlus,
  Gift,
} from "lucide-react";

export default function Landing() {
  const [isLoginOpen, setIsLoginOpen] = useState(false);
  const [isRegisterOpen, setIsRegisterOpen] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const navigate = useNavigate();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const formData = new FormData(e.target as HTMLFormElement);
    const username = formData.get("username") as string;
    const password = formData.get("password") as string;

    // Simulate login
    const userData = {
      username,
      role: username === "admin" ? "admin" : "user",
      name: username === "admin" ? "Yönetici" : "Kullanıcı",
    };
    localStorage.setItem("mlm_user", JSON.stringify(userData));
    setIsLoginOpen(false);
    navigate("/dashboard");
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setIsRegisterOpen(false);
    setIsLoginOpen(true);
  };

  const stats = [
    {
      label: "Aktif Üye",
      value: "12,847",
      icon: Users,
      color: "text-blue-600",
    },
    {
      label: "Toplam Kazanç",
      value: "₺8.5M",
      icon: DollarSign,
      color: "text-green-600",
    },
    {
      label: "Başarı Oranı",
      value: "%94",
      icon: TrendingUp,
      color: "text-purple-600",
    },
    {
      label: "Ülke Sayısı",
      value: "23",
      icon: Globe,
      color: "text-orange-600",
    },
  ];

  const steps = [
    {
      number: "01",
      title: "Kayıt Ol",
      description: "Ücretsiz hesap oluştur ve sisteme katıl",
      icon: UserPlus,
      color: "bg-blue-500",
    },
    {
      number: "02",
      title: "Takımını Kur",
      description: "Referans kodunla yeni üyeler davet et",
      icon: Network,
      color: "bg-green-500",
    },
    {
      number: "03",
      title: "Kazan",
      description: "Binary sistem ve bonuslarla gelir elde et",
      icon: DollarSign,
      color: "bg-purple-500",
    },
  ];

  const features = [
    {
      title: "Binary Sistem",
      description: "Sol ve sağ bacak eşleşmesiyle maksimum kazanç",
      icon: BarChart3,
      color: "text-blue-600",
    },
    {
      title: "Çoklu Bonus",
      description: "Sponsor, eşleşme, liderlik ve satış bonusları",
      icon: Gift,
      color: "text-green-600",
    },
    {
      title: "Güvenli Sistem",
      description: "Şifreli altyapı ve güvenli ödeme sistemi",
      icon: Shield,
      color: "text-purple-600",
    },
    {
      title: "7/24 Destek",
      description: "Kesintisiz teknik ve operasyonel destek",
      icon: Heart,
      color: "text-red-600",
    },
  ];

  const motivationalQuotes = [
    {
      quote:
        "Başarı, hazırlığın fırsatla buluşması değildir. Başarı, azmin bilgiyle buluşmasıdır.",
      author: "Kutbul Zaman Network",
      role: "Kurucu Vizyonu",
    },
    {
      quote:
        "Takım halinde çalışmak, bireysel yeteneklerin ortak bir hedefe yönlendirilmesidir.",
      author: "Liderlik Akademisi",
      role: "Başarı Formülü",
    },
    {
      quote:
        "Büyük başarılar, küçük adımların toplamından oluşur. Her günün bir adım olsun.",
      author: "Network Marketing",
      role: "Gelişim Felsefesi",
    },
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <Header />

      {/* Hero Section */}
      <section
        id="hero"
        className="bg-gradient-to-br from-blue-50 via-white to-purple-50 py-20 lg:py-32"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="flex justify-center mb-6">
              <Badge className="bg-gradient-to-r from-[#2D1E5F] to-[#00A9A5] text-white px-6 py-2 text-lg rounded-xl">
                <Sparkles className="w-5 h-5 mr-2" />
                Kutbul Zaman Network
              </Badge>
            </div>

            <h1 className="text-4xl lg:text-7xl font-bold text-gray-900 mb-6 leading-tight">
              <span className="bg-gradient-to-r from-[#2D1E5F] to-[#00A9A5] bg-clip-text text-transparent">
                Kazandıran sistem,
              </span>
              <br />
              <span className="text-[#2D1E5F]">sürdürülebilir başarı</span>
            </h1>

            <p className="text-xl text-gray-600 mb-10 max-w-3xl mx-auto leading-relaxed">
              Girişimci ruhu ve takım gücüyle birlikte, binary MLM sisteminin
              sunduğu sınırsız gelir fırsatlarından yararlanın. Başarıya giden
              yolda size öncülük ediyoruz.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Button
                onClick={() => setIsRegisterOpen(true)}
                size="lg"
                className="bg-[#00A9A5] hover:bg-[#008b87] text-lg px-8 py-6 rounded-xl"
              >
                <Zap className="w-5 h-5 mr-2" />
                Hemen Başla
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>

              <Button
                variant="outline"
                size="lg"
                className="border-2 border-[#2D1E5F] text-[#2D1E5F] text-lg px-8 py-6 hover:bg-[#2D1E5F] hover:text-white rounded-xl"
              >
                <Play className="w-5 h-5 mr-2" />
                Tanıtım Videosu
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => {
              const Icon = stat.icon;
              return (
                <div key={index} className="text-center">
                  <div className="flex justify-center mb-4">
                    <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center">
                      <Icon className={`w-8 h-8 ${stat.color}`} />
                    </div>
                  </div>
                  <div className="text-3xl font-bold text-gray-900 mb-2">
                    {stat.value}
                  </div>
                  <div className="text-gray-600">{stat.label}</div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section id="system" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              3 Adımda Nasıl Çalışır?
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Basit adımlarla başarıya ulaşın ve sürdürülebilir gelir elde edin
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {steps.map((step, index) => {
              const Icon = step.icon;
              return (
                <div key={index} className="relative">
                  <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow">
                    <div className="flex items-center justify-between mb-6">
                      <div
                        className={`w-16 h-16 ${step.color} rounded-xl flex items-center justify-center`}
                      >
                        <Icon className="w-8 h-8 text-white" />
                      </div>
                      <div className="text-6xl font-bold text-gray-100">
                        {step.number}
                      </div>
                    </div>
                    <h3 className="text-2xl font-bold text-gray-900 mb-4">
                      {step.title}
                    </h3>
                    <p className="text-gray-600 leading-relaxed">
                      {step.description}
                    </p>
                  </div>

                  {index < steps.length - 1 && (
                    <div className="hidden md:block absolute top-1/2 -right-4 transform -translate-y-1/2">
                      <ChevronRight className="w-8 h-8 text-gray-300" />
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Sistem Özellikleri
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Modern teknoloji ve güvenilir altyapıyla desteklenen özellikler
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <div
                  key={index}
                  className="text-center p-6 rounded-xl hover:bg-gray-50 transition-colors"
                >
                  <div className="flex justify-center mb-4">
                    <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center">
                      <Icon className={`w-8 h-8 ${feature.color}`} />
                    </div>
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">
                    {feature.title}
                  </h3>
                  <p className="text-gray-600">{feature.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Earnings Plan */}
      <section className="py-20 bg-gradient-to-br from-blue-50 to-purple-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Kazanç Planı
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Binary sistem ile sınırsız gelir potansiyeli
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="bg-white rounded-2xl p-8 shadow-xl">
                <h3 className="text-2xl font-bold text-gray-900 mb-6">
                  Bonus Türleri
                </h3>
                <div className="space-y-4">
                  {[
                    {
                      name: "Sponsor Bonusu",
                      rate: "%20",
                      description: "Direkt referanslarınızdan",
                    },
                    {
                      name: "Eşleşme Bonusu",
                      rate: "%12",
                      description: "Binary sistem eşleşmeleri",
                    },
                    {
                      name: "Liderlik Bonusu",
                      rate: "%5",
                      description: "Takım performansından",
                    },
                    {
                      name: "Satış Bonusu",
                      rate: "%8",
                      description: "Kişisel satışlarınızdan",
                    },
                  ].map((bonus, index) => (
                    <div
                      key={index}
                      className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
                    >
                      <div>
                        <div className="font-semibold text-gray-900">
                          {bonus.name}
                        </div>
                        <div className="text-sm text-gray-600">
                          {bonus.description}
                        </div>
                      </div>
                      <div className="text-2xl font-bold text-green-600">
                        {bonus.rate}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div>
              <div className="bg-white rounded-2xl p-8 shadow-xl">
                <div className="flex items-center justify-center h-64 bg-gradient-to-br from-blue-100 to-purple-100 rounded-xl mb-6">
                  <div className="text-center">
                    <Play className="w-16 h-16 text-blue-600 mx-auto mb-4 cursor-pointer hover:text-blue-700 transition-colors" />
                    <p className="text-gray-600">Kazanç Planı Videosu</p>
                  </div>
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-4">
                  Binary Sistem Avantajları
                </h3>
                <ul className="space-y-3">
                  {[
                    "Sınırsız derinlik",
                    "Otomatik yeniden dağıtım",
                    "Hızlı büyüme potansiyeli",
                    "Adil kazanç dağılımı",
                  ].map((advantage, index) => (
                    <li key={index} className="flex items-center">
                      <CheckCircle className="w-5 h-5 text-green-500 mr-3" />
                      <span className="text-gray-700">{advantage}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Leadership Content */}
      <section id="leadership" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Liderlik & Motivasyon
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Başarı hikayelerinden ilham alın ve hedefinize odaklanın
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {motivationalQuotes.map((quote, index) => (
              <div
                key={index}
                className="bg-gradient-to-br from-gray-50 to-gray-100 rounded-2xl p-8"
              >
                <div className="flex justify-center mb-6">
                  <Lightbulb className="w-12 h-12 text-yellow-500" />
                </div>
                <blockquote className="text-lg text-gray-700 mb-6 leading-relaxed">
                  "{quote.quote}"
                </blockquote>
                <div className="text-center">
                  <div className="font-semibold text-gray-900">
                    {quote.author}
                  </div>
                  <div className="text-sm text-gray-600">{quote.role}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="flex justify-center items-center space-x-3 mb-6">
              <div className="w-12 h-12 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                <Network className="w-7 h-7 text-white" />
              </div>
              <div>
                <h3 className="text-2xl font-bold">Kutbul Zaman Network</h3>
                <p className="text-gray-400">MLM & Gelir Paylaşım Sistemi</p>
              </div>
            </div>

            <p className="text-gray-400 max-w-2xl mx-auto mb-8">
              Girişimcilik ruhu ve takım çalışmasıyla birlikte sürdürülebilir
              başarıya ulaşın. Network marketing dünyasında fark yaratın.
            </p>

            <div className="border-t border-gray-800 pt-8">
              <p className="text-gray-500">
                © 2024 Kutbul Zaman Network. Tüm hakları saklıdır.
              </p>
            </div>
          </div>
        </div>
      </footer>

      {/* Login Dialog */}
      <Dialog open={isLoginOpen} onOpenChange={setIsLoginOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-center text-2xl">
              Giriş Yap
            </DialogTitle>
            <DialogDescription className="text-center">
              Hesabınıza erişim sağlayın
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <Label htmlFor="username">Kullanıcı Adı</Label>
              <Input
                id="username"
                name="username"
                type="text"
                required
                className="mt-1"
                placeholder="Kullanıcı adınızı girin"
              />
            </div>
            <div>
              <Label htmlFor="password">Şifre</Label>
              <div className="relative mt-1">
                <Input
                  id="password"
                  name="password"
                  type={showPassword ? "text" : "password"}
                  required
                  placeholder="Şifrenizi girin"
                />
                <button
                  type="button"
                  className="absolute inset-y-0 right-0 pr-3 flex items-center"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? (
                    <EyeOff className="h-4 w-4" />
                  ) : (
                    <Eye className="h-4 w-4" />
                  )}
                </button>
              </div>
            </div>
            <Button
              type="submit"
              className="w-full bg-gradient-to-r from-blue-600 to-purple-600"
            >
              Giriş Yap
            </Button>
            <div className="text-center text-sm text-gray-600">
              Hesabınız yok mu?{" "}
              <button
                type="button"
                onClick={() => {
                  setIsLoginOpen(false);
                  setIsRegisterOpen(true);
                }}
                className="text-blue-600 hover:underline"
              >
                Kayıt olun
              </button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Register Dialog */}
      <Dialog open={isRegisterOpen} onOpenChange={setIsRegisterOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-center text-2xl">Kayıt Ol</DialogTitle>
            <DialogDescription className="text-center">
              Yeni hesap oluşturun ve başarı yolculuğunuza başlayın
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleRegister} className="space-y-4">
            <div>
              <Label htmlFor="reg-name">Ad Soyad</Label>
              <Input
                id="reg-name"
                type="text"
                required
                className="mt-1"
                placeholder="Adınızı ve soyadınızı girin"
              />
            </div>
            <div>
              <Label htmlFor="reg-email">E-posta</Label>
              <Input
                id="reg-email"
                type="email"
                required
                className="mt-1"
                placeholder="E-posta adresinizi girin"
              />
            </div>
            <div>
              <Label htmlFor="reg-username">Kullanıcı Adı</Label>
              <Input
                id="reg-username"
                type="text"
                required
                className="mt-1"
                placeholder="Kullanıcı adınızı seçin"
              />
            </div>
            <div>
              <Label htmlFor="reg-sponsor">Sponsor Kodu (Opsiyonel)</Label>
              <Input
                id="reg-sponsor"
                type="text"
                className="mt-1"
                placeholder="Sponsor kodunu girin"
              />
            </div>
            <div>
              <Label htmlFor="reg-password">Şifre</Label>
              <Input
                id="reg-password"
                type="password"
                required
                className="mt-1"
                placeholder="Güçlü bir şifre oluşturun"
              />
            </div>
            <Button
              type="submit"
              className="w-full bg-gradient-to-r from-blue-600 to-purple-600"
            >
              Kayıt Ol
            </Button>
            <div className="text-center text-sm text-gray-600">
              Zaten hesabınız var mı?{" "}
              <button
                type="button"
                onClick={() => {
                  setIsRegisterOpen(false);
                  setIsLoginOpen(true);
                }}
                className="text-blue-600 hover:underline"
              >
                Giriş yapın
              </button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
