import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Users,
  Home,
  GitBranch,
  TrendingUp,
  Settings as SettingsIcon,
  LogOut,
  Copy,
  Check,
  DollarSign,
  UserPlus,
  Crown,
  BarChart3,
  Bell,
  ChevronLeft,
  Menu,
  Wallet as WalletIcon,
  Award,
  Target,
  Calendar,
  ArrowUpRight,
  ArrowDownRight,
  Coins,
  CreditCard,
  History,
  PieChart,
  LineChart,
  TreePine,
  Trophy,
  Zap,
  Eye,
  Banknote,
  Gift,
  Star,
  Network,
  TrendingDown,
} from "lucide-react";
import {
  User,
  Wallet as WalletType,
  Transaction,
  Bonus,
  KUTBUL_ZAMAN_RANKS,
} from "../../shared/mlm-types";
import Wallet from "@/components/Wallet";
import BinaryTree from "@/components/BinaryTree";
import BonusSystem from "@/components/BonusSystem";
import { ActivityManager } from "@/components/ActivityManager";
import { IncomeDistribution } from "@/components/IncomeDistribution";
import KutbulZamanBonusSystem from "@/components/KutbulZamanBonusSystem";
import EarningsHistory from "@/components/EarningsHistory";
import Settings from "@/components/Settings";
import Notifications from "@/components/Notifications";

export default function Dashboard() {
  const [user, setUser] = useState<User | null>(null);
  const [wallet, setWallet] = useState<WalletType | null>(null);
  const [activeTab, setActiveTab] = useState("dashboard");
  const [referralLinkCopied, setReferralLinkCopied] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const navigate = useNavigate();

  const referralLink = `https://kutbulzaman.com/register?ref=${user?.referenceNumber || user?.username || "ak000001"}`;

  // Transaction data - gerçek sistemde API'den gelecek
  const sampleTransactions: Transaction[] = [
    {
      id: "1",
      userId: "ak000001",
      type: "bonus",
      subType: "sponsor",
      amount: 125.0,
      currency: "USD",
      description: "Sponsor bonusu - Yeni üye yatırımı",
      status: "completed",
      date: "2024-03-15T10:30:00Z",
    },
    {
      id: "2",
      userId: "ak000001",
      type: "bonus",
      subType: "career_bonus",
      amount: 300.0,
      currency: "USD",
      description: "Kariyer bonusu - Safiye seviyesi",
      status: "completed",
      date: "2024-03-01T00:00:00Z",
    },
    {
      id: "3",
      userId: "ak000001",
      type: "bonus",
      subType: "infinite_team",
      amount: 85.0,
      currency: "USD",
      description: "Sonsuz ekip bonusu - Alt üye yatırımları",
      status: "completed",
      date: "2024-03-10T14:20:00Z",
    },
    {
      id: "4",
      userId: "ak000001",
      type: "withdrawal",
      amount: -250.0,
      currency: "USD",
      description: "Çekim talebi - Banka transferi",
      status: "pending",
      date: "2024-03-14T16:00:00Z",
    },
  ];

  const sampleBonuses: Bonus[] = [
    {
      id: "1",
      userId: "user1",
      type: "binary",
      amount: 1250.5,
      percentage: 12,
      period: "2024-01",
      date: "2024-01-31T00:00:00Z",
      status: "paid",
      calculationData: { leftLeg: 15000, rightLeg: 18000, matched: 15000 },
    },
    {
      id: "2",
      userId: "user1",
      type: "sponsor",
      amount: 850.0,
      percentage: 20,
      fromUserName: "5 direkt referans",
      period: "2024-01",
      date: "2024-01-31T00:00:00Z",
      status: "paid",
      calculationData: { directReferrals: 5, totalVolume: 4250 },
    },
  ];

  useEffect(() => {
    const userData = localStorage.getItem("mlm_user");
    if (!userData) {
      navigate("/login");
      return;
    }

    const parsedUser = JSON.parse(userData);

    // Use real user data from localStorage with defaults
    const enhancedUser: User = {
      ...parsedUser,
      totalInvestment: parsedUser.totalInvestment || 0,
      leftLegVolume: parsedUser.leftLegVolume || 0,
      rightLegVolume: parsedUser.rightLegVolume || 0,
      totalDownlineCount: parsedUser.totalDownlineCount || 0,
      directReferrals: parsedUser.directReferrals || 0,
      leaderCount: parsedUser.leaderCount || 0,
      activeIncome: parsedUser.activeIncome || 0,
      passiveIncome: parsedUser.passiveIncome || 0,
      sponsorIncome: parsedUser.sponsorIncome || 0,
      totalEarnings: parsedUser.totalEarnings || 0,
      personalVolume: parsedUser.personalVolume || 0,
      groupVolume: parsedUser.groupVolume || 0,
      activityStatus: parsedUser.activityStatus || "pending",
    };

    const sampleWallet: WalletType = {
      id: "wallet1",
      userId: "user1",
      totalBalance: 15840.75,
      availableBalance: 14340.75,
      pendingBalance: 1500.0,
      currencies: {
        TRY: 15840.75,
        USD: 534.5,
        EUR: 467.3,
      },
      lastUpdated: new Date().toISOString(),
    };

    setUser(enhancedUser);
    setWallet(sampleWallet);
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem("mlm_user");
    navigate("/login");
  };

  const copyReferralLink = async () => {
    await navigator.clipboard.writeText(referralLink);
    setReferralLinkCopied(true);
    setTimeout(() => setReferralLinkCopied(false), 2000);
  };

  const getCurrentRank = () => {
    if (!user) return KUTBUL_ZAMAN_RANKS[0];
    return (
      KUTBUL_ZAMAN_RANKS.find((rank) => rank.name === user.rank) ||
      KUTBUL_ZAMAN_RANKS[0]
    );
  };

  const getNextRank = () => {
    const currentRank = getCurrentRank();
    return KUTBUL_ZAMAN_RANKS.find(
      (rank) => rank.level === currentRank.level + 1,
    );
  };

  const calculateRankProgress = () => {
    if (!user) return 0;
    const currentRank = getCurrentRank();
    const nextRank = getNextRank();
    if (!nextRank) return 100;

    const progress = Math.min(
      ((user.totalInvestment || 0) / nextRank.requirements.personalVolume) *
        100,
      ((user.groupVolume || 0) / nextRank.requirements.groupVolume) * 100,
      ((user.directReferrals || 0) / nextRank.requirements.directReferrals) *
        100,
    );
    return Math.round(progress);
  };

  const navigationButtons = [
    {
      id: "career",
      label: "Kariyerim",
      icon: Crown,
      href: "/panel/kariyerim",
      color: "bg-purple-600 hover:bg-purple-700",
    },
    {
      id: "bonuses",
      label: "Bonuslarım",
      icon: Award,
      href: "/panel/bonuslar",
      color: "bg-blue-600 hover:bg-blue-700",
    },
    {
      id: "investment",
      label: "Yatırım Yap",
      icon: Coins,
      href: "/panel/yatirim-yap",
      color: "bg-green-600 hover:bg-green-700",
    },
    {
      id: "simulation",
      label: "Kazanç Simülasyonu",
      icon: BarChart3,
      href: "/panel/simulasyon",
      color: "bg-indigo-600 hover:bg-indigo-700",
    },
    {
      id: "shopping",
      label: "Alışverişe Git",
      icon: Star,
      href: "/alisveris",
      color: "bg-accent hover:bg-accent/90",
    },
    {
      id: "development",
      label: "Kişisel Gelişim",
      icon: Target,
      href: "/gelisim",
      color: "bg-info hover:bg-info/90",
    },
    ...(user?.role === "admin"
      ? [
          {
            id: "admin-panel",
            label: "Admin Paneli",
            icon: Crown,
            href: "/admin",
            color: "bg-warning hover:bg-warning/90",
          },
        ]
      : []),
  ];

  const sidebarItems = [
    { id: "dashboard", label: "Ana Panel", icon: Home },
    { id: "wallet", label: "E-Cüzdan", icon: WalletIcon },
    { id: "team", label: "Ekip Ağacı", icon: GitBranch },
    { id: "bonuses", label: "Bonuslar", icon: TrendingUp },
    { id: "earnings", label: "Kazanç Geçmişi", icon: DollarSign },
    { id: "activity", label: "Aktiflik", icon: Calendar },
    { id: "distribution", label: "Gelir Dağıtım", icon: PieChart },
    { id: "notifications", label: "Bildirimler", icon: Bell },
    ...(user?.role === "admin"
      ? [
          { id: "admin", label: "Admin Panel", icon: Crown },
          { id: "members", label: "Üye Yönetimi", icon: Users },
          { id: "announcements", label: "Duyurular", icon: Star },
        ]
      : []),
    { id: "settings", label: "Ayarlar", icon: SettingsIcon },
  ];

  if (!user || !wallet) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-primary/10 via-background to-accent/10 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Yükleniyor...</p>
        </div>
      </div>
    );
  }

  const renderDashboard = () => (
    <div className="space-y-6">
      {/* Welcome Section */}
      <Card className="border-2 border-primary/20 bg-gradient-to-r from-primary/5 to-accent/5">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-2xl text-primary flex items-center gap-2">
                <Crown className="w-6 h-6" />
                Hoş Geldiniz, {user.name}!
              </CardTitle>
              <CardDescription className="text-lg mt-2">
                {user.referenceNumber === "ak000001"
                  ? "Kutbul Zaman Network kurucusu ve sistem yöneticisi olarak hoş geldiniz"
                  : "Kutbul Zaman Network üyesi olarak sisteme hoş geldiniz"}
              </CardDescription>
              <div className="flex flex-wrap items-center gap-4 mt-3">
                <div className="flex items-center gap-2">
                  <span className="text-sm">Pozisyon:</span>
                  <Badge
                    variant={
                      user.referenceNumber === "ak000001"
                        ? "default"
                        : "secondary"
                    }
                    className={
                      user.referenceNumber === "ak000001"
                        ? "bg-purple-600 text-white font-semibold"
                        : "text-accent font-semibold"
                    }
                  >
                    {user.referenceNumber === "ak000001" ? "KURUCU" : user.rank}
                  </Badge>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm">Ref Kodu:</span>
                  <Badge variant="outline" className="font-mono">
                    {user.referenceNumber || user.username.toUpperCase()}
                  </Badge>
                </div>
                <div className="text-sm text-muted-foreground">
                  Üyelik:{" "}
                  {user.joinDate
                    ? new Date(user.joinDate).toLocaleDateString("tr-TR")
                    : "Bilinmiyor"}
                </div>
              </div>
            </div>
            <div className="text-right">
              <div className="text-3xl font-bold text-accent">
                $
                {wallet.totalBalance.toLocaleString("en-US", {
                  minimumFractionDigits: 2,
                })}
              </div>
              <div className="text-sm text-muted-foreground">Toplam Bakiye</div>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Stats Grid */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="border-l-4 border-l-success">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Toplam Kazanç</CardTitle>
            <DollarSign className="h-4 w-4 text-success" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-success">
              ${wallet.totalBalance.toLocaleString("en-US")}
            </div>
            <p className="text-xs text-muted-foreground">+$455 bu ay</p>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-info">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Ekip Üyeleri</CardTitle>
            <Users className="h-4 w-4 text-info" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-info">
              {user.totalDownlineCount || 0}
            </div>
            <p className="text-xs text-muted-foreground">
              Direkt: {user.directReferrals || 0} • Dolaylı:{" "}
              {(user.totalDownlineCount || 0) - (user.directReferrals || 0)}
            </p>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-accent">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Toplam Yatırım
            </CardTitle>
            <BarChart3 className="h-4 w-4 text-accent" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-accent">
              ${(user.totalInvestment || 0).toLocaleString("en-US")}
            </div>
            <p className="text-xs text-muted-foreground">
              Kutbul Zaman sistemi
            </p>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-warning">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Aktiflik Durumu
            </CardTitle>
            <Gift className="h-4 w-4 text-warning" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-warning">
              {(user.activityStatus || "pending") === "active"
                ? "Aktif"
                : "Pasif"}
            </div>
            <p className="text-xs text-muted-foreground">
              Son ödeme: {user.lastActivityPayment || "Yok"}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Rank Progress */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Trophy className="w-5 h-5 text-accent" />
            Rütbe İlerlemeniz
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">
                Mevcut Rütbe: {user.rank}
              </span>
              <span className="text-sm text-muted-foreground">
                {getNextRank()
                  ? `Hedef: ${getNextRank()?.name}`
                  : "Maksimum seviye"}
              </span>
            </div>
            <Progress value={calculateRankProgress()} className="h-3" />
            <div className="grid grid-cols-3 gap-4 text-sm">
              <div>
                <div className="font-medium">Toplam Yatırım</div>
                <div className="text-muted-foreground">
                  ${(user.totalInvestment || 0).toLocaleString("en-US")} / $
                  {getNextRank()?.requirements.personalVolume.toLocaleString(
                    "en-US",
                  ) || "Max"}
                </div>
              </div>
              <div>
                <div className="font-medium">Direkt Referanslar</div>
                <div className="text-muted-foreground">
                  {user.directReferrals || 0} /{" "}
                  {getNextRank()?.requirements.directReferrals || "Max"}
                </div>
              </div>
              <div>
                <div className="font-medium">Lider Sayısı</div>
                <div className="text-muted-foreground">
                  {user.leaderCount || 0} /{" "}
                  {getNextRank()?.requirements.leaderCount || "Max"}
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Navigation Buttons */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Star className="w-5 h-5 text-primary" />
            Hızlı Erişim
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
            {navigationButtons.map((button) => {
              const Icon = button.icon;
              return (
                <Button
                  key={button.id}
                  className={`h-16 ${button.color} text-white font-semibold`}
                  onClick={() => navigate(button.href)}
                >
                  <div className="flex flex-col items-center gap-2">
                    <Icon className="w-6 h-6" />
                    <span className="text-sm">{button.label}</span>
                  </div>
                </Button>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Binary Tree Summary & Referral */}
      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Network className="w-5 h-5 text-primary" />
              Binary Ağaç Özeti
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <div className="text-center">
                  <div className="text-2xl font-bold text-info">
                    ${(user.leftLegVolume || 0).toLocaleString("en-US")}
                  </div>
                  <div className="text-sm text-muted-foreground">Sol Bacak</div>
                </div>
                <div className="flex items-center text-muted-foreground">
                  <ArrowUpRight className="w-4 h-4" />
                  <TreePine className="w-8 h-8 mx-2" />
                  <ArrowDownRight className="w-4 h-4" />
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-warning">
                    ${(user.rightLegVolume || 0).toLocaleString("en-US")}
                  </div>
                  <div className="text-sm text-muted-foreground">Sağ Bacak</div>
                </div>
              </div>
              <div className="text-center text-sm text-muted-foreground">
                Eşleşen Hacim: $
                {Math.min(
                  user.leftLegVolume || 0,
                  user.rightLegVolume || 0,
                ).toLocaleString("en-US")}
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <UserPlus className="w-5 h-5 text-accent" />
              Kayıt Linki Oluşturma ve Alt Üye Ekleme
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex space-x-2">
                <input
                  type="text"
                  value={referralLink}
                  readOnly
                  className="flex-1 px-3 py-2 text-sm bg-muted border border-border rounded-md"
                />
                <Button
                  onClick={copyReferralLink}
                  variant="outline"
                  className="border-2 border-accent text-accent hover:bg-accent hover:text-accent-foreground"
                >
                  {referralLinkCopied ? (
                    <Check className="w-4 h-4" />
                  ) : (
                    <Copy className="w-4 h-4" />
                  )}
                </Button>
              </div>
              <div className="text-sm text-muted-foreground">
                Bu linki paylaşarak yeni üyeler davet edin ve sponsor bonusu
                kazanın. Ref Kodunuz:{" "}
                <strong>
                  {user.referenceNumber || user.username.toUpperCase()}
                </strong>
                {user.referenceNumber === "ak000001" && (
                  <span className="ml-2 text-purple-600 font-semibold">
                    (Kurucu)
                  </span>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <History className="w-5 h-5 text-primary" />
            Son İşlemler
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {sampleTransactions.slice(0, 5).map((transaction) => (
              <div
                key={transaction.id}
                className="flex items-center justify-between p-3 bg-muted/50 rounded-lg"
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-2 h-2 rounded-full ${
                      transaction.type === "bonus"
                        ? "bg-success"
                        : transaction.type === "withdrawal"
                          ? "bg-warning"
                          : "bg-info"
                    }`}
                  />
                  <div>
                    <div className="font-medium">{transaction.description}</div>
                    <div className="text-sm text-muted-foreground">
                      {new Date(transaction.date).toLocaleDateString("tr-TR")}
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div
                    className={`font-semibold ${transaction.amount > 0 ? "text-success" : "text-warning"}`}
                  >
                    {transaction.amount > 0 ? "+" : ""}$
                    {Math.abs(transaction.amount).toLocaleString("en-US", {
                      minimumFractionDigits: 2,
                    })}
                  </div>
                  <Badge
                    variant={
                      transaction.status === "completed"
                        ? "default"
                        : "secondary"
                    }
                    className="text-xs"
                  >
                    {transaction.status === "completed"
                      ? "Tamamlandı"
                      : transaction.status === "pending"
                        ? "Bekliyor"
                        : "İptal"}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );

  return (
    <div className="flex h-screen bg-background">
      {/* Sidebar */}
      <div
        className={`${
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        } fixed inset-y-0 left-0 z-50 w-64 bg-sidebar transform transition-transform duration-300 ease-in-out lg:translate-x-0 lg:static lg:inset-0`}
      >
        <div className="flex items-center justify-between h-16 px-4 border-b border-sidebar-border">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-sidebar-primary rounded-lg flex items-center justify-center">
              <Users className="w-5 h-5 text-sidebar-primary-foreground" />
            </div>
            <span className="text-lg font-bold text-sidebar-foreground mystical-font">
              Kutbul Zaman
            </span>
          </div>
          <Button
            variant="ghost"
            size="sm"
            className="lg:hidden text-sidebar-foreground hover:bg-sidebar-accent"
            onClick={() => setSidebarOpen(false)}
          >
            <ChevronLeft className="w-4 h-4" />
          </Button>
        </div>

        <div className="p-4">
          <div className="flex items-center space-x-3 p-3 bg-sidebar-accent rounded-lg mb-4">
            <Avatar className="w-10 h-10">
              <AvatarImage src="/placeholder.svg" />
              <AvatarFallback className="bg-sidebar-primary text-sidebar-primary-foreground">
                {user.name.charAt(0)}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-sidebar-foreground truncate">
                {user.name}
              </p>
              <div className="flex items-center gap-1">
                <Badge
                  variant={
                    user.referenceNumber === "ak000001"
                      ? "default"
                      : user.role === "admin"
                        ? "default"
                        : "secondary"
                  }
                  className={
                    user.referenceNumber === "ak000001"
                      ? "text-xs bg-purple-600"
                      : "text-xs"
                  }
                >
                  {user.referenceNumber === "ak000001"
                    ? "KURUCU"
                    : user.role === "admin"
                      ? "Yönetici"
                      : user.rank}
                </Badge>
                <div className="text-xs text-sidebar-foreground">
                  ₺{wallet.availableBalance.toLocaleString("tr-TR")}
                </div>
              </div>
            </div>
          </div>

          <nav className="space-y-2">
            {sidebarItems.map((item) => {
              const Icon = item.icon;
              return (
                <Button
                  key={item.id}
                  variant={activeTab === item.id ? "default" : "ghost"}
                  className={`w-full justify-start ${
                    activeTab === item.id
                      ? "bg-sidebar-primary text-sidebar-primary-foreground"
                      : "text-sidebar-foreground hover:bg-sidebar-accent"
                  }`}
                  onClick={() => setActiveTab(item.id)}
                >
                  <Icon className="w-4 h-4 mr-3" />
                  {item.label}
                </Button>
              );
            })}
            <Button
              variant="ghost"
              className="w-full justify-start text-sidebar-foreground hover:bg-destructive hover:text-destructive-foreground mt-4"
              onClick={handleLogout}
            >
              <LogOut className="w-4 h-4 mr-3" />
              Çıkış Yap
            </Button>
          </nav>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="bg-card border-b border-border">
          <div className="flex items-center justify-between h-16 px-6">
            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                size="sm"
                className="lg:hidden"
                onClick={() => setSidebarOpen(true)}
              >
                <Menu className="w-5 h-5" />
              </Button>
              <h1 className="text-xl font-semibold text-foreground">
                {sidebarItems.find((item) => item.id === activeTab)?.label ||
                  "Ana Panel"}
              </h1>
            </div>
            <div className="flex items-center space-x-4">
              <Badge variant="outline" className="border-accent text-accent">
                {user.rank}
              </Badge>
              <div className="text-sm text-muted-foreground">
                ₺{wallet.availableBalance.toLocaleString("tr-TR")}
              </div>
            </div>
          </div>
        </header>

        {/* Main Content Area */}
        <main className="flex-1 overflow-x-hidden overflow-y-auto bg-background p-6">
          {activeTab === "dashboard" && renderDashboard()}

          {/* E-Wallet Component */}
          {activeTab === "wallet" && (
            <Wallet wallet={wallet} transactions={sampleTransactions} />
          )}

          {/* Binary Tree Component */}
          {activeTab === "team" && <BinaryTree user={user} />}

          {/* Kutbul Zaman Bonus System Component */}
          {activeTab === "bonuses" && <KutbulZamanBonusSystem user={user} />}

          {/* Activity Manager Component */}
          {activeTab === "activity" && <ActivityManager />}

          {/* Income Distribution Component */}
          {activeTab === "distribution" && <IncomeDistribution />}

          {/* Earnings History Component */}
          {activeTab === "earnings" && (
            <EarningsHistory user={user} transactions={sampleTransactions} />
          )}

          {/* Settings Component */}
          {activeTab === "settings" && <Settings user={user} />}

          {/* Notifications Component */}
          {activeTab === "notifications" && <Notifications user={user} />}

          {/* Other sections */}
          {![
            "dashboard",
            "wallet",
            "team",
            "bonuses",
            "earnings",
            "settings",
            "notifications",
            "activity",
            "distribution",
          ].includes(activeTab) && (
            <Card>
              <CardHeader>
                <CardTitle>
                  {sidebarItems.find((item) => item.id === activeTab)?.label}
                </CardTitle>
                <CardDescription>
                  Bu bölüm şu anda geliştiriliyor.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Detaylı {activeTab} bölümü yakında tamamlanacak.
                </p>
              </CardContent>
            </Card>
          )}
        </main>
      </div>

      {/* Overlay for mobile sidebar */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}
    </div>
  );
}
