import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import {
  Crown,
  TrendingUp,
  Users,
  DollarSign,
  Target,
  Award,
  Star,
  CheckCircle,
  ArrowRight,
  Trophy,
  Gift,
  Calendar,
  BarChart3,
} from "lucide-react";
import { User, KUTBUL_ZAMAN_RANKS } from "../../shared/mlm-types";

export default function Kariyerim() {
  const [user, setUser] = useState<User | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    const userData = localStorage.getItem("mlm_user");
    if (!userData) {
      navigate("/login");
      return;
    }
    setUser(JSON.parse(userData));
  }, [navigate]);

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Yükleniyor...</p>
        </div>
      </div>
    );
  }

  const getCurrentRank = () => {
    return (
      KUTBUL_ZAMAN_RANKS.find((rank) => rank.name === user.rank) ||
      KUTBUL_ZAMAN_RANKS[0]
    );
  };

  const getNextRank = () => {
    const currentRank = getCurrentRank();
    return KUTBUL_ZAMAN_RANKS.find(
      (rank) => rank.level === currentRank.level + 1,
    );
  };

  const calculateProgress = () => {
    const nextRank = getNextRank();
    if (!nextRank) return 100;

    const investmentProgress =
      (user.totalInvestment / nextRank.requirements.personalVolume) * 100;
    const referralProgress =
      (user.directReferrals / nextRank.requirements.directReferrals) * 100;
    const leaderProgress = nextRank.requirements.leaderCount
      ? (user.leaderCount / nextRank.requirements.leaderCount) * 100
      : 100;

    return Math.min(investmentProgress, referralProgress, leaderProgress);
  };

  const currentRank = getCurrentRank();
  const nextRank = getNextRank();
  const progress = calculateProgress();

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-blue-50 p-4">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-purple-800 mb-2">Kariyerim</h1>
          <p className="text-gray-600">
            Kutbul Zaman Network kariyer seviyeniz ve kazanım durumunuz
          </p>
        </div>

        {/* Current Status */}
        <Card className="border-2 border-purple-200 bg-gradient-to-r from-purple-50 to-blue-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-3">
              <Crown className="h-6 w-6 text-purple-600" />
              Mevcut Seviyeniz
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="text-center">
                <div className="text-6xl font-bold text-purple-600 mb-2">
                  {user.rank}
                </div>
                <div className="text-lg text-gray-600">
                  Seviye {currentRank.level} / 7
                </div>
                <Badge className="mt-2 bg-purple-100 text-purple-800 px-4 py-2">
                  <Star className="h-4 w-4 mr-1" />
                  Aktif Üye
                </Badge>
              </div>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="font-medium">Referans No:</span>
                  <span className="font-bold text-purple-600">
                    {user.referenceNumber}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="font-medium">Üyelik Tarihi:</span>
                  <span>
                    {new Date(user.joinDate).toLocaleDateString("tr-TR")}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="font-medium">Toplam Kazanç:</span>
                  <span className="font-bold text-green-600">
                    ${user.totalEarnings.toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="font-medium">Aktiflik Durumu:</span>
                  <Badge
                    className={
                      user.activityStatus === "active"
                        ? "bg-green-100 text-green-800"
                        : "bg-yellow-100 text-yellow-800"
                    }
                  >
                    {user.activityStatus === "active" ? "Aktif" : "Pasif"}
                  </Badge>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Next Level Progress */}
        {nextRank && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5 text-orange-600" />
                Sonraki Seviye: {nextRank.name}
              </CardTitle>
              <CardDescription>
                {nextRank.name} seviyesine ulaşmak için tamamlamanız gerekenler
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="flex items-center justify-between mb-4">
                  <span className="font-medium">Genel İlerleme</span>
                  <span className="text-sm font-bold">
                    {progress.toFixed(1)}%
                  </span>
                </div>
                <Progress value={progress} className="h-3" />

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="p-4 border rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <DollarSign className="h-4 w-4 text-green-600" />
                      <span className="font-medium">Yatırım Şartı</span>
                    </div>
                    <div className="text-2xl font-bold text-green-600">
                      ${user.totalInvestment.toLocaleString()}
                    </div>
                    <div className="text-sm text-gray-600">
                      / ${nextRank.requirements.personalVolume.toLocaleString()}{" "}
                      gerekli
                    </div>
                    <Progress
                      value={
                        (user.totalInvestment /
                          nextRank.requirements.personalVolume) *
                        100
                      }
                      className="mt-2 h-2"
                    />
                  </div>

                  <div className="p-4 border rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <Users className="h-4 w-4 text-blue-600" />
                      <span className="font-medium">Direkt Referans</span>
                    </div>
                    <div className="text-2xl font-bold text-blue-600">
                      {user.directReferrals}
                    </div>
                    <div className="text-sm text-gray-600">
                      / {nextRank.requirements.directReferrals} gerekli
                    </div>
                    <Progress
                      value={
                        (user.directReferrals /
                          nextRank.requirements.directReferrals) *
                        100
                      }
                      className="mt-2 h-2"
                    />
                  </div>

                  {nextRank.requirements.leaderCount && (
                    <div className="p-4 border rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <Crown className="h-4 w-4 text-purple-600" />
                        <span className="font-medium">Lider Sayısı</span>
                      </div>
                      <div className="text-2xl font-bold text-purple-600">
                        {user.leaderCount}
                      </div>
                      <div className="text-sm text-gray-600">
                        / {nextRank.requirements.leaderCount} gerekli
                      </div>
                      <Progress
                        value={
                          (user.leaderCount /
                            nextRank.requirements.leaderCount) *
                          100
                        }
                        className="mt-2 h-2"
                      />
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {!nextRank && (
          <Card className="border-2 border-gold bg-gradient-to-r from-yellow-50 to-orange-50">
            <CardContent className="text-center py-8">
              <Trophy className="h-16 w-16 text-yellow-600 mx-auto mb-4" />
              <h3 className="text-2xl font-bold text-yellow-800 mb-2">
                Tebrikler! 🎉
              </h3>
              <p className="text-yellow-700">
                En yüksek seviye olan <strong>Safiye</strong> seviyesindesiniz!
              </p>
            </CardContent>
          </Card>
        )}

        {/* Career Benefits */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Gift className="h-5 w-5 text-green-600" />
              Mevcut Seviye Avantajları
            </CardTitle>
            <CardDescription>
              {user.rank} seviyesi ile sahip olduğunuz kazanç oranları
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 bg-blue-50 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <Users className="h-4 w-4 text-blue-600" />
                  <span className="font-medium">Sponsor Bonusu</span>
                </div>
                <div className="text-2xl font-bold text-blue-600">
                  %{(currentRank.benefits.sponsorBonusRate * 100).toFixed(1)}
                </div>
                <div className="text-sm text-gray-600">
                  Her referans yatırımından
                </div>
              </div>

              <div className="p-4 bg-purple-50 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <BarChart3 className="h-4 w-4 text-purple-600" />
                  <span className="font-medium">Sonsuz Ekip</span>
                </div>
                <div className="text-2xl font-bold text-purple-600">
                  %{(currentRank.benefits.infiniteTeamRate * 100).toFixed(1)}
                </div>
                <div className="text-sm text-gray-600">
                  Alt ekip yatırımlarından
                </div>
              </div>

              <div className="p-4 bg-yellow-50 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <Crown className="h-4 w-4 text-yellow-600" />
                  <span className="font-medium">Kariyer Bonusu</span>
                </div>
                <div className="text-2xl font-bold text-yellow-600">
                  %{(currentRank.benefits.leadershipBonusRate * 100).toFixed(1)}
                </div>
                <div className="text-sm text-gray-600">
                  Aylık bonus havuzundan
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* All Career Levels */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              Tüm Kariyer Seviyeleri
            </CardTitle>
            <CardDescription>
              Kutbul Zaman Network kariyer yolculuğu
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {KUTBUL_ZAMAN_RANKS.map((rank, index) => (
                <div
                  key={rank.name}
                  className={`p-4 border rounded-lg ${
                    rank.name === user.rank
                      ? "border-purple-300 bg-purple-50"
                      : "border-gray-200"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="flex items-center gap-2">
                        {rank.name === user.rank && (
                          <CheckCircle className="h-5 w-5 text-green-600" />
                        )}
                        <div className="text-lg font-bold text-purple-800">
                          {rank.level}. {rank.name}
                        </div>
                      </div>
                      {rank.name === user.rank && (
                        <Badge className="bg-purple-100 text-purple-800">
                          Mevcut
                        </Badge>
                      )}
                    </div>
                    <div className="text-right">
                      <div className="text-sm text-gray-600">
                        Kariyer Bonusu
                      </div>
                      <div className="font-bold text-purple-600">
                        %{(rank.benefits.leadershipBonusRate * 100).toFixed(0)}
                      </div>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-3 text-sm">
                    <div>
                      <span className="text-gray-600">Yatırım:</span>
                      <div className="font-medium">
                        ${rank.requirements.personalVolume.toLocaleString()}
                      </div>
                    </div>
                    <div>
                      <span className="text-gray-600">Referans:</span>
                      <div className="font-medium">
                        {rank.requirements.directReferrals}
                      </div>
                    </div>
                    {rank.requirements.leaderCount && (
                      <div>
                        <span className="text-gray-600">Lider:</span>
                        <div className="font-medium">
                          {rank.requirements.leaderCount}
                        </div>
                      </div>
                    )}
                    <div>
                      <span className="text-gray-600">Sonsuz Ekip:</span>
                      <div className="font-medium">
                        %{(rank.benefits.infiniteTeamRate * 100).toFixed(1)}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Action Buttons */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Button
            onClick={() => navigate("/panel/yatirim-yap")}
            className="bg-green-600 hover:bg-green-700 text-white"
          >
            <DollarSign className="h-4 w-4 mr-2" />
            Yatırım Yap
          </Button>
          <Button
            onClick={() => navigate("/panel/bonuslar")}
            className="bg-blue-600 hover:bg-blue-700 text-white"
          >
            <Award className="h-4 w-4 mr-2" />
            Bonuslarım
          </Button>
          <Button
            onClick={() => navigate("/panel/simulasyon")}
            className="bg-purple-600 hover:bg-purple-700 text-white"
          >
            <BarChart3 className="h-4 w-4 mr-2" />
            Kazanç Simülasyonu
          </Button>
        </div>
      </div>
    </div>
  );
}
