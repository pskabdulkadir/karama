import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { GraduationCap, ArrowLeft, Book, Video, Users } from "lucide-react";
import { Link } from "react-router-dom";

export default function Gelisim() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 p-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div className="w-20 h-20 bg-gradient-to-r from-green-600 to-blue-600 rounded-full flex items-center justify-center">
              <GraduationCap className="w-10 h-10 text-white" />
            </div>
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Kişisel Gelişim Merkezi
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Network marketing başarısı için gerekli bilgi ve becerileri
            geliştirin
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader>
              <div className="flex justify-center mb-2">
                <Book className="w-8 h-8 text-blue-600" />
              </div>
              <CardTitle className="text-center">Eğitim Modülleri</CardTitle>
            </CardHeader>
            <CardContent className="text-center">
              <p className="text-gray-600 mb-4">
                Satış teknikleri, liderlik becerileri ve network marketing
                stratejileri
              </p>
              <Button variant="outline" className="w-full">
                Yakında
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex justify-center mb-2">
                <Video className="w-8 h-8 text-green-600" />
              </div>
              <CardTitle className="text-center">Video Dersler</CardTitle>
            </CardHeader>
            <CardContent className="text-center">
              <p className="text-gray-600 mb-4">
                Uzman eğitmenlerden canlı ve kayıtlı video eğitimleri
              </p>
              <Button variant="outline" className="w-full">
                Yakında
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex justify-center mb-2">
                <Users className="w-8 h-8 text-purple-600" />
              </div>
              <CardTitle className="text-center">Mentorluk</CardTitle>
            </CardHeader>
            <CardContent className="text-center">
              <p className="text-gray-600 mb-4">
                Başarılı liderlerden bire bir mentorluk ve coaching hizmetleri
              </p>
              <Button variant="outline" className="w-full">
                Yakında
              </Button>
            </CardContent>
          </Card>
        </div>

        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Gelişim Programı İçerikleri</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-semibold mb-3">Temel Eğitimler</h3>
                <ul className="space-y-2 text-gray-600">
                  <li>• Network Marketing Temelleri</li>
                  <li>• Etkili İletişim Teknikleri</li>
                  <li>• Sunum Becerileri</li>
                  <li>• Zaman Yönetimi</li>
                  <li>• Hedef Belirleme</li>
                </ul>
              </div>
              <div>
                <h3 className="font-semibold mb-3">İleri Seviye</h3>
                <ul className="space-y-2 text-gray-600">
                  <li>• Liderlik ve Takım Yönetimi</li>
                  <li>• Pazarlama Stratejileri</li>
                  <li>• Finansal Planlama</li>
                  <li>• Kişisel Marka Oluşturma</li>
                  <li>• Uluslararası Genişleme</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="text-center">
          <Link to="/">
            <Button className="bg-gradient-to-r from-green-600 to-blue-600">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Ana Sayfaya Dön
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
