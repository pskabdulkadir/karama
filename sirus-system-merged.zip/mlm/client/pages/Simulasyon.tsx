import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import {
  BarChart3,
  Calculator,
  TrendingUp,
  Users,
  Crown,
  DollarSign,
  Target,
  Infinity,
  PieChart,
  LineChart,
  RefreshCw,
  Play,
  Award,
  Coins,
  Calendar,
  ArrowUpRight,
  Gift,
  Zap,
  Star,
} from "lucide-react";
import {
  User,
  KUTBUL_ZAMAN_CONFIG,
  KUTBUL_ZAMAN_RANKS,
  EarningsSimulation,
} from "../../shared/mlm-types";

interface SimulationParams {
  teamSize: number;
  averageInvestment: number;
  personalInvestment: number;
  activeMembers: number;
  monthlyGrowth: number;
  careerLevel: string;
}

export default function Simulasyon() {
  const [user, setUser] = useState<User | null>(null);
  const [params, setParams] = useState<SimulationParams>({
    teamSize: 50,
    averageInvestment: 250,
    personalInvestment: 1000,
    activeMembers: 80,
    monthlyGrowth: 10,
    careerLevel: "Safiye",
  });
  const [simulation, setSimulation] = useState<EarningsSimulation | null>(null);
  const [isCalculating, setIsCalculating] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const userData = localStorage.getItem("mlm_user");
    if (!userData) {
      navigate("/login");
      return;
    }
    setUser(JSON.parse(userData));
    calculateSimulation();
  }, [navigate]);

  const getCurrentRank = () => {
    return (
      KUTBUL_ZAMAN_RANKS.find((rank) => rank.name === params.careerLevel) ||
      KUTBUL_ZAMAN_RANKS[0]
    );
  };

  const calculateSimulation = () => {
    setIsCalculating(true);

    setTimeout(() => {
      const rank = getCurrentRank();
      const totalTeamInvestment = params.teamSize * params.averageInvestment;
      const activeTeamInvestment =
        totalTeamInvestment * (params.activeMembers / 100);

      // Monthly calculations
      const sponsorIncome =
        params.teamSize *
        0.1 * // 10% average monthly new investments
        params.averageInvestment *
        rank.benefits.sponsorBonusRate;

      const passiveIncome =
        activeTeamInvestment * rank.benefits.infiniteTeamRate * 0.05; // 5% monthly passive rate

      const careerIncome =
        totalTeamInvestment *
        KUTBUL_ZAMAN_CONFIG.careerBonusRate *
        rank.benefits.leadershipBonusRate;

      const activeIncome = params.personalInvestment * 0.02; // 2% monthly active income

      const monthlyTotal =
        sponsorIncome + passiveIncome + careerIncome + activeIncome;

      const newSimulation: EarningsSimulation = {
        userId: user?.id || "demo",
        teamSize: params.teamSize,
        averageInvestment: params.averageInvestment,
        monthlyProjection: {
          sponsorIncome: sponsorIncome,
          passiveIncome: passiveIncome,
          careerIncome: careerIncome,
          activeIncome: activeIncome,
          totalIncome: monthlyTotal,
        },
        annualProjection: {
          sponsorIncome: sponsorIncome * 12,
          passiveIncome: passiveIncome * 12,
          careerIncome: careerIncome * 12,
          activeIncome: activeIncome * 12,
          totalIncome: monthlyTotal * 12,
        },
      };

      setSimulation(newSimulation);
      setIsCalculating(false);
    }, 1500);
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Yükleniyor...</p>
        </div>
      </div>
    );
  }

  const rank = getCurrentRank();

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-indigo-50 p-4">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-purple-800 mb-2">
            Kazanç Simülasyonu
          </h1>
          <p className="text-gray-600">
            Varsayılan ekip ve yatırım ile potansiyel kazancınızı hesaplayın
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Simulation Parameters */}
          <Card className="lg:col-span-1">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calculator className="h-5 w-5 text-purple-600" />
                Simülasyon Parametreleri
              </CardTitle>
              <CardDescription>
                Hesaplama için değerleri ayarlayın
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Team Size */}
              <div className="space-y-3">
                <Label>Ekip Büyüklüğü: {params.teamSize} üye</Label>
                <Slider
                  value={[params.teamSize]}
                  onValueChange={([value]) =>
                    setParams({ ...params, teamSize: value })
                  }
                  max={500}
                  min={10}
                  step={10}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-gray-500">
                  <span>10</span>
                  <span>500</span>
                </div>
              </div>

              {/* Average Investment */}
              <div className="space-y-3">
                <Label>
                  Ortalama Yatırım: ${params.averageInvestment.toLocaleString()}
                </Label>
                <Slider
                  value={[params.averageInvestment]}
                  onValueChange={([value]) =>
                    setParams({ ...params, averageInvestment: value })
                  }
                  max={2000}
                  min={100}
                  step={50}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-gray-500">
                  <span>$100</span>
                  <span>$2,000</span>
                </div>
              </div>

              {/* Personal Investment */}
              <div className="space-y-2">
                <Label htmlFor="personal-investment">
                  Kişisel Yatırımınız ($)
                </Label>
                <Input
                  id="personal-investment"
                  type="number"
                  value={params.personalInvestment}
                  onChange={(e) =>
                    setParams({
                      ...params,
                      personalInvestment: parseInt(e.target.value) || 0,
                    })
                  }
                  min="100"
                  step="100"
                />
              </div>

              {/* Active Members Percentage */}
              <div className="space-y-3">
                <Label>Aktif Üyeler: %{params.activeMembers}</Label>
                <Slider
                  value={[params.activeMembers]}
                  onValueChange={([value]) =>
                    setParams({ ...params, activeMembers: value })
                  }
                  max={100}
                  min={50}
                  step={5}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-gray-500">
                  <span>%50</span>
                  <span>%100</span>
                </div>
              </div>

              {/* Career Level */}
              <div className="space-y-2">
                <Label>Kariyer Seviyeniz</Label>
                <Select
                  value={params.careerLevel}
                  onValueChange={(value) =>
                    setParams({ ...params, careerLevel: value })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {KUTBUL_ZAMAN_RANKS.map((rank) => (
                      <SelectItem key={rank.name} value={rank.name}>
                        {rank.name} (Seviye {rank.level})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Calculate Button */}
              <Button
                onClick={calculateSimulation}
                disabled={isCalculating}
                className="w-full bg-purple-600 hover:bg-purple-700 text-white"
              >
                {isCalculating ? (
                  <div className="flex items-center gap-2">
                    <RefreshCw className="h-4 w-4 animate-spin" />
                    Hesaplanıyor...
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <Play className="h-4 w-4" />
                    Simülasyonu Çalıştır
                  </div>
                )}
              </Button>
            </CardContent>
          </Card>

          {/* Results */}
          <div className="lg:col-span-2 space-y-6">
            {simulation && (
              <>
                {/* Monthly Projections */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Calendar className="h-5 w-5 text-green-600" />
                      Aylık Kazanç Projeksiyonu
                    </CardTitle>
                    <CardDescription>
                      {params.careerLevel} seviyesi ile aylık gelir dağılımı
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                      <div className="p-4 bg-blue-50 rounded-lg text-center">
                        <Users className="h-6 w-6 text-blue-600 mx-auto mb-2" />
                        <div className="text-2xl font-bold text-blue-600">
                          $
                          {simulation.monthlyProjection.sponsorIncome.toFixed(
                            0,
                          )}
                        </div>
                        <div className="text-sm text-gray-600">
                          Sponsor Geliri
                        </div>
                      </div>

                      <div className="p-4 bg-purple-50 rounded-lg text-center">
                        <Infinity className="h-6 w-6 text-purple-600 mx-auto mb-2" />
                        <div className="text-2xl font-bold text-purple-600">
                          $
                          {simulation.monthlyProjection.passiveIncome.toFixed(
                            0,
                          )}
                        </div>
                        <div className="text-sm text-gray-600">Pasif Gelir</div>
                      </div>

                      <div className="p-4 bg-yellow-50 rounded-lg text-center">
                        <Crown className="h-6 w-6 text-yellow-600 mx-auto mb-2" />
                        <div className="text-2xl font-bold text-yellow-600">
                          $
                          {simulation.monthlyProjection.careerIncome.toFixed(0)}
                        </div>
                        <div className="text-sm text-gray-600">
                          Kariyer Bonusu
                        </div>
                      </div>

                      <div className="p-4 bg-green-50 rounded-lg text-center">
                        <TrendingUp className="h-6 w-6 text-green-600 mx-auto mb-2" />
                        <div className="text-2xl font-bold text-green-600">
                          $
                          {simulation.monthlyProjection.activeIncome.toFixed(0)}
                        </div>
                        <div className="text-sm text-gray-600">Aktif Gelir</div>
                      </div>
                    </div>

                    <div className="mt-6 p-4 bg-gradient-to-r from-green-100 to-blue-100 rounded-lg text-center">
                      <div className="text-3xl font-bold text-green-700 mb-1">
                        ${simulation.monthlyProjection.totalIncome.toFixed(0)}
                      </div>
                      <div className="text-lg text-gray-700">
                        Toplam Aylık Gelir
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Annual Projections */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <BarChart3 className="h-5 w-5 text-purple-600" />
                      Yıllık Kazanç Projeksiyonu
                    </CardTitle>
                    <CardDescription>
                      12 aylık toplam gelir potansiyeliniz
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg">
                        <div className="flex items-center gap-3">
                          <Users className="h-5 w-5 text-blue-600" />
                          <span className="font-medium">Sponsor Gelirleri</span>
                        </div>
                        <div className="text-right">
                          <div className="text-xl font-bold text-blue-600">
                            $
                            {simulation.annualProjection.sponsorIncome.toFixed(
                              0,
                            )}
                          </div>
                          <div className="text-sm text-gray-600">Yıllık</div>
                        </div>
                      </div>

                      <div className="flex items-center justify-between p-4 bg-purple-50 rounded-lg">
                        <div className="flex items-center gap-3">
                          <Infinity className="h-5 w-5 text-purple-600" />
                          <span className="font-medium">Pasif Gelirleri</span>
                        </div>
                        <div className="text-right">
                          <div className="text-xl font-bold text-purple-600">
                            $
                            {simulation.annualProjection.passiveIncome.toFixed(
                              0,
                            )}
                          </div>
                          <div className="text-sm text-gray-600">Yıllık</div>
                        </div>
                      </div>

                      <div className="flex items-center justify-between p-4 bg-yellow-50 rounded-lg">
                        <div className="flex items-center gap-3">
                          <Crown className="h-5 w-5 text-yellow-600" />
                          <span className="font-medium">Kariyer Bonusları</span>
                        </div>
                        <div className="text-right">
                          <div className="text-xl font-bold text-yellow-600">
                            $
                            {simulation.annualProjection.careerIncome.toFixed(
                              0,
                            )}
                          </div>
                          <div className="text-sm text-gray-600">Yıllık</div>
                        </div>
                      </div>

                      <div className="flex items-center justify-between p-4 bg-green-50 rounded-lg">
                        <div className="flex items-center gap-3">
                          <TrendingUp className="h-5 w-5 text-green-600" />
                          <span className="font-medium">Aktif Gelirleri</span>
                        </div>
                        <div className="text-right">
                          <div className="text-xl font-bold text-green-600">
                            $
                            {simulation.annualProjection.activeIncome.toFixed(
                              0,
                            )}
                          </div>
                          <div className="text-sm text-gray-600">Yıllık</div>
                        </div>
                      </div>

                      <div className="mt-6 p-6 bg-gradient-to-r from-purple-100 to-indigo-100 rounded-xl text-center">
                        <Star className="h-8 w-8 text-purple-600 mx-auto mb-2" />
                        <div className="text-4xl font-bold text-purple-700 mb-2">
                          ${simulation.annualProjection.totalIncome.toFixed(0)}
                        </div>
                        <div className="text-xl text-purple-600">
                          Toplam Yıllık Gelir Potansiyeli
                        </div>
                        <div className="text-sm text-gray-600 mt-2">
                          {params.teamSize} kişilik ekip ile{" "}
                          {params.careerLevel} seviyesinde
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </>
            )}

            {/* Scenario Analysis */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-5 w-5 text-orange-600" />
                  Senaryo Analizi
                </CardTitle>
                <CardDescription>
                  Farklı durumlar için hızlı karşılaştırma
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="p-4 border rounded-lg">
                    <div className="text-center mb-3">
                      <Badge className="bg-green-100 text-green-800">
                        Muhafazakar
                      </Badge>
                    </div>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span>Ekip:</span>
                        <span>25 üye</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Ort. Yatırım:</span>
                        <span>$200</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Aylık:</span>
                        <span className="font-bold text-green-600">$380</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Yıllık:</span>
                        <span className="font-bold text-green-600">$4,560</span>
                      </div>
                    </div>
                  </div>

                  <div className="p-4 border-2 border-blue-300 rounded-lg bg-blue-50">
                    <div className="text-center mb-3">
                      <Badge className="bg-blue-100 text-blue-800">
                        Dengeli
                      </Badge>
                    </div>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span>Ekip:</span>
                        <span>50 üye</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Ort. Yatırım:</span>
                        <span>$300</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Aylık:</span>
                        <span className="font-bold text-blue-600">$720</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Yıllık:</span>
                        <span className="font-bold text-blue-600">$8,640</span>
                      </div>
                    </div>
                  </div>

                  <div className="p-4 border rounded-lg">
                    <div className="text-center mb-3">
                      <Badge className="bg-purple-100 text-purple-800">
                        Agresif
                      </Badge>
                    </div>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span>Ekip:</span>
                        <span>100 üye</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Ort. Yatırım:</span>
                        <span>$500</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Aylık:</span>
                        <span className="font-bold text-purple-600">
                          $1,520
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span>Yıllık:</span>
                        <span className="font-bold text-purple-600">
                          $18,240
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Tips */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Gift className="h-5 w-5 text-green-600" />
                  Kazanç Artırma İpuçları
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-3">
                    <h4 className="font-semibold flex items-center gap-2">
                      <Users className="h-4 w-4 text-blue-600" />
                      Ekip Büyütme
                    </h4>
                    <ul className="text-sm text-gray-600 space-y-1">
                      <li>• Aktif referans kazanımına odaklanın</li>
                      <li>• Ekibinizi eğitin ve motive edin</li>
                      <li>• Düzenli takip ve destek sağlayın</li>
                    </ul>
                  </div>
                  <div className="space-y-3">
                    <h4 className="font-semibold flex items-center gap-2">
                      <Crown className="h-4 w-4 text-yellow-600" />
                      Kariyer Gelişimi
                    </h4>
                    <ul className="text-sm text-gray-600 space-y-1">
                      <li>• Yatırım şartlarını tamamlayın</li>
                      <li>• Lider yetiştirmeye odaklanın</li>
                      <li>• Sürekli öğrenme ve gelişim</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Button
            onClick={() => navigate("/panel/yatirim-yap")}
            className="bg-green-600 hover:bg-green-700 text-white"
          >
            <Coins className="h-4 w-4 mr-2" />
            Yatırım Yap
          </Button>
          <Button
            onClick={() => navigate("/panel/kariyerim")}
            className="bg-purple-600 hover:bg-purple-700 text-white"
          >
            <Crown className="h-4 w-4 mr-2" />
            Kariyerim
          </Button>
          <Button
            onClick={() => navigate("/panel/bonuslar")}
            className="bg-blue-600 hover:bg-blue-700 text-white"
          >
            <Award className="h-4 w-4 mr-2" />
            Bonuslarım
          </Button>
        </div>
      </div>
    </div>
  );
}
