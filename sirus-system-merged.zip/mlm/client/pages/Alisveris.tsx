import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ShoppingCart, ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";

export default function Alisveris() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 flex items-center justify-center p-4">
      <Card className="max-w-md w-full">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <div className="w-16 h-16 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full flex items-center justify-center">
              <ShoppingCart className="w-8 h-8 text-white" />
            </div>
          </div>
          <CardTitle className="text-2xl">Alışveriş Merkezi</CardTitle>
        </CardHeader>
        <CardContent className="text-center space-y-4">
          <p className="text-gray-600">
            Alışveriş merkezi yakında açılacak! Ürünlerimizi ve hizmetlerimizi
            keşfetmeye hazır olun.
          </p>
          <div className="space-y-2">
            <p className="text-sm text-gray-500">Yakında:</p>
            <ul className="text-sm text-gray-600 space-y-1">
              <li>• Premium ürün kataloğu</li>
              <li>• Özel üye indirimleri</li>
              <li>• Hızlı teslimat seçenekleri</li>
              <li>• Bonus puan sistemi</li>
            </ul>
          </div>
          <Link to="/">
            <Button className="w-full mt-6">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Ana Sayfaya Dön
            </Button>
          </Link>
        </CardContent>
      </Card>
    </div>
  );
}
