import Header from "@/components/Header";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Users,
  Target,
  Heart,
  Award,
  Globe,
  Zap,
  Shield,
  TrendingUp,
  Network,
  Star,
  ArrowRight,
} from "lucide-react";
import { Link } from "react-router-dom";

export default function Hakkimizda() {
  const values = [
    {
      icon: Heart,
      title: "Güven ve Dürüstlük",
      description:
        "Her işlemimizde şeffaflık ve dürüstlük prensiplerini ön planda tutarız.",
    },
    {
      icon: Users,
      title: "Takım Ruhu",
      description:
        "Bireysel başarılar kadar takım başarısını da önemsiyor, birlikte büyüyoruz.",
    },
    {
      icon: Target,
      title: "Hedef Odaklılık",
      description:
        "Net hedefler belirliyor ve bunlara ulaşmak için kararlılıkla çalışıyoruz.",
    },
    {
      icon: Zap,
      title: "İnovasyon",
      description:
        "Teknoloji ve yeniliklerle network marketing sektörüne değer katıyoruz.",
    },
  ];

  const achievements = [
    {
      number: "12,847",
      label: "Aktif Üye",
      description: "Türkiye ve dünya genelinde aktif üye ağımız",
    },
    {
      number: "₺8.5M",
      label: "Toplam Kazanç",
      description: "Üyelerimizin toplam kazançları",
    },
    {
      number: "%94",
      label: "Başarı Oranı",
      description: "Sisteme katılan üyelerin başarı oranı",
    },
    {
      number: "23",
      label: "Ülke",
      description: "Faaliyet gösterdiğimiz ülke sayısı",
    },
  ];

  return (
    <div className="min-h-screen bg-white">
      <Header />

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-[#2D1E5F]/10 via-white to-[#00A9A5]/10 py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl lg:text-6xl font-bold text-[#2D1E5F] mb-6 mystical-font">
            Hakkımızda
          </h1>
          <p className="text-xl text-gray-600 mb-8 leading-relaxed">
            Kutbul Zaman Network olarak, girişimci ruhu ve takım gücünü
            birleştirerek sürdürülebilir başarı hikayelerinin yaratıldığı bir
            ekosistem oluşturduk.
          </p>
          <div className="flex justify-center">
            <div className="w-20 h-1 bg-gradient-to-r from-[#2D1E5F] to-[#00A9A5] rounded-full"></div>
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12">
            <Card className="rounded-xl shadow-md">
              <CardHeader>
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 bg-[#2D1E5F] rounded-xl flex items-center justify-center">
                    <Target className="w-6 h-6 text-white" />
                  </div>
                  <CardTitle className="text-2xl text-[#2D1E5F]">
                    Misyonumuz
                  </CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 leading-relaxed">
                  Network marketing sektöründe güvenilir, şeffaf ve
                  sürdürülebilir bir platform sunarak, üyelerimizin finansal
                  özgürlüğe ulaşmalarını sağlamak. Modern teknoloji ile
                  geleneksel değerleri harmanlayarak, herkesin kazanabileceği
                  adil bir sistem oluşturmak.
                </p>
              </CardContent>
            </Card>

            <Card className="rounded-xl shadow-md">
              <CardHeader>
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 bg-[#00A9A5] rounded-xl flex items-center justify-center">
                    <Star className="w-6 h-6 text-white" />
                  </div>
                  <CardTitle className="text-2xl text-[#2D1E5F]">
                    Vizyonumuz
                  </CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 leading-relaxed">
                  Dünya genelinde network marketing alanında öncü bir marka
                  olarak, milyonlarca insanın hayallerine ulaşmasına vesile
                  olmak. Teknoloji destekli çözümlerle sektörü bir üst seviyeye
                  taşıyarak, geleceğin network marketing platformunu oluşturmak.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-[#2D1E5F] mb-4">
              Değerlerimiz
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              İş yapış şeklimizi ve kültürümüzü şekillendiren temel değerler
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => {
              const Icon = value.icon;
              return (
                <Card key={index} className="rounded-xl shadow-md text-center">
                  <CardContent className="p-6">
                    <div className="flex justify-center mb-4">
                      <div className="w-16 h-16 bg-gradient-to-r from-[#2D1E5F] to-[#00A9A5] rounded-xl flex items-center justify-center">
                        <Icon className="w-8 h-8 text-white" />
                      </div>
                    </div>
                    <h3 className="text-xl font-semibold text-[#2D1E5F] mb-3">
                      {value.title}
                    </h3>
                    <p className="text-gray-600">{value.description}</p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Achievements */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-[#2D1E5F] mb-4">
              Başarılarımız
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Güçlü ekibimiz ve üyelerimizle birlikte elde ettiğimiz başarılar
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {achievements.map((achievement, index) => (
              <div key={index} className="text-center">
                <div className="text-4xl font-bold text-[#2D1E5F] mb-2">
                  {achievement.number}
                </div>
                <div className="text-xl font-semibold text-[#00A9A5] mb-2">
                  {achievement.label}
                </div>
                <div className="text-gray-600">{achievement.description}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-20 bg-gradient-to-br from-[#2D1E5F] to-[#00A9A5] text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">Neden Kutbul Zaman?</h2>
            <p className="text-xl text-white/90 max-w-2xl mx-auto">
              Bizimle birlikte network marketing dünyasında fark yaratın
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                icon: Shield,
                title: "Güvenli Sistem",
                description:
                  "Şifreli altyapı ve güvenilir ödeme sistemleriyle verileriniz güvende",
              },
              {
                icon: TrendingUp,
                title: "Kanıtlanmış Başarı",
                description:
                  "Binlerce üyemizin başarı hikayesi ve yüksek kazanç oranları",
              },
              {
                icon: Globe,
                title: "Global Erişim",
                description:
                  "23 ülkede faaliyet gösteren geniş network ağımıza katılın",
              },
            ].map((feature, index) => {
              const Icon = feature.icon;
              return (
                <div key={index} className="text-center">
                  <div className="flex justify-center mb-6">
                    <div className="w-16 h-16 bg-white/20 rounded-xl flex items-center justify-center">
                      <Icon className="w-8 h-8 text-white" />
                    </div>
                  </div>
                  <h3 className="text-2xl font-semibold mb-4">
                    {feature.title}
                  </h3>
                  <p className="text-white/90 leading-relaxed">
                    {feature.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-[#2D1E5F] mb-6">
            Başarı Yolculuğunuza Bugün Başlayın
          </h2>
          <p className="text-xl text-gray-600 mb-8">
            Kutbul Zaman Network ailesine katılın ve finansal özgürlüğe giden
            yolculuğunuzu başlatın.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/register">
              <Button
                size="lg"
                className="bg-[#00A9A5] hover:bg-[#008b87] text-lg px-8 py-6 rounded-xl"
              >
                <Users className="w-5 h-5 mr-2" />
                Hemen Katıl
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
            <Link to="/">
              <Button
                variant="outline"
                size="lg"
                className="border-2 border-[#2D1E5F] text-[#2D1E5F] text-lg px-8 py-6 hover:bg-[#2D1E5F] hover:text-white rounded-xl"
              >
                Daha Fazla Bilgi
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#2D1E5F] text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="flex justify-center items-center space-x-3 mb-6">
              <div className="w-12 h-12 bg-gradient-to-r from-[#00A9A5] to-white rounded-xl flex items-center justify-center">
                <Network className="w-7 h-7 text-[#2D1E5F]" />
              </div>
              <div>
                <h3 className="text-2xl font-bold mystical-font">
                  Kutbul Zaman
                </h3>
                <p className="text-white/70">Network</p>
              </div>
            </div>

            <p className="text-white/80 max-w-2xl mx-auto mb-8">
              Girişimcilik ruhu ve takım çalışmasıyla birlikte sürdürülebilir
              başarıya ulaşın. Network marketing dünyasında fark yaratın.
            </p>

            <div className="border-t border-white/20 pt-8">
              <p className="text-white/60">
                © 2024 Kutbul Zaman Network. Tüm hakları saklıdır.
              </p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
