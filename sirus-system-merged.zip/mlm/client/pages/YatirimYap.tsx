import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  DollarSign,
  CreditCard,
  Calendar,
  Gift,
  Users,
  Crown,
  Infinity,
  CheckCircle,
  AlertTriangle,
  Calculator,
  PieChart,
  Coins,
  Building2,
  Clock,
  Star,
  ArrowRight,
} from "lucide-react";
import {
  User,
  KUTBUL_ZAMAN_CONFIG,
  PaymentSimulation,
} from "../../shared/mlm-types";

interface InvestmentOption {
  id: string;
  name: string;
  amount: number;
  description: string;
  benefits: string[];
  popular?: boolean;
}

export default function YatirimYap() {
  const [user, setUser] = useState<User | null>(null);
  const [selectedAmount, setSelectedAmount] = useState<number>(100);
  const [customAmount, setCustomAmount] = useState<string>("");
  const [paymentMethod, setPaymentMethod] = useState<string>("virtual");
  const [investmentType, setInvestmentType] = useState<string>("entry");
  const [isProcessing, setIsProcessing] = useState(false);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [termsAccepted, setTermsAccepted] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const userData = localStorage.getItem("mlm_user");
    if (!userData) {
      navigate("/login");
      return;
    }
    setUser(JSON.parse(userData));
  }, [navigate]);

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Yükleniyor...</p>
        </div>
      </div>
    );
  }

  const investmentOptions: InvestmentOption[] = [
    {
      id: "entry",
      name: "Giriş Paketi",
      amount: 100,
      description: "Sisteme başlamak için zorunlu giriş yatırımı",
      benefits: [
        "Aktif üye statüsü kazanın",
        "Sponsor bonusu almaya başlayın",
        "Pasif gelir sistemine dahil olun",
        "Kariyer yolculuğunuzu başlatın",
      ],
    },
    {
      id: "monthly",
      name: "Aylık Aktiflik",
      amount: 20,
      description: "Aylık aktiflik ücretinizi ödeyin",
      benefits: [
        "Aktif statünüzü koruyun",
        "Bonuslarınızı almaya devam edin",
        "Sistem haklarınızı koruyun",
      ],
    },
    {
      id: "annual",
      name: "Yıllık Paket",
      amount: 200,
      description: "12 ay peşin ödeme ile %15 tasarruf",
      benefits: [
        "12 ay aktif statü garantisi",
        "%15 indirim kazanın",
        "Safiye üyeler için ek %1 bonus",
        "Ödeme hatırlatması yok",
      ],
      popular: true,
    },
    {
      id: "investment",
      name: "Ek Yatırım",
      amount: 500,
      description: "Seviye atlama ve daha fazla bonus için",
      benefits: [
        "Kariyer seviyenizi hızlandırın",
        "Daha yüksek sponsor bonusları",
        "Artan pasif gelir oranları",
        "Liderlik pozisyonu kazanın",
      ],
    },
  ];

  const calculateDistribution = (
    amount: number,
  ): PaymentSimulation["distributions"] => {
    return {
      careerBonus: amount * KUTBUL_ZAMAN_CONFIG.careerBonusRate, // 25%
      sponsorBonus: amount * KUTBUL_ZAMAN_CONFIG.sponsorBonusRate, // 10%
      passiveBonus: amount * KUTBUL_ZAMAN_CONFIG.passiveBonusRate, // 5%
      systemFund: amount * KUTBUL_ZAMAN_CONFIG.remainingRate, // 60%
    };
  };

  const handleAmountChange = (value: string) => {
    const numValue = parseInt(value);
    if (!isNaN(numValue) && numValue >= 20) {
      setSelectedAmount(numValue);
      setCustomAmount(value);
    }
  };

  const handleQuickSelect = (amount: number, type: string) => {
    setSelectedAmount(amount);
    setCustomAmount(amount.toString());
    setInvestmentType(type);
  };

  const processPayment = async () => {
    setIsProcessing(true);

    // Simulate payment processing
    setTimeout(() => {
      setIsProcessing(false);
      setShowConfirmation(true);

      // Simulate updating user data
      const updatedUser = { ...user };
      if (investmentType === "entry") {
        updatedUser.entryPaymentCompleted = true;
        updatedUser.activityStatus = "active";
      }
      if (investmentType === "monthly" || investmentType === "annual") {
        updatedUser.activityStatus = "active";
        updatedUser.lastActivityPayment = new Date()
          .toISOString()
          .split("T")[0];
        if (investmentType === "annual") {
          updatedUser.annualPayment = true;
        }
      }
      updatedUser.totalInvestment += selectedAmount;

      localStorage.setItem("mlm_user", JSON.stringify(updatedUser));
      setUser(updatedUser);
    }, 3000);
  };

  const distribution = calculateDistribution(selectedAmount);

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 p-4">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-green-800 mb-2">
            Yatırım Yap
          </h1>
          <p className="text-gray-600">
            Aktiflik yenileme ve sistem yatırımlarınızı gerçekleştirin
          </p>
        </div>

        {/* User Status */}
        <Card className="border-2 border-green-200 bg-gradient-to-r from-green-50 to-emerald-50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                  <Users className="h-6 w-6 text-green-600" />
                </div>
                <div>
                  <div className="font-bold text-green-800">{user.name}</div>
                  <div className="text-sm text-gray-600">
                    Ref: {user.referenceNumber} • Seviye: {user.rank}
                  </div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-2xl font-bold text-green-600">
                  ${user.totalInvestment.toLocaleString()}
                </div>
                <div className="text-sm text-gray-600">Toplam Yatırım</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Investment Selection */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Coins className="h-5 w-5 text-green-600" />
                Yatırım Seçenekleri
              </CardTitle>
              <CardDescription>
                İhtiyacınıza uygun yatırım paketini seçin
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {investmentOptions.map((option) => (
                <div
                  key={option.id}
                  className={`p-4 border rounded-lg cursor-pointer transition-all ${
                    investmentType === option.id
                      ? "border-green-300 bg-green-50"
                      : "border-gray-200 hover:border-green-200"
                  } ${option.popular ? "ring-2 ring-yellow-300" : ""}`}
                  onClick={() => handleQuickSelect(option.amount, option.id)}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div className="font-bold text-lg">{option.name}</div>
                      {option.popular && (
                        <Badge className="bg-yellow-100 text-yellow-800">
                          <Star className="h-3 w-3 mr-1" />
                          Popüler
                        </Badge>
                      )}
                    </div>
                    <div className="text-2xl font-bold text-green-600">
                      ${option.amount}
                    </div>
                  </div>
                  <div className="text-sm text-gray-600 mb-3">
                    {option.description}
                  </div>
                  <div className="space-y-1">
                    {option.benefits.map((benefit, index) => (
                      <div
                        key={index}
                        className="text-xs text-gray-700 flex items-center gap-2"
                      >
                        <CheckCircle className="h-3 w-3 text-green-600" />
                        {benefit}
                      </div>
                    ))}
                  </div>
                </div>
              ))}

              {/* Custom Amount */}
              <div className="p-4 border-2 border-dashed border-gray-300 rounded-lg">
                <Label htmlFor="custom-amount">Özel Miktar (Min: $20)</Label>
                <div className="flex gap-2 mt-2">
                  <Input
                    id="custom-amount"
                    type="number"
                    min="20"
                    placeholder="Özel miktar girin"
                    value={customAmount}
                    onChange={(e) => handleAmountChange(e.target.value)}
                    className="flex-1"
                  />
                  <Button
                    variant="outline"
                    onClick={() => setInvestmentType("custom")}
                    disabled={!customAmount || parseInt(customAmount) < 20}
                  >
                    Seç
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Payment Details */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calculator className="h-5 w-5 text-blue-600" />
                Ödeme Detayları
              </CardTitle>
              <CardDescription>
                Seçtiğiniz miktar ve dağıtım hesaplaması
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Amount Summary */}
              <div className="text-center p-4 bg-blue-50 rounded-lg">
                <div className="text-3xl font-bold text-blue-600 mb-1">
                  ${selectedAmount.toLocaleString()}
                </div>
                <div className="text-sm text-gray-600">Yatırım Miktarı</div>
              </div>

              {/* Distribution Breakdown */}
              <div className="space-y-3">
                <h4 className="font-medium text-gray-800">Dağıtım Hesabı:</h4>

                <div className="flex items-center justify-between p-3 bg-yellow-50 rounded">
                  <div className="flex items-center gap-2">
                    <Crown className="h-4 w-4 text-yellow-600" />
                    <span className="text-sm">Kariyer Bonusu (25%)</span>
                  </div>
                  <span className="font-bold text-yellow-600">
                    ${distribution.careerBonus.toFixed(0)}
                  </span>
                </div>

                <div className="flex items-center justify-between p-3 bg-blue-50 rounded">
                  <div className="flex items-center gap-2">
                    <Users className="h-4 w-4 text-blue-600" />
                    <span className="text-sm">Sponsor Bonusu (10%)</span>
                  </div>
                  <span className="font-bold text-blue-600">
                    ${distribution.sponsorBonus.toFixed(0)}
                  </span>
                </div>

                <div className="flex items-center justify-between p-3 bg-purple-50 rounded">
                  <div className="flex items-center gap-2">
                    <Infinity className="h-4 w-4 text-purple-600" />
                    <span className="text-sm">Pasif Bonus (5%)</span>
                  </div>
                  <span className="font-bold text-purple-600">
                    ${distribution.passiveBonus.toFixed(0)}
                  </span>
                </div>

                <div className="flex items-center justify-between p-3 bg-gray-50 rounded">
                  <div className="flex items-center gap-2">
                    <Building2 className="h-4 w-4 text-gray-600" />
                    <span className="text-sm">Sistem Fonu (60%)</span>
                  </div>
                  <span className="font-bold text-gray-600">
                    ${distribution.systemFund.toFixed(0)}
                  </span>
                </div>
              </div>

              {/* Payment Method */}
              <div className="space-y-3">
                <Label>Ödeme Yöntemi</Label>
                <Select value={paymentMethod} onValueChange={setPaymentMethod}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="virtual">
                      <div className="flex items-center gap-2">
                        <Calculator className="h-4 w-4" />
                        Sanal Simülasyon (Demo)
                      </div>
                    </SelectItem>
                    <SelectItem value="crypto">
                      <div className="flex items-center gap-2">
                        <Coins className="h-4 w-4" />
                        Kripto Para
                      </div>
                    </SelectItem>
                    <SelectItem value="bank">
                      <div className="flex items-center gap-2">
                        <Building2 className="h-4 w-4" />
                        Banka Havalesi
                      </div>
                    </SelectItem>
                    <SelectItem value="card">
                      <div className="flex items-center gap-2">
                        <CreditCard className="h-4 w-4" />
                        Kredi Kartı
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Terms */}
              <div className="flex items-start space-x-2">
                <Checkbox
                  id="terms"
                  checked={termsAccepted}
                  onCheckedChange={(checked) =>
                    setTermsAccepted(checked as boolean)
                  }
                />
                <Label htmlFor="terms" className="text-sm">
                  Yatırım şartlarını ve bonus dağıtım kurallarını okudum, kabul
                  ediyorum.
                </Label>
              </div>

              {/* Payment Button */}
              <Button
                onClick={processPayment}
                disabled={!termsAccepted || isProcessing}
                className="w-full bg-green-600 hover:bg-green-700 text-white py-6"
              >
                {isProcessing ? (
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4 animate-spin" />
                    İşleniyor...
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <DollarSign className="h-4 w-4" />${selectedAmount} Yatırım
                    Yap
                  </div>
                )}
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Investment Benefits */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Gift className="h-5 w-5 text-purple-600" />
              Yatırım Avantajları
            </CardTitle>
            <CardDescription>
              Kutbul Zaman Network'e yatırım yapmanın faydaları
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 border rounded-lg text-center">
                <Users className="h-8 w-8 text-blue-600 mx-auto mb-2" />
                <h4 className="font-bold mb-2">Sponsor Geliri</h4>
                <p className="text-sm text-gray-600">
                  Her referansınızın yatırımından %10 + kariyer bonusu kazanın
                </p>
              </div>
              <div className="p-4 border rounded-lg text-center">
                <Infinity className="h-8 w-8 text-purple-600 mx-auto mb-2" />
                <h4 className="font-bold mb-2">Pasif Gelir</h4>
                <p className="text-sm text-gray-600">
                  Alt ekibinizin tüm yatırımlarından %5'e kadar pasif gelir
                </p>
              </div>
              <div className="p-4 border rounded-lg text-center">
                <Crown className="h-8 w-8 text-yellow-600 mx-auto mb-2" />
                <h4 className="font-bold mb-2">Kariyer Bonusu</h4>
                <p className="text-sm text-gray-600">
                  Aylık bonus havuzundan seviyenize göre %2-12 arası pay
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Success Dialog */}
        <Dialog open={showConfirmation} onOpenChange={setShowConfirmation}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <CheckCircle className="h-6 w-6 text-green-600" />
                Yatırım Başarılı!
              </DialogTitle>
              <DialogDescription>
                ${selectedAmount} yatırımınız başarıyla işleme alındı.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="p-4 bg-green-50 rounded-lg">
                <div className="text-sm space-y-2">
                  <div className="flex justify-between">
                    <span>Yatırım Miktarı:</span>
                    <span className="font-bold">${selectedAmount}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>İşlem Tarihi:</span>
                    <span>{new Date().toLocaleDateString("tr-TR")}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Durum:</span>
                    <Badge className="bg-green-100 text-green-800">
                      Tamamlandı
                    </Badge>
                  </div>
                </div>
              </div>
              <div className="flex gap-2">
                <Button
                  onClick={() => navigate("/panel/bonuslar")}
                  className="flex-1"
                >
                  Bonuslarımı Gör
                </Button>
                <Button
                  onClick={() => setShowConfirmation(false)}
                  variant="outline"
                  className="flex-1"
                >
                  Tamam
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
