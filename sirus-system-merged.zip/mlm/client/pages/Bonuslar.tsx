import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DollarSign,
  Users,
  Crown,
  TrendingUp,
  Award,
  Calendar,
  ArrowUpRight,
  Gift,
  Target,
  Infinity,
  PieChart,
  BarChart3,
  CheckCircle,
  Clock,
  Coins,
} from "lucide-react";
import { User, KUTBUL_ZAMAN_CONFIG } from "../../shared/mlm-types";

interface BonusTransaction {
  id: string;
  type: "sponsor" | "passive" | "career";
  amount: number;
  source: string;
  date: string;
  status: "completed" | "pending";
  description: string;
}

export default function Bonuslar() {
  const [user, setUser] = useState<User | null>(null);
  const [selectedPeriod, setSelectedPeriod] = useState("2024-03");
  const [selectedBonusType, setSelectedBonusType] = useState("all");
  const navigate = useNavigate();

  useEffect(() => {
    const userData = localStorage.getItem("mlm_user");
    if (!userData) {
      navigate("/login");
      return;
    }
    setUser(JSON.parse(userData));
  }, [navigate]);

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Yükleniyor...</p>
        </div>
      </div>
    );
  }

  // Sample bonus transactions
  const bonusTransactions: BonusTransaction[] = [
    {
      id: "1",
      type: "sponsor",
      amount: 125,
      source: "Mehmet Öz (ak000015)",
      date: "2024-03-15T10:30:00Z",
      status: "completed",
      description: "$100 yatırım sponsor bonusu + %25 kariyer bonusu",
    },
    {
      id: "2",
      type: "passive",
      amount: 50,
      source: "Alt Ekip (12 üye)",
      date: "2024-03-14T15:45:00Z",
      status: "completed",
      description: "Sonsuz ekip pasif geliri (%4 Safiye seviyesi)",
    },
    {
      id: "3",
      type: "career",
      amount: 300,
      source: "Aylık Kariyer Bonusu",
      date: "2024-03-01T00:00:00Z",
      status: "completed",
      description: "Mart ayı kariyer bonusu (%12 Safiye seviyesi)",
    },
    {
      id: "4",
      type: "sponsor",
      amount: 100,
      source: "Ayşe Kaya (ak000023)",
      date: "2024-03-12T09:15:00Z",
      status: "completed",
      description: "$100 yatırım sponsor bonusu (temel %10)",
    },
    {
      id: "5",
      type: "passive",
      amount: 25,
      source: "Alt Ekip (6 üye)",
      date: "2024-03-10T14:20:00Z",
      status: "pending",
      description: "Bekleyen pasif gelir ödemesi",
    },
  ];

  const calculateTotalsByType = () => {
    const totals = {
      sponsor: bonusTransactions
        .filter((t) => t.type === "sponsor")
        .reduce((sum, t) => sum + t.amount, 0),
      passive: bonusTransactions
        .filter((t) => t.type === "passive")
        .reduce((sum, t) => sum + t.amount, 0),
      career: bonusTransactions
        .filter((t) => t.type === "career")
        .reduce((sum, t) => sum + t.amount, 0),
    };
    totals.total = totals.sponsor + totals.passive + totals.career;
    return totals;
  };

  const totals = calculateTotalsByType();

  const getBonusTypeIcon = (type: string) => {
    switch (type) {
      case "sponsor":
        return <Users className="h-4 w-4" />;
      case "passive":
        return <Infinity className="h-4 w-4" />;
      case "career":
        return <Crown className="h-4 w-4" />;
      default:
        return <Award className="h-4 w-4" />;
    }
  };

  const getBonusTypeColor = (type: string) => {
    switch (type) {
      case "sponsor":
        return "bg-blue-100 text-blue-800";
      case "passive":
        return "bg-purple-100 text-purple-800";
      case "career":
        return "bg-yellow-100 text-yellow-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getBonusTypeName = (type: string) => {
    switch (type) {
      case "sponsor":
        return "Sponsor Bonusu";
      case "passive":
        return "Pasif Gelir";
      case "career":
        return "Kariyer Bonusu";
      default:
        return "Diğer";
    }
  };

  const filteredTransactions = bonusTransactions.filter((transaction) => {
    if (selectedBonusType !== "all" && transaction.type !== selectedBonusType) {
      return false;
    }
    return transaction.date.startsWith(selectedPeriod);
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 p-4">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-blue-800 mb-2">Bonuslarım</h1>
          <p className="text-gray-600">
            Sponsor, Kariyer ve Pasif Gelir bonuslarınızın detaylı tablosu
          </p>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="border-2 border-green-200 bg-gradient-to-r from-green-50 to-emerald-50">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <DollarSign className="h-5 w-5 text-green-600" />
                <span className="font-medium">Toplam Kazanç</span>
              </div>
              <div className="text-3xl font-bold text-green-600">
                ${totals.total.toLocaleString()}
              </div>
              <div className="text-sm text-gray-600">Bu ay</div>
            </CardContent>
          </Card>

          <Card className="border-2 border-blue-200">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <Users className="h-5 w-5 text-blue-600" />
                <span className="font-medium">Sponsor Geliri</span>
              </div>
              <div className="text-2xl font-bold text-blue-600">
                ${totals.sponsor.toLocaleString()}
              </div>
              <div className="text-sm text-gray-600">%10 + kariyer bonusu</div>
            </CardContent>
          </Card>

          <Card className="border-2 border-purple-200">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <Infinity className="h-5 w-5 text-purple-600" />
                <span className="font-medium">Pasif Gelir</span>
              </div>
              <div className="text-2xl font-bold text-purple-600">
                ${totals.passive.toLocaleString()}
              </div>
              <div className="text-sm text-gray-600">Sonsuz ekip %5</div>
            </CardContent>
          </Card>

          <Card className="border-2 border-yellow-200">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <Crown className="h-5 w-5 text-yellow-600" />
                <span className="font-medium">Kariyer Bonusu</span>
              </div>
              <div className="text-2xl font-bold text-yellow-600">
                ${totals.career.toLocaleString()}
              </div>
              <div className="text-sm text-gray-600">%25 bonus havuzu</div>
            </CardContent>
          </Card>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Genel Bakış</TabsTrigger>
            <TabsTrigger value="transactions">İşlem Geçmişi</TabsTrigger>
            <TabsTrigger value="structure">Bonus Yapısı</TabsTrigger>
            <TabsTrigger value="analytics">Analiz</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Income Distribution */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <PieChart className="h-5 w-5" />
                    Gelir Dağılımı
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Sponsor Bonusları</span>
                      <div className="flex items-center gap-2">
                        <div className="w-16 bg-gray-200 rounded-full h-2">
                          <div
                            className="bg-blue-600 h-2 rounded-full"
                            style={{
                              width: `${(totals.sponsor / totals.total) * 100}%`,
                            }}
                          ></div>
                        </div>
                        <span className="text-sm font-medium w-12">
                          {((totals.sponsor / totals.total) * 100).toFixed(0)}%
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Pasif Gelir</span>
                      <div className="flex items-center gap-2">
                        <div className="w-16 bg-gray-200 rounded-full h-2">
                          <div
                            className="bg-purple-600 h-2 rounded-full"
                            style={{
                              width: `${(totals.passive / totals.total) * 100}%`,
                            }}
                          ></div>
                        </div>
                        <span className="text-sm font-medium w-12">
                          {((totals.passive / totals.total) * 100).toFixed(0)}%
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Kariyer Bonusu</span>
                      <div className="flex items-center gap-2">
                        <div className="w-16 bg-gray-200 rounded-full h-2">
                          <div
                            className="bg-yellow-600 h-2 rounded-full"
                            style={{
                              width: `${(totals.career / totals.total) * 100}%`,
                            }}
                          ></div>
                        </div>
                        <span className="text-sm font-medium w-12">
                          {((totals.career / totals.total) * 100).toFixed(0)}%
                        </span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Performance Metrics */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3 className="h-5 w-5" />
                    Performans Metrikleri
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between">
                      <span className="text-sm">Aylık Ortalama</span>
                      <span className="font-medium">
                        ${(totals.total / 1).toLocaleString()}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">En Yüksek Bonus</span>
                      <span className="font-medium">
                        $
                        {Math.max(
                          ...bonusTransactions.map((t) => t.amount),
                        ).toLocaleString()}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Aktif Bonus Türü</span>
                      <span className="font-medium">3/3</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Toplam İşlem</span>
                      <span className="font-medium">
                        {bonusTransactions.length}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Recent Transactions */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="h-5 w-5" />
                  Son Bonus Ödemeleri
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {bonusTransactions.slice(0, 5).map((transaction) => (
                    <div
                      key={transaction.id}
                      className="flex items-center justify-between p-3 border rounded-lg hover:bg-gray-50"
                    >
                      <div className="flex items-center gap-3">
                        <Badge className={getBonusTypeColor(transaction.type)}>
                          {getBonusTypeIcon(transaction.type)}
                          <span className="ml-1">
                            {getBonusTypeName(transaction.type)}
                          </span>
                        </Badge>
                        <div>
                          <div className="font-medium">
                            ${transaction.amount.toLocaleString()}
                          </div>
                          <div className="text-sm text-gray-600">
                            {transaction.source}
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-sm text-gray-600">
                          {new Date(transaction.date).toLocaleDateString(
                            "tr-TR",
                          )}
                        </div>
                        <Badge
                          variant={
                            transaction.status === "completed"
                              ? "default"
                              : "secondary"
                          }
                        >
                          {transaction.status === "completed"
                            ? "Ödendi"
                            : "Beklemede"}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="transactions" className="space-y-4">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Bonus İşlem Geçmişi</CardTitle>
                  <div className="flex gap-2">
                    <Select
                      value={selectedPeriod}
                      onValueChange={setSelectedPeriod}
                    >
                      <SelectTrigger className="w-40">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="2024-01">Ocak 2024</SelectItem>
                        <SelectItem value="2024-02">Şubat 2024</SelectItem>
                        <SelectItem value="2024-03">Mart 2024</SelectItem>
                      </SelectContent>
                    </Select>
                    <Select
                      value={selectedBonusType}
                      onValueChange={setSelectedBonusType}
                    >
                      <SelectTrigger className="w-48">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Tüm Bonuslar</SelectItem>
                        <SelectItem value="sponsor">Sponsor Bonusu</SelectItem>
                        <SelectItem value="passive">Pasif Gelir</SelectItem>
                        <SelectItem value="career">Kariyer Bonusu</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Tarih</TableHead>
                      <TableHead>Tip</TableHead>
                      <TableHead>Kaynak</TableHead>
                      <TableHead>Açıklama</TableHead>
                      <TableHead>Miktar</TableHead>
                      <TableHead>Durum</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredTransactions.map((transaction) => (
                      <TableRow key={transaction.id}>
                        <TableCell>
                          {new Date(transaction.date).toLocaleDateString(
                            "tr-TR",
                          )}
                        </TableCell>
                        <TableCell>
                          <Badge
                            className={getBonusTypeColor(transaction.type)}
                          >
                            {getBonusTypeIcon(transaction.type)}
                            <span className="ml-1">
                              {getBonusTypeName(transaction.type)}
                            </span>
                          </Badge>
                        </TableCell>
                        <TableCell>{transaction.source}</TableCell>
                        <TableCell>{transaction.description}</TableCell>
                        <TableCell className="font-bold text-green-600">
                          ${transaction.amount.toLocaleString()}
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant={
                              transaction.status === "completed"
                                ? "default"
                                : "secondary"
                            }
                          >
                            {transaction.status === "completed" ? (
                              <CheckCircle className="h-3 w-3 mr-1" />
                            ) : (
                              <Clock className="h-3 w-3 mr-1" />
                            )}
                            {transaction.status === "completed"
                              ? "Ödendi"
                              : "Beklemede"}
                          </Badge>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="structure" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card className="border-blue-200">
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Users className="h-5 w-5 text-blue-600" />
                    Sponsor Bonusu
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="text-sm">
                    <div className="font-medium">Temel Oran: %10</div>
                    <div className="text-gray-600">
                      Her referans yatırımından doğrudan
                    </div>
                  </div>
                  <div className="text-sm">
                    <div className="font-medium">Kariyer Bonusu: +%25</div>
                    <div className="text-gray-600">
                      Yüksek seviye üyeler için ek bonus
                    </div>
                  </div>
                  <div className="p-3 bg-blue-50 rounded text-sm">
                    <div className="font-medium">Örnek Hesaplama:</div>
                    <div>$100 yatırım × %10 = $10</div>
                    <div>Safiye seviyesi: $10 × 1.25 = $12.50</div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-purple-200">
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Infinity className="h-5 w-5 text-purple-600" />
                    Pasif Gelir (%5)
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="text-sm">
                    <div className="font-medium">Sonsuz Ekip Sistemi</div>
                    <div className="text-gray-600">
                      Alt ekip yatırımlarından %5
                    </div>
                  </div>
                  <div className="space-y-1 text-xs">
                    <div className="flex justify-between">
                      <span>Emmare-Mutmainne:</span>
                      <span className="font-medium">%0.5 - %1.5</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Radiyye-Mardiyye:</span>
                      <span className="font-medium">%2 - %3</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Safiye:</span>
                      <span className="font-medium">%4</span>
                    </div>
                  </div>
                  <div className="p-3 bg-purple-50 rounded text-sm">
                    <div className="font-medium">Koşul:</div>
                    <div className="text-xs">
                      Sadece aktif üyeler pasif gelir alabilir
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-yellow-200">
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Crown className="h-5 w-5 text-yellow-600" />
                    Kariyer Bonusu (%25)
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="text-sm">
                    <div className="font-medium">Aylık Bonus Havuzu</div>
                    <div className="text-gray-600">
                      Toplam yatırımların %25'i
                    </div>
                  </div>
                  <div className="space-y-1 text-xs">
                    <div className="flex justify-between">
                      <span>Emmare-Levvame:</span>
                      <span className="font-medium">%2 - %3</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Mülhime-Radiyye:</span>
                      <span className="font-medium">%4 - %6</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Mardiyye-Safiye:</span>
                      <span className="font-medium">%8 - %12</span>
                    </div>
                  </div>
                  <div className="p-3 bg-yellow-50 rounded text-sm">
                    <div className="font-medium">Dağıtım:</div>
                    <div className="text-xs">
                      Seviye oranına göre aylık paylaşım
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Aylık Gelir Trendi</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Ocak 2024</span>
                      <span className="font-medium">$420</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Şubat 2024</span>
                      <span className="font-medium">$530</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Mart 2024</span>
                      <span className="font-medium text-green-600">$600</span>
                    </div>
                    <div className="pt-4 border-t">
                      <div className="flex justify-between items-center">
                        <span className="font-medium">Büyüme Oranı:</span>
                        <span className="font-bold text-green-600">+42.8%</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Bonus Projeksiyonları</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between">
                      <span className="text-sm">Nisan 2024 (Tahmini)</span>
                      <span className="font-medium text-blue-600">$720</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Mayıs 2024 (Tahmini)</span>
                      <span className="font-medium text-blue-600">$850</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Yıllık Hedef</span>
                      <span className="font-medium text-purple-600">
                        $12,000
                      </span>
                    </div>
                    <div className="pt-4 border-t">
                      <div className="flex justify-between items-center">
                        <span className="font-medium">Hedef Gerçekleşme:</span>
                        <span className="font-bold text-purple-600">18.7%</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        {/* Action Buttons */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Button
            onClick={() => navigate("/panel/kariyerim")}
            className="bg-purple-600 hover:bg-purple-700 text-white"
          >
            <Crown className="h-4 w-4 mr-2" />
            Kariyerim
          </Button>
          <Button
            onClick={() => navigate("/panel/yatirim-yap")}
            className="bg-green-600 hover:bg-green-700 text-white"
          >
            <Coins className="h-4 w-4 mr-2" />
            Yatırım Yap
          </Button>
          <Button
            onClick={() => navigate("/panel/simulasyon")}
            className="bg-blue-600 hover:bg-blue-700 text-white"
          >
            <BarChart3 className="h-4 w-4 mr-2" />
            Simülasyon
          </Button>
        </div>
      </div>
    </div>
  );
}
