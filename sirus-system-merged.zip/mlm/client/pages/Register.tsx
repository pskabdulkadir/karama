import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Users, UserPlus, Eye, EyeOff, Copy, Check } from "lucide-react";

export default function Register() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    username: "",
    password: "",
    confirmPassword: "",
    sponsorCode: "ak000001", // Varsayılan sponsor: Abdulkadir Kan (Kurucu)
  });
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [sponsorCodeCopied, setSponsorCodeCopied] = useState(false);
  const navigate = useNavigate();

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const generateSponsorCode = () => {
    const code = Math.random().toString(36).substring(2, 8).toUpperCase();
    setFormData((prev) => ({ ...prev, sponsorCode: code }));
  };

  const copySponsorCode = async () => {
    await navigator.clipboard.writeText(formData.sponsorCode);
    setSponsorCodeCopied(true);
    setTimeout(() => setSponsorCodeCopied(false), 2000);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    if (formData.password !== formData.confirmPassword) {
      alert("Şifreler eşleşmiyor!");
      setIsLoading(false);
      return;
    }

    // Simulate registration API call
    setTimeout(() => {
      setIsLoading(false);
      alert("Kayıt başarılı! Giriş sayfasına yönlendiriliyorsunuz.");
      navigate("/login");
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/10 via-background to-accent/10 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-primary text-primary-foreground rounded-full mb-4">
            <Users className="w-8 h-8" />
          </div>
          <h1 className="text-3xl font-bold text-primary mb-2">
            kutbulzaman panel
          </h1>
          <p className="text-muted-foreground">
            Network Marketing Yönetim Sistemi
          </p>
        </div>

        <Card className="border-2 border-primary/20 shadow-xl">
          <CardHeader className="space-y-1">
            <CardTitle className="text-2xl text-center text-primary">
              Kayıt Ol
            </CardTitle>
            <CardDescription className="text-center">
              Yeni hesap oluşturun
            </CardDescription>
          </CardHeader>
          <form onSubmit={handleSubmit}>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Ad Soyad</Label>
                  <Input
                    id="name"
                    name="name"
                    type="text"
                    placeholder="Adınızı ve soyadınızı girin"
                    value={formData.name}
                    onChange={handleInputChange}
                    required
                    className="border-2 focus:border-accent"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">E-posta</Label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    placeholder="E-posta adresinizi girin"
                    value={formData.email}
                    onChange={handleInputChange}
                    required
                    className="border-2 focus:border-accent"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="username">Kullanıcı Adı</Label>
                  <Input
                    id="username"
                    name="username"
                    type="text"
                    placeholder="Kullanıcı adınızı seçin"
                    value={formData.username}
                    onChange={handleInputChange}
                    required
                    className="border-2 focus:border-accent"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="sponsorCode">
                    Sponsor Kodu (Varsayılan: Kurucu)
                  </Label>
                  <div className="flex space-x-2">
                    <Input
                      id="sponsorCode"
                      name="sponsorCode"
                      type="text"
                      placeholder="ak000001 (Abdulkadir Kan - Kurucu)"
                      value={formData.sponsorCode}
                      onChange={handleInputChange}
                      className="border-2 focus:border-accent"
                    />
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={generateSponsorCode}
                      className="px-3 border-2 border-accent text-accent hover:bg-accent hover:text-accent-foreground"
                    >
                      Oluştur
                    </Button>
                    {formData.sponsorCode && (
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={copySponsorCode}
                        className="px-3 border-2 border-primary text-primary hover:bg-primary hover:text-primary-foreground"
                      >
                        {sponsorCodeCopied ? (
                          <Check className="w-4 h-4" />
                        ) : (
                          <Copy className="w-4 h-4" />
                        )}
                      </Button>
                    )}
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="password">Şifre</Label>
                  <div className="relative">
                    <Input
                      id="password"
                      name="password"
                      type={showPassword ? "text" : "password"}
                      placeholder="Şifrenizi girin"
                      value={formData.password}
                      onChange={handleInputChange}
                      required
                      className="border-2 focus:border-accent pr-10"
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                      onClick={() => setShowPassword(!showPassword)}
                    >
                      {showPassword ? (
                        <EyeOff className="h-4 w-4 text-muted-foreground" />
                      ) : (
                        <Eye className="h-4 w-4 text-muted-foreground" />
                      )}
                    </Button>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="confirmPassword">Şifre Tekrar</Label>
                  <div className="relative">
                    <Input
                      id="confirmPassword"
                      name="confirmPassword"
                      type={showConfirmPassword ? "text" : "password"}
                      placeholder="Şifrenizi tekrar girin"
                      value={formData.confirmPassword}
                      onChange={handleInputChange}
                      required
                      className="border-2 focus:border-accent pr-10"
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                      onClick={() =>
                        setShowConfirmPassword(!showConfirmPassword)
                      }
                    >
                      {showConfirmPassword ? (
                        <EyeOff className="h-4 w-4 text-muted-foreground" />
                      ) : (
                        <Eye className="h-4 w-4 text-muted-foreground" />
                      )}
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex flex-col space-y-4">
              <Button
                type="submit"
                className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-semibold py-6"
                disabled={isLoading}
              >
                {isLoading ? (
                  <div className="flex items-center space-x-2">
                    <UserPlus className="w-4 h-4 animate-spin" />
                    <span>Kayıt oluşturuluyor...</span>
                  </div>
                ) : (
                  <div className="flex items-center space-x-2">
                    <UserPlus className="w-4 h-4" />
                    <span>Kayıt Ol</span>
                  </div>
                )}
              </Button>
              <div className="text-center text-sm text-muted-foreground">
                Zaten hesabınız var mı?{" "}
                <Link
                  to="/login"
                  className="text-accent hover:text-accent/80 font-medium"
                >
                  Giriş Yap
                </Link>
              </div>
            </CardFooter>
          </form>
        </Card>
      </div>
    </div>
  );
}
