import "./global.css";

import { Toaster } from "@/components/ui/toaster";
import { createRoot } from "react-dom/client";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import Landing from "./pages/Landing";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Dashboard from "./pages/Dashboard";
import Alisveris from "./pages/Alisveris";
import Gelisim from "./pages/Gelisim";
import Hakkimizda from "./pages/Hakkimizda";
import Kariyerim from "./pages/Kariyerim";
import Bonuslar from "./pages/Bonuslar";
import YatirimYap from "./pages/YatirimYap";
import Simulasyon from "./pages/Simulasyon";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/landing" element={<Landing />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/alisveris" element={<Alisveris />} />
          <Route path="/gelisim" element={<Gelisim />} />
          <Route path="/hakkimizda" element={<Hakkimizda />} />
          <Route path="/panel/kariyerim" element={<Kariyerim />} />
          <Route path="/panel/bonuslar" element={<Bonuslar />} />
          <Route path="/panel/yatirim-yap" element={<YatirimYap />} />
          <Route path="/panel/simulasyon" element={<Simulasyon />} />
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

createRoot(document.getElementById("root")!).render(<App />);
