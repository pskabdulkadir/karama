import {
  StandardUser,
  LoginCredentials,
  RegisterData,
  UserRole,
  MLMUserData,
} from "../constants/auth-types";
import { User } from "../constants/mlm-types";
import {
  findUserByCredentials,
  generateReferenceNumber,
  INITIAL_USERS,
} from "../services/users-database";

const AUTH_TOKEN_KEY = "global_auth_token";
const USER_DATA_KEY = "global_user_data";
const MLM_DATA_KEY = "mlm_user_data"; // Store MLM-specific data separately

function generateAuthToken(): string {
  return `token_${Date.now()}_${Math.random().toString(36).substring(2)}`;
}

function mapUserToStandardUser(user: User): StandardUser {
  return {
    id: user.id,
    name: user.name,
    email: user.email,
    role: user.role as UserRole,
    isActive: user.isActive,
  };
}

function mapUserToMLMData(user: User): MLMUserData {
  return {
    referenceNumber: user.referenceNumber,
    sponsorId: user.sponsorId,
    rank: user.rank,
    totalInvestment: user.totalInvestment,
    totalEarnings: user.totalEarnings,
  };
}

export class AuthService {
  private static instance: AuthService;

  private constructor() {}

  static getInstance(): AuthService {
    if (!AuthService.instance) {
      AuthService.instance = new AuthService();
    }
    return AuthService.instance;
  }

  async login(credentials: LoginCredentials): Promise<StandardUser | null> {
    try {
      // Try username/email login
      const user =
        findUserByCredentials(credentials.email, credentials.password) ||
        INITIAL_USERS.find(
          (u) =>
            u.email === credentials.email &&
            u.password === credentials.password,
        );

      if (user) {
        const token = generateAuthToken();
        const standardUser = mapUserToStandardUser(user);
        const mlmData = mapUserToMLMData(user);

        // Store standardized user data
        localStorage.setItem(AUTH_TOKEN_KEY, token);
        localStorage.setItem(USER_DATA_KEY, JSON.stringify(standardUser));
        localStorage.setItem(MLM_DATA_KEY, JSON.stringify(mlmData));

        return standardUser;
      }
      return null;
    } catch (error) {
      console.error("Login error:", error);
      return null;
    }
  }

  async register(data: RegisterData): Promise<StandardUser | null> {
    try {
      // Check if user already exists
      const existingUser = INITIAL_USERS.find(
        (u) => u.email === data.email || u.username === data.email,
      );
      if (existingUser) {
        throw new Error("User already exists");
      }

      // Create new user
      const referenceNumber = generateReferenceNumber();
      const sponsorUser = INITIAL_USERS.find(
        (u) => u.referenceNumber === (data.sponsorCode || "ak000001"),
      );

      const newUser: User = {
        id: referenceNumber,
        username: data.email.split("@")[0],
        name: data.fullName,
        email: data.email,
        password: data.password,
        referenceNumber,
        role: "user", // Default role for new registrations
        sponsorId: sponsorUser?.id || "ak000001",
        sponsorReferenceNumber: sponsorUser?.referenceNumber || "ak000001",
        joinDate: new Date().toISOString(),
        rank: "Emmare",
        isActive: true,
        activityStatus: "new",
        lastActivityPayment: null,
        annualPayment: false,
        entryPaymentCompleted: false,
        personalVolume: 0,
        groupVolume: 0,
        leftLegVolume: 0,
        rightLegVolume: 0,
        totalDownlineCount: 0,
        directReferrals: 0,
        leaderCount: 0,
        totalInvestment: 0,
        activeIncome: 0,
        passiveIncome: 0,
        sponsorIncome: 0,
        totalEarnings: 0,
      };

      // Add to database (in real app, this would be an API call)
      INITIAL_USERS.push(newUser);

      const token = generateAuthToken();
      const standardUser = mapUserToStandardUser(newUser);
      const mlmData = mapUserToMLMData(newUser);

      // Store standardized user data
      localStorage.setItem(AUTH_TOKEN_KEY, token);
      localStorage.setItem(USER_DATA_KEY, JSON.stringify(standardUser));
      localStorage.setItem(MLM_DATA_KEY, JSON.stringify(mlmData));

      return standardUser;
    } catch (error) {
      console.error("Register error:", error);
      return null;
    }
  }

  logout(): void {
    localStorage.removeItem(AUTH_TOKEN_KEY);
    localStorage.removeItem(USER_DATA_KEY);
    localStorage.removeItem(MLM_DATA_KEY);
  }

  getCurrentUser(): StandardUser | null {
    try {
      const token = localStorage.getItem(AUTH_TOKEN_KEY);
      const userData = localStorage.getItem(USER_DATA_KEY);

      if (token && userData) {
        return JSON.parse(userData) as StandardUser;
      }
      return null;
    } catch (error) {
      console.error("Error getting current user:", error);
      return null;
    }
  }

  getMLMData(): MLMUserData | null {
    try {
      const mlmData = localStorage.getItem(MLM_DATA_KEY);
      return mlmData ? JSON.parse(mlmData) : null;
    } catch (error) {
      console.error("Error getting MLM data:", error);
      return null;
    }
  }

  getAuthToken(): string | null {
    return localStorage.getItem(AUTH_TOKEN_KEY);
  }

  isAuthenticated(): boolean {
    return this.getCurrentUser() !== null;
  }

  hasRole(role: UserRole): boolean {
    const user = this.getCurrentUser();
    return user?.role === role;
  }

  hasAnyRole(roles: UserRole[]): boolean {
    const user = this.getCurrentUser();
    return user ? roles.includes(user.role) : false;
  }

  updateUserData(userData: Partial<StandardUser>): void {
    const currentUser = this.getCurrentUser();
    if (currentUser) {
      const updatedUser = { ...currentUser, ...userData };
      localStorage.setItem(USER_DATA_KEY, JSON.stringify(updatedUser));
    }
  }

  updateMLMData(mlmData: Partial<MLMUserData>): void {
    const currentMLMData = this.getMLMData();
    if (currentMLMData) {
      const updatedMLMData = { ...currentMLMData, ...mlmData };
      localStorage.setItem(MLM_DATA_KEY, JSON.stringify(updatedMLMData));
    }
  }
}

export const authService = AuthService.getInstance();
