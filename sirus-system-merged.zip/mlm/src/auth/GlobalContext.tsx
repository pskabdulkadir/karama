import React, { createContext, useContext } from "react";
import { AuthProvider, useAuth } from "./AuthContext";
import { GlobalState } from "../constants/auth-types";

// Global context that matches the standardized structure
const GlobalContext = createContext<GlobalState | null>(null);

export function GlobalProvider({ children }: { children: React.ReactNode }) {
  return (
    <AuthProvider>
      <GlobalContextProvider>{children}</GlobalContextProvider>
    </AuthProvider>
  );
}

function GlobalContextProvider({ children }: { children: React.ReactNode }) {
  const { user, isAuthenticated, currentSystem } = useAuth();

  const globalState: GlobalState = {
    user,
    isAuthenticated,
    currentSystem,
  };

  return (
    <GlobalContext.Provider value={globalState}>
      {children}
    </GlobalContext.Provider>
  );
}

// Hook to access global state in the standardized format
export function useGlobalState(): GlobalState {
  const context = useContext(GlobalContext);
  if (!context) {
    throw new Error("useGlobalState must be used within a GlobalProvider");
  }
  return context;
}

// Re-export auth hook for convenience
export { useAuth };
