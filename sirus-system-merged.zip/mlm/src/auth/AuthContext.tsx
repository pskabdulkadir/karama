import React, { createContext, useContext, useReducer, useEffect } from "react";
import {
  AuthState,
  AuthContextType,
  LoginCredentials,
  RegisterData,
  UserRole,
  StandardUser,
  CurrentSystem,
} from "../constants/auth-types";
import { authService } from "./auth-service";

const initialState: AuthState = {
  user: null,
  isAuthenticated: false,
  currentSystem: "mlm", // Default to MLM system
  isLoading: true,
};

type AuthAction =
  | { type: "LOGIN_START" }
  | { type: "LOGIN_SUCCESS"; payload: StandardUser }
  | { type: "LOGIN_FAILURE" }
  | { type: "LOGOUT" }
  | { type: "SET_LOADING"; payload: boolean }
  | { type: "SET_CURRENT_SYSTEM"; payload: CurrentSystem };

function authReducer(state: AuthState, action: AuthAction): AuthState {
  switch (action.type) {
    case "LOGIN_START":
      return { ...state, isLoading: true };
    case "LOGIN_SUCCESS":
      return {
        ...state,
        user: action.payload,
        isAuthenticated: true,
        isLoading: false,
      };
    case "LOGIN_FAILURE":
      return {
        ...state,
        user: null,
        isAuthenticated: false,
        isLoading: false,
      };
    case "LOGOUT":
      return {
        ...state,
        user: null,
        isAuthenticated: false,
        isLoading: false,
      };
    case "SET_LOADING":
      return { ...state, isLoading: action.payload };
    case "SET_CURRENT_SYSTEM":
      return { ...state, currentSystem: action.payload };
    default:
      return state;
  }
}

const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(authReducer, initialState);

  useEffect(() => {
    // Check for existing authentication on app start
    const initializeAuth = async () => {
      try {
        const currentUser = authService.getCurrentUser();
        if (currentUser) {
          dispatch({ type: "LOGIN_SUCCESS", payload: currentUser });
        } else {
          dispatch({ type: "SET_LOADING", payload: false });
        }
      } catch (error) {
        console.error("Error initializing auth:", error);
        dispatch({ type: "SET_LOADING", payload: false });
      }
    };

    initializeAuth();
  }, []);

  const login = async (credentials: LoginCredentials): Promise<boolean> => {
    dispatch({ type: "LOGIN_START" });

    try {
      const user = await authService.login(credentials);
      if (user) {
        dispatch({ type: "LOGIN_SUCCESS", payload: user });
        return true;
      } else {
        dispatch({ type: "LOGIN_FAILURE" });
        return false;
      }
    } catch (error) {
      console.error("Login error:", error);
      dispatch({ type: "LOGIN_FAILURE" });
      return false;
    }
  };

  const logout = () => {
    authService.logout();
    dispatch({ type: "LOGOUT" });
  };

  const register = async (data: RegisterData): Promise<boolean> => {
    dispatch({ type: "LOGIN_START" });

    try {
      const user = await authService.register(data);
      if (user) {
        dispatch({ type: "LOGIN_SUCCESS", payload: user });
        return true;
      } else {
        dispatch({ type: "LOGIN_FAILURE" });
        return false;
      }
    } catch (error) {
      console.error("Register error:", error);
      dispatch({ type: "LOGIN_FAILURE" });
      return false;
    }
  };

  const hasRole = (role: UserRole): boolean => {
    return state.user?.role === role;
  };

  const hasAnyRole = (roles: UserRole[]): boolean => {
    return state.user ? roles.includes(state.user.role) : false;
  };

  const setCurrentSystem = (system: CurrentSystem) => {
    dispatch({ type: "SET_CURRENT_SYSTEM", payload: system });
    // Store in localStorage for persistence
    localStorage.setItem("currentSystem", system);
  };

  // Load current system from localStorage on init
  useEffect(() => {
    const savedSystem = localStorage.getItem("currentSystem") as CurrentSystem;
    if (
      savedSystem &&
      ["mlm", "ecommerce", "development", "panel"].includes(savedSystem)
    ) {
      dispatch({ type: "SET_CURRENT_SYSTEM", payload: savedSystem });
    }
  }, []);

  const contextValue: AuthContextType = {
    ...state,
    login,
    logout,
    register,
    hasRole,
    hasAnyRole,
    setCurrentSystem,
  };

  return (
    <AuthContext.Provider value={contextValue}>{children}</AuthContext.Provider>
  );
}

export function useAuth(): AuthContextType {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}

// Export global state type for use in other systems
export type { AuthState as GlobalAppState };
