import { useState, useEffect } from "react";
import { authService } from "./auth-service";
import { MLMUserData } from "../constants/auth-types";

export function useMLMData() {
  const [mlmData, setMLMData] = useState<MLMUserData | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadMLMData = () => {
      try {
        const data = authService.getMLMData();
        setMLMData(data);
      } catch (error) {
        console.error("Error loading MLM data:", error);
        setMLMData(null);
      } finally {
        setIsLoading(false);
      }
    };

    loadMLMData();
  }, []);

  const updateMLMData = (updates: Partial<MLMUserData>) => {
    if (mlmData) {
      const newData = { ...mlmData, ...updates };
      setMLMData(newData);
      authService.updateMLMData(updates);
    }
  };

  return {
    mlmData,
    isLoading,
    updateMLMData,
  };
}
