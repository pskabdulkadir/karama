export type UserRole = "user" | "admin" | "mlm" | "psychologist" | "merchant";

export type CurrentSystem = "mlm" | "ecommerce" | "development" | "panel";

export interface StandardUser {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  isActive: boolean;
}

export interface GlobalState {
  user: StandardUser | null;
  isAuthenticated: boolean;
  currentSystem: CurrentSystem;
}

export interface AuthState extends GlobalState {
  isLoading: boolean;
}

export interface LoginCredentials {
  email: string;
  password: string;
}

export interface RegisterData {
  email: string;
  password: string;
  fullName: string;
  sponsorCode?: string;
}

export interface AuthContextType extends AuthState {
  login: (credentials: LoginCredentials) => Promise<boolean>;
  logout: () => void;
  register: (data: RegisterData) => Promise<boolean>;
  hasRole: (role: UserRole) => boolean;
  hasAnyRole: (roles: UserRole[]) => boolean;
  setCurrentSystem: (system: CurrentSystem) => void;
}

// Legacy compatibility types for MLM system
export interface MLMUserData {
  referenceNumber?: string;
  sponsorId?: string;
  rank?: string;
  totalInvestment?: number;
  totalEarnings?: number;
}
