// Binary MLM System Types
export interface User {
  id: string;
  username: string;
  name: string;
  email: string;
  password?: string;
  referenceNumber: string; // Format: ak000001
  role: "user" | "admin" | "distributor" | "leader";
  sponsorId?: string;
  sponsorReferenceNumber?: string;
  binaryPosition?: "left" | "right";
  parentId?: string;
  joinDate: string;
  rank: string;
  isActive: boolean;
  activityStatus: "active" | "passive" | "pending";
  lastActivityPayment?: string;
  annualPayment: boolean;
  entryPaymentCompleted: boolean;
  personalVolume: number;
  groupVolume: number;
  leftLegVolume: number;
  rightLegVolume: number;
  totalDownlineCount: number;
  directReferrals: number;
  leaderCount: number;
  totalInvestment: number;
  activeIncome: number;
  passiveIncome: number;
  sponsorIncome: number;
  totalEarnings: number;
}

export interface Wallet {
  id: string;
  userId: string;
  totalBalance: number;
  availableBalance: number;
  pendingBalance: number;
  currencies: {
    TRY: number;
    USD: number;
    EUR: number;
  };
  lastUpdated: string;
}

export interface Transaction {
  id: string;
  userId: string;
  type:
    | "bonus"
    | "withdrawal"
    | "purchase"
    | "commission"
    | "rank_bonus"
    | "entry_payment"
    | "activity_payment"
    | "annual_payment";
  subType?:
    | "binary"
    | "sponsor"
    | "leadership"
    | "sales"
    | "matching"
    | "rank"
    | "infinite_team"
    | "career_bonus";
  amount: number;
  currency: string;
  description: string;
  status: "pending" | "completed" | "failed";
  date: string;
  referenceId?: string;
  distributionData?: {
    bonusAmount: number;
    systemFundAmount: number;
    percentage: number;
  };
}

export interface BinaryTree {
  user: User;
  left?: BinaryTree;
  right?: BinaryTree;
  depth: number;
  leftCount: number;
  rightCount: number;
  leftVolume: number;
  rightVolume: number;
}

export interface Bonus {
  id: string;
  userId: string;
  type:
    | "binary"
    | "sponsor"
    | "leadership"
    | "sales"
    | "matching"
    | "rank"
    | "infinite_team"
    | "career_bonus";
  amount: number;
  percentage: number;
  fromUserId?: string;
  fromUserName?: string;
  calculationData: any;
  period: string; // YYYY-MM
  date: string;
  status: "pending" | "paid" | "cancelled";
  investmentAmount?: number;
  careerLevel?: string;
}

export interface Rank {
  name: string;
  level: number;
  requirements: {
    personalVolume: number;
    groupVolume: number;
    directReferrals: number;
    balancedLegs?: boolean;
    minimumLegVolume?: number;
    leaderCount?: number;
    totalDownlineCount?: number;
  };
  benefits: {
    binaryBonusRate: number;
    sponsorBonusRate: number;
    leadershipBonusRate: number;
    rankBonus: number;
    carBonus?: number;
    travelBonus?: number;
    infiniteTeamRate: number;
    annualBonusExtra?: number;
  };
}

export interface MLMStats {
  totalMembers: number;
  activeMembers: number;
  totalVolume: number;
  monthlyVolume: number;
  totalCommissions: number;
  monthlyCommissions: number;
  averageRank: string;
  topPerformers: User[];
}

export interface ActivityPayment {
  id: string;
  userId: string;
  type: "entry" | "monthly" | "annual";
  amount: number;
  currency: string;
  dueDate: string;
  paidDate?: string;
  status: "pending" | "paid" | "overdue";
  discountApplied?: number;
}

export interface IncomeDistribution {
  totalAmount: number;
  bonusPool: number; // 40%
  systemFund: number; // 60%
  distributionDate: string;
  beneficiaries: {
    userId: string;
    bonusType: string;
    amount: number;
    percentage: number;
  }[];
}

export interface KutbulZamanConfig {
  entryFee: number;
  monthlyFee: number;
  annualFee: number;
  annualDiscount: number; // 15%
  careerBonusRate: number; // 25%
  sponsorBonusRate: number; // 10%
  passiveBonusRate: number; // 5%
  remainingRate: number; // 60% (100% - 25% - 10% - 5%)
}

export interface PaymentSimulation {
  id: string;
  userId: string;
  amount: number;
  currency: string;
  type: "entry" | "monthly" | "annual" | "investment";
  simulationDate: string;
  distributions: {
    careerBonus: number; // 25%
    sponsorBonus: number; // 10%
    passiveBonus: number; // 5%
    systemFund: number; // 60%
  };
  beneficiaries: {
    sponsorId?: string;
    passiveBeneficiaries: string[];
    careerBeneficiaries: string[];
  };
}

export interface EarningsSimulation {
  userId: string;
  teamSize: number;
  averageInvestment: number;
  monthlyProjection: {
    activeIncome: number;
    passiveIncome: number;
    sponsorIncome: number;
    careerIncome: number;
    totalIncome: number;
  };
  annualProjection: {
    activeIncome: number;
    passiveIncome: number;
    sponsorIncome: number;
    careerIncome: number;
    totalIncome: number;
  };
}

export const KUTBUL_ZAMAN_RANKS: Rank[] = [
  {
    name: "Emmare",
    level: 1,
    requirements: {
      personalVolume: 100,
      groupVolume: 0,
      directReferrals: 0,
    },
    benefits: {
      binaryBonusRate: 0,
      sponsorBonusRate: 0.1,
      leadershipBonusRate: 0.02,
      rankBonus: 0,
      infiniteTeamRate: 0,
    },
  },
  {
    name: "Levvame",
    level: 2,
    requirements: {
      personalVolume: 500,
      groupVolume: 0,
      directReferrals: 2,
    },
    benefits: {
      binaryBonusRate: 0,
      sponsorBonusRate: 0.125, // 25% bonus over base 10%
      leadershipBonusRate: 0.03,
      rankBonus: 0,
      infiniteTeamRate: 0.005,
    },
  },
  {
    name: "Mülhime",
    level: 3,
    requirements: {
      personalVolume: 1500,
      groupVolume: 0,
      directReferrals: 4,
    },
    benefits: {
      binaryBonusRate: 0,
      sponsorBonusRate: 0.125,
      leadershipBonusRate: 0.04,
      rankBonus: 0,
      infiniteTeamRate: 0.01,
    },
  },
  {
    name: "Mutmainne",
    level: 4,
    requirements: {
      personalVolume: 3000,
      groupVolume: 0,
      directReferrals: 10,
    },
    benefits: {
      binaryBonusRate: 0,
      sponsorBonusRate: 0.125,
      leadershipBonusRate: 0.05,
      rankBonus: 0,
      infiniteTeamRate: 0.015,
    },
  },
  {
    name: "Radiyye",
    level: 5,
    requirements: {
      personalVolume: 5000,
      groupVolume: 0,
      directReferrals: 0,
      leaderCount: 2,
    },
    benefits: {
      binaryBonusRate: 0,
      sponsorBonusRate: 0.125,
      leadershipBonusRate: 0.06,
      rankBonus: 0,
      infiniteTeamRate: 0.02,
    },
  },
  {
    name: "Mardiyye",
    level: 6,
    requirements: {
      personalVolume: 10000,
      groupVolume: 0,
      directReferrals: 0,
      totalDownlineCount: 50,
    },
    benefits: {
      binaryBonusRate: 0,
      sponsorBonusRate: 0.125,
      leadershipBonusRate: 0.08,
      rankBonus: 0,
      infiniteTeamRate: 0.03,
    },
  },
  {
    name: "Safiye",
    level: 7,
    requirements: {
      personalVolume: 25000,
      groupVolume: 0,
      directReferrals: 0,
      leaderCount: 3,
    },
    benefits: {
      binaryBonusRate: 0,
      sponsorBonusRate: 0.125,
      leadershipBonusRate: 0.12,
      rankBonus: 0,
      infiniteTeamRate: 0.04,
      annualBonusExtra: 0.01, // Extra 1% for annual payments
    },
  },
];

export const RANKS = KUTBUL_ZAMAN_RANKS;

export const KUTBUL_ZAMAN_CONFIG: KutbulZamanConfig = {
  entryFee: 100,
  monthlyFee: 20,
  annualFee: 200,
  annualDiscount: 0.15,
  careerBonusRate: 0.25,
  sponsorBonusRate: 0.1,
  passiveBonusRate: 0.05,
  remainingRate: 0.6,
};
