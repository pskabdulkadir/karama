import React from "react";
import { useAuth } from "../../auth/AuthContext";
import { UserRole } from "../../constants/auth-types";

interface RoleGuardProps {
  allowedRoles: UserRole[];
  children: React.ReactNode;
  fallback?: React.ReactNode;
}

export function RoleGuard({
  allowedRoles,
  children,
  fallback = null,
}: RoleGuardProps) {
  const { hasAnyRole } = useAuth();

  if (hasAnyRole(allowedRoles)) {
    return <>{children}</>;
  }

  return <>{fallback}</>;
}

interface RequireRoleProps {
  role: UserRole;
  children: React.ReactNode;
  fallback?: React.ReactNode;
}

export function RequireRole({
  role,
  children,
  fallback = null,
}: RequireRoleProps) {
  const { hasRole } = useAuth();

  if (hasRole(role)) {
    return <>{children}</>;
  }

  return <>{fallback}</>;
}
