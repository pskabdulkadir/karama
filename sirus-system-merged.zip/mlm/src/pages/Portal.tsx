import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../auth/AuthContext";
import { Button } from "../components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "../components/ui/card";
import {
  Users,
  ShoppingCart,
  TrendingUp,
  User,
  Settings,
  Heart,
} from "lucide-react";

export default function Portal() {
  const { user, isAuthenticated, setCurrentSystem } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    // Auto-redirect based on user role if authenticated
    if (isAuthenticated && user) {
      if (user.role === "admin") {
        navigate("/admin");
      } else if (user.role === "mlm") {
        setCurrentSystem("mlm");
        navigate("/mlm");
      }
    }
  }, [isAuthenticated, user, navigate, setCurrentSystem]);

  const systemCards = [
    {
      title: "Kullanıcı Paneli",
      description: "Hesap yönetimi ve genel işlemler",
      icon: User,
      path: "/panel",
      color: "bg-blue-500",
      roles: ["user", "admin", "mlm"],
    },
    {
      title: "Network Marketing",
      description: "MLM sistemi ve kazanç takibi",
      icon: Users,
      path: "/mlm",
      color: "bg-emerald-500",
      roles: ["user", "admin", "mlm"],
    },
    {
      title: "Alışveriş",
      description: "Ürün kataloğu ve sipariş yönetimi",
      icon: ShoppingCart,
      path: "/shop",
      color: "bg-purple-500",
      roles: ["user", "admin", "merchant"],
    },
    {
      title: "Kişisel Gelişim",
      description: "Eğitim içerikleri ve danışmanlık",
      icon: Heart,
      path: "/self",
      color: "bg-pink-500",
      roles: ["user", "admin", "psychologist"],
    },
    {
      title: "Yönetim Paneli",
      description: "Sistem yönetimi ve raporlar",
      icon: Settings,
      path: "/admin",
      color: "bg-red-500",
      roles: ["admin"],
    },
  ];

  const handleSystemSelect = (path: string, systemKey: string) => {
    if (systemKey === "mlm") setCurrentSystem("mlm");
    else if (systemKey === "ecommerce") setCurrentSystem("ecommerce");
    else if (systemKey === "development") setCurrentSystem("development");
    else if (systemKey === "panel") setCurrentSystem("panel");

    if (isAuthenticated) {
      navigate(path);
    } else {
      navigate(`/login?redirect=${encodeURIComponent(path)}`);
    }
  };

  const getSystemKey = (path: string) => {
    if (path === "/mlm") return "mlm";
    if (path === "/shop") return "ecommerce";
    if (path === "/self") return "development";
    return "panel";
  };

  const canAccessSystem = (roles: string[]) => {
    if (!isAuthenticated || !user) return true; // Allow access to login
    return roles.includes(user.role);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-navy-50 via-background to-gold-50 p-4 fade-in">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12 slide-up">
          <div className="inline-flex items-center justify-center w-24 h-24 bg-gradient-to-br from-primary to-navy-700 text-white rounded-3xl mb-6 shadow-2xl">
            <TrendingUp className="w-12 h-12" />
          </div>
          <h1 className="text-5xl font-bold text-primary mb-4 brand-font">
            Kutbul Zaman Portal
          </h1>
          <p className="text-xl text-muted-foreground mb-6">
            Tüm sistemlere merkezi erişim noktası
          </p>

          {isAuthenticated && user ? (
            <div className="bg-gold-50 border border-gold-200 rounded-xl p-4 inline-block">
              <p className="text-navy-700">
                Hoş geldin, <span className="font-semibold">{user.name}</span>
              </p>
              <p className="text-sm text-navy-600">Rol: {user.role}</p>
            </div>
          ) : (
            <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 inline-block">
              <p className="text-blue-700 mb-2">
                Sistemlere erişim için giriş yapın
              </p>
              <Button
                onClick={() => navigate("/login")}
                className="bg-primary hover:bg-primary/90"
              >
                Giriş Yap
              </Button>
            </div>
          )}
        </div>

        {/* System Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {systemCards.map((system, index) => {
            const canAccess = canAccessSystem(system.roles);
            const Icon = system.icon;

            return (
              <Card
                key={system.path}
                className={`card-kutbul cursor-pointer transition-all duration-300 ${
                  !canAccess ? "opacity-50" : "hover:transform hover:scale-105"
                }`}
                style={{ animationDelay: `${index * 100}ms` }}
                onClick={() => {
                  if (canAccess) {
                    handleSystemSelect(system.path, getSystemKey(system.path));
                  }
                }}
              >
                <CardHeader className="text-center pb-4">
                  <div
                    className={`inline-flex items-center justify-center w-16 h-16 ${system.color} text-white rounded-2xl mb-4 mx-auto shadow-lg`}
                  >
                    <Icon className="w-8 h-8" />
                  </div>
                  <CardTitle className="text-xl brand-font">
                    {system.title}
                  </CardTitle>
                  <CardDescription className="text-base">
                    {system.description}
                  </CardDescription>
                </CardHeader>
                <CardContent className="text-center">
                  <div className="text-xs text-muted-foreground mb-3">
                    Gerekli roller:{" "}
                    {system.roles.map((role, i) => (
                      <span
                        key={role}
                        className={`inline-block px-2 py-1 rounded-full text-xs mr-1 ${
                          user?.role === role
                            ? "bg-gold-100 text-gold-800"
                            : "bg-gray-100 text-gray-600"
                        }`}
                      >
                        {role}
                      </span>
                    ))}
                  </div>
                  {canAccess ? (
                    <Button
                      className="w-full"
                      variant={isAuthenticated ? "default" : "outline"}
                    >
                      {isAuthenticated ? "Sisteme Git" : "Giriş Yap & Git"}
                    </Button>
                  ) : (
                    <Button className="w-full" variant="ghost" disabled>
                      Erişim Yok
                    </Button>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Quick Actions */}
        {!isAuthenticated && (
          <div className="mt-12 text-center">
            <Card className="card-kutbul max-w-md mx-auto">
              <CardHeader>
                <CardTitle>Hızlı İşlemler</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button
                  onClick={() => navigate("/login")}
                  className="w-full"
                  variant="default"
                >
                  Giriş Yap
                </Button>
                <Button
                  onClick={() => navigate("/register")}
                  className="w-full"
                  variant="outline"
                >
                  Üye Ol
                </Button>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}
