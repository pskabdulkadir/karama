import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "../components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "../components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "../components/ui/avatar";
import { Badge } from "../components/ui/badge";
import { Progress } from "../components/ui/progress";
import {
  Users,
  Home,
  GitBranch,
  TrendingUp,
  Settings as SettingsIcon,
  LogOut,
  Copy,
  Check,
  DollarSign,
  UserPlus,
  Crown,
  BarChart3,
  Bell,
  ChevronLeft,
  Menu,
  Wallet as WalletIcon,
  Award,
  Target,
  Calendar,
  ArrowUpRight,
  ArrowDownRight,
  Coins,
  CreditCard,
  History,
  PieChart,
  LineChart,
  TreePine,
  Trophy,
  Zap,
  Eye,
  Banknote,
  Gift,
  Star,
  Network,
  TrendingDown,
} from "lucide-react";
import {
  User,
  Wallet as WalletType,
  Transaction,
  Bonus,
  KUTBUL_ZAMAN_RANKS,
} from "../constants/mlm-types";
import { authService } from "../auth/auth-service";

export default function Dashboard() {
  const [user, setUser] = useState<User | null>(null);
  const [wallet, setWallet] = useState<WalletType | null>(null);
  const [activeTab, setActiveTab] = useState("dashboard");
  const [referralLinkCopied, setReferralLinkCopied] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const navigate = useNavigate();

  const referralLink = `https://kutbulzaman.com/register?ref=${
    user?.referenceNumber || user?.username || "ak000001"
  }`;

  useEffect(() => {
    const currentUser = authService.getCurrentUser();
    if (!currentUser) {
      navigate("/login");
      return;
    }

    // Enhanced user data with defaults
    const enhancedUser: User = {
      ...currentUser,
      totalInvestment: currentUser.totalInvestment || 0,
      leftLegVolume: currentUser.leftLegVolume || 0,
      rightLegVolume: currentUser.rightLegVolume || 0,
      totalDownlineCount: currentUser.totalDownlineCount || 0,
      directReferrals: currentUser.directReferrals || 0,
      leaderCount: currentUser.leaderCount || 0,
      activeIncome: currentUser.activeIncome || 0,
      passiveIncome: currentUser.passiveIncome || 0,
      sponsorIncome: currentUser.sponsorIncome || 0,
      totalEarnings: currentUser.totalEarnings || 0,
      personalVolume: currentUser.personalVolume || 0,
      groupVolume: currentUser.groupVolume || 0,
      activityStatus: currentUser.activityStatus || "pending",
    };

    const sampleWallet: WalletType = {
      id: "wallet1",
      userId: "user1",
      totalBalance: 15840.75,
      availableBalance: 14340.75,
      pendingBalance: 1500.0,
      currencies: {
        TRY: 15840.75,
        USD: 534.5,
        EUR: 467.3,
      },
      lastUpdated: new Date().toISOString(),
    };

    setUser(enhancedUser);
    setWallet(sampleWallet);
  }, [navigate]);

  const handleLogout = () => {
    authService.logout();
    navigate("/login");
  };

  const copyReferralLink = async () => {
    await navigator.clipboard.writeText(referralLink);
    setReferralLinkCopied(true);
    setTimeout(() => setReferralLinkCopied(false), 2000);
  };

  const getCurrentRank = () => {
    if (!user) return KUTBUL_ZAMAN_RANKS[0];
    return (
      KUTBUL_ZAMAN_RANKS.find((rank) => rank.name === user.rank) ||
      KUTBUL_ZAMAN_RANKS[0]
    );
  };

  const getNextRank = () => {
    const currentRank = getCurrentRank();
    return KUTBUL_ZAMAN_RANKS.find(
      (rank) => rank.level === currentRank.level + 1,
    );
  };

  const calculateRankProgress = () => {
    if (!user) return 0;
    const currentRank = getCurrentRank();
    const nextRank = getNextRank();
    if (!nextRank) return 100;

    const progress = Math.min(
      ((user.totalInvestment || 0) / nextRank.requirements.personalVolume) *
        100,
      ((user.groupVolume || 0) / nextRank.requirements.groupVolume) * 100,
      ((user.directReferrals || 0) / nextRank.requirements.directReferrals) *
        100,
    );
    return Math.round(progress);
  };

  const navigationButtons = [
    {
      id: "career",
      label: "Kariyerim",
      icon: Crown,
      href: "/panel/kariyerim",
      color: "bg-purple-600 hover:bg-purple-700",
    },
    {
      id: "bonuses",
      label: "Bonuslarım",
      icon: Award,
      href: "/panel/bonuslar",
      color: "bg-blue-600 hover:bg-blue-700",
    },
    {
      id: "investment",
      label: "Yatırım Yap",
      icon: Coins,
      href: "/panel/yatirim-yap",
      color: "bg-green-600 hover:bg-green-700",
    },
    {
      id: "simulation",
      label: "Kazanç Simülasyonu",
      icon: BarChart3,
      href: "/panel/simulasyon",
      color: "bg-indigo-600 hover:bg-indigo-700",
    },
    {
      id: "shopping",
      label: "Alışverişe Git",
      icon: Star,
      href: "/alisveris",
      color: "bg-accent hover:bg-accent/90",
    },
    {
      id: "development",
      label: "Kişisel Gelişim",
      icon: Target,
      href: "/gelisim",
      color: "bg-info hover:bg-info/90",
    },
    ...(user?.role === "admin"
      ? [
          {
            id: "admin-panel",
            label: "Admin Paneli",
            icon: Crown,
            href: "/admin",
            color: "bg-warning hover:bg-warning/90",
          },
        ]
      : []),
  ];

  if (!user || !wallet) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-primary/10 via-background to-accent/10 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Yükleniyor...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/10 via-background to-accent/10 p-4">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Welcome Section */}
        <Card className="border-2 border-primary/20 bg-gradient-to-r from-primary/5 to-accent/5">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-2xl text-primary flex items-center gap-2">
                  <Crown className="w-6 h-6" />
                  Hoş Geldiniz, {user.name}!
                </CardTitle>
                <CardDescription className="text-lg mt-2">
                  {user.referenceNumber === "ak000001"
                    ? "Kutbul Zaman Network kurucusu ve sistem yöneticisi olarak hoş geldiniz"
                    : "Kutbul Zaman Network üyesi olarak sisteme hoş geldiniz"}
                </CardDescription>
                <div className="flex flex-wrap items-center gap-4 mt-3">
                  <div className="flex items-center gap-2">
                    <span className="text-sm">Pozisyon:</span>
                    <Badge
                      variant={
                        user.referenceNumber === "ak000001"
                          ? "default"
                          : "secondary"
                      }
                      className={
                        user.referenceNumber === "ak000001"
                          ? "bg-purple-600 text-white font-semibold"
                          : "text-accent font-semibold"
                      }
                    >
                      {user.referenceNumber === "ak000001"
                        ? "KURUCU"
                        : user.rank}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm">Ref Kodu:</span>
                    <Badge variant="outline" className="font-mono">
                      {user.referenceNumber || user.username.toUpperCase()}
                    </Badge>
                  </div>
                  <div className="text-sm text-muted-foreground">
                    Üyelik:{" "}
                    {user.joinDate
                      ? new Date(user.joinDate).toLocaleDateString("tr-TR")
                      : "Bilinmiyor"}
                  </div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-3xl font-bold text-accent">
                  $
                  {wallet.totalBalance.toLocaleString("en-US", {
                    minimumFractionDigits: 2,
                  })}
                </div>
                <div className="text-sm text-muted-foreground">
                  Toplam Bakiye
                </div>
              </div>
            </div>
          </CardHeader>
        </Card>

        {/* Stats Grid */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Card className="border-l-4 border-l-success">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Toplam Kazanç
              </CardTitle>
              <DollarSign className="h-4 w-4 text-success" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-success">
                ${wallet.totalBalance.toLocaleString("en-US")}
              </div>
              <p className="text-xs text-muted-foreground">+$455 bu ay</p>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-l-info">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Ekip Üyeleri
              </CardTitle>
              <Users className="h-4 w-4 text-info" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-info">
                {user.totalDownlineCount || 0}
              </div>
              <p className="text-xs text-muted-foreground">
                Direkt: {user.directReferrals || 0} • Dolaylı:{" "}
                {(user.totalDownlineCount || 0) - (user.directReferrals || 0)}
              </p>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-l-accent">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Toplam Yatırım
              </CardTitle>
              <BarChart3 className="h-4 w-4 text-accent" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-accent">
                ${(user.totalInvestment || 0).toLocaleString("en-US")}
              </div>
              <p className="text-xs text-muted-foreground">
                Kutbul Zaman sistemi
              </p>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-l-warning">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Aktiflik Durumu
              </CardTitle>
              <Gift className="h-4 w-4 text-warning" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-warning">
                {(user.activityStatus || "pending") === "active"
                  ? "Aktif"
                  : "Pasif"}
              </div>
              <p className="text-xs text-muted-foreground">
                Son ödeme: {user.lastActivityPayment || "Yok"}
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Navigation Buttons */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Star className="w-5 h-5 text-primary" />
              Hızlı Erişim
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
              {navigationButtons.map((button) => {
                const Icon = button.icon;
                return (
                  <Button
                    key={button.id}
                    asChild
                    className={`${button.color} text-white p-4 h-auto rounded-xl`}
                  >
                    <a href={button.href}>
                      <div className="flex items-center gap-3">
                        <Icon className="w-5 h-5" />
                        <span className="text-sm">{button.label}</span>
                      </div>
                    </a>
                  </Button>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Referral Section */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <UserPlus className="w-5 h-5 text-accent" />
              Kayıt Linki Oluşturma ve Alt Üye Ekleme
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex space-x-2">
                <input
                  type="text"
                  value={referralLink}
                  readOnly
                  className="flex-1 px-3 py-2 text-sm bg-muted border border-border rounded-md"
                />
                <Button
                  onClick={copyReferralLink}
                  variant="outline"
                  className="border-2 border-accent text-accent hover:bg-accent hover:text-accent-foreground"
                >
                  {referralLinkCopied ? (
                    <Check className="w-4 h-4" />
                  ) : (
                    <Copy className="w-4 h-4" />
                  )}
                </Button>
              </div>
              <div className="text-sm text-muted-foreground">
                Bu linki paylaşarak yeni üyeler davet edin ve sponsor bonusu
                kazanın. Ref Kodunuz:{" "}
                <strong>
                  {user.referenceNumber || user.username.toUpperCase()}
                </strong>
                {user.referenceNumber === "ak000001" && (
                  <span className="ml-2 text-purple-600 font-semibold">
                    (Kurucu)
                  </span>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
