import { useState, useEffect } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "../components/ui/card";
import { Users, Lock, Eye, EyeOff, AlertCircle } from "lucide-react";
import { useAuth } from "../auth/AuthContext";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { login, isLoading, isAuthenticated, user } = useAuth();

  // Get redirect URL from query parameters
  const redirectTo = searchParams.get("redirect") || null;

  useEffect(() => {
    if (isAuthenticated && user) {
      // Use redirect parameter if available, otherwise redirect based on user role
      if (redirectTo) {
        navigate(redirectTo);
      } else if (user.role === "admin") {
        navigate("/admin");
      } else if (user.role === "mlm") {
        navigate("/mlm");
      } else {
        navigate("/panel");
      }
    }
  }, [isAuthenticated, user, navigate, redirectTo]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    const success = await login({ email, password });
    if (!success) {
      setError("Kullanıcı adı veya şifre hatalı!");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-navy-50 via-background to-gold-50 flex items-center justify-center p-4 fade-in">
      <div className="w-full max-w-md">
        <div className="text-center mb-8 slide-up">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-primary to-navy-700 text-white rounded-2xl mb-6 shadow-xl">
            <Users className="w-10 h-10" />
          </div>
          <h1 className="text-4xl font-bold text-primary mb-3 brand-font">
            Kutbul Zaman
          </h1>
          <p className="text-muted-foreground text-lg">
            Network Marketing Yönetim Sistemi
          </p>
        </div>

        <Card className="border-2 border-primary/20 shadow-2xl card-kutbul backdrop-blur-sm">
          <CardHeader className="space-y-1">
            <CardTitle className="text-3xl text-center text-primary brand-font">
              Giriş Yap
            </CardTitle>
            <CardDescription className="text-center text-base mt-2">
              Hesabınıza erişim sağlayın
            </CardDescription>
          </CardHeader>
          <form onSubmit={handleSubmit}>
            <CardContent className="space-y-4">
              {error && (
                <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2">
                  <AlertCircle className="h-4 w-4 text-red-600" />
                  <span className="text-red-700 text-sm">{error}</span>
                </div>
              )}

              <div className="mb-6 p-4 bg-gradient-to-r from-gold-50 to-gold-100 border border-gold-200 rounded-xl">
                <h4 className="font-semibold text-navy-800 mb-3 flex items-center gap-2">
                  <div className="w-2 h-2 bg-gold-500 rounded-full"></div>
                  Sistem Yöneticisi Girişi
                </h4>
                <div className="text-sm text-navy-700 space-y-2">
                  <div className="flex justify-between">
                    <span className="font-medium">Kullanıcı:</span>
                    <span className="text-navy-600">abdulkadirkqn</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-medium">Şifre:</span>
                    <span className="text-navy-600">Abdulkadir1983</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-medium">Ref No:</span>
                    <span className="text-gold-600 font-semibold">
                      ak000001 (Kurucu)
                    </span>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">Kullanıcı Adı / Email</Label>
                <Input
                  id="email"
                  type="text"
                  placeholder="Kullanıcı adı veya email girin"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="input-kutbul h-12"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Şifre</Label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    placeholder="Şifrenizi girin"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    className="input-kutbul h-12 pr-12"
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? (
                      <EyeOff className="h-4 w-4 text-muted-foreground" />
                    ) : (
                      <Eye className="h-4 w-4 text-muted-foreground" />
                    )}
                  </Button>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <Link
                  to="/forgot-password"
                  className="text-sm text-gold-600 hover:text-gold-700 font-medium transition-colors duration-200"
                >
                  Şifremi Unuttum
                </Link>
              </div>
            </CardContent>
            <CardFooter className="flex flex-col space-y-4">
              <Button
                type="submit"
                className="w-full h-14 text-base font-semibold"
                disabled={isLoading}
              >
                {isLoading ? (
                  <div className="flex items-center space-x-2">
                    <Lock className="w-4 h-4 animate-spin" />
                    <span>Giriş yapılıyor...</span>
                  </div>
                ) : (
                  <div className="flex items-center space-x-2">
                    <Lock className="w-4 h-4" />
                    <span>Giriş Yap</span>
                  </div>
                )}
              </Button>
              <div className="text-center text-sm">
                <span className="text-muted-foreground">
                  Hesabınız yok mu?{" "}
                </span>
                <Link
                  to="/register"
                  className="text-primary hover:text-primary/80 font-medium transition-colors duration-200"
                >
                  Üye Ol
                </Link>
              </div>
            </CardFooter>
          </form>
        </Card>
      </div>
    </div>
  );
}
