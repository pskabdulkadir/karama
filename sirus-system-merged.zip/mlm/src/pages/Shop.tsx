import { Button } from "../components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "../components/ui/card";
import { ShoppingCart, Package, CreditCard, Star } from "lucide-react";

export default function Shop() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-navy-50 via-background to-gold-50 p-6 fade-in">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12 slide-up">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-purple-500 to-purple-700 text-white rounded-2xl mb-6 shadow-xl">
            <ShoppingCart className="w-10 h-10" />
          </div>
          <h1 className="text-4xl font-bold text-primary mb-3 brand-font">
            Kutbul Zaman Mağaza
          </h1>
          <p className="text-lg text-muted-foreground">
            Premium ürünler ve özel teklifler
          </p>
        </div>

        {/* Coming Soon Card */}
        <Card className="card-kutbul max-w-2xl mx-auto text-center mb-8">
          <CardHeader>
            <CardTitle className="text-2xl brand-font">
              E-ticaret Sistemi Çok Yakında
            </CardTitle>
            <CardDescription className="text-base">
              Alışveriş deneyiminizi geliştirmek için çalışıyoruz
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 bg-purple-50 rounded-xl">
                <Package className="w-8 h-8 text-purple-600 mx-auto mb-2" />
                <h3 className="font-semibold text-purple-800">
                  Premium Ürünler
                </h3>
                <p className="text-sm text-purple-600">
                  Yüksek kaliteli ürün kataloğu
                </p>
              </div>
              <div className="p-4 bg-green-50 rounded-xl">
                <CreditCard className="w-8 h-8 text-green-600 mx-auto mb-2" />
                <h3 className="font-semibold text-green-800">Güvenli Ödeme</h3>
                <p className="text-sm text-green-600">
                  Çoklu ödeme seçenekleri
                </p>
              </div>
              <div className="p-4 bg-gold-50 rounded-xl">
                <Star className="w-8 h-8 text-gold-600 mx-auto mb-2" />
                <h3 className="font-semibold text-gold-800">VIP Avantajlar</h3>
                <p className="text-sm text-gold-600">Üyelere özel indirimler</p>
              </div>
            </div>

            <div className="bg-gradient-to-r from-purple-100 to-pink-100 p-6 rounded-xl">
              <h3 className="font-semibold text-purple-800 mb-2">
                Haberdar Olmak İster Misiniz?
              </h3>
              <p className="text-purple-600 mb-4">
                E-ticaret sistemimiz hazır olduğunda size haber verelim
              </p>
              <Button className="bg-purple-600 hover:bg-purple-700 text-white">
                Bilgilendirme İste
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Navigation */}
        <div className="text-center">
          <Button variant="outline" onClick={() => window.history.back()}>
            Geri Dön
          </Button>
        </div>
      </div>
    </div>
  );
}
