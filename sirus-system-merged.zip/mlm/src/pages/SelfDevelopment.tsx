import { Button } from "../components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "../components/ui/card";
import { Heart, BookOpen, Users, Award } from "lucide-react";

export default function SelfDevelopment() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-navy-50 via-background to-pink-50 p-6 fade-in">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12 slide-up">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-pink-500 to-pink-700 text-white rounded-2xl mb-6 shadow-xl">
            <Heart className="w-10 h-10" />
          </div>
          <h1 className="text-4xl font-bold text-primary mb-3 brand-font">
            Kişisel Gelişim Merkezi
          </h1>
          <p className="text-lg text-muted-foreground">
            Kendinizi geliştirin, potansiyelinizi keşfedin
          </p>
        </div>

        {/* Coming Soon Card */}
        <Card className="card-kutbul max-w-2xl mx-auto text-center mb-8">
          <CardHeader>
            <CardTitle className="text-2xl brand-font">
              Kişisel Gelişim Platformu Çok Yakında
            </CardTitle>
            <CardDescription className="text-base">
              Size özel gelişim programları hazırlanıyor
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 bg-pink-50 rounded-xl">
                <BookOpen className="w-8 h-8 text-pink-600 mx-auto mb-2" />
                <h3 className="font-semibold text-pink-800">
                  Eğitim İçerikleri
                </h3>
                <p className="text-sm text-pink-600">
                  Uzman eğitmenlerden kurslar
                </p>
              </div>
              <div className="p-4 bg-blue-50 rounded-xl">
                <Users className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                <h3 className="font-semibold text-blue-800">
                  Birebir Danışmanlık
                </h3>
                <p className="text-sm text-blue-600">
                  Profesyonel psikolog desteği
                </p>
              </div>
              <div className="p-4 bg-gold-50 rounded-xl">
                <Award className="w-8 h-8 text-gold-600 mx-auto mb-2" />
                <h3 className="font-semibold text-gold-800">Sertifikalar</h3>
                <p className="text-sm text-gold-600">
                  Tamamladığınız programlar için
                </p>
              </div>
            </div>

            <div className="bg-gradient-to-r from-pink-100 to-purple-100 p-6 rounded-xl">
              <h3 className="font-semibold text-pink-800 mb-2">
                Gelişim Yolculuğunuz Başlasın
              </h3>
              <p className="text-pink-600 mb-4">
                Kişisel gelişim platformumuz hazır olduğunda öncelikli erişim
                sağlayın
              </p>
              <Button className="bg-pink-600 hover:bg-pink-700 text-white">
                Erken Erişim İste
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-left">
              <div className="p-4 bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl">
                <h4 className="font-semibold text-blue-800 mb-2">
                  📚 Planlanan İçerikler
                </h4>
                <ul className="text-sm text-blue-700 space-y-1">
                  <li>• Stres yönetimi teknikleri</li>
                  <li>• Motivasyon ve hedef belirleme</li>
                  <li>• İletişim becerileri</li>
                  <li>• Liderlik geliştirme</li>
                </ul>
              </div>
              <div className="p-4 bg-gradient-to-br from-green-50 to-green-100 rounded-xl">
                <h4 className="font-semibold text-green-800 mb-2">
                  🎯 Hedeflerimiz
                </h4>
                <ul className="text-sm text-green-700 space-y-1">
                  <li>• Kişisel farkındalık artırma</li>
                  <li>• Yaşam kalitesi iyileştirme</li>
                  <li>• Kariyer gelişimi destekleme</li>
                  <li>• Ruh sağlığı güçlendirme</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Navigation */}
        <div className="text-center">
          <Button variant="outline" onClick={() => window.history.back()}>
            Geri Dön
          </Button>
        </div>
      </div>
    </div>
  );
}
