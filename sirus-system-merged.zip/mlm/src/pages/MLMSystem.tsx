import { useNavigate } from "react-router-dom";
import { useAuth } from "../auth/AuthContext";
import { Button } from "../components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import {
  Users,
  TrendingUp,
  DollarSign,
  Target,
  Award,
  BarChart3,
} from "lucide-react";

export default function MLMSystem() {
  const { user } = useAuth();
  const navigate = useNavigate();

  const mlmFeatures = [
    {
      title: "Kariyer Takibi",
      description: "Seviye ilerlemesi ve başarılarınız",
      icon: Award,
      path: "/mlm/kariyerim",
      color: "bg-emerald-500",
    },
    {
      title: "Bonus Sistemi",
      description: "Kazançlarınız ve bonus hesapları",
      icon: DollarSign,
      path: "/mlm/bonuslar",
      color: "bg-green-500",
    },
    {
      title: "Yatırım Yap",
      description: "Paket satın alma ve aktivasyon",
      icon: TrendingUp,
      path: "/mlm/yatirim-yap",
      color: "bg-blue-500",
    },
    {
      title: "Simülasyon",
      description: "Gelir projeksiyonu hesaplama",
      icon: BarChart3,
      path: "/mlm/simulasyon",
      color: "bg-purple-500",
    },
    {
      title: "Takım Görünümü",
      description: "Network yapınız ve ekibiniz",
      icon: Users,
      path: "/mlm/takim",
      color: "bg-orange-500",
    },
    {
      title: "Hedefler",
      description: "Aylık ve yıllık hedefleriniz",
      icon: Target,
      path: "/mlm/hedefler",
      color: "bg-pink-500",
    },
  ];

  const quickStats = [
    {
      label: "Aktuel Seviye",
      value: "Emmare",
      color: "bg-gold-100 text-gold-800",
    },
    {
      label: "Aylık Gelir",
      value: "$1,250",
      color: "bg-green-100 text-green-800",
    },
    { label: "Ekip Sayısı", value: "24", color: "bg-blue-100 text-blue-800" },
    {
      label: "Bu Ay Bonus",
      value: "$320",
      color: "bg-purple-100 text-purple-800",
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-navy-50 via-background to-emerald-50 p-6 fade-in">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8 slide-up">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-4xl font-bold text-primary mb-2 brand-font">
                MLM Network Sistemi
              </h1>
              <p className="text-lg text-muted-foreground">
                Hoş geldin, {user?.name}
              </p>
            </div>
            <div className="flex items-center gap-4">
              <Badge
                variant="secondary"
                className="bg-emerald-100 text-emerald-800"
              >
                <Users className="w-4 h-4 mr-1" />
                Network Üyesi
              </Badge>
              <Button variant="outline" onClick={() => navigate("/panel")}>
                Ana Panel
              </Button>
            </div>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {quickStats.map((stat, index) => (
            <Card
              key={stat.label}
              className="card-kutbul text-center"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <CardContent className="p-4">
                <p className="text-sm text-muted-foreground mb-1">
                  {stat.label}
                </p>
                <Badge className={`text-lg font-bold ${stat.color}`}>
                  {stat.value}
                </Badge>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* MLM Features */}
        <Card className="card-kutbul mb-8">
          <CardHeader>
            <CardTitle className="text-2xl brand-font">
              Network Marketing Araçları
            </CardTitle>
            <CardDescription>
              MLM sisteminizi yönetmek için ihtiyacınız olan tüm araçlar
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {mlmFeatures.map((feature, index) => {
                const Icon = feature.icon;
                return (
                  <Card
                    key={feature.title}
                    className="cursor-pointer hover:transform hover:scale-105 transition-all duration-200 border-2 hover:border-emerald-300"
                    style={{ animationDelay: `${(index + 4) * 100}ms` }}
                    onClick={() => navigate(feature.path)}
                  >
                    <CardContent className="p-6 text-center">
                      <div
                        className={`inline-flex items-center justify-center w-16 h-16 ${feature.color} text-white rounded-2xl mb-4 shadow-lg`}
                      >
                        <Icon className="w-8 h-8" />
                      </div>
                      <h3 className="font-semibold text-primary mb-2 text-lg">
                        {feature.title}
                      </h3>
                      <p className="text-sm text-muted-foreground">
                        {feature.description}
                      </p>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Recent Activity */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card className="card-kutbul">
            <CardHeader>
              <CardTitle>Son Aktiviteler</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center gap-3 p-3 bg-emerald-50 rounded-lg">
                  <div className="w-3 h-3 bg-emerald-500 rounded-full"></div>
                  <div className="flex-1">
                    <p className="text-sm font-medium">
                      Yeni ekip üyesi eklendi
                    </p>
                    <p className="text-xs text-muted-foreground">2 saat önce</p>
                  </div>
                  <Badge variant="outline" className="text-xs">
                    +$50
                  </Badge>
                </div>
                <div className="flex items-center gap-3 p-3 bg-blue-50 rounded-lg">
                  <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                  <div className="flex-1">
                    <p className="text-sm font-medium">
                      Aylık bonus hesaplandı
                    </p>
                    <p className="text-xs text-muted-foreground">1 gün önce</p>
                  </div>
                  <Badge variant="outline" className="text-xs">
                    +$320
                  </Badge>
                </div>
                <div className="flex items-center gap-3 p-3 bg-purple-50 rounded-lg">
                  <div className="w-3 h-3 bg-purple-500 rounded-full"></div>
                  <div className="flex-1">
                    <p className="text-sm font-medium">Paket aktivasyonu</p>
                    <p className="text-xs text-muted-foreground">3 gün önce</p>
                  </div>
                  <Badge variant="outline" className="text-xs">
                    $200
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="card-kutbul">
            <CardHeader>
              <CardTitle>Hızlı İşlemler</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button
                className="w-full justify-start"
                variant="outline"
                onClick={() => navigate("/mlm/yatirim-yap")}
              >
                <TrendingUp className="w-4 h-4 mr-2" />
                Yeni Paket Satın Al
              </Button>
              <Button
                className="w-full justify-start"
                variant="outline"
                onClick={() => navigate("/mlm/takim")}
              >
                <Users className="w-4 h-4 mr-2" />
                Ekibimi Görüntüle
              </Button>
              <Button
                className="w-full justify-start"
                variant="outline"
                onClick={() => navigate("/mlm/bonuslar")}
              >
                <DollarSign className="w-4 h-4 mr-2" />
                Kazançlarım
              </Button>
              <Button
                className="w-full justify-start"
                variant="outline"
                onClick={() => navigate("/mlm/simulasyon")}
              >
                <BarChart3 className="w-4 h-4 mr-2" />
                Gelir Simülasyonu
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
