import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Info, Home } from "lucide-react";
import { Link } from "react-router-dom";

export default function Hakkimizda() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/10 to-accent/10 p-4">
      <div className="max-w-4xl mx-auto space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-2xl">
              <Info className="h-6 w-6" />
              Kutbul Zaman Network Hakkında
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <p className="text-muted-foreground">
                Kutbul Zaman Network, network marketing alanında yenilikçi
                çözümler sunan bir platformdur. Amacımız, üyelerimize
                sürdürülebilir gelir imkanları sağlamak ve başarıya giden yolda
                onlara rehberlik etmektir.
              </p>
              <p className="text-muted-foreground">
                Binary MLM sistemi ile dengeli ve adil bir gelir dağıtımı
                sağlayarak, tüm üyelerimizin eşit şartlarda başarıya
                ulaşabilmesini hedefliyoruz.
              </p>
              <Button asChild>
                <Link to="/">
                  <Home className="w-4 h-4 mr-2" />
                  Ana Sayfaya Dön
                </Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
