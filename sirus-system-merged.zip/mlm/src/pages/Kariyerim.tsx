import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { Crown, Home } from "lucide-react";
import { Link } from "react-router-dom";
import { useState, useEffect } from "react";
import { authService } from "../auth/auth-service";
import { User } from "../constants/mlm-types";

export default function Kariyerim() {
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    const currentUser = authService.getCurrentUser();
    if (currentUser) {
      setUser(currentUser);
    }
  }, []);

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Yükleniyor...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-blue-50 p-4">
      <div className="max-w-4xl mx-auto space-y-6">
        <Card className="border-2 border-purple-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-2xl">
              <Crown className="h-6 w-6 text-purple-600" />
              Kariyerim
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="text-center">
                <div className="text-4xl font-bold text-purple-600 mb-2">
                  {user.rank}
                </div>
                <Badge className="bg-purple-100 text-purple-800">
                  {user.referenceNumber === "ak000001" ? "KURUCU" : "Aktif Üye"}
                </Badge>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 bg-purple-50 rounded-lg">
                  <div className="text-sm text-gray-600">Referans No</div>
                  <div className="font-bold text-purple-600">
                    {user.referenceNumber}
                  </div>
                </div>
                <div className="p-4 bg-purple-50 rounded-lg">
                  <div className="text-sm text-gray-600">Toplam Yatırım</div>
                  <div className="font-bold text-purple-600">
                    ${(user.totalInvestment || 0).toLocaleString()}
                  </div>
                </div>
                <div className="p-4 bg-purple-50 rounded-lg">
                  <div className="text-sm text-gray-600">Direkt Referans</div>
                  <div className="font-bold text-purple-600">
                    {user.directReferrals || 0}
                  </div>
                </div>
                <div className="p-4 bg-purple-50 rounded-lg">
                  <div className="text-sm text-gray-600">Toplam Ekip</div>
                  <div className="font-bold text-purple-600">
                    {user.totalDownlineCount || 0}
                  </div>
                </div>
              </div>

              <Button asChild className="w-full">
                <Link to="/dashboard">
                  <Home className="w-4 h-4 mr-2" />
                  Ana Panele Dön
                </Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
