import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "../components/ui/card";
import { Button } from "../components/ui/button";
import { BarChart3, Home } from "lucide-react";
import { Link } from "react-router-dom";

export default function Simulasyon() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-indigo-50 p-4">
      <div className="max-w-4xl mx-auto space-y-6">
        <Card className="text-center">
          <CardHeader>
            <CardTitle className="flex items-center justify-center gap-2 text-2xl">
              <BarChart3 className="h-6 w-6" />
              Kazanç Simülasyonu
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground mb-6">
              Kazanç simülasyon sistemi yakında aktif olacaktır!
            </p>
            <Button asChild>
              <Link to="/dashboard">
                <Home className="w-4 h-4 mr-2" />
                Ana Panele Dön
              </Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
