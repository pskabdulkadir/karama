import { useAuth } from "../auth/AuthContext";
import { Button } from "../components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import {
  Users,
  ShoppingCart,
  TrendingUp,
  Settings,
  BarChart3,
  Shield,
  Database,
  Activity,
} from "lucide-react";

export default function AdminDashboard() {
  const { user } = useAuth();

  const statsCards = [
    {
      title: "Toplam Kullanıcılar",
      value: "1,247",
      change: "+12%",
      icon: Users,
      color: "text-blue-600",
      bgColor: "bg-blue-50",
    },
    {
      title: "Aktif Sistemler",
      value: "4",
      change: "100%",
      icon: Activity,
      color: "text-green-600",
      bgColor: "bg-green-50",
    },
    {
      title: "Aylık Gelir",
      value: "$45,230",
      change: "+8.2%",
      icon: TrendingUp,
      color: "text-emerald-600",
      bgColor: "bg-emerald-50",
    },
    {
      title: "Sistem Durumu",
      value: "Çevrimiçi",
      change: "99.9%",
      icon: Shield,
      color: "text-purple-600",
      bgColor: "bg-purple-50",
    },
  ];

  const systemManagement = [
    {
      title: "Kullanıcı Yönetimi",
      description: "Kullanıcı hesapları ve roller",
      icon: Users,
      path: "/admin/users",
    },
    {
      title: "MLM Sistem Yönetimi",
      description: "Network marketing ayarları",
      icon: TrendingUp,
      path: "/admin/mlm",
    },
    {
      title: "E-ticaret Yönetimi",
      description: "Ürün ve sipariş yönetimi",
      icon: ShoppingCart,
      path: "/admin/shop",
    },
    {
      title: "Sistem Ayarları",
      description: "Genel konfigürasyon",
      icon: Settings,
      path: "/admin/settings",
    },
    {
      title: "Veri Tabanı",
      description: "Veri yönetimi ve backup",
      icon: Database,
      path: "/admin/database",
    },
    {
      title: "Raporlar",
      description: "Analitik ve istatistikler",
      icon: BarChart3,
      path: "/admin/reports",
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-navy-50 via-background to-gold-50 p-6 fade-in">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8 slide-up">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-4xl font-bold text-primary mb-2 brand-font">
                Yönetim Paneli
              </h1>
              <p className="text-lg text-muted-foreground">
                Hoş geldin, {user?.name}
              </p>
            </div>
            <div className="flex items-center gap-4">
              <Badge variant="secondary" className="bg-gold-100 text-gold-800">
                <Shield className="w-4 h-4 mr-1" />
                Admin
              </Badge>
              <Button variant="outline">Sistem Durumu</Button>
            </div>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {statsCards.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <Card
                key={stat.title}
                className="card-kutbul"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">
                        {stat.title}
                      </p>
                      <p className="text-2xl font-bold text-primary">
                        {stat.value}
                      </p>
                      <p className="text-sm text-green-600 mt-1">
                        {stat.change} son ay
                      </p>
                    </div>
                    <div className={`p-3 rounded-xl ${stat.bgColor}`}>
                      <Icon className={`w-6 h-6 ${stat.color}`} />
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* System Management */}
        <Card className="card-kutbul mb-8">
          <CardHeader>
            <CardTitle className="text-2xl brand-font">
              Sistem Yönetimi
            </CardTitle>
            <CardDescription>
              Tüm sistemlerin merkezi yönetim paneli
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {systemManagement.map((system, index) => {
                const Icon = system.icon;
                return (
                  <Card
                    key={system.title}
                    className="cursor-pointer hover:transform hover:scale-105 transition-all duration-200 border-2 hover:border-primary/30"
                    style={{ animationDelay: `${(index + 4) * 100}ms` }}
                  >
                    <CardContent className="p-6 text-center">
                      <div className="inline-flex items-center justify-center w-12 h-12 bg-primary/10 text-primary rounded-xl mb-4">
                        <Icon className="w-6 h-6" />
                      </div>
                      <h3 className="font-semibold text-primary mb-2">
                        {system.title}
                      </h3>
                      <p className="text-sm text-muted-foreground">
                        {system.description}
                      </p>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card className="card-kutbul">
            <CardHeader>
              <CardTitle>Son Aktiviteler</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center gap-3 p-3 bg-green-50 rounded-lg">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <div className="flex-1">
                    <p className="text-sm font-medium">Yeni kullanıcı kaydı</p>
                    <p className="text-xs text-muted-foreground">
                      2 dakika önce
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-3 p-3 bg-blue-50 rounded-lg">
                  <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                  <div className="flex-1">
                    <p className="text-sm font-medium">
                      MLM sistemi güncellendi
                    </p>
                    <p className="text-xs text-muted-foreground">
                      5 dakika önce
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-3 p-3 bg-purple-50 rounded-lg">
                  <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                  <div className="flex-1">
                    <p className="text-sm font-medium">Yeni sipariş alındı</p>
                    <p className="text-xs text-muted-foreground">
                      10 dakika önce
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="card-kutbul">
            <CardHeader>
              <CardTitle>Hızlı İşlemler</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button className="w-full justify-start" variant="outline">
                <Users className="w-4 h-4 mr-2" />
                Yeni Kullanıcı Ekle
              </Button>
              <Button className="w-full justify-start" variant="outline">
                <Settings className="w-4 h-4 mr-2" />
                Sistem Ayarları
              </Button>
              <Button className="w-full justify-start" variant="outline">
                <BarChart3 className="w-4 h-4 mr-2" />
                Rapor Oluştur
              </Button>
              <Button className="w-full justify-start" variant="outline">
                <Database className="w-4 h-4 mr-2" />
                Veri Yedekle
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
