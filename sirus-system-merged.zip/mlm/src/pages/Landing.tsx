import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "../components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "../components/ui/card";
import {
  Users,
  TrendingUp,
  Shield,
  Crown,
  Star,
  DollarSign,
  Network,
  ArrowRight,
  Play,
  Zap,
} from "lucide-react";

export default function Landing() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#2D1E5F]/10 to-[#00A9A5]/10">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-br from-[#2D1E5F] to-[#00A9A5] rounded-lg flex items-center justify-center">
              <Network className="w-6 h-6 text-white" />
            </div>
            <span className="text-2xl font-bold font-['Cinzel'] text-[#2D1E5F]">
              Kutbul Zaman
            </span>
          </div>
          <nav className="hidden md:flex space-x-6">
            <Link
              to="/"
              className="text-[#2D1E5F] hover:text-[#00A9A5] transition-colors"
            >
              Ana Sayfa
            </Link>
            <Link
              to="/hakkimizda"
              className="text-[#2D1E5F] hover:text-[#00A9A5] transition-colors"
            >
              Hakkımızda
            </Link>
            <Button
              onClick={() => navigate("/login")}
              variant="outline"
              className="border-[#2D1E5F] text-[#2D1E5F] hover:bg-[#2D1E5F] hover:text-white"
            >
              Giriş
            </Button>
            <Button
              onClick={() => navigate("/register")}
              className="bg-[#00A9A5] hover:bg-[#008b87] text-white"
            >
              Üye Ol
            </Button>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 text-center">
        <div className="container mx-auto px-4">
          <h1 className="text-5xl md:text-6xl font-bold mb-6 leading-tight">
            <span className="text-[#00A9A5]">Kazandıran sistem,</span>
            <br />
            <span className="text-[#2D1E5F]">sürdürülebilir başarı</span>
          </h1>

          <p className="text-xl text-gray-600 mb-10 max-w-3xl mx-auto leading-relaxed">
            Girişimci ruhu ve takım gücüyle birlikte, binary MLM sisteminin
            sunduğu sınırsız gelir fırsatlarından yararlanın. Başarıya giden
            yolda size öncülük ediyoruz.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button
              onClick={() => navigate("/register")}
              size="lg"
              className="bg-[#00A9A5] hover:bg-[#008b87] text-lg px-8 py-6 rounded-xl"
            >
              <Zap className="w-5 h-5 mr-2" />
              Hemen Başla
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>

            <Button
              variant="outline"
              size="lg"
              className="border-2 border-[#2D1E5F] text-[#2D1E5F] text-lg px-8 py-6 hover:bg-[#2D1E5F] hover:text-white rounded-xl"
            >
              <Play className="w-5 h-5 mr-2" />
              Tanıtım Videosu
            </Button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white/50">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold text-center mb-16 text-[#2D1E5F]">
            Neden Kutbul Zaman Network?
          </h2>

          <div className="grid md:grid-cols-3 gap-8">
            <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow rounded-xl">
              <CardHeader className="text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-[#2D1E5F] to-[#00A9A5] rounded-full flex items-center justify-center mx-auto mb-4">
                  <TrendingUp className="w-8 h-8 text-white" />
                </div>
                <CardTitle className="text-[#2D1E5F]">
                  Sürdürülebilir Kazanç
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 text-center">
                  Binary sistem ile dengeli ve sürekli gelir akışı sağlayın.
                  Pasif gelir elde etmenin en etkili yolu.
                </p>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow rounded-xl">
              <CardHeader className="text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-[#2D1E5F] to-[#00A9A5] rounded-full flex items-center justify-center mx-auto mb-4">
                  <Shield className="w-8 h-8 text-white" />
                </div>
                <CardTitle className="text-[#2D1E5F]">
                  Güvenilir Sistem
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 text-center">
                  Şeffaf işlemler ve güvenli altyapı ile her adımda
                  yanınızdayız. Güvenilir bir gelecek inşa edin.
                </p>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow rounded-xl">
              <CardHeader className="text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-[#2D1E5F] to-[#00A9A5] rounded-full flex items-center justify-center mx-auto mb-4">
                  <Crown className="w-8 h-8 text-white" />
                </div>
                <CardTitle className="text-[#2D1E5F]">
                  Liderlik Gelişimi
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 text-center">
                  Kişisel gelişim programları ve liderlik eğitimleri ile
                  potansiyelinizi maksimize edin.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold text-[#00A9A5] mb-2">
                12,847
              </div>
              <div className="text-gray-600">Aktif Üye</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-[#00A9A5] mb-2">
                ₺8.5M
              </div>
              <div className="text-gray-600">Toplam Kazanç</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-[#00A9A5] mb-2">94%</div>
              <div className="text-gray-600">Başarı Oranı</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-[#00A9A5] mb-2">23</div>
              <div className="text-gray-600">Ülke</div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-[#2D1E5F] to-[#00A9A5] text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold mb-6">
            Başarı Yolculuğunuza Bugün Başlayın
          </h2>
          <p className="text-xl mb-8 opacity-90">
            Kutbul Zaman Network ailesine katılın ve finansal özgürlüğünüze
            giden yolda ilk adımı atın.
          </p>
          <Button
            onClick={() => navigate("/register")}
            size="lg"
            className="bg-white text-[#2D1E5F] hover:bg-gray-100 text-lg px-8 py-6 rounded-xl"
          >
            <Star className="w-5 h-5 mr-2" />
            Hemen Üye Ol
            <ArrowRight className="w-5 h-5 ml-2" />
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#2D1E5F] text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-8 h-8 bg-gradient-to-br from-white to-[#00A9A5] rounded-lg flex items-center justify-center">
                  <Network className="w-5 h-5 text-[#2D1E5F]" />
                </div>
                <span className="text-xl font-bold font-['Cinzel']">
                  Kutbul Zaman
                </span>
              </div>
              <p className="text-gray-300 text-sm">
                Birlikte büyüyelim, birlikte kazanalım. Sürdürülebilir başarının
                adresi.
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Hızlı Bağlantılar</h3>
              <ul className="space-y-2 text-sm text-gray-300">
                <li>
                  <Link to="/hakkimizda" className="hover:text-[#00A9A5]">
                    Hakkımızda
                  </Link>
                </li>
                <li>
                  <Link to="/login" className="hover:text-[#00A9A5]">
                    Giriş Yap
                  </Link>
                </li>
                <li>
                  <Link to="/register" className="hover:text-[#00A9A5]">
                    Üye Ol
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Destek</h3>
              <ul className="space-y-2 text-sm text-gray-300">
                <li>
                  <a
                    href="mailto:info@kutbulzaman.com"
                    className="hover:text-[#00A9A5]"
                  >
                    info@kutbulzaman.com
                  </a>
                </li>
                <li>
                  <a href="tel:+90555123456" className="hover:text-[#00A9A5]">
                    +90 555 123 45 67
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Sosyal Medya</h3>
              <div className="flex space-x-4">
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-gray-300 hover:text-[#00A9A5]"
                >
                  Facebook
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-gray-300 hover:text-[#00A9A5]"
                >
                  Instagram
                </Button>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-800 pt-8 mt-8">
            <p className="text-gray-500 text-center">
              © 2024 Kutbul Zaman Network. Tüm hakları saklıdır.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
