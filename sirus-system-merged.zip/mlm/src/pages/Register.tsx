import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "../components/ui/card";
import { UserPlus, Users, AlertCircle } from "lucide-react";
import { useAuth } from "../auth/AuthContext";

export default function Register() {
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    password: "",
    confirmPassword: "",
    sponsorCode: "ak000001", // Varsayılan sponsor: Abdulkadir Kan (Kurucu)
  });
  const [error, setError] = useState("");
  const navigate = useNavigate();
  const { register, isLoading, isAuthenticated, user } = useAuth();

  useEffect(() => {
    if (isAuthenticated && user) {
      // Redirect based on user role
      if (user.role === "admin" || user.role === "mlm") {
        navigate("/panel/dashboard");
      } else {
        navigate("/dashboard");
      }
    }
  }, [isAuthenticated, user, navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (formData.password !== formData.confirmPassword) {
      setError("Şifreler eşleşmiyor!");
      return;
    }

    if (formData.password.length < 6) {
      setError("Şifre en az 6 karakter olmalıdır!");
      return;
    }

    const success = await register({
      email: formData.email,
      password: formData.password,
      fullName: formData.fullName,
      sponsorCode: formData.sponsorCode,
    });

    if (!success) {
      setError("Kayıt işlemi başarısız. Bu email zaten kullanımda olabilir.");
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/10 via-background to-accent/10 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-primary text-primary-foreground rounded-full mb-4">
            <Users className="w-8 h-8" />
          </div>
          <h1 className="text-3xl font-bold text-primary mb-2">
            kutbulzaman panel
          </h1>
          <p className="text-muted-foreground">Yeni hesap oluşturun</p>
        </div>

        <Card className="border-2 border-primary/20 shadow-xl">
          <CardHeader>
            <CardTitle className="text-2xl text-center text-primary">
              Üye Ol
            </CardTitle>
            <CardDescription className="text-center">
              Kutbul Zaman Network ailesine katılın
            </CardDescription>
          </CardHeader>
          <form onSubmit={handleSubmit}>
            <CardContent className="space-y-4">
              {error && (
                <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2">
                  <AlertCircle className="h-4 w-4 text-red-600" />
                  <span className="text-red-700 text-sm">{error}</span>
                </div>
              )}
              <div className="space-y-2">
                <Label htmlFor="fullName">Ad Soyad</Label>
                <Input
                  id="fullName"
                  name="fullName"
                  type="text"
                  placeholder="Adınızı ve soyadınızı girin"
                  value={formData.fullName}
                  onChange={handleInputChange}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">E-posta</Label>
                <Input
                  id="email"
                  name="email"
                  type="email"
                  placeholder="E-posta adresinizi girin"
                  value={formData.email}
                  onChange={handleInputChange}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="sponsorCode">
                  Sponsor Kodu (Varsayılan: Kurucu)
                </Label>
                <Input
                  id="sponsorCode"
                  name="sponsorCode"
                  type="text"
                  placeholder="ak000001 (Abdulkadir Kan - Kurucu)"
                  value={formData.sponsorCode}
                  onChange={handleInputChange}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">Şifre</Label>
                <Input
                  id="password"
                  name="password"
                  type="password"
                  placeholder="Güçlü bir şifre oluşturun"
                  value={formData.password}
                  onChange={handleInputChange}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="confirmPassword">Şifre Tekrar</Label>
                <Input
                  id="confirmPassword"
                  name="confirmPassword"
                  type="password"
                  placeholder="Şifrenizi tekrar girin"
                  value={formData.confirmPassword}
                  onChange={handleInputChange}
                  required
                />
              </div>

              <Button
                type="submit"
                className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-semibold py-6"
                disabled={isLoading}
              >
                {isLoading ? (
                  <div className="flex items-center space-x-2">
                    <UserPlus className="w-4 h-4 animate-spin" />
                    <span>Kayıt yapılıyor...</span>
                  </div>
                ) : (
                  <div className="flex items-center space-x-2">
                    <UserPlus className="w-4 h-4" />
                    <span>Üye Ol</span>
                  </div>
                )}
              </Button>

              <div className="text-center text-sm">
                <span className="text-muted-foreground">
                  Zaten hesabınız var mı?{" "}
                </span>
                <Link
                  to="/login"
                  className="text-accent hover:text-accent/80 font-medium"
                >
                  Giriş Yap
                </Link>
              </div>
            </CardContent>
          </form>
        </Card>
      </div>
    </div>
  );
}
