import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Award, Home } from "lucide-react";
import { Link } from "react-router-dom";

export default function Bonuslar() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 p-4">
      <div className="max-w-4xl mx-auto space-y-6">
        <Card className="text-center">
          <CardHeader>
            <CardTitle className="flex items-center justify-center gap-2 text-2xl">
              <Award className="h-6 w-6" />
              Bonuslarım
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground mb-6">
              Bonus sistemi ve gelir takibi yakında aktif olacaktır!
            </p>
            <Button asChild>
              <Link to="/dashboard">
                <Home className="w-4 h-4 mr-2" />
                Ana Panele Dön
              </Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
