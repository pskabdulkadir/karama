import { Routes, Route } from "react-router-dom";
import { ProtectedRoute } from "../components/auth/ProtectedRoute";

// Public pages
import Index from "../pages/Index";
import Landing from "../pages/Landing";
import Login from "../pages/Login";
import Register from "../pages/Register";
import Unauthorized from "../pages/Unauthorized";
import NotFound from "../pages/NotFound";

// System pages
import Portal from "../pages/Portal";
import Dashboard from "../pages/Dashboard";
import AdminDashboard from "../pages/AdminDashboard";
import MLMSystem from "../pages/MLMSystem";
import Shop from "../pages/Shop";
import SelfDevelopment from "../pages/SelfDevelopment";

// Legacy/compatibility pages
import Alisveris from "../pages/Alisveris";
import Gelisim from "../pages/Gelisim";
import Hakkimizda from "../pages/Hakkimizda";

// MLM specific pages
import Kariyerim from "../pages/Kariyerim";
import Bonuslar from "../pages/Bonuslar";
import YatirimYap from "../pages/YatirimYap";
import Simulasyon from "../pages/Simulasyon";

export default function AppRoutes() {
  return (
    <Routes>
      {/* Public routes */}
      <Route path="/" element={<Index />} />
      <Route path="/landing" element={<Landing />} />
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/unauthorized" element={<Unauthorized />} />

      {/* Legacy public routes (compatibility) */}
      <Route path="/alisveris" element={<Alisveris />} />
      <Route path="/gelisim" element={<Gelisim />} />
      <Route path="/hakkimizda" element={<Hakkimizda />} />

      {/* Central Portal */}
      <Route path="/portal" element={<Portal />} />

      {/* System Routes - New Convention */}

      {/* /panel → Ortak kullanıcı paneli */}
      <Route
        path="/panel"
        element={
          <ProtectedRoute>
            <Dashboard />
          </ProtectedRoute>
        }
      />
      <Route
        path="/panel/*"
        element={
          <ProtectedRoute allowedRoles={["admin", "mlm", "user"]}>
            <Routes>
              <Route index element={<Dashboard />} />
              <Route path="dashboard" element={<Dashboard />} />
              <Route path="kariyerim" element={<Kariyerim />} />
              <Route path="bonuslar" element={<Bonuslar />} />
              <Route path="yatirim-yap" element={<YatirimYap />} />
              <Route path="simulasyon" element={<Simulasyon />} />
            </Routes>
          </ProtectedRoute>
        }
      />

      {/* /mlm → Network sistemi */}
      <Route
        path="/mlm"
        element={
          <ProtectedRoute allowedRoles={["admin", "mlm", "user"]}>
            <MLMSystem />
          </ProtectedRoute>
        }
      />
      <Route
        path="/mlm/*"
        element={
          <ProtectedRoute allowedRoles={["admin", "mlm", "user"]}>
            <Routes>
              <Route index element={<MLMSystem />} />
              <Route path="dashboard" element={<MLMSystem />} />
              <Route path="kariyerim" element={<Kariyerim />} />
              <Route path="bonuslar" element={<Bonuslar />} />
              <Route path="yatirim-yap" element={<YatirimYap />} />
              <Route path="simulasyon" element={<Simulasyon />} />
              <Route path="takim" element={<Dashboard />} />
              <Route path="hedefler" element={<Dashboard />} />
            </Routes>
          </ProtectedRoute>
        }
      />

      {/* /shop → Alışveriş sayfası */}
      <Route
        path="/shop"
        element={
          <ProtectedRoute allowedRoles={["admin", "merchant", "user"]}>
            <Shop />
          </ProtectedRoute>
        }
      />
      <Route
        path="/shop/*"
        element={
          <ProtectedRoute allowedRoles={["admin", "merchant", "user"]}>
            <Routes>
              <Route index element={<Shop />} />
              <Route path="products" element={<Shop />} />
              <Route path="orders" element={<Shop />} />
              <Route path="cart" element={<Shop />} />
            </Routes>
          </ProtectedRoute>
        }
      />

      {/* /self → Kişisel gelişim */}
      <Route
        path="/self"
        element={
          <ProtectedRoute allowedRoles={["admin", "psychologist", "user"]}>
            <SelfDevelopment />
          </ProtectedRoute>
        }
      />
      <Route
        path="/self/*"
        element={
          <ProtectedRoute allowedRoles={["admin", "psychologist", "user"]}>
            <Routes>
              <Route index element={<SelfDevelopment />} />
              <Route path="courses" element={<SelfDevelopment />} />
              <Route path="sessions" element={<SelfDevelopment />} />
              <Route path="progress" element={<SelfDevelopment />} />
            </Routes>
          </ProtectedRoute>
        }
      />

      {/* /admin → Yöneticiler için giriş ve yönetim */}
      <Route
        path="/admin"
        element={
          <ProtectedRoute allowedRoles={["admin"]}>
            <AdminDashboard />
          </ProtectedRoute>
        }
      />
      <Route
        path="/admin/*"
        element={
          <ProtectedRoute allowedRoles={["admin"]}>
            <Routes>
              <Route index element={<AdminDashboard />} />
              <Route path="dashboard" element={<AdminDashboard />} />
              <Route path="users" element={<AdminDashboard />} />
              <Route path="mlm" element={<AdminDashboard />} />
              <Route path="shop" element={<AdminDashboard />} />
              <Route path="settings" element={<AdminDashboard />} />
              <Route path="database" element={<AdminDashboard />} />
              <Route path="reports" element={<AdminDashboard />} />
            </Routes>
          </ProtectedRoute>
        }
      />

      {/* Legacy routes for backward compatibility */}
      <Route
        path="/dashboard"
        element={
          <ProtectedRoute>
            <Dashboard />
          </ProtectedRoute>
        }
      />

      {/* 404 - Not Found */}
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}
