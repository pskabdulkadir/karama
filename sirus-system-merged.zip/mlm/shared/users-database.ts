import { User } from "./mlm-types";

export const INITIAL_USERS: User[] = [
  {
    id: "ak000001",
    username: "abdulkadirkqn",
    name: "Abdulkadir Kan",
    email: "abdulkadirkqn@gmail.com",
    password: "Abdulkadir1983",
    referenceNumber: "ak000001",
    role: "admin",
    sponsorId: undefined, // Kurucu - sponsor yok
    sponsorReferenceNumber: undefined,
    joinDate: "2024-01-01T00:00:00Z",
    rank: "Safiye",
    isActive: true,
    activityStatus: "active",
    lastActivityPayment: "2024-03-01",
    annualPayment: true,
    entryPaymentCompleted: true,
    personalVolume: 50000,
    groupVolume: 1250000,
    leftLegVolume: 625000,
    rightLegVolume: 625000,
    totalDownlineCount: 127,
    directReferrals: 25,
    leaderCount: 8,
    totalInvestment: 50000,
    activeIncome: 12500,
    passiveIncome: 5200,
    sponsorIncome: 2850,
    totalEarnings: 20550,
  },
];

export function generateReferenceNumber(): string {
  // Get next reference number (starting from ak000002 since ak000001 is founder)
  const existingUsers = INITIAL_USERS.length;
  const nextNumber = (existingUsers + 1).toString().padStart(6, "0");
  return `ak${nextNumber}`;
}

export function findUserByCredentials(
  username: string,
  password: string,
): User | null {
  return (
    INITIAL_USERS.find(
      (user) => user.username === username && user.password === password,
    ) || null
  );
}

export function findUserByReferenceNumber(refNumber: string): User | null {
  return (
    INITIAL_USERS.find((user) => user.referenceNumber === refNumber) || null
  );
}

export function addNewUser(userData: Partial<User>): User {
  const newUser: User = {
    id: generateReferenceNumber(),
    referenceNumber: generateReferenceNumber(),
    username: userData.username || "",
    name: userData.name || "",
    email: userData.email || "",
    password: userData.password || "",
    role: "user",
    sponsorId: userData.sponsorId || "ak000001", // Varsayılan sponsor: Abdulkadir Kan
    sponsorReferenceNumber: userData.sponsorReferenceNumber || "ak000001",
    joinDate: new Date().toISOString(),
    rank: "Emmare",
    isActive: false,
    activityStatus: "pending",
    annualPayment: false,
    entryPaymentCompleted: false,
    personalVolume: 0,
    groupVolume: 0,
    leftLegVolume: 0,
    rightLegVolume: 0,
    totalDownlineCount: 0,
    directReferrals: 0,
    leaderCount: 0,
    totalInvestment: 0,
    activeIncome: 0,
    passiveIncome: 0,
    sponsorIncome: 0,
    totalEarnings: 0,
  };

  INITIAL_USERS.push(newUser);
  return newUser;
}
