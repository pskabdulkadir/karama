import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import {
  Menu,
  X,
  MessageCircle,
  User,
  Bell,
  LogOut,
  Home,
  Info,
} from "lucide-react";
import { Link, useLocation } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";

interface HeaderProps {
  onNavigate?: (section: string) => void;
}

export function Header({ onNavigate }: HeaderProps) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [notificationCount] = useState(3); // Mock notification count
  const location = useLocation();
  const { user, isAuthenticated, logout } = useAuth();

  const openWhatsApp = () => {
    const phoneNumber = "+905551234567";
    const message = encodeURIComponent(
      "Merhaba! Kutbu'l Zaman hizmetleri hakkında bilgi almak istiyorum.",
    );
    window.open(`https://wa.me/${phoneNumber}?text=${message}`, "_blank");
  };

  // Close mobile menu when clicking outside
  useEffect(() => {
    const handleClickOutside = () => {
      setIsMobileMenuOpen(false);
    };
    if (isMobileMenuOpen) {
      document.addEventListener("click", handleClickOutside);
      return () => document.removeEventListener("click", handleClickOutside);
    }
  }, [isMobileMenuOpen]);

  const handleLogout = () => {
    logout();
    setIsMobileMenuOpen(false);
  };

  const isHomePage = location.pathname === "/";
  const isKutbulZamanPage = location.pathname === "/kutbulzaman";

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-sm border-b border-brand-gray shadow-sm">
      <div className="max-w-6xl mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link
            to={isKutbulZamanPage ? "/kutbulzaman" : "/"}
            className="mystical-logo brand-text-gradient text-2xl"
          >
            Kutbu'l Zaman
          </Link>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center gap-6">
            {!isAuthenticated ? (
              // Not logged in navigation
              <>
                <Link
                  to="/"
                  className="text-brand-purple/80 hover:text-brand-purple transition-colors flex items-center gap-2"
                >
                  <Home className="w-4 h-4" />
                  Ana Sayfa
                </Link>
                {isHomePage && onNavigate && (
                  <button
                    onClick={() => onNavigate("about")}
                    className="text-brand-purple/80 hover:text-brand-purple transition-colors flex items-center gap-2"
                  >
                    <Info className="w-4 h-4" />
                    Hakkımızda
                  </button>
                )}
                <Link
                  to="/giris"
                  className="text-brand-purple/80 hover:text-brand-purple transition-colors"
                >
                  Giriş
                </Link>
                <Link
                  to="/uye-ol"
                  className="text-brand-purple/80 hover:text-brand-purple transition-colors"
                >
                  Üye Ol
                </Link>
              </>
            ) : (
              // Logged in navigation
              <>
                <Link
                  to="/profil"
                  className="text-brand-purple/80 hover:text-brand-purple transition-colors flex items-center gap-2"
                >
                  <User className="w-4 h-4" />
                  Profilim
                </Link>
                <Link
                  to="/bildirimler"
                  className="text-brand-purple/80 hover:text-brand-purple transition-colors flex items-center gap-2 relative"
                >
                  <Bell className="w-4 h-4" />
                  Bildirimler
                  {notificationCount > 0 && (
                    <Badge className="absolute -top-2 -right-2 h-5 w-5 flex items-center justify-center text-xs bg-brand-teal text-white p-0">
                      {notificationCount}
                    </Badge>
                  )}
                </Link>
                <button
                  onClick={handleLogout}
                  className="text-brand-purple/80 hover:text-brand-purple transition-colors flex items-center gap-2"
                >
                  <LogOut className="w-4 h-4" />
                  Çıkış
                </button>
              </>
            )}
          </div>

          {/* Desktop Action Area */}
          <div className="hidden md:flex items-center gap-3">
            <Button onClick={openWhatsApp} size="sm" className="brand-button">
              <MessageCircle className="w-4 h-4 mr-2" />
              WhatsApp
            </Button>

            {isAuthenticated && user && (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="h-8 w-8 rounded-full">
                    <Avatar className="h-8 w-8">
                      <AvatarImage src={user.avatar} alt={user.name} />
                      <AvatarFallback className="bg-brand-purple text-white">
                        {user.name.charAt(0)}
                      </AvatarFallback>
                    </Avatar>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-56 brand-card" align="end">
                  <DropdownMenuLabel className="font-normal">
                    <div className="flex flex-col space-y-1">
                      <p className="text-sm font-medium leading-none text-brand-purple">
                        {user.name}
                      </p>
                      <p className="text-xs leading-none text-muted-foreground">
                        {user.email}
                      </p>
                    </div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link to="/profil" className="cursor-pointer">
                      <User className="mr-2 h-4 w-4" />
                      Profilim
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link to="/bildirimler" className="cursor-pointer">
                      <Bell className="mr-2 h-4 w-4" />
                      Bildirimler
                      {notificationCount > 0 && (
                        <Badge className="ml-auto h-5 w-5 flex items-center justify-center text-xs bg-brand-teal text-white p-0">
                          {notificationCount}
                        </Badge>
                      )}
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout}>
                    <LogOut className="mr-2 h-4 w-4" />
                    Çıkış
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            )}
          </div>

          {/* Mobile Menu Button */}
          <Button
            onClick={(e) => {
              e.stopPropagation();
              setIsMobileMenuOpen(!isMobileMenuOpen);
            }}
            variant="outline"
            size="sm"
            className="md:hidden border-brand-gray"
          >
            {isMobileMenuOpen ? (
              <X className="w-4 h-4" />
            ) : (
              <Menu className="w-4 h-4" />
            )}
          </Button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-white border-t border-brand-gray shadow-lg">
          <div className="px-4 py-4 space-y-4">
            {!isAuthenticated ? (
              // Not logged in mobile navigation
              <>
                <Link
                  to="/"
                  className="block text-brand-purple/80 hover:text-brand-purple transition-colors py-2 flex items-center gap-2"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  <Home className="w-4 h-4" />
                  Ana Sayfa
                </Link>
                {isHomePage && onNavigate && (
                  <button
                    onClick={() => {
                      onNavigate("about");
                      setIsMobileMenuOpen(false);
                    }}
                    className="block w-full text-left text-brand-purple/80 hover:text-brand-purple transition-colors py-2 flex items-center gap-2"
                  >
                    <Info className="w-4 h-4" />
                    Hakkımızda
                  </button>
                )}
                <Link
                  to="/giris"
                  className="block text-brand-purple/80 hover:text-brand-purple transition-colors py-2"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  Giriş
                </Link>
                <Link
                  to="/uye-ol"
                  className="block text-brand-purple/80 hover:text-brand-purple transition-colors py-2"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  Üye Ol
                </Link>
              </>
            ) : (
              // Logged in mobile navigation
              <>
                {user && (
                  <div className="border-b border-brand-gray pb-4 mb-4">
                    <div className="flex items-center gap-3">
                      <Avatar className="h-10 w-10">
                        <AvatarImage src={user.avatar} alt={user.name} />
                        <AvatarFallback className="bg-brand-purple text-white">
                          {user.name.charAt(0)}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium text-brand-purple">
                          {user.name}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          {user.email}
                        </p>
                      </div>
                    </div>
                  </div>
                )}
                <Link
                  to="/profil"
                  className="block text-brand-purple/80 hover:text-brand-purple transition-colors py-2 flex items-center gap-2"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  <User className="w-4 h-4" />
                  Profilim
                </Link>
                <Link
                  to="/bildirimler"
                  className="block text-brand-purple/80 hover:text-brand-purple transition-colors py-2 flex items-center gap-2"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  <Bell className="w-4 h-4" />
                  Bildirimler
                  {notificationCount > 0 && (
                    <Badge className="ml-2 h-5 w-5 flex items-center justify-center text-xs bg-brand-teal text-white p-0">
                      {notificationCount}
                    </Badge>
                  )}
                </Link>
                <button
                  onClick={handleLogout}
                  className="block w-full text-left text-brand-purple/80 hover:text-brand-purple transition-colors py-2 flex items-center gap-2"
                >
                  <LogOut className="w-4 h-4" />
                  Çıkış
                </button>
              </>
            )}

            <div className="border-t border-brand-gray pt-4">
              <Button
                onClick={() => {
                  openWhatsApp();
                  setIsMobileMenuOpen(false);
                }}
                size="sm"
                className="w-full brand-button"
              >
                <MessageCircle className="w-4 h-4 mr-2" />
                WhatsApp
              </Button>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}
