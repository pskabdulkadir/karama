import { Button } from "@/components/ui/button";
import {
  Instagram,
  Facebook,
  Youtube,
  Phone,
  Mail,
  MapPin,
} from "lucide-react";
import { Link, useLocation } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";

export function Footer() {
  const { toast } = useToast();
  const location = useLocation();

  const openInstagram = () => {
    window.open("https://instagram.com/kutbulzaman", "_blank");
  };

  const openYoutube = () => {
    window.open("https://youtube.com/@kutbulzaman", "_blank");
  };

  const openFacebook = () => {
    window.open("https://facebook.com/kutbulzaman", "_blank");
  };

  const makePhoneCall = () => {
    window.location.href = "tel:+905551234567";
  };

  const sendEmail = () => {
    window.location.href =
      "mailto:info@kutbulzaman.com?subject=Danışmanlık Talebi";
  };

  const isKutbulZamanPage = location.pathname === "/kutbulzaman";

  return (
    <footer className="bg-mystical-navy/40 py-12 px-4 border-t border-mystical-purple/30">
      <div className="max-w-6xl mx-auto">
        <div className="grid md:grid-cols-4 gap-8 mb-8">
          {/* Brand */}
          <div className="space-y-4">
            <h3 className="text-2xl font-bold mystical-text-gradient">
              {isKutbulZamanPage ? "Kutbu'l Zaman" : "Farkındalık Terapi"}
            </h3>
            <p className="text-mystical-white/70 text-sm">
              {isKutbulZamanPage
                ? "Manevi gelişim ve danışmanlık hizmetlerinde uzman kadro ile yanınızdayız."
                : "Zihinsel, duygusal ve ruhsal dönüşümde yanınızdayız"}
            </p>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h4 className="text-lg font-semibold text-mystical-white">
              Hızlı Bağlantılar
            </h4>
            <div className="space-y-2">
              <Link
                to="/"
                className="block text-mystical-white/70 hover:text-mystical-purple transition-colors text-sm"
              >
                Ana Sayfa
              </Link>
              <Link
                to="/kutbulzaman"
                className="block text-mystical-white/70 hover:text-mystical-purple transition-colors text-sm"
              >
                Kutbu'l Zaman
              </Link>
              <Link
                to="/giris"
                className="block text-mystical-white/70 hover:text-mystical-purple transition-colors text-sm"
              >
                MLM Panel Giriş
              </Link>
              <button
                onClick={() =>
                  toast({
                    title: "Blog",
                    description: "Blog sayfası yakında aktif olacak!",
                  })
                }
                className="block text-mystical-white/70 hover:text-mystical-purple transition-colors text-sm text-left"
              >
                Blog
              </button>
            </div>
          </div>

          {/* Services */}
          <div className="space-y-4">
            <h4 className="text-lg font-semibold text-mystical-white">
              Hizmetlerimiz
            </h4>
            <div className="space-y-2 text-sm text-mystical-white/70">
              <p>Psikolojik Danışmanlık</p>
              <p>Aile Dizimi</p>
              <p>Kuantum Koçluk</p>
              <p>Manevi Rehberlik</p>
              <p>Eğitim Programları</p>
            </div>
          </div>

          {/* Contact */}
          <div className="space-y-4">
            <h4 className="text-lg font-semibold text-mystical-white">
              İletişim
            </h4>
            <div className="space-y-3">
              <button
                onClick={makePhoneCall}
                className="flex items-center gap-2 text-mystical-white/70 hover:text-mystical-purple transition-colors text-sm"
              >
                <Phone className="w-4 h-4" />
                +90 (555) 123 45 67
              </button>
              <button
                onClick={sendEmail}
                className="flex items-center gap-2 text-mystical-white/70 hover:text-mystical-purple transition-colors text-sm"
              >
                <Mail className="w-4 h-4" />
                info@kutbulzaman.com
              </button>
              <div className="flex items-center gap-2 text-mystical-white/70 text-sm">
                <MapPin className="w-4 h-4" />
                <span>Atatürk Mah. Barış Sok. No:15/3</span>
              </div>
            </div>
          </div>
        </div>

        {/* Social Media & Bottom */}
        <div className="border-t border-mystical-purple/30 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="flex gap-4">
              <Button
                size="icon"
                variant="outline"
                className="border-mystical-purple text-mystical-purple hover:bg-mystical-purple hover:text-white"
                onClick={openInstagram}
              >
                <Instagram className="w-4 h-4" />
              </Button>
              <Button
                size="icon"
                variant="outline"
                className="border-mystical-purple text-mystical-purple hover:bg-mystical-purple hover:text-white"
                onClick={openYoutube}
              >
                <Youtube className="w-4 h-4" />
              </Button>
              <Button
                size="icon"
                variant="outline"
                className="border-mystical-purple text-mystical-purple hover:bg-mystical-purple hover:text-white"
                onClick={openFacebook}
              >
                <Facebook className="w-4 h-4" />
              </Button>
            </div>

            <div className="flex flex-wrap justify-center md:justify-end gap-6 text-sm text-mystical-white/60">
              <span>© 2024 Tüm hakları saklıdır.</span>
              <button
                className="hover:text-mystical-purple transition-colors"
                onClick={() =>
                  toast({
                    title: "Gizlilik Politikası",
                    description: "Yakında eklenecek!",
                  })
                }
              >
                Gizlilik Politikası
              </button>
              <button
                className="hover:text-mystical-purple transition-colors"
                onClick={() =>
                  toast({
                    title: "Kullanım Şartları",
                    description: "Yakında eklenecek!",
                  })
                }
              >
                Kullanım Şartları
              </button>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
