import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Link, useNavigate } from "react-router-dom";
import { LogIn, ArrowLeft, User, Lock, Eye, EyeOff } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";

export default function Login() {
  const [formData, setFormData] = useState({
    email: "",
    password: "",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const { toast } = useToast();
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.email || !formData.password) {
      toast({
        title: "Hata",
        description: "Lütfen e-posta ve şifrenizi girin.",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);

    try {
      const success = await login(formData.email, formData.password);

      if (success) {
        toast({
          title: "Başarılı!",
          description: "Hoş geldiniz!",
        });
        navigate("/");
      } else {
        toast({
          title: "Hata",
          description: "E-posta veya şifre hatalı.",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Hata",
        description: "Bir hata oluştu. Lütfen tekrar deneyin.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-white flex items-center justify-center px-4 py-20">
      <div className="w-full max-w-md">
        {/* Back Button */}
        <div className="mb-6">
          <Link
            to="/"
            className="inline-flex items-center text-brand-purple/80 hover:text-brand-purple transition-colors"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Ana Sayfaya Dön
          </Link>
        </div>

        <Card className="brand-card">
          <CardHeader className="text-center">
            <div className="w-16 h-16 bg-brand-teal/10 rounded-xl flex items-center justify-center mx-auto mb-4">
              <LogIn className="w-8 h-8 text-brand-teal" />
            </div>
            <CardTitle className="text-2xl text-brand-purple">
              Giriş Yap
            </CardTitle>
            <p className="text-muted-foreground">
              Kutbu'l Zaman hesabınıza giriş yapın
            </p>
          </CardHeader>

          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-brand-purple mb-2 font-medium text-sm">
                  E-posta
                </label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    type="email"
                    value={formData.email}
                    onChange={(e) =>
                      setFormData({ ...formData, email: e.target.value })
                    }
                    className="brand-input pl-10"
                    placeholder="E-posta adresinizi girin"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-brand-purple mb-2 font-medium text-sm">
                  Şifre
                </label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    type={showPassword ? "text" : "password"}
                    value={formData.password}
                    onChange={(e) =>
                      setFormData({ ...formData, password: e.target.value })
                    }
                    className="brand-input pl-10 pr-10"
                    placeholder="Şifrenizi girin"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground hover:text-brand-purple"
                  >
                    {showPassword ? (
                      <EyeOff className="w-4 h-4" />
                    ) : (
                      <Eye className="w-4 h-4" />
                    )}
                  </button>
                </div>
              </div>

              <Button
                type="submit"
                disabled={isSubmitting}
                className="w-full brand-button"
              >
                {isSubmitting ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2"></div>
                    Giriş Yapılıyor...
                  </>
                ) : (
                  <>
                    <LogIn className="w-4 h-4 mr-2" />
                    Giriş Yap
                  </>
                )}
              </Button>

              <div className="text-center space-y-4">
                <p className="text-muted-foreground text-sm">
                  Hesabınız yok mu?{" "}
                  <Link
                    to="/uye-ol"
                    className="text-brand-teal hover:underline font-medium"
                  >
                    Üye olun
                  </Link>
                </p>

                <p className="text-muted-foreground text-sm">
                  <button
                    type="button"
                    onClick={() =>
                      toast({
                        title: "Şifre Sıfırlama",
                        description:
                          "Şifre sıfırlama için destek ekibiyle ileti��ime geçin.",
                      })
                    }
                    className="text-brand-teal hover:underline"
                  >
                    Şifremi Unuttum
                  </button>
                </p>
              </div>
            </form>

            {/* Demo Credentials */}
            <div className="mt-6 p-4 bg-brand-teal/5 rounded-xl border border-brand-gray">
              <h4 className="text-brand-purple font-medium mb-2 text-sm">
                Demo Giriş:
              </h4>
              <p className="text-muted-foreground text-sm">
                E-posta:{" "}
                <code className="text-brand-teal font-mono">
                  demo@kutbulzaman.com
                </code>
              </p>
              <p className="text-muted-foreground text-sm">
                Şifre:{" "}
                <code className="text-brand-teal font-mono">demo123</code>
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Links */}
        <div className="mt-6 text-center space-y-2">
          <Link
            to="/kutbulzaman"
            className="block text-muted-foreground hover:text-brand-purple transition-colors text-sm"
          >
            Kutbu'l Zaman Sayfası
          </Link>
          <p className="text-muted-foreground text-xs">
            © 2024 Kutbu'l Zaman. Tüm hakları saklıdır.
          </p>
        </div>
      </div>
    </div>
  );
}
