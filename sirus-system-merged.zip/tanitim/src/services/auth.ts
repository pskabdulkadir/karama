import { LoginCredentials, RegisterData, User, UserRole } from "../auth/types";

interface AuthResponse {
  success: boolean;
  user?: User;
  token?: string;
  error?: string;
}

interface TokenValidationResponse {
  valid: boolean;
  user?: User;
  error?: string;
}

class AuthService {
  private baseUrl = "/api/auth";

  // Demo users with different roles for testing
  private demoUsers = [
    {
      id: "1",
      userId: "1", // for backward compatibility
      name: "Demo Kullanıcı",
      fullName: "Demo Kullanıcı", // for backward compatibility
      email: "demo@kutbulzaman.com",
      role: "user" as UserRole,
      isActive: true,
      password: "demo123",
      avatar:
        "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face&auto=format&q=80",
    },
    {
      id: "2",
      userId: "2", // for backward compatibility
      name: "Admin Kullanıcı",
      fullName: "Admin Kullanıcı", // for backward compatibility
      email: "admin@kutbulzaman.com",
      role: "admin" as UserRole,
      isActive: true,
      password: "admin123",
      avatar:
        "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face&auto=format&q=80",
    },
    {
      id: "3",
      userId: "3", // for backward compatibility
      name: "MLM Üyesi",
      fullName: "MLM Üyesi", // for backward compatibility
      email: "mlm@kutbulzaman.com",
      role: "mlm" as UserRole,
      isActive: true,
      password: "mlm123",
      avatar:
        "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop&crop=face&auto=format&q=80",
    },
    {
      id: "4",
      userId: "4", // for backward compatibility
      name: "Dr. Ayşe Yılmaz",
      fullName: "Dr. Ayşe Yılmaz", // for backward compatibility
      email: "psychologist@kutbulzaman.com",
      role: "psychologist" as UserRole,
      isActive: true,
      password: "psy123",
      avatar:
        "https://images.unsplash.com/photo-1594824884675-25a7ac2ad8fd?w=100&h=100&fit=crop&crop=face&auto=format&q=80",
    },
    {
      id: "5",
      userId: "5", // for backward compatibility
      name: "Satış Temsilcisi",
      fullName: "Satış Temsilcisi", // for backward compatibility
      email: "merchant@kutbulzaman.com",
      role: "merchant" as UserRole,
      isActive: true,
      password: "merchant123",
      avatar:
        "https://images.unsplash.com/photo-1519345182560-3f2917c472ef?w=100&h=100&fit=crop&crop=face&auto=format&q=80",
    },
  ];

  // Generate a simple JWT-like token (for demo purposes)
  private generateToken(userId: string, role: UserRole): string {
    const header = btoa(JSON.stringify({ alg: "HS256", typ: "JWT" }));
    const payload = btoa(
      JSON.stringify({
        userId,
        role,
        iat: Math.floor(Date.now() / 1000),
        exp: Math.floor(Date.now() / 1000) + 7 * 24 * 60 * 60, // 7 days
      }),
    );
    const signature = btoa(`signature_${userId}_${role}`);
    return `${header}.${payload}.${signature}`;
  }

  // Parse token (for demo purposes)
  private parseToken(token: string): any {
    try {
      const parts = token.split(".");
      if (parts.length !== 3) return null;

      const payload = JSON.parse(atob(parts[1]));
      return payload;
    } catch (error) {
      return null;
    }
  }

  async login(credentials: LoginCredentials): Promise<AuthResponse> {
    try {
      // Simulate API delay
      await new Promise((resolve) => setTimeout(resolve, 1000));

      // Find user in demo users
      const demoUser = this.demoUsers.find(
        (user) =>
          user.email === credentials.email &&
          user.password === credentials.password,
      );

      if (demoUser) {
        const token = this.generateToken(demoUser.id, demoUser.role);

        const user: User = {
          id: demoUser.id,
          name: demoUser.name,
          email: demoUser.email,
          role: demoUser.role,
          isActive: demoUser.isActive,
          token,
          avatar: demoUser.avatar,
          createdAt: new Date().toISOString(),
          lastLogin: new Date().toISOString(),
        };

        return {
          success: true,
          user,
          token,
        };
      }

      return {
        success: false,
        error: "E-posta veya şifre hatalı",
      };
    } catch (error) {
      return {
        success: false,
        error: "Giriş işlemi sırasında hata oluştu",
      };
    }
  }

  async register(data: RegisterData): Promise<AuthResponse> {
    try {
      // Simulate API delay
      await new Promise((resolve) => setTimeout(resolve, 1000));

      // Check if email already exists
      const existingUser = this.demoUsers.find(
        (user) => user.email === data.email,
      );

      if (existingUser) {
        return {
          success: false,
          error: "Bu e-posta adresi zaten kayıtlı",
        };
      }

      // Create new user
      const userId = Date.now().toString();
      const role = data.role || "user";
      const token = this.generateToken(userId, role);

      const user: User = {
        id: userId,
        name: data.name,
        email: data.email,
        role,
        isActive: true,
        token,
        phone: data.phone,
        createdAt: new Date().toISOString(),
        lastLogin: new Date().toISOString(),
      };

      // In a real app, this would save to database
      console.log("New user registered:", user);

      return {
        success: true,
        user,
        token,
      };
    } catch (error) {
      return {
        success: false,
        error: "Kayıt işlemi sırasında hata oluştu",
      };
    }
  }

  async verifyToken(token: string): Promise<boolean> {
    try {
      // Simulate API delay
      await new Promise((resolve) => setTimeout(resolve, 500));

      const payload = this.parseToken(token);
      if (!payload) return false;

      // Check if token is expired
      const currentTime = Math.floor(Date.now() / 1000);
      if (payload.exp < currentTime) return false;

      return true;
    } catch (error) {
      return false;
    }
  }

  async refreshToken(token: string): Promise<AuthResponse> {
    try {
      const payload = this.parseToken(token);
      if (!payload) {
        return {
          success: false,
          error: "Geçersiz token",
        };
      }

      // Generate new token
      const newToken = this.generateToken(payload.userId, payload.role);

      return {
        success: true,
        token: newToken,
      };
    } catch (error) {
      return {
        success: false,
        error: "Token yenileme başarısız",
      };
    }
  }

  async logout(token: string): Promise<{ success: boolean }> {
    try {
      // Simulate API call to invalidate token on server
      await new Promise((resolve) => setTimeout(resolve, 500));

      // In a real app, this would invalidate the token on the server
      console.log("Token invalidated:", token);

      return { success: true };
    } catch (error) {
      return { success: false };
    }
  }

  async getUserProfile(token: string): Promise<AuthResponse> {
    try {
      const payload = this.parseToken(token);
      if (!payload) {
        return {
          success: false,
          error: "Geçersiz token",
        };
      }

      // Find user by ID
      const demoUser = this.demoUsers.find(
        (user) => user.id === payload.userId || user.userId === payload.userId,
      );

      if (demoUser) {
        const user: User = {
          id: demoUser.id,
          name: demoUser.name,
          email: demoUser.email,
          role: demoUser.role,
          isActive: demoUser.isActive,
          token,
          avatar: demoUser.avatar,
          createdAt: "2024-01-01T00:00:00.000Z",
          lastLogin: new Date().toISOString(),
        };

        return {
          success: true,
          user,
        };
      }

      return {
        success: false,
        error: "Kullanıcı bulunamadı",
      };
    } catch (error) {
      return {
        success: false,
        error: "Profil bilgileri alınamadı",
      };
    }
  }

  async updateProfile(
    token: string,
    updates: Partial<User>,
  ): Promise<AuthResponse> {
    try {
      const payload = this.parseToken(token);
      if (!payload) {
        return {
          success: false,
          error: "Geçersiz token",
        };
      }

      // In a real app, this would update the user in the database
      console.log("Profile updated:", updates);

      return {
        success: true,
      };
    } catch (error) {
      return {
        success: false,
        error: "Profil güncellenemedi",
      };
    }
  }

  // Role-based access helpers
  hasPermission(
    userRole: UserRole,
    resource: string,
    permission: string = "view",
  ): boolean {
    // Admin has access to everything
    if (userRole === "admin") return true;

    // Define role-based permissions
    const permissions = {
      guest: {
        view: ["home", "about", "services"],
      },
      user: {
        view: ["home", "about", "services", "profile"],
        access: ["profile", "appointments"],
      },
      mlm: {
        view: ["home", "about", "services", "profile", "mlm-dashboard"],
        access: ["profile", "mlm-dashboard", "network"],
        manage: ["network"],
      },
      psychologist: {
        view: ["home", "about", "services", "profile", "clients"],
        access: ["profile", "clients", "appointments"],
        manage: ["appointments", "client-notes"],
      },
      merchant: {
        view: ["home", "about", "services", "profile", "products"],
        access: ["profile", "products", "orders"],
        manage: ["products", "inventory"],
      },
    };

    const userPermissions = permissions[userRole];
    return userPermissions?.[permission]?.includes(resource) || false;
  }
}

export const authService = new AuthService();
