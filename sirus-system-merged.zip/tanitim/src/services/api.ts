const API_BASE = import.meta.env.VITE_API_URL || "https://api.kutbulzaman.com";

interface LoginResponse {
  success: boolean;
  user?: any;
  token?: string;
  error?: string;
}

interface UserResponse {
  success: boolean;
  user?: any;
  error?: string;
}

export const login = async (
  email: string,
  password: string,
): Promise<Response> => {
  return fetch(`${API_BASE}/auth/login`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ email, password }),
  });
};

export const fetchUser = async (token: string): Promise<Response> => {
  return fetch(`${API_BASE}/auth/me`, {
    method: "GET",
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
    },
  });
};

// Additional utility functions for better API handling
export const apiRequest = async (
  endpoint: string,
  options: RequestInit = {},
): Promise<Response> => {
  const url = `${API_BASE}${endpoint}`;

  const defaultOptions: RequestInit = {
    headers: {
      "Content-Type": "application/json",
      ...options.headers,
    },
    ...options,
  };

  return fetch(url, defaultOptions);
};

export const authenticatedRequest = async (
  endpoint: string,
  token: string,
  options: RequestInit = {},
): Promise<Response> => {
  return apiRequest(endpoint, {
    ...options,
    headers: {
      Authorization: `Bearer ${token}`,
      ...options.headers,
    },
  });
};

// API Service object for easier usage
export const apiService = {
  async submitContactForm(formData: any): Promise<void> {
    const response = await apiRequest("/contact", {
      method: "POST",
      body: JSON.stringify(formData),
    });

    if (!response.ok) {
      throw new Error("Form submission failed");
    }
  },

  async submitAppointmentForm(formData: any): Promise<void> {
    const response = await apiRequest("/appointments", {
      method: "POST",
      body: JSON.stringify(formData),
    });

    if (!response.ok) {
      throw new Error("Appointment submission failed");
    }
  },
};
