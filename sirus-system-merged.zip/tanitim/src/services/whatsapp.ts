export class WhatsAppService {
  private static phoneNumber = "+905551234567";

  static openChat(message?: string) {
    const defaultMessage =
      "Merhaba! Kutbu'l Zaman hizmetleri hakkında bilgi almak istiyorum.";
    const encodedMessage = encodeURIComponent(message || defaultMessage);
    const url = `https://wa.me/${this.phoneNumber}?text=${encodedMessage}`;
    window.open(url, "_blank");
  }

  static openAppointmentChat() {
    const message =
      "Merhaba! Randevu talep etmek istiyorum. Müsait zamanlarınızı öğrenebilir miyim?";
    this.openChat(message);
  }

  static openSupportChat() {
    const message = "Merhaba! Destek almak istiyorum.";
    this.openChat(message);
  }

  static openConsultationChat(service?: string) {
    const message = service
      ? `Merhaba! ${service} hizmeti hakkında bilgi almak istiyorum.`
      : "Merhaba! Danışmanlık hizmetleriniz hakkında bilgi almak istiyorum.";
    this.openChat(message);
  }
}
