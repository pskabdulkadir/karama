import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../auth/AuthContext";
import { UserRole } from "../auth/types";
import { PageTransition } from "./PageTransition";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Shield, Lock } from "lucide-react";

interface ProtectedRouteProps {
  children: React.ReactNode;
  requiredRoles?: UserRole[];
  redirectTo?: string;
}

export function ProtectedRoute({
  children,
  requiredRoles = [],
  redirectTo = "/giris",
}: ProtectedRouteProps) {
  const { isAuthenticated, user, isLoading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      // Store current path for redirect after login
      localStorage.setItem("redirectAfterLogin", window.location.pathname);
      navigate(redirectTo);
    }
  }, [isAuthenticated, isLoading, navigate, redirectTo]);

  // Show loading state
  if (isLoading) {
    return (
      <PageTransition>
        <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-brand-navy via-brand-navy-light to-brand-navy-dark">
          <Card className="brand-card w-96">
            <CardContent className="p-8 text-center">
              <div className="animate-spin w-8 h-8 border-2 border-brand-gold border-t-transparent rounded-full mx-auto mb-4" />
              <p className="text-brand-navy">Yükleniyor...</p>
            </CardContent>
          </Card>
        </div>
      </PageTransition>
    );
  }

  // If not authenticated, don't render anything (will redirect)
  if (!isAuthenticated) {
    return null;
  }

  // Check role permissions if required roles are specified
  if (requiredRoles.length > 0 && user && !requiredRoles.includes(user.role)) {
    return (
      <PageTransition>
        <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-brand-navy via-brand-navy-light to-brand-navy-dark">
          <Card className="brand-card w-96">
            <CardContent className="p-8 text-center">
              <Shield className="w-16 h-16 text-red-500 mx-auto mb-4" />
              <h2 className="text-2xl font-bold text-red-600 mb-2">
                Erişim Reddedildi
              </h2>
              <p className="text-gray-600 mb-4">
                Bu sayfaya erişim için gerekli yetkiniz bulunmuyor.
              </p>
              <p className="text-sm text-gray-500 mb-6">
                Gerekli rol: {requiredRoles.join(", ")}
                <br />
                Mevcut rol: {user?.role}
              </p>
              <div className="space-y-2">
                <Button
                  onClick={() => navigate("/portal")}
                  className="w-full brand-button"
                >
                  Portala Dön
                </Button>
                <Button
                  onClick={() => navigate("/")}
                  variant="outline"
                  className="w-full"
                >
                  Ana Sayfaya Dön
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </PageTransition>
    );
  }

  // User is authenticated and has required roles
  return <>{children}</>;
}

// Higher-order component for easy wrapping
export function withAuth<T extends Record<string, any>>(
  Component: React.ComponentType<T>,
  requiredRoles?: UserRole[],
) {
  return function AuthenticatedComponent(props: T) {
    return (
      <ProtectedRoute requiredRoles={requiredRoles}>
        <Component {...props} />
      </ProtectedRoute>
    );
  };
}

// Hook for checking authentication in components
export function useAuthGuard(requiredRoles?: UserRole[]) {
  const { isAuthenticated, user, isLoading } = useAuth();
  const navigate = useNavigate();

  const hasAccess = () => {
    if (!isAuthenticated) return false;
    if (!requiredRoles || requiredRoles.length === 0) return true;
    return user ? requiredRoles.includes(user.role) : false;
  };

  const redirectToLogin = () => {
    localStorage.setItem("redirectAfterLogin", window.location.pathname);
    navigate("/giris");
  };

  return {
    isAuthenticated,
    user,
    isLoading,
    hasAccess: hasAccess(),
    redirectToLogin,
  };
}
