import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../auth/AuthContext";
import { PageTransition } from "../components/PageTransition";
import { MainLayout } from "../layouts/MainLayout";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Settings,
  Users,
  Database,
  BarChart3,
  Shield,
  ArrowLeft,
  Search,
  Plus,
  Edit,
  Trash2,
  Activity,
} from "lucide-react";

const ADMIN_STATS = [
  {
    label: "Toplam Kullanıcı",
    value: "1,247",
    change: "+12%",
    icon: Users,
    color: "text-blue-600",
  },
  {
    label: "Aktif Sistemler",
    value: "5",
    change: "100%",
    icon: Activity,
    color: "text-green-600",
  },
  {
    label: "Aylık Gelir",
    value: "₺45,230",
    change: "+8%",
    icon: BarChart3,
    color: "text-purple-600",
  },
  {
    label: "Sistem Sağlığı",
    value: "98.5%",
    change: "+0.5%",
    icon: Shield,
    color: "text-emerald-600",
  },
];

const RECENT_USERS = [
  {
    id: 1,
    name: "Ahmet Yılmaz",
    email: "ahmet@example.com",
    role: "user",
    status: "active",
    joined: "2024-01-10",
  },
  {
    id: 2,
    name: "Fatma Kaya",
    email: "fatma@example.com",
    role: "mlm",
    status: "active",
    joined: "2024-01-09",
  },
  {
    id: 3,
    name: "Mehmet Demir",
    email: "mehmet@example.com",
    role: "merchant",
    status: "inactive",
    joined: "2024-01-08",
  },
];

const ADMIN_MODULES = [
  {
    title: "Kullanıcı Yönetimi",
    description: "Kullanıcı hesapları, roller ve izinler",
    icon: Users,
    count: "1,247 kullanıcı",
    action: () => console.log("Kullanıcı Yönetimi"),
  },
  {
    title: "Sistem Ayarları",
    description: "Genel sistem konfigürasyonu",
    icon: Settings,
    count: "5 sistem",
    action: () => console.log("Sistem Ayarları"),
  },
  {
    title: "Veritabanı",
    description: "Veri yönetimi ve yedekleme",
    icon: Database,
    count: "12 GB",
    action: () => console.log("Veritabanı"),
  },
  {
    title: "Raporlar",
    description: "Analitik ve performans raporları",
    icon: BarChart3,
    count: "25 rapor",
    action: () => console.log("Raporlar"),
  },
];

export default function Admin() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState("");

  // Check if user has admin access
  if (user?.role !== "admin") {
    return (
      <MainLayout>
        <PageTransition>
          <div className="min-h-screen flex items-center justify-center">
            <Card className="brand-card">
              <CardContent className="p-8 text-center">
                <Shield className="w-16 h-16 text-red-500 mx-auto mb-4" />
                <h2 className="text-2xl font-bold text-red-600 mb-2">
                  Erişim Reddedildi
                </h2>
                <p className="text-gray-600 mb-4">
                  Bu sayfaya erişim için admin yetkisi gereklidir.
                </p>
                <Button onClick={() => navigate("/portal")}>Portala Dön</Button>
              </CardContent>
            </Card>
          </div>
        </PageTransition>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <PageTransition>
        <div className="min-h-screen bg-gradient-to-br from-slate-50 to-gray-100">
          <div className="container mx-auto px-4 py-8">
            {/* Header */}
            <div className="flex items-center justify-between mb-8">
              <div className="flex items-center space-x-4">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => navigate("/portal")}
                  className="flex items-center space-x-2"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>Portala Dön</span>
                </Button>
                <div>
                  <h1 className="text-3xl font-bold text-brand-navy">
                    Yönetim Paneli
                  </h1>
                  <p className="text-gray-600">Sistem yönetimi ve ayarları</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <Button className="brand-button-secondary">
                  <Plus className="w-4 h-4 mr-2" />
                  Yeni Kullanıcı
                </Button>
              </div>
            </div>

            {/* Admin Stats */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              {ADMIN_STATS.map((stat, index) => {
                const IconComponent = stat.icon;
                return (
                  <Card key={index} className="brand-card">
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm text-gray-600">{stat.label}</p>
                          <p className={`text-2xl font-bold ${stat.color}`}>
                            {stat.value}
                          </p>
                          <p className="text-sm text-green-600">
                            {stat.change}
                          </p>
                        </div>
                        <div className="p-3 rounded-full bg-gray-100">
                          <IconComponent className={`w-6 h-6 ${stat.color}`} />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>

            {/* Admin Welcome */}
            <Card className="brand-card mb-8 bg-gradient-to-r from-slate-600 to-slate-800 text-white">
              <CardHeader>
                <CardTitle className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
                    <Shield className="w-6 h-6" />
                  </div>
                  <div>
                    <h2 className="text-xl">Hoş geldin, {user?.name}!</h2>
                    <p className="text-sm opacity-90 font-normal">
                      Sistem Admin Paneli
                    </p>
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="mb-4">
                  Sistem sağlığı mükemmel durumda. Son 24 saatte 45 yeni
                  kullanıcı kaydı yapıldı ve sistem performansı %98.5
                  seviyesinde.
                </p>
                <Button className="bg-white text-slate-800 hover:bg-gray-100">
                  Detaylı Rapor
                </Button>
              </CardContent>
            </Card>

            {/* Admin Modules */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              {ADMIN_MODULES.map((module, index) => {
                const IconComponent = module.icon;

                return (
                  <Card
                    key={index}
                    className="brand-card cursor-pointer group"
                    onClick={module.action}
                  >
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-4">
                          <div className="w-12 h-12 bg-slate-100 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                            <IconComponent className="w-6 h-6 text-slate-600" />
                          </div>
                          <div>
                            <CardTitle className="text-lg">
                              {module.title}
                            </CardTitle>
                            <CardDescription>
                              {module.description}
                            </CardDescription>
                          </div>
                        </div>
                        <div className="text-sm text-gray-500">
                          {module.count}
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <Button className="w-full brand-button">Yönet</Button>
                    </CardContent>
                  </Card>
                );
              })}
            </div>

            {/* Recent Users */}
            <Card className="brand-card">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Son Kullanıcılar</CardTitle>
                    <CardDescription>
                      Yeni kayıt olan kullanıcılar
                    </CardDescription>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                      <Input
                        placeholder="Kullanıcı ara..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-10 w-64"
                      />
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {RECENT_USERS.map((user) => (
                    <div
                      key={user.id}
                      className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
                    >
                      <div className="flex items-center space-x-4">
                        <div className="w-10 h-10 bg-brand-navy rounded-full flex items-center justify-center">
                          <span className="text-white text-sm">
                            {user.name.charAt(0)}
                          </span>
                        </div>
                        <div>
                          <p className="font-medium">{user.name}</p>
                          <p className="text-sm text-gray-600">{user.email}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-4">
                        <span className="text-sm capitalize bg-gray-200 px-2 py-1 rounded">
                          {user.role}
                        </span>
                        <span
                          className={`text-sm px-2 py-1 rounded ${
                            user.status === "active"
                              ? "bg-green-100 text-green-700"
                              : "bg-red-100 text-red-700"
                          }`}
                        >
                          {user.status === "active" ? "Aktif" : "Pasif"}
                        </span>
                        <div className="flex space-x-2">
                          <Button variant="outline" size="sm">
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button variant="outline" size="sm">
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </PageTransition>
    </MainLayout>
  );
}
