import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Header } from "../components/Header";
import { Footer } from "../components/Footer";
import { WhatsAppService } from "../services/whatsapp";
import { apiService } from "../services/api";
import { validation } from "../utils/validation";
import {
  Phone,
  Mail,
  MapPin,
  Instagram,
  Facebook,
  Youtube,
  Star,
  Sparkles,
  Zap,
  Brain,
  Heart,
  Eye,
  MessageCircle,
  Send,
  ArrowDown,
  Play,
  Menu,
  X,
} from "lucide-react";

export default function Index() {
  const [selectedCategory, setSelectedCategory] = useState("Tümü");
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    email: "",
    message: "",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [imageLoadErrors, setImageLoadErrors] = useState<Set<string>>(
    new Set(),
  );
  const { toast } = useToast();

  // References for smooth scrolling
  const aboutRef = useRef<HTMLElement>(null);
  const expertiseRef = useRef<HTMLElement>(null);
  const blogRef = useRef<HTMLElement>(null);
  const appointmentRef = useRef<HTMLElement>(null);
  const contactRef = useRef<HTMLElement>(null);

  const expertiseAreas = [
    {
      title: "Kuantum Terapisi",
      description: "Kuantum bilinciyle derin iyileşme ve dönüşüm süreci",
      icon: <Zap className="w-8 h-8" />,
    },
    {
      title: "Aile Dizimi",
      description: "Aile sistemlerindeki gizli dinamikleri ortaya çıkarma",
      icon: <Heart className="w-8 h-8" />,
    },
    {
      title: "Rüya Analizi",
      description: "Bilinçaltının mesajlarını çözümleme ve anlama",
      icon: <Brain className="w-8 h-8" />,
    },
    {
      title: "Bilinçaltı Temizliği",
      description: "Eski kalıpları temizleyip yeni başlangıçlar yaratma",
      icon: <Sparkles className="w-8 h-8" />,
    },
    {
      title: "Enerji/Aura Okuması",
      description: "Enerji alanınızın analizi ve harmonizasyonu",
      icon: <Eye className="w-8 h-8" />,
    },
  ];

  const blogPosts = [
    {
      title: "Kuantum Bilincin Gücü",
      category: "Kuantum Terapisi",
      excerpt:
        "Kuantum fiziğinin ruhsal gelişimdeki rolü ve bilinç üzerindeki etkileri...",
      image:
        "https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=400&h=300&fit=crop&auto=format&q=80",
      slug: "kuantum-bilincin-gucu",
    },
    {
      title: "Aile Diziminde İlk Adımlar",
      category: "Aile Dizimi",
      excerpt:
        "Aile sistemlerindeki görünmeyen bağları anlamak için temel bilgiler...",
      image:
        "https://images.unsplash.com/photo-1511632765486-a01980e01a18?w=400&h=300&fit=crop&auto=format&q=80",
      slug: "aile-diziminde-ilk-adimlar",
    },
    {
      title: "Rüyalarınız Size Ne Söylüyor?",
      category: "Rüya Analizi",
      excerpt: "Jung'un rüya analizi metodları ve modern yaklaşımlar...",
      image:
        "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400&h=300&fit=crop&auto=format&q=80",
      slug: "ruyalariniz-size-ne-soyluyor",
    },
  ];

  const categories = [
    "Tümü",
    "Kuantum Terapisi",
    "Aile Dizimi",
    "Rüya Analizi",
    "Bilinçaltı",
    "Enerji Çalışması",
    "Manevi Gelişim",
  ];

  const filteredPosts =
    selectedCategory === "Tümü"
      ? blogPosts
      : blogPosts.filter((post) => post.category === selectedCategory);

  // Smooth scroll function
  const scrollToSection = (ref: React.RefObject<HTMLElement>) => {
    ref.current?.scrollIntoView({
      behavior: "smooth",
      block: "start",
    });
  };

  const handleNavigation = (section: string) => {
    const refs = {
      about: aboutRef,
      expertise: expertiseRef,
      blog: blogRef,
      appointment: appointmentRef,
      contact: contactRef,
    };
    const ref = refs[section as keyof typeof refs];
    ref?.current?.scrollIntoView({
      behavior: "smooth",
      block: "start",
    });
  };

  // Blog post handler
  const readBlogPost = (slug: string) => {
    toast({
      title: "Blog Yazısı",
      description: "Blog sayfası yakında aktif olacak!",
    });
  };

  // Form validation
  const validateForm = () => {
    if (!validation.required(formData.name)) {
      toast({
        title: "Hata",
        description: "Lütfen isim soyisim alanını doldurun.",
        variant: "destructive",
      });
      return false;
    }
    if (!validation.required(formData.phone)) {
      toast({
        title: "Hata",
        description: "Lütfen telefon numaranızı girin.",
        variant: "destructive",
      });
      return false;
    }
    if (!validation.email(formData.email)) {
      toast({
        title: "Hata",
        description: "Lütfen geçerli bir e-posta adresi girin.",
        variant: "destructive",
      });
      return false;
    }
    return true;
  };

  // Form submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) return;

    setIsSubmitting(true);

    try {
      await apiService.submitContactForm(formData);

      toast({
        title: "Başarılı!",
        description:
          "Randevu talebiniz alındı. En kısa sürede size dönüş yapacağız.",
      });

      setFormData({
        name: "",
        phone: "",
        email: "",
        message: "",
      });
    } catch (error) {
      toast({
        title: "Hata",
        description: "Bir hata oluştu. Lütfen tekrar deneyin.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  // Image error handler
  const handleImageError = (imageSrc: string) => {
    setImageLoadErrors((prev) => new Set(prev).add(imageSrc));
  };

  return (
    <div className="min-h-screen bg-white">
      <Header onNavigate={handleNavigation} />

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center px-4 pt-20 bg-gradient-to-br from-white to-brand-gray/20">
        <div className="relative z-10 text-center max-w-4xl mx-auto">
          <div className="mb-8">
            <h1 className="text-5xl md:text-7xl font-bold mb-6 brand-text-gradient">
              Farkındalıkla Dönüşüm Başlar
            </h1>
            <p className="text-xl md:text-2xl text-brand-purple/80 mb-8 font-light">
              Zihnini değiştir, hayatın değişsin.
            </p>
          </div>

          <div className="mb-12 max-w-2xl mx-auto">
            <div className="brand-card p-4 aspect-video relative overflow-hidden">
              <iframe
                className="w-full h-full rounded-lg"
                src="https://www.youtube.com/embed/kJQP7kiw5Fk?rel=0&modestbranding=1"
                title="Farkındalık ve Kişisel Gelişim - Tanıtım Videosu"
                frameBorder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                allowFullScreen
                style={{
                  border: "none",
                  borderRadius: "0.5rem",
                }}
              />
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              onClick={() => WhatsAppService.openAppointmentChat()}
              size="lg"
              className="brand-button"
            >
              <MessageCircle className="w-5 h-5 mr-2" />
              Hemen Randevu Al
            </Button>
            <Button
              onClick={() => scrollToSection(aboutRef)}
              size="lg"
              variant="outline"
              className="border-brand-purple text-brand-purple hover:bg-brand-purple hover:text-white"
            >
              Daha Fazla Bilgi
            </Button>
          </div>

          <div className="mt-12">
            <button
              onClick={() => scrollToSection(aboutRef)}
              className="text-brand-purple hover:text-brand-purple/80 transition-colors animate-bounce"
            >
              <ArrowDown className="w-6 h-6" />
            </button>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section ref={aboutRef} className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold mb-6 brand-text-gradient">
                Hakkımızda
              </h2>
              <div className="prose prose-lg text-brand-purple/80 space-y-4">
                <p>
                  25 yıllık deneyimimle, kuantum bilinci, psikoloji ve manevi
                  ilimler alanında binlerce kişinin hayatına dokundum. Akademik
                  eğitimim ve spiritüel yolculuğumu harmanlayarak geliştirdiğim
                  holistik yaklaşımla, her bireyin kendi içindeki güçlü
                  yanlarını keşfetmesine yardımcı oluyorum.
                </p>
                <p>
                  Aile dizimi, kuantum terapisi ve bilinçaltı çalışmaları
                  konularında uzmanlaşmış olarak, modern psikoloji ile antik
                  bilgeliği bir araya getiren benzersiz metodlar kullanıyorum.
                </p>
                <div className="pt-4">
                  <div className="flex items-center gap-3 text-brand-purple">
                    <Star className="w-5 h-5 fill-current" />
                    <span className="font-semibold">Dr. Ayşe Nur Yılmaz</span>
                  </div>
                  <p className="text-sm text-muted-foreground mt-1">
                    Klinik Psikolog, Kuantum Terapi Uzmanı
                  </p>
                </div>
              </div>
            </div>
            <div className="flex justify-center">
              <div className="brand-card p-4 w-80 h-80 flex items-center justify-center">
                <img
                  src="https://images.unsplash.com/photo-1594824884675-25a7ac2ad8fd?w=400&h=400&fit=crop&crop=face&auto=format&q=80"
                  alt="Dr. Ayşe Nur Yılmaz - Klinik Psikolog ve Kuantum Terapi Uzmanı"
                  className="w-64 h-64 rounded-full object-cover border-4 border-brand-purple/30"
                  loading="lazy"
                  width="256"
                  height="256"
                  onError={() => handleImageError("about-photo")}
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Expertise Areas */}
      <section ref={expertiseRef} className="py-20 px-4 bg-brand-gray/10">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4 brand-text-gradient">
              Uzmanlık Alanlarımız
            </h2>
            <p className="text-xl text-brand-purple/80">
              Ruhsal dönüşümünüz için kapsamlı yaklaşımlar
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {expertiseAreas.map((area, index) => (
              <Card
                key={index}
                className="brand-card hover:shadow-lg transition-all group cursor-pointer"
                onClick={() => scrollToSection(appointmentRef)}
              >
                <CardHeader className="text-center pb-4">
                  <div className="text-brand-teal mb-4 group-hover:scale-110 transition-transform">
                    {area.icon}
                  </div>
                  <CardTitle className="text-xl text-brand-purple">
                    {area.title}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-muted-foreground text-center mb-4">
                    {area.description}
                  </CardDescription>
                  <Button
                    variant="outline"
                    size="sm"
                    className="w-full border-brand-teal text-brand-teal hover:bg-brand-teal hover:text-white"
                  >
                    Randevu Al
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Blog Section */}
      <section ref={blogRef} className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4 brand-text-gradient">
              Blog
            </h2>
            <p className="text-xl text-brand-purple/80">
              Bilgi ve farkındalık için yazılarımız
            </p>
          </div>

          {/* Category Filter */}
          <div className="flex flex-wrap justify-center gap-2 mb-12">
            {categories.map((category) => (
              <Badge
                key={category}
                variant={selectedCategory === category ? "default" : "outline"}
                className={`cursor-pointer px-4 py-2 transition-all ${
                  selectedCategory === category
                    ? "bg-brand-teal text-white"
                    : "border-brand-teal/50 text-brand-teal hover:bg-brand-teal/20"
                }`}
                onClick={() => setSelectedCategory(category)}
              >
                {category}
              </Badge>
            ))}
          </div>

          {/* Blog Posts */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredPosts.map((post, index) => (
              <Card
                key={index}
                className="brand-card hover:shadow-lg transition-all group overflow-hidden cursor-pointer"
                onClick={() => readBlogPost(post.slug)}
              >
                <div className="aspect-video bg-brand-gray/20 flex items-center justify-center overflow-hidden">
                  {imageLoadErrors.has(post.image) ? (
                    <div className="w-full h-full bg-brand-gray/50 flex items-center justify-center">
                      <div className="text-center text-muted-foreground">
                        <Eye className="w-8 h-8 mx-auto mb-2" />
                        <p className="text-sm">Görsel Yüklenemedi</p>
                      </div>
                    </div>
                  ) : (
                    <img
                      src={post.image}
                      alt={`${post.title} - ${post.category} blog yazısı`}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                      loading="lazy"
                      width="400"
                      height="300"
                      onError={() => handleImageError(post.image)}
                    />
                  )}
                </div>
                <CardHeader>
                  <Badge
                    variant="outline"
                    className="w-fit border-brand-teal/50 text-brand-teal text-xs"
                  >
                    {post.category}
                  </Badge>
                  <CardTitle className="text-lg text-brand-purple group-hover:text-brand-teal transition-colors">
                    {post.title}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-muted-foreground mb-4">
                    {post.excerpt}
                  </CardDescription>
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-brand-teal text-brand-teal hover:bg-brand-teal hover:text-white"
                    onClick={(e) => {
                      e.stopPropagation();
                      readBlogPost(post.slug);
                    }}
                  >
                    Devamını Oku
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Appointment Form */}
      <section ref={appointmentRef} className="py-20 px-4 bg-brand-gray/10">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4 brand-text-gradient">
              Randevu Formu
            </h2>
            <p className="text-xl text-brand-purple/80">
              Dönüşüm yolculuğunuzun ilk adımını atın
            </p>
          </div>

          <Card className="brand-card">
            <CardContent className="p-8">
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-brand-purple mb-2 font-medium">
                      İsim Soyisim *
                    </label>
                    <Input
                      value={formData.name}
                      onChange={(e) =>
                        handleInputChange("name", e.target.value)
                      }
                      className="brand-input"
                      placeholder="Adınızı ve soyadınızı girin"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-brand-purple mb-2 font-medium">
                      Telefon *
                    </label>
                    <Input
                      value={formData.phone}
                      onChange={(e) =>
                        handleInputChange("phone", e.target.value)
                      }
                      className="brand-input"
                      placeholder="Telefon numaranızı girin"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-brand-purple mb-2 font-medium">
                    E-posta *
                  </label>
                  <Input
                    type="email"
                    value={formData.email}
                    onChange={(e) => handleInputChange("email", e.target.value)}
                    className="brand-input"
                    placeholder="E-posta adresinizi girin"
                    required
                  />
                </div>

                <div>
                  <label className="block text-brand-purple mb-2 font-medium">
                    Mesaj
                  </label>
                  <Textarea
                    value={formData.message}
                    onChange={(e) =>
                      handleInputChange("message", e.target.value)
                    }
                    className="brand-input min-h-32"
                    placeholder="Hangi konularda destek almak istiyorsunuz?"
                  />
                </div>

                <div className="flex flex-col sm:flex-row gap-4">
                  <Button
                    type="submit"
                    disabled={isSubmitting}
                    className="brand-button"
                  >
                    {isSubmitting ? (
                      <>
                        <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2"></div>
                        Gönderiliyor...
                      </>
                    ) : (
                      <>
                        <Send className="w-4 h-4 mr-2" />
                        Randevu Talep Et
                      </>
                    )}
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    className="border-brand-teal text-brand-teal hover:bg-brand-teal hover:text-white"
                    onClick={() => WhatsAppService.openAppointmentChat()}
                  >
                    <MessageCircle className="w-4 h-4 mr-2" />
                    WhatsApp
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Contact Section */}
      <section ref={contactRef} className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4 brand-text-gradient">
              İletişim
            </h2>
            <p className="text-xl text-brand-purple/80">
              Bize ulaşın ve dönüşüm yolculuğunuzda yanınızda olalım
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-12">
            {/* Contact Info */}
            <div className="space-y-8">
              <Card className="brand-card p-6 cursor-pointer hover:shadow-lg transition-all">
                <div className="flex items-center gap-4">
                  <div className="text-brand-teal">
                    <MapPin className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-brand-purple">Adres</h3>
                    <p className="text-muted-foreground">
                      Atatürk Mah. Barış Sokak No:15/3 Kadıköy/İstanbul
                    </p>
                  </div>
                </div>
              </Card>

              <Card
                className="brand-card p-6 cursor-pointer hover:shadow-lg transition-all"
                onClick={() => window.open("tel:+905551234567")}
              >
                <div className="flex items-center gap-4">
                  <div className="text-brand-teal">
                    <Phone className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-brand-purple">Telefon</h3>
                    <p className="text-muted-foreground">+90 (555) 123 45 67</p>
                  </div>
                </div>
              </Card>

              <Card
                className="brand-card p-6 cursor-pointer hover:shadow-lg transition-all"
                onClick={() => window.open("mailto:info@farkindallkterapi.com")}
              >
                <div className="flex items-center gap-4">
                  <div className="text-brand-teal">
                    <Mail className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-brand-purple">E-posta</h3>
                    <p className="text-muted-foreground">
                      info@farkindallkterapi.com
                    </p>
                  </div>
                </div>
              </Card>

              {/* Social Media */}
              <div className="space-y-4">
                <h3 className="text-xl font-semibold text-brand-purple">
                  Sosyal Medya
                </h3>
                <div className="flex gap-4">
                  <Button
                    size="icon"
                    variant="outline"
                    className="border-brand-teal text-brand-teal hover:bg-brand-teal hover:text-white"
                    onClick={() =>
                      window.open("https://instagram.com/farkindallkterapi")
                    }
                  >
                    <Instagram className="w-5 h-5" />
                  </Button>
                  <Button
                    size="icon"
                    variant="outline"
                    className="border-brand-teal text-brand-teal hover:bg-brand-teal hover:text-white"
                    onClick={() =>
                      window.open("https://youtube.com/@farkindallkterapi")
                    }
                  >
                    <Youtube className="w-5 h-5" />
                  </Button>
                  <Button
                    size="icon"
                    variant="outline"
                    className="border-brand-teal text-brand-teal hover:bg-brand-teal hover:text-white"
                    onClick={() =>
                      window.open("https://facebook.com/farkindallkterapi")
                    }
                  >
                    <Facebook className="w-5 h-5" />
                  </Button>
                </div>
              </div>
            </div>

            {/* Map */}
            <div className="brand-card p-4 h-96">
              <iframe
                className="w-full h-full rounded-lg"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3010.2918176394855!2d29.02635251595!3d40.9825!5e0!3m2!1str!2str!4v1234567890123!5m2!1str!2str"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                title="Ofis Lokasyonu"
              ></iframe>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
