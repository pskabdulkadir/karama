import { useNavigate } from "react-router-dom";
import { useAuth } from "../auth/AuthContext";
import { PageTransition } from "../components/PageTransition";
import { ProtectedRoute } from "../components/ProtectedRoute";
import { MainLayout } from "../layouts/MainLayout";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  User,
  Bell,
  Settings,
  Calendar,
  FileText,
  LogOut,
  ArrowLeft,
} from "lucide-react";

export default function Panel() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate("/");
  };

  const panelFeatures = [
    {
      title: "Profil Bilgileri",
      description: "Kişisel bilgilerinizi görüntüleyin ve düzenleyin",
      icon: User,
      action: () => navigate("/profil"),
    },
    {
      title: "Bildirimler",
      description: "Önemli bildirimleri ve güncellemeleri görün",
      icon: Bell,
      action: () => navigate("/bildirimler"),
    },
    {
      title: "Randevular",
      description: "Randevu geçmişiniz ve gelecek randevularınız",
      icon: Calendar,
      action: () => console.log("Randevular"),
    },
    {
      title: "Belgeler",
      description: "Kişisel belgeleriniz ve raporlarınız",
      icon: FileText,
      action: () => console.log("Belgeler"),
    },
    {
      title: "Ayarlar",
      description: "Hesap ayarları ve güvenlik seçenekleri",
      icon: Settings,
      action: () => console.log("Ayarlar"),
    },
  ];

  return (
    <ProtectedRoute>
      <MainLayout>
        <PageTransition>
          <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
            <div className="container mx-auto px-4 py-8">
              {/* Header */}
              <div className="flex items-center justify-between mb-8">
                <div className="flex items-center space-x-4">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => navigate("/portal")}
                    className="flex items-center space-x-2"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    <span>Portala Dön</span>
                  </Button>
                  <div>
                    <h1 className="text-3xl font-bold text-brand-navy">
                      Kullanıcı Paneli
                    </h1>
                    <p className="text-gray-600">Hoş geldin, {user?.name}!</p>
                  </div>
                </div>
                <Button
                  variant="outline"
                  onClick={handleLogout}
                  className="flex items-center space-x-2 text-red-600 border-red-600 hover:bg-red-50"
                >
                  <LogOut className="w-4 h-4" />
                  <span>Çıkış Yap</span>
                </Button>
              </div>

              {/* User Info Card */}
              <Card className="brand-card mb-8">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-3">
                    <div className="w-12 h-12 bg-brand-navy rounded-full flex items-center justify-center">
                      <User className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h2 className="text-xl">{user?.name}</h2>
                      <p className="text-sm text-gray-600 font-normal">
                        {user?.email}
                      </p>
                    </div>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <span className="text-sm text-gray-500">Rol</span>
                      <p className="font-medium capitalize">{user?.role}</p>
                    </div>
                    <div>
                      <span className="text-sm text-gray-500">Durum</span>
                      <p className="font-medium">
                        {user?.isActive ? (
                          <span className="text-green-600">Aktif</span>
                        ) : (
                          <span className="text-red-600">Pasif</span>
                        )}
                      </p>
                    </div>
                    <div>
                      <span className="text-sm text-gray-500">Üyelik</span>
                      <p className="font-medium">Premium</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Panel Features */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {panelFeatures.map((feature, index) => {
                  const IconComponent = feature.icon;

                  return (
                    <Card
                      key={index}
                      className="brand-card cursor-pointer group"
                      onClick={feature.action}
                    >
                      <CardHeader>
                        <div className="w-12 h-12 bg-brand-gold rounded-lg flex items-center justify-center mb-3 group-hover:scale-110 transition-transform duration-300">
                          <IconComponent className="w-6 h-6 text-brand-navy" />
                        </div>
                        <CardTitle className="text-lg">
                          {feature.title}
                        </CardTitle>
                        <CardDescription>{feature.description}</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <Button className="w-full brand-button">
                          Görüntüle
                        </Button>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>

              {/* Quick Stats */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mt-8">
                <div className="text-center p-6 bg-white rounded-lg shadow-md">
                  <div className="text-2xl font-bold text-brand-navy">12</div>
                  <div className="text-sm text-gray-600">Toplam Randevu</div>
                </div>
                <div className="text-center p-6 bg-white rounded-lg shadow-md">
                  <div className="text-2xl font-bold text-brand-gold">5</div>
                  <div className="text-sm text-gray-600">Aktif Hizmet</div>
                </div>
                <div className="text-center p-6 bg-white rounded-lg shadow-md">
                  <div className="text-2xl font-bold text-green-600">8</div>
                  <div className="text-sm text-gray-600">Tamamlanan</div>
                </div>
                <div className="text-center p-6 bg-white rounded-lg shadow-md">
                  <div className="text-2xl font-bold text-blue-600">3</div>
                  <div className="text-sm text-gray-600">Bekleyen</div>
                </div>
              </div>
            </div>
          </div>
        </PageTransition>
      </MainLayout>
    </ProtectedRoute>
  );
}
