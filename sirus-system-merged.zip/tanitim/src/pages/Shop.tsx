import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../auth/AuthContext";
import { PageTransition } from "../components/PageTransition";
import { MainLayout } from "../layouts/MainLayout";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  ShoppingCart,
  Search,
  Filter,
  Star,
  ArrowLeft,
  Heart,
  Package,
} from "lucide-react";

const PRODUCTS = [
  {
    id: 1,
    name: "Enerji Kristali Seti",
    price: 299,
    image:
      "https://images.unsplash.com/photo-1518611012118-696072aa579a?w=300&h=300&fit=crop",
    rating: 4.8,
    category: "Kristaller",
  },
  {
    id: 2,
    name: "Meditasyon Yastığı",
    price: 199,
    image:
      "https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=300&h=300&fit=crop",
    rating: 4.9,
    category: "Meditasyon",
  },
  {
    id: 3,
    name: "Çakra Balans Kiti",
    price: 450,
    image:
      "https://images.unsplash.com/photo-1519452575417-564c1401ecc0?w=300&h=300&fit=crop",
    rating: 4.7,
    category: "Çakra",
  },
  {
    id: 4,
    name: "Aromaterapi Yağları",
    price: 129,
    image:
      "https://images.unsplash.com/photo-1596755389378-c31d21fd1273?w=300&h=300&fit=crop",
    rating: 4.6,
    category: "Aromaterapi",
  },
  {
    id: 5,
    name: "Yoga Matı Premium",
    price: 249,
    image:
      "https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=300&h=300&fit=crop",
    rating: 4.8,
    category: "Yoga",
  },
  {
    id: 6,
    name: "Tibetli Çıngırak",
    price: 89,
    image:
      "https://images.unsplash.com/photo-1589652717406-1c69efaf1ff8?w=300&h=300&fit=crop",
    rating: 4.5,
    category: "Müzik",
  },
];

const CATEGORIES = [
  "Tümü",
  "Kristaller",
  "Meditasyon",
  "Çakra",
  "Aromaterapi",
  "Yoga",
  "Müzik",
];

export default function Shop() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [selectedCategory, setSelectedCategory] = useState("Tümü");
  const [searchQuery, setSearchQuery] = useState("");
  const [cart, setCart] = useState<number[]>([]);
  const [favorites, setFavorites] = useState<number[]>([]);

  const filteredProducts = PRODUCTS.filter((product) => {
    const matchesCategory =
      selectedCategory === "Tümü" || product.category === selectedCategory;
    const matchesSearch = product.name
      .toLowerCase()
      .includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const addToCart = (productId: number) => {
    setCart([...cart, productId]);
  };

  const toggleFavorite = (productId: number) => {
    setFavorites(
      favorites.includes(productId)
        ? favorites.filter((id) => id !== productId)
        : [...favorites, productId],
    );
  };

  return (
    <MainLayout>
      <PageTransition>
        <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50">
          <div className="container mx-auto px-4 py-8">
            {/* Header */}
            <div className="flex items-center justify-between mb-8">
              <div className="flex items-center space-x-4">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => navigate("/portal")}
                  className="flex items-center space-x-2"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>Portala Dön</span>
                </Button>
                <div>
                  <h1 className="text-3xl font-bold text-brand-navy">
                    Manevi Alışveriş
                  </h1>
                  <p className="text-gray-600">Kişisel gelişim ürünleri</p>
                </div>
              </div>
              <div className="flex items-center space-x-4">
                <Button
                  variant="outline"
                  className="flex items-center space-x-2"
                >
                  <ShoppingCart className="w-4 h-4" />
                  <span>Sepet ({cart.length})</span>
                </Button>
              </div>
            </div>

            {/* Search and Filter */}
            <div className="mb-8">
              <div className="flex flex-col md:flex-row gap-4 mb-4">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    placeholder="Ürün ara..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <Button
                  variant="outline"
                  className="flex items-center space-x-2"
                >
                  <Filter className="w-4 h-4" />
                  <span>Filtrele</span>
                </Button>
              </div>

              {/* Categories */}
              <div className="flex flex-wrap gap-2">
                {CATEGORIES.map((category) => (
                  <Button
                    key={category}
                    variant={
                      selectedCategory === category ? "default" : "outline"
                    }
                    size="sm"
                    onClick={() => setSelectedCategory(category)}
                    className={
                      selectedCategory === category ? "brand-button" : ""
                    }
                  >
                    {category}
                  </Button>
                ))}
              </div>
            </div>

            {/* Products Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
              {filteredProducts.map((product) => (
                <Card key={product.id} className="brand-card group">
                  <CardHeader className="p-0">
                    <div className="relative">
                      <img
                        src={product.image}
                        alt={product.name}
                        className="w-full h-48 object-cover rounded-t-xl"
                      />
                      <Button
                        variant="outline"
                        size="sm"
                        className="absolute top-2 right-2 p-2 h-auto bg-white/80 backdrop-blur-sm"
                        onClick={() => toggleFavorite(product.id)}
                      >
                        <Heart
                          className={`w-4 h-4 ${
                            favorites.includes(product.id)
                              ? "fill-red-500 text-red-500"
                              : "text-gray-600"
                          }`}
                        />
                      </Button>
                      <div className="absolute bottom-2 left-2 bg-brand-gold text-brand-navy px-2 py-1 rounded text-sm font-medium">
                        {product.category}
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="p-4">
                    <CardTitle className="text-lg mb-2">
                      {product.name}
                    </CardTitle>
                    <div className="flex items-center mb-2">
                      <div className="flex items-center">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`w-4 h-4 ${
                              i < Math.floor(product.rating)
                                ? "fill-yellow-400 text-yellow-400"
                                : "text-gray-300"
                            }`}
                          />
                        ))}
                      </div>
                      <span className="ml-2 text-sm text-gray-600">
                        ({product.rating})
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-2xl font-bold text-brand-navy">
                        ₺{product.price}
                      </span>
                      <Button
                        className="brand-button-secondary"
                        onClick={() => addToCart(product.id)}
                      >
                        Sepete Ekle
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Empty State */}
            {filteredProducts.length === 0 && (
              <div className="text-center py-12">
                <Package className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-xl font-medium text-gray-600 mb-2">
                  Ürün bulunamadı
                </h3>
                <p className="text-gray-500">
                  Arama kriterlerinizi değiştirmeyi deneyin
                </p>
              </div>
            )}

            {/* Shopping Stats */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className="brand-card">
                <CardContent className="p-6 text-center">
                  <ShoppingCart className="w-12 h-12 text-brand-gold mx-auto mb-3" />
                  <h3 className="font-semibold mb-1">Ücretsiz Kargo</h3>
                  <p className="text-sm text-gray-600">
                    200₺ üzeri alışverişlerde
                  </p>
                </CardContent>
              </Card>

              <Card className="brand-card">
                <CardContent className="p-6 text-center">
                  <Star className="w-12 h-12 text-brand-gold mx-auto mb-3" />
                  <h3 className="font-semibold mb-1">Kalite Garantisi</h3>
                  <p className="text-sm text-gray-600">
                    30 gün değişim garantisi
                  </p>
                </CardContent>
              </Card>

              <Card className="brand-card">
                <CardContent className="p-6 text-center">
                  <Heart className="w-12 h-12 text-brand-gold mx-auto mb-3" />
                  <h3 className="font-semibold mb-1">Uzman Desteği</h3>
                  <p className="text-sm text-gray-600">
                    7/24 müşteri hizmetleri
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </PageTransition>
    </MainLayout>
  );
}
