import { useLocation, Link } from "react-router-dom";
import { useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Home, ArrowLeft } from "lucide-react";
import { ROUTES } from "../constants";

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error(
      "404 Error: User attempted to access non-existent route:",
      location.pathname,
    );
  }, [location.pathname]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-white px-4">
      <div className="text-center max-w-md">
        <div className="text-8xl mb-6">🔍</div>
        <h1 className="text-6xl font-bold mb-4 brand-text-gradient">404</h1>
        <h2 className="text-2xl font-semibold text-brand-purple mb-4">
          Sayfa Bulunamadı
        </h2>
        <p className="text-muted-foreground mb-8">
          Aradığınız sayfa mevcut değil veya taşınmış olabilir.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button asChild className="brand-button">
            <Link to={ROUTES.HOME}>
              <Home className="w-4 h-4 mr-2" />
              Ana Sayfaya Dön
            </Link>
          </Button>

          <Button
            variant="outline"
            className="border-brand-purple text-brand-purple hover:bg-brand-purple hover:text-white"
            onClick={() => window.history.back()}
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Geri Dön
          </Button>
        </div>

        <div className="mt-12 text-sm text-muted-foreground">
          <p>Eğer bu bir hata ise, lütfen bizimle iletişime geçin.</p>
        </div>
      </div>
    </div>
  );
};

export default NotFound;
