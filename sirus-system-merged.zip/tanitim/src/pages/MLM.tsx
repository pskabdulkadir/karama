import { useNavigate } from "react-router-dom";
import { useAuth } from "../auth/AuthContext";
import { PageTransition } from "../components/PageTransition";
import { MainLayout } from "../layouts/MainLayout";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Users,
  TrendingUp,
  DollarSign,
  UserPlus,
  Award,
  ArrowLeft,
  Target,
  Network,
} from "lucide-react";

export default function MLM() {
  const { user } = useAuth();
  const navigate = useNavigate();

  const networkStats = [
    {
      label: "Toplam Network",
      value: "156",
      icon: Users,
      color: "text-blue-600",
    },
    {
      label: "Bu Ay Kazanç",
      value: "₺12,450",
      icon: DollarSign,
      color: "text-green-600",
    },
    {
      label: "Aktif Üyeler",
      value: "89",
      icon: UserPlus,
      color: "text-purple-600",
    },
    { label: "Seviye", value: "Gold", icon: Award, color: "text-yellow-600" },
  ];

  const mlmFeatures = [
    {
      title: "Network Ağacı",
      description: "Alt ağınızı ve üst sponsor yapınızı görüntüleyin",
      icon: Network,
      action: () => console.log("Network Ağacı"),
    },
    {
      title: "Komisyon Raporu",
      description: "Kazanç geçmişiniz ve komisyon detayları",
      icon: TrendingUp,
      action: () => console.log("Komisyon Raporu"),
    },
    {
      title: "Yeni Üye Davet",
      description: "Network ağınıza yeni üyeler ekleyin",
      icon: UserPlus,
      action: () => console.log("Yeni Üye Davet"),
    },
    {
      title: "Hedefler",
      description: "Aylık ve yıllık hedeflerinizi takip edin",
      icon: Target,
      action: () => console.log("Hedefler"),
    },
  ];

  return (
    <MainLayout>
      <PageTransition>
        <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50">
          <div className="container mx-auto px-4 py-8">
            {/* Header */}
            <div className="flex items-center justify-between mb-8">
              <div className="flex items-center space-x-4">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => navigate("/portal")}
                  className="flex items-center space-x-2"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>Portala Dön</span>
                </Button>
                <div>
                  <h1 className="text-3xl font-bold text-brand-navy">
                    Network Sistemi
                  </h1>
                  <p className="text-gray-600">MLM ve Network Yönetimi</p>
                </div>
              </div>
            </div>

            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              {networkStats.map((stat, index) => {
                const IconComponent = stat.icon;
                return (
                  <Card key={index} className="brand-card">
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm text-gray-600">{stat.label}</p>
                          <p className={`text-2xl font-bold ${stat.color}`}>
                            {stat.value}
                          </p>
                        </div>
                        <div className={`p-3 rounded-full bg-gray-100`}>
                          <IconComponent className={`w-6 h-6 ${stat.color}`} />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>

            {/* Welcome Card */}
            <Card className="brand-card mb-8 bg-gradient-to-r from-blue-500 to-purple-600 text-white">
              <CardHeader>
                <CardTitle className="text-xl flex items-center space-x-3">
                  <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
                    <Users className="w-6 h-6" />
                  </div>
                  <div>
                    <h2>Hoş geldin, {user?.name}!</h2>
                    <p className="text-sm opacity-90 font-normal">
                      Network seviyeniz: Gold Partner
                    </p>
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="mb-4">
                  Bu ay hedeflerinize %78 ulaştınız. Platinum seviyesine çıkmak
                  için sadece 12 yeni üye kaldı!
                </p>
                <Button className="bg-white text-blue-600 hover:bg-gray-100">
                  Hedef Detayları
                </Button>
              </CardContent>
            </Card>

            {/* MLM Features */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              {mlmFeatures.map((feature, index) => {
                const IconComponent = feature.icon;

                return (
                  <Card
                    key={index}
                    className="brand-card cursor-pointer group"
                    onClick={feature.action}
                  >
                    <CardHeader>
                      <div className="flex items-center space-x-4">
                        <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                          <IconComponent className="w-6 h-6 text-blue-600" />
                        </div>
                        <div>
                          <CardTitle className="text-lg">
                            {feature.title}
                          </CardTitle>
                          <CardDescription>
                            {feature.description}
                          </CardDescription>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <Button className="w-full brand-button">Görüntüle</Button>
                    </CardContent>
                  </Card>
                );
              })}
            </div>

            {/* Recent Activity */}
            <Card className="brand-card">
              <CardHeader>
                <CardTitle>Son Aktiviteler</CardTitle>
                <CardDescription>
                  Network ağınızdaki son gelişmeler
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center space-x-3 p-3 bg-green-50 rounded-lg">
                    <UserPlus className="w-5 h-5 text-green-600" />
                    <div>
                      <p className="font-medium">Yeni üye eklendi</p>
                      <p className="text-sm text-gray-600">
                        Ahmet Yılmaz ağınıza katıldı
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3 p-3 bg-blue-50 rounded-lg">
                    <DollarSign className="w-5 h-5 text-blue-600" />
                    <div>
                      <p className="font-medium">Komisyon kazandınız</p>
                      <p className="text-sm text-gray-600">
                        ₺850 komisyon hesabınıza eklendi
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3 p-3 bg-purple-50 rounded-lg">
                    <Award className="w-5 h-5 text-purple-600" />
                    <div>
                      <p className="font-medium">Seviye yükseltme</p>
                      <p className="text-sm text-gray-600">
                        Platinum seviyesine 12 üye kaldı
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </PageTransition>
    </MainLayout>
  );
}
