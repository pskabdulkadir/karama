import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { WhatsAppService } from "../services/whatsapp";
import { apiService } from "../services/api";
import {
  Phone,
  Calendar,
  Download,
  Play,
  BookOpen,
  Star,
  Heart,
  Brain,
  Zap,
  Eye,
  Sparkles,
  Moon,
  Sun,
  MessageCircle,
  Send,
  ArrowDown,
  Home,
  Video,
  FileText,
  LogIn,
  Menu,
  X,
} from "lucide-react";

export default function KutbulZaman() {
  const [selectedVideoCategory, setSelectedVideoCategory] = useState("Tümü");
  const [isAppointmentOpen, setIsAppointmentOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    email: "",
    service: "",
    message: "",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  // References for smooth scrolling
  const aboutRef = useRef<HTMLElement>(null);
  const servicesRef = useRef<HTMLElement>(null);
  const videosRef = useRef<HTMLElement>(null);
  const booksRef = useRef<HTMLElement>(null);
  const blogRef = useRef<HTMLElement>(null);

  // Smooth scroll function
  const scrollToSection = (ref: React.RefObject<HTMLElement>) => {
    ref.current?.scrollIntoView({
      behavior: "smooth",
      block: "start",
    });
  };

  // Spiritual services
  const spiritualServices = [
    {
      title: "Kuantum Dönüşüm",
      description: "Bilinç seviyenizi yükselterek yaşamsal dönüşüm",
      icon: <Zap className="w-8 h-8" />,
      color: "from-indigo-400 to-purple-600",
    },
    {
      title: "Aile Dizimi",
      description: "Nesiller arası enerji temizliği ve şifa",
      icon: <Heart className="w-8 h-8" />,
      color: "from-purple-400 to-pink-600",
    },
    {
      title: "Enerji/Aura Temizliği",
      description: "Negatif enerjilerden arınma ve korunma",
      icon: <Sparkles className="w-8 h-8" />,
      color: "from-blue-400 to-indigo-600",
    },
    {
      title: "Havas İlmi",
      description: "Kutsal harflerin gücüyle manevi destek",
      icon: <Star className="w-8 h-8" />,
      color: "from-yellow-400 to-orange-600",
    },
    {
      title: "Rüya Tabiri",
      description: "Rüyalarınızdaki manevi mesajları anlama",
      icon: <Moon className="w-8 h-8" />,
      color: "from-indigo-400 to-blue-600",
    },
    {
      title: "Spiritüel Danışmanlık",
      description: "Manevi yolculuğunuzda rehberlik",
      icon: <Sun className="w-8 h-8" />,
      color: "from-orange-400 to-yellow-600",
    },
  ];

  // Video categories and content
  const videoCategories = [
    "Tümü",
    "Manevi Sohbetler",
    "Kuantum Bilinç",
    "Rüya Tabirleri",
    "Enerji Çalışması",
  ];

  const spiritualVideos = [
    {
      title: "Manevi Uyanış Yolculuğu",
      category: "Manevi Sohbetler",
      src: "https://www.youtube.com/embed/kJQP7kiw5Fk",
      thumbnail:
        "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400&h=300&fit=crop&auto=format&q=80",
    },
    {
      title: "Kuantum Bilincin Sırları",
      category: "Kuantum Bilinç",
      src: "https://www.youtube.com/embed/kJQP7kiw5Fk",
      thumbnail:
        "https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=400&h=300&fit=crop&auto=format&q=80",
    },
    {
      title: "Rüyalarda Gizli Mesajlar",
      category: "Rüya Tabirleri",
      src: "https://www.youtube.com/embed/kJQP7kiw5Fk",
      thumbnail:
        "https://images.unsplash.com/photo-1558618047-3c8c76ca7d13?w=400&h=300&fit=crop&auto=format&q=80",
    },
    {
      title: "Enerji Temizliği Teknikleri",
      category: "Enerji Çalışması",
      src: "https://www.youtube.com/embed/kJQP7kiw5Fk",
      thumbnail:
        "https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=400&h=300&fit=crop&auto=format&q=80",
    },
  ];

  const filteredVideos =
    selectedVideoCategory === "Tümü"
      ? spiritualVideos
      : spiritualVideos.filter(
          (video) => video.category === selectedVideoCategory,
        );

  // PDF Books
  const spiritualBooks = [
    {
      title: "Manevi Dönüşüm Rehberi",
      description: "İç yolculuğa çıkacaklar için kapsamlı rehber",
      pages: 120,
      image:
        "https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=300&h=400&fit=crop&auto=format&q=80",
    },
    {
      title: "Kuantum Bilinci ve Şifa",
      description: "Modern fizik ile manevi şifanın buluşması",
      pages: 89,
      image:
        "https://images.unsplash.com/photo-1512820790803-83ca734da794?w=300&h=400&fit=crop&auto=format&q=80",
    },
    {
      title: "Rüya Aleminin Sırları",
      description: "Rüyalar ve manevi mesajlar üzerine derinlemesine inceleme",
      pages: 156,
      image:
        "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&h=400&fit=crop&auto=format&q=80",
    },
  ];

  // Blog articles
  const spiritualArticles = [
    {
      title: "Bilinç Seviyenizi Yükseltmenin 7 Yolu",
      excerpt:
        "Manevi gelişim yolculuğunda bilinç seviyenizi artıracak pratik yöntemler...",
      category: "Bilinç Gelişimi",
      date: "15 Mart 2024",
      readTime: "8 dk",
      image:
        "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400&h=300&fit=crop&auto=format&q=80",
    },
    {
      title: "Enerji Korunma ve Temizlik Ritüelleri",
      excerpt:
        "Günlük hayatta negatif enerjilerden korunmak için uygulanabilir yöntemler...",
      category: "Enerji Çalışması",
      date: "10 Mart 2024",
      readTime: "6 dk",
      image:
        "https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=400&h=300&fit=crop&auto=format&q=80",
    },
    {
      title: "Rüyalarda Görülen Semboller ve Anlamları",
      excerpt: "En yaygın rüya sembolleri ve manevi mesajlarının deşifresi...",
      category: "Rüya Tabiri",
      date: "5 Mart 2024",
      readTime: "10 dk",
      image:
        "https://images.unsplash.com/photo-1558618047-3c8c76ca7d13?w=400&h=300&fit=crop&auto=format&q=80",
    },
  ];

  // Form submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.phone || !formData.email) {
      toast({
        title: "Hata",
        description: "Lütfen zorunlu alanları doldurun.",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);
    try {
      await apiService.submitContactForm(formData);
      toast({
        title: "Başarılı!",
        description:
          "Randevu talebiniz alındı. En kısa sürede size dönüş yapacağız.",
      });
      setFormData({ name: "", phone: "", email: "", service: "", message: "" });
      setIsAppointmentOpen(false);
    } catch (error) {
      toast({
        title: "Hata",
        description: "Bir hata oluştu. Lütfen tekrar deneyin.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  // Download book function
  const downloadBook = (bookTitle: string) => {
    toast({
      title: "İndiriliyor",
      description: `${bookTitle} PDF'i indiriliyor...`,
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-indigo-950 to-purple-950 relative overflow-hidden">
      {/* Animated Stars Background */}
      <div className="stars-container">
        {[...Array(10)].map((_, i) => (
          <div key={i} className={`star star-${i + 1}`}></div>
        ))}
      </div>

      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 glass-effect border-b border-indigo-500/30">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <h1 className="text-xl font-bold spiritual-text-gradient">
              Kutbu'l Zaman Rehberlik
            </h1>

            {/* Desktop Menu */}
            <div className="hidden md:flex items-center gap-6">
              <button
                onClick={() => scrollToSection(aboutRef)}
                className="text-indigo-200/80 hover:text-white transition-colors"
              >
                Ana Sayfa
              </button>
              <button
                onClick={() => scrollToSection(aboutRef)}
                className="text-indigo-200/80 hover:text-white transition-colors"
              >
                Hakkımızda
              </button>
              <button
                onClick={() => scrollToSection(videosRef)}
                className="text-indigo-200/80 hover:text-white transition-colors"
              >
                Videolar
              </button>
              <button
                onClick={() => scrollToSection(booksRef)}
                className="text-indigo-200/80 hover:text-white transition-colors"
              >
                Kitaplar
              </button>
              <Dialog
                open={isAppointmentOpen}
                onOpenChange={setIsAppointmentOpen}
              >
                <DialogTrigger asChild>
                  <button className="text-indigo-200/80 hover:text-white transition-colors">
                    Randevu
                  </button>
                </DialogTrigger>
              </Dialog>
              <button className="text-indigo-200/80 hover:text-white transition-colors">
                Giriş
              </button>
            </div>

            {/* Desktop WhatsApp Button */}
            <Button
              onClick={() => WhatsAppService.openChat()}
              size="sm"
              className="hidden md:flex spiritual-gradient text-white border-0 hover:opacity-90 holy-glow"
            >
              <MessageCircle className="w-4 h-4 mr-2" />
              WhatsApp
            </Button>

            {/* Mobile Menu Button */}
            <Button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              variant="outline"
              size="sm"
              className="md:hidden border-indigo-400 text-indigo-200"
            >
              {isMobileMenuOpen ? (
                <X className="w-4 h-4" />
              ) : (
                <Menu className="w-4 h-4" />
              )}
            </Button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden glass-effect border-t border-indigo-500/30">
            <div className="px-4 py-4 space-y-4">
              <button
                onClick={() => {
                  scrollToSection(aboutRef);
                  setIsMobileMenuOpen(false);
                }}
                className="block w-full text-left text-indigo-200/80 hover:text-white transition-colors py-2"
              >
                Ana Sayfa
              </button>
              <button
                onClick={() => {
                  scrollToSection(aboutRef);
                  setIsMobileMenuOpen(false);
                }}
                className="block w-full text-left text-indigo-200/80 hover:text-white transition-colors py-2"
              >
                Hakkımızda
              </button>
              <button
                onClick={() => {
                  scrollToSection(videosRef);
                  setIsMobileMenuOpen(false);
                }}
                className="block w-full text-left text-indigo-200/80 hover:text-white transition-colors py-2"
              >
                Videolar
              </button>
              <button
                onClick={() => {
                  scrollToSection(booksRef);
                  setIsMobileMenuOpen(false);
                }}
                className="block w-full text-left text-indigo-200/80 hover:text-white transition-colors py-2"
              >
                Kitaplar
              </button>
              <Dialog
                open={isAppointmentOpen}
                onOpenChange={setIsAppointmentOpen}
              >
                <DialogTrigger asChild>
                  <button
                    onClick={() => setIsMobileMenuOpen(false)}
                    className="block w-full text-left text-indigo-200/80 hover:text-white transition-colors py-2"
                  >
                    Randevu
                  </button>
                </DialogTrigger>
              </Dialog>
              <Button
                onClick={() => WhatsAppService.openChat()}
                size="sm"
                className="w-full spiritual-gradient text-white border-0 hover:opacity-90"
              >
                <MessageCircle className="w-4 h-4 mr-2" />
                WhatsApp
              </Button>
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center px-4 pt-20">
        <div className="relative z-10 text-center max-w-5xl mx-auto">
          <div className="mb-12 fade-in-up">
            <h1 className="text-6xl md:text-8xl font-bold mb-8 spiritual-text-gradient floating">
              Kutbu'l Zaman
            </h1>
            <div className="text-2xl md:text-4xl text-indigo-100 mb-6 font-light">
              <span className="typing-animation inline-block">
                "Edep ile gelen, lütuf ile döner"
              </span>
            </div>
            <p className="text-lg md:text-xl text-indigo-200/80 mb-12 font-light max-w-3xl mx-auto">
              Manevi rehberlik ve kişisel gelişim yolculuğunuzda
              <br />
              size eşlik etmek için buradayız
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Dialog
              open={isAppointmentOpen}
              onOpenChange={setIsAppointmentOpen}
            >
              <DialogTrigger asChild>
                <Button
                  size="lg"
                  className="spiritual-gradient text-white border-0 hover:opacity-90 holy-glow"
                >
                  <Calendar className="w-5 h-5 mr-2" />
                  Randevu Al
                </Button>
              </DialogTrigger>
            </Dialog>
            <Button
              onClick={() => scrollToSection(servicesRef)}
              size="lg"
              variant="outline"
              className="border-indigo-400 text-indigo-200 hover:bg-indigo-400 hover:text-white"
            >
              Hizmetlerimiz
            </Button>
          </div>

          <div className="flex justify-center">
            <button
              onClick={() => scrollToSection(aboutRef)}
              className="text-indigo-300 hover:text-white transition-colors animate-bounce"
            >
              <ArrowDown className="w-6 h-6" />
            </button>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section ref={aboutRef} className="py-20 px-4 relative z-10">
        <div className="max-w-6xl mx-auto text-center">
          <h2 className="text-4xl font-bold mb-8 spiritual-text-gradient">
            Hakkımızda
          </h2>
          <div className="max-w-4xl mx-auto">
            <p className="text-lg text-indigo-100/80 leading-relaxed mb-8">
              Kutbu'l Zaman, manevi gelişim ve kişisel dönüşüm alanında size
              rehberlik etmek için kurulmuş bir danışmanlık merkezidir.
              Geleneksel bilgelikle modern yaklaşımları harmanlayarak, her
              bireyin kendi içindeki potansiyeli keşfetmesine yardımcı oluyoruz.
            </p>
            <p className="text-lg text-indigo-100/80 leading-relaxed">
              Misyonumuz, manevi uyanış ve bilinç gelişimi yolculuğunda
              danışanlarımıza ışık tutmak, onların yaşamlarında denge ve huzuru
              bulmalarına destek olmaktır.
            </p>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section ref={servicesRef} className="py-20 px-4 relative z-10">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4 spiritual-text-gradient">
              Manevi Hizmetlerimiz
            </h2>
            <p className="text-xl text-indigo-200/80">
              Ruhsal yolculuğunuzda size eşlik eden hizmetlerimiz
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {spiritualServices.map((service, index) => (
              <Card
                key={index}
                className="glass-effect border-indigo-500/30 hover:border-indigo-400/60 transition-all group holy-glow hover:scale-105"
              >
                <CardHeader className="text-center">
                  <div
                    className={`w-16 h-16 rounded-full bg-gradient-to-r ${service.color} p-4 mx-auto mb-4 group-hover:scale-110 transition-transform`}
                  >
                    <div className="text-white">{service.icon}</div>
                  </div>
                  <CardTitle className="text-xl text-white">
                    {service.title}
                  </CardTitle>
                  <CardDescription className="text-indigo-200/70">
                    {service.description}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Dialog
                    open={isAppointmentOpen}
                    onOpenChange={setIsAppointmentOpen}
                  >
                    <DialogTrigger asChild>
                      <Button
                        variant="outline"
                        className="w-full border-indigo-400 text-indigo-200 hover:bg-indigo-400 hover:text-white"
                      >
                        Bilgi Al
                      </Button>
                    </DialogTrigger>
                  </Dialog>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Appointment Dialog */}
      <Dialog open={isAppointmentOpen} onOpenChange={setIsAppointmentOpen}>
        <DialogContent className="glass-effect border-indigo-500/30 text-white max-w-md">
          <DialogHeader>
            <DialogTitle className="spiritual-text-gradient text-center">
              Randevu Talebi
            </DialogTitle>
            <DialogDescription className="text-indigo-200/70 text-center">
              Manevi danışmanlık için randevu talep edin
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-indigo-200 mb-2 font-medium text-sm">
                İsim Soyisim *
              </label>
              <Input
                value={formData.name}
                onChange={(e) =>
                  setFormData({ ...formData, name: e.target.value })
                }
                className="bg-indigo-950/30 border-indigo-500/50 text-white placeholder:text-indigo-300/50"
                placeholder="Adınızı girin"
                required
              />
            </div>

            <div>
              <label className="block text-indigo-200 mb-2 font-medium text-sm">
                Telefon *
              </label>
              <Input
                value={formData.phone}
                onChange={(e) =>
                  setFormData({ ...formData, phone: e.target.value })
                }
                className="bg-indigo-950/30 border-indigo-500/50 text-white placeholder:text-indigo-300/50"
                placeholder="Telefon numaranızı girin"
                required
              />
            </div>

            <div>
              <label className="block text-indigo-200 mb-2 font-medium text-sm">
                E-posta *
              </label>
              <Input
                type="email"
                value={formData.email}
                onChange={(e) =>
                  setFormData({ ...formData, email: e.target.value })
                }
                className="bg-indigo-950/30 border-indigo-500/50 text-white placeholder:text-indigo-300/50"
                placeholder="E-posta adresinizi girin"
                required
              />
            </div>

            <div>
              <label className="block text-indigo-200 mb-2 font-medium text-sm">
                İlgilendiğiniz Hizmet
              </label>
              <Input
                value={formData.service}
                onChange={(e) =>
                  setFormData({ ...formData, service: e.target.value })
                }
                className="bg-indigo-950/30 border-indigo-500/50 text-white placeholder:text-indigo-300/50"
                placeholder="Hangi hizmetimizle ilgileniyorsunuz?"
              />
            </div>

            <div>
              <label className="block text-indigo-200 mb-2 font-medium text-sm">
                Mesaj
              </label>
              <Textarea
                value={formData.message}
                onChange={(e) =>
                  setFormData({ ...formData, message: e.target.value })
                }
                className="bg-indigo-950/30 border-indigo-500/50 text-white placeholder:text-indigo-300/50 min-h-20"
                placeholder="Mesajınızı yazın..."
              />
            </div>

            <div className="flex gap-3 pt-4">
              <Button
                type="submit"
                disabled={isSubmitting}
                className="flex-1 spiritual-gradient text-white border-0 hover:opacity-90 holy-glow"
              >
                {isSubmitting ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2"></div>
                    Gönderiliyor...
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4 mr-2" />
                    Gönder
                  </>
                )}
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={() => WhatsAppService.openChat()}
                className="border-indigo-400 text-indigo-200 hover:bg-indigo-400 hover:text-white"
              >
                <MessageCircle className="w-4 h-4" />
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Footer */}
      <footer className="bg-indigo-950/40 py-12 px-4 border-t border-indigo-500/30 relative z-10">
        <div className="max-w-6xl mx-auto text-center">
          <h3 className="text-2xl font-bold spiritual-text-gradient mb-4">
            Kutbu'l Zaman Rehberlik
          </h3>
          <p className="text-indigo-200/70 mb-6">
            "Edep ile gelen, lütuf ile döner"
          </p>
          <div className="flex justify-center gap-6 text-sm text-indigo-200/60">
            <span>© 2024 Tüm hakları saklıdır.</span>
            <span>•</span>
            <span>Manevi rehberlik ve kişisel gelişim</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
