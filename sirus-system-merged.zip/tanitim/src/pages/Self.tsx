import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../auth/AuthContext";
import { PageTransition } from "../components/PageTransition";
import { MainLayout } from "../layouts/MainLayout";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Heart,
  Brain,
  Calendar,
  BookOpen,
  Play,
  ArrowLeft,
  Clock,
  User,
  Target,
  Award,
} from "lucide-react";

const THERAPY_SERVICES = [
  {
    id: 1,
    title: "Kuantum Terapisi",
    description: "Bilinç seviyenizi yükselterek yaşamsal dönüşüm",
    duration: "60 dk",
    price: "₺400",
    category: "Terapi",
    icon: Brain,
  },
  {
    id: 2,
    title: "Aile Dizimi",
    description: "Nesiller arası enerji temizliği ve şifa",
    duration: "90 dk",
    price: "₺600",
    category: "Terapi",
    icon: Heart,
  },
  {
    id: 3,
    title: "Rüya Analizi",
    description: "Rüyalarınızdaki manevi mesajları anlama",
    duration: "45 dk",
    price: "₺300",
    category: "Analiz",
    icon: BookOpen,
  },
  {
    id: 4,
    title: "Spiritüel Danışmanlık",
    description: "Manevi yolculuğunuzda rehberlik",
    duration: "75 dk",
    price: "₺500",
    category: "Danışmanlık",
    icon: Target,
  },
];

const DEVELOPMENT_PROGRAMS = [
  {
    title: "7 Günlük Bilinç Dönüşümü",
    description: "Günlük meditasyon ve farkındalık egzersizleri",
    lessons: 7,
    duration: "1 hafta",
    level: "Başlangıç",
  },
  {
    title: "Çakra Balans Kursu",
    description: "Enerji merkezlerinizi dengeleme teknikleri",
    lessons: 14,
    duration: "2 hafta",
    level: "Orta",
  },
  {
    title: "İleri Meditasyon",
    description: "Derin meditasyon ve spiritüel gelişim",
    lessons: 21,
    duration: "3 hafta",
    level: "İleri",
  },
];

export default function Self() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [selectedService, setSelectedService] = useState<number | null>(null);

  const userProgress = {
    completedSessions: 12,
    totalPrograms: 3,
    achievements: 8,
    nextAppointment: "15 Ocak 2024, 14:00",
  };

  return (
    <MainLayout>
      <PageTransition>
        <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50">
          <div className="container mx-auto px-4 py-8">
            {/* Header */}
            <div className="flex items-center justify-between mb-8">
              <div className="flex items-center space-x-4">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => navigate("/portal")}
                  className="flex items-center space-x-2"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>Portala Dön</span>
                </Button>
                <div>
                  <h1 className="text-3xl font-bold text-brand-navy">
                    Kişisel Gelişim
                  </h1>
                  <p className="text-gray-600">
                    Psikoloji ve terapi hizmetleri
                  </p>
                </div>
              </div>
            </div>

            {/* User Progress Overview */}
            <Card className="brand-card mb-8 bg-gradient-to-r from-purple-500 to-pink-500 text-white">
              <CardHeader>
                <CardTitle className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
                    <Heart className="w-6 h-6" />
                  </div>
                  <div>
                    <h2 className="text-xl">Kişisel Gelişim Yolculuğunuz</h2>
                    <p className="text-sm opacity-90 font-normal">
                      Hoş geldin, {user?.name}!
                    </p>
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold">
                      {userProgress.completedSessions}
                    </div>
                    <div className="text-sm opacity-90">Tamamlanan Seans</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold">
                      {userProgress.totalPrograms}
                    </div>
                    <div className="text-sm opacity-90">Aktif Program</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold">
                      {userProgress.achievements}
                    </div>
                    <div className="text-sm opacity-90">Başarı</div>
                  </div>
                  <div className="text-center">
                    <div className="text-sm opacity-90">Sonraki Randevu</div>
                    <div className="text-sm font-medium">
                      {userProgress.nextAppointment}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Therapy Services */}
            <div className="mb-8">
              <h2 className="text-2xl font-bold text-brand-navy mb-6">
                Terapi Hizmetleri
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {THERAPY_SERVICES.map((service) => {
                  const IconComponent = service.icon;
                  return (
                    <Card
                      key={service.id}
                      className={`brand-card cursor-pointer transition-all duration-300 ${
                        selectedService === service.id
                          ? "ring-2 ring-purple-500 shadow-lg"
                          : ""
                      }`}
                      onClick={() => setSelectedService(service.id)}
                    >
                      <CardHeader>
                        <div className="flex items-start justify-between">
                          <div className="flex items-center space-x-3">
                            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                              <IconComponent className="w-6 h-6 text-purple-600" />
                            </div>
                            <div>
                              <CardTitle className="text-lg">
                                {service.title}
                              </CardTitle>
                              <div className="flex items-center space-x-4 text-sm text-gray-600">
                                <span className="flex items-center">
                                  <Clock className="w-4 h-4 mr-1" />
                                  {service.duration}
                                </span>
                                <span className="font-medium text-brand-navy">
                                  {service.price}
                                </span>
                              </div>
                            </div>
                          </div>
                        </div>
                        <CardDescription>{service.description}</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <Button className="w-full brand-button">
                          Randevu Al
                        </Button>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </div>

            {/* Development Programs */}
            <div className="mb-8">
              <h2 className="text-2xl font-bold text-brand-navy mb-6">
                Gelişim Programları
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {DEVELOPMENT_PROGRAMS.map((program, index) => (
                  <Card key={index} className="brand-card">
                    <CardHeader>
                      <div className="flex items-center justify-between mb-2">
                        <CardTitle className="text-lg">
                          {program.title}
                        </CardTitle>
                        <span className="text-xs bg-purple-100 text-purple-700 px-2 py-1 rounded">
                          {program.level}
                        </span>
                      </div>
                      <CardDescription>{program.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center justify-between text-sm text-gray-600 mb-4">
                        <span>{program.lessons} Ders</span>
                        <span>{program.duration}</span>
                      </div>
                      <Button className="w-full brand-button-secondary">
                        <Play className="w-4 h-4 mr-2" />
                        Başla
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            {/* Quick Actions */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className="brand-card cursor-pointer group">
                <CardContent className="p-6 text-center">
                  <Calendar className="w-12 h-12 text-purple-600 mx-auto mb-3 group-hover:scale-110 transition-transform duration-300" />
                  <h3 className="font-semibold mb-2">Randevularım</h3>
                  <p className="text-sm text-gray-600 mb-4">
                    Gelecek ve geçmiş randevularınızı görüntüleyin
                  </p>
                  <Button variant="outline" className="w-full">
                    Görüntüle
                  </Button>
                </CardContent>
              </Card>

              <Card className="brand-card cursor-pointer group">
                <CardContent className="p-6 text-center">
                  <User className="w-12 h-12 text-blue-600 mx-auto mb-3 group-hover:scale-110 transition-transform duration-300" />
                  <h3 className="font-semibold mb-2">Terapistlerim</h3>
                  <p className="text-sm text-gray-600 mb-4">
                    Çalıştığınız uzmanlar ve iletişim bilgileri
                  </p>
                  <Button variant="outline" className="w-full">
                    Görüntüle
                  </Button>
                </CardContent>
              </Card>

              <Card className="brand-card cursor-pointer group">
                <CardContent className="p-6 text-center">
                  <Award className="w-12 h-12 text-yellow-600 mx-auto mb-3 group-hover:scale-110 transition-transform duration-300" />
                  <h3 className="font-semibold mb-2">Başarılarım</h3>
                  <p className="text-sm text-gray-600 mb-4">
                    Kişisel gelişim yolculuğunuzdaki kilometre taşları
                  </p>
                  <Button variant="outline" className="w-full">
                    Görüntüle
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </PageTransition>
    </MainLayout>
  );
}
