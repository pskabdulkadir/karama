import { useNavigate } from "react-router-dom";
import { useAuth } from "../auth/AuthContext";
import { PageTransition } from "../components/PageTransition";
import { ProtectedRoute } from "../components/ProtectedRoute";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Users,
  ShoppingCart,
  User,
  Settings,
  Heart,
  ArrowRight,
} from "lucide-react";

const SYSTEM_CARDS = [
  {
    id: "panel",
    title: "Kullanıcı Paneli",
    description: "Genel kullanıcı yönetim paneli",
    icon: User,
    path: "/panel",
    color: "bg-brand-navy",
    requiredRoles: ["user", "admin", "mlm", "psychologist", "merchant"],
  },
  {
    id: "mlm",
    title: "Network Sistemi",
    description: "MLM ve network yönetimi",
    icon: Users,
    path: "/mlm",
    color: "bg-blue-600",
    requiredRoles: ["mlm", "admin"],
  },
  {
    id: "shop",
    title: "Alışveriş",
    description: "E-ticaret ve satış sistemi",
    icon: ShoppingCart,
    path: "/shop",
    color: "bg-green-600",
    requiredRoles: ["merchant", "admin", "user"],
  },
  {
    id: "self",
    title: "Kişisel Gelişim",
    description: "Psikoloji ve terapi hizmetleri",
    icon: Heart,
    path: "/self",
    color: "bg-purple-600",
    requiredRoles: ["psychologist", "admin", "user"],
  },
  {
    id: "admin",
    title: "Yönetim",
    description: "Sistem yönetimi ve ayarları",
    icon: Settings,
    path: "/admin",
    color: "bg-red-600",
    requiredRoles: ["admin"],
  },
];

export default function Portal() {
  const { user } = useAuth();
  const navigate = useNavigate();

  const getAccessibleSystems = () => {
    if (!user) return [];

    return SYSTEM_CARDS.filter((system) =>
      system.requiredRoles.includes(user.role),
    );
  };

  const handleSystemSelect = (path: string) => {
    navigate(path);
  };

  const accessibleSystems = getAccessibleSystems();

  return (
    <ProtectedRoute>
      <PageTransition>
        <div className="min-h-screen bg-gradient-to-br from-brand-navy via-brand-navy-light to-brand-navy-dark">
          <div className="container mx-auto px-4 py-12">
            <div className="text-center mb-12">
              <h1 className="text-4xl font-bold text-white mb-4">
                Sistem Portalı
              </h1>
              <p className="text-brand-gold text-lg">
                Hoş geldin, {user.name}! Erişim izniniz olan sistemleri seçin.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
              {accessibleSystems.map((system) => {
                const IconComponent = system.icon;

                return (
                  <Card
                    key={system.id}
                    className="brand-card bg-white/10 border-white/20 backdrop-blur-md hover:bg-white/20 transition-all duration-300 cursor-pointer group"
                    onClick={() => handleSystemSelect(system.path)}
                  >
                    <CardHeader className="text-center">
                      <div
                        className={`w-16 h-16 ${system.color} rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300`}
                      >
                        <IconComponent className="w-8 h-8 text-white" />
                      </div>
                      <CardTitle className="text-white text-xl">
                        {system.title}
                      </CardTitle>
                      <CardDescription className="text-brand-gold">
                        {system.description}
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="text-center">
                      <Button
                        className="brand-button-secondary w-full group-hover:shadow-gold-glow"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleSystemSelect(system.path);
                        }}
                      >
                        Sisteme Gir
                        <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform duration-300" />
                      </Button>
                    </CardContent>
                  </Card>
                );
              })}
            </div>

            {accessibleSystems.length === 0 && (
              <div className="text-center py-12">
                <p className="text-white text-lg">
                  Herhangi bir sisteme erişim izniniz bulunmuyor.
                </p>
                <p className="text-brand-gold">
                  Lütfen yöneticinizle iletişime geçin.
                </p>
              </div>
            )}

            <div className="text-center mt-12">
              <Button
                variant="outline"
                className="border-brand-gold text-brand-gold hover:bg-brand-gold hover:text-brand-navy"
                onClick={() => navigate("/")}
              >
                Ana Sayfaya Dön
              </Button>
            </div>
          </div>
        </div>
      </PageTransition>
    </ProtectedRoute>
  );
}
