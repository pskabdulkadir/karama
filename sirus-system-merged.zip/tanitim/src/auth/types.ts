export type UserRole = "user" | "admin" | "mlm" | "psychologist" | "merchant";

export type SystemType = "mlm" | "ecommerce" | "development" | "panel";

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  isActive: boolean;
  // Additional optional fields for internal use
  token?: string;
  avatar?: string;
  phone?: string;
  createdAt?: string;
  lastLogin?: string;
}

export interface GlobalContextState {
  user: {
    id: string;
    name: string;
    email: string;
    role: UserRole;
    isActive: boolean;
  };
  isAuthenticated: boolean;
  currentSystem: SystemType;
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  currentSystem: SystemType;
  isLoading: boolean;
  error: string | null;
}

export interface LoginCredentials {
  email: string;
  password: string;
}

export interface RegisterData {
  name: string;
  email: string;
  phone?: string;
  password: string;
  role?: UserRole;
}

export interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  currentSystem: SystemType;
  isLoading: boolean;
  error: string | null;
  login: (credentials: LoginCredentials) => Promise<boolean>;
  logout: () => void;
  register: (data: RegisterData) => Promise<boolean>;
  clearError: () => void;
  hasRole: (role: UserRole) => boolean;
  hasAnyRole: (roles: UserRole[]) => boolean;
  updateUser: (userData: Partial<User>) => void;
  setCurrentSystem: (system: SystemType) => void;
  getGlobalState: () => GlobalContextState | null;
}

// Role permissions mapping
export const ROLE_PERMISSIONS = {
  user: {
    canView: ["home", "about", "services", "profile", "appointments"],
    canAccess: ["profile", "appointments", "notifications"],
    systems: ["ecommerce", "development"] as SystemType[],
  },
  admin: {
    canView: ["*"],
    canAccess: ["*"],
    canManage: ["users", "content", "settings"],
    systems: ["mlm", "ecommerce", "development", "panel"] as SystemType[],
  },
  mlm: {
    canView: [
      "home",
      "about",
      "services",
      "profile",
      "mlm-dashboard",
      "network",
    ],
    canAccess: ["profile", "mlm-dashboard", "network", "commissions"],
    canManage: ["network", "sales"],
    systems: ["mlm", "ecommerce"] as SystemType[],
  },
  psychologist: {
    canView: [
      "home",
      "about",
      "services",
      "profile",
      "appointments",
      "clients",
    ],
    canAccess: ["profile", "appointments", "clients", "calendar"],
    canManage: ["appointments", "client-notes"],
    systems: ["development", "panel"] as SystemType[],
  },
  merchant: {
    canView: ["home", "about", "services", "profile", "products", "orders"],
    canAccess: ["profile", "products", "orders", "inventory"],
    canManage: ["products", "orders", "inventory"],
    systems: ["ecommerce", "panel"] as SystemType[],
  },
} as const;

export type Permission = keyof (typeof ROLE_PERMISSIONS)[UserRole];
export type Resource = string;
