import { ReactNode } from "react";
import { Navigate, useLocation } from "react-router-dom";
import { UserRole } from "./types";
import { useAuth, useRoleAccess } from "./AuthContext";
import { ROUTES } from "../constants";

interface RoleGuardProps {
  children: ReactNode;
  allowedRoles: UserRole | UserRole[];
  fallbackComponent?: ReactNode;
  redirectTo?: string;
  requireAuth?: boolean;
}

/**
 * RoleGuard component for protecting routes based on user roles
 */
export function RoleGuard({
  children,
  allowedRoles,
  fallbackComponent,
  redirectTo,
  requireAuth = true,
}: RoleGuardProps) {
  const { isAuthenticated, isLoading } = useAuth();
  const { hasAccess } = useRoleAccess(allowedRoles);
  const location = useLocation();

  // Show loading while checking authentication
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-brand-teal border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-brand-purple">Yükleniyor...</p>
        </div>
      </div>
    );
  }

  // If authentication is required but user is not authenticated
  if (requireAuth && !isAuthenticated) {
    return (
      <Navigate
        to={redirectTo || ROUTES.LOGIN}
        state={{ from: location.pathname }}
        replace
      />
    );
  }

  // If user doesn't have required role
  if (isAuthenticated && !hasAccess) {
    if (fallbackComponent) {
      return <>{fallbackComponent}</>;
    }

    return (
      <div className="min-h-screen flex items-center justify-center px-4">
        <div className="text-center max-w-md">
          <div className="text-6xl mb-4">🚫</div>
          <h1 className="text-2xl font-bold text-brand-purple mb-4">
            Erişim Yetkisi Yok
          </h1>
          <p className="text-muted-foreground mb-6">
            Bu sayfayı görüntülemek için gerekli yetkiye sahip değilsiniz.
          </p>
          <button
            onClick={() => window.history.back()}
            className="brand-button px-6 py-2 rounded-xl"
          >
            Geri Dön
          </button>
        </div>
      </div>
    );
  }

  return <>{children}</>;
}

interface ConditionalRenderProps {
  children: ReactNode;
  allowedRoles: UserRole | UserRole[];
  fallback?: ReactNode;
  requireAuth?: boolean;
}

/**
 * ConditionalRender component for conditionally rendering content based on roles
 */
export function ConditionalRender({
  children,
  allowedRoles,
  fallback = null,
  requireAuth = true,
}: ConditionalRenderProps) {
  const { isAuthenticated } = useAuth();
  const { hasAccess } = useRoleAccess(allowedRoles);

  if (requireAuth && !isAuthenticated) {
    return <>{fallback}</>;
  }

  if (isAuthenticated && !hasAccess) {
    return <>{fallback}</>;
  }

  return <>{children}</>;
}

interface ProtectedLinkProps {
  children: ReactNode;
  allowedRoles: UserRole | UserRole[];
  to: string;
  className?: string;
  onClick?: () => void;
}

/**
 * ProtectedLink component for role-based navigation links
 */
export function ProtectedLink({
  children,
  allowedRoles,
  to,
  className,
  onClick,
}: ProtectedLinkProps) {
  const { hasAccess } = useRoleAccess(allowedRoles);

  if (!hasAccess) {
    return null;
  }

  return (
    <a href={to} className={className} onClick={onClick}>
      {children}
    </a>
  );
}

// Higher-order component for protecting entire components
export function withRoleGuard<P extends object>(
  Component: React.ComponentType<P>,
  allowedRoles: UserRole | UserRole[],
) {
  return function ProtectedComponent(props: P) {
    return (
      <RoleGuard allowedRoles={allowedRoles}>
        <Component {...props} />
      </RoleGuard>
    );
  };
}

// Custom hook for role-based feature flags
export function useFeatureFlag(feature: string) {
  const { user } = useAuth();

  const featureFlags = {
    admin: ["user-management", "system-settings", "analytics"],
    mlm: ["network-view", "commission-tracking", "referral-system"],
    psychologist: ["client-management", "appointment-scheduling", "notes"],
    merchant: ["product-management", "order-tracking", "inventory"],
    user: ["profile-edit", "appointment-booking"],
    guest: [],
  };

  const userFlags = user?.role ? featureFlags[user.role] || [] : [];
  return userFlags.includes(feature);
}
