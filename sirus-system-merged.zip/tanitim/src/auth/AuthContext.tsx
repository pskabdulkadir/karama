import {
  createContext,
  useContext,
  useState,
  useEffect,
  ReactNode,
  useCallback,
} from "react";
import {
  User,
  UserRole,
  SystemType,
  AuthState,
  AuthContextType,
  LoginCredentials,
  RegisterData,
  GlobalContextState,
  ROLE_PERMISSIONS,
} from "./types";
import { STORAGE_KEYS } from "../constants";
import { authService } from "../services/auth";

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<AuthState>({
    user: null,
    isAuthenticated: false,
    currentSystem: "development",
    isLoading: true,
    error: null,
  });

  // Initialize auth state from localStorage
  useEffect(() => {
    const initializeAuth = async () => {
      try {
        const savedUser = localStorage.getItem(STORAGE_KEYS.USER);
        const savedToken = localStorage.getItem(STORAGE_KEYS.AUTH_TOKEN);
        const savedSystem = localStorage.getItem(
          STORAGE_KEYS.CURRENT_SYSTEM,
        ) as SystemType;

        if (savedUser && savedToken) {
          const user: User = JSON.parse(savedUser);

          // Verify token is still valid
          const isValid = await authService.verifyToken(savedToken);

          if (isValid) {
            setState({
              user: { ...user, token: savedToken },
              isAuthenticated: true,
              currentSystem: savedSystem || "development",
              isLoading: false,
              error: null,
            });
          } else {
            // Token is invalid, clear storage
            localStorage.removeItem(STORAGE_KEYS.USER);
            localStorage.removeItem(STORAGE_KEYS.AUTH_TOKEN);
            localStorage.removeItem(STORAGE_KEYS.CURRENT_SYSTEM);
            setState({
              user: null,
              isAuthenticated: false,
              currentSystem: "development",
              isLoading: false,
              error: null,
            });
          }
        } else {
          setState({
            user: null,
            isAuthenticated: false,
            currentSystem: savedSystem || "development",
            isLoading: false,
            error: null,
          });
        }
      } catch (error) {
        console.error("Auth initialization error:", error);
        setState({
          user: null,
          isAuthenticated: false,
          currentSystem: "development",
          isLoading: false,
          error: "Kimlik doğrulama başlatılamadı",
        });
      }
    };

    initializeAuth();
  }, []);

  const login = async (credentials: LoginCredentials): Promise<boolean> => {
    setState((prev) => ({ ...prev, isLoading: true, error: null }));

    try {
      const response = await authService.login(credentials);

      if (response.success && response.user && response.token) {
        const user: User = {
          id: response.user.id || response.user.userId,
          name: response.user.name || response.user.fullName,
          email: response.user.email,
          role: response.user.role,
          isActive: response.user.isActive ?? true,
          token: response.token,
          avatar: response.user.avatar,
          phone: response.user.phone,
          createdAt: response.user.createdAt,
          lastLogin: new Date().toISOString(),
        };

        // Determine default system based on role
        const defaultSystem = getDefaultSystemForRole(user.role);

        // Save to localStorage
        localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(user));
        localStorage.setItem(STORAGE_KEYS.AUTH_TOKEN, response.token);
        localStorage.setItem(STORAGE_KEYS.CURRENT_SYSTEM, defaultSystem);

        setState({
          user,
          isAuthenticated: true,
          currentSystem: defaultSystem,
          isLoading: false,
          error: null,
        });

        return true;
      } else {
        setState((prev) => ({
          ...prev,
          isLoading: false,
          error: response.error || "Giriş başarısız",
        }));
        return false;
      }
    } catch (error) {
      setState((prev) => ({
        ...prev,
        isLoading: false,
        error: "Bağlantı hatası oluştu",
      }));
      return false;
    }
  };

  const register = async (data: RegisterData): Promise<boolean> => {
    setState((prev) => ({ ...prev, isLoading: true, error: null }));

    try {
      const response = await authService.register(data);

      if (response.success && response.user && response.token) {
        const user: User = {
          id: response.user.id || response.user.userId,
          name: response.user.name || response.user.fullName || data.name,
          email: response.user.email,
          role: response.user.role || "user",
          isActive: response.user.isActive ?? true,
          token: response.token,
          avatar: response.user.avatar,
          phone: response.user.phone,
          createdAt: new Date().toISOString(),
          lastLogin: new Date().toISOString(),
        };

        // Determine default system based on role
        const defaultSystem = getDefaultSystemForRole(user.role);

        // Save to localStorage
        localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(user));
        localStorage.setItem(STORAGE_KEYS.AUTH_TOKEN, response.token);
        localStorage.setItem(STORAGE_KEYS.CURRENT_SYSTEM, defaultSystem);

        setState({
          user,
          isAuthenticated: true,
          currentSystem: defaultSystem,
          isLoading: false,
          error: null,
        });

        return true;
      } else {
        setState((prev) => ({
          ...prev,
          isLoading: false,
          error: response.error || "Kayıt başarısız",
        }));
        return false;
      }
    } catch (error) {
      setState((prev) => ({
        ...prev,
        isLoading: false,
        error: "Bağlantı hatası oluştu",
      }));
      return false;
    }
  };

  const logout = useCallback(() => {
    // Clear localStorage
    localStorage.removeItem(STORAGE_KEYS.USER);
    localStorage.removeItem(STORAGE_KEYS.AUTH_TOKEN);
    localStorage.removeItem(STORAGE_KEYS.CURRENT_SYSTEM);

    // Reset state
    setState({
      user: null,
      isAuthenticated: false,
      currentSystem: "development",
      isLoading: false,
      error: null,
    });

    // Optional: Call logout API to invalidate token on server
    if (state.user?.token) {
      authService.logout(state.user.token).catch(console.error);
    }
  }, [state.user?.token]);

  const clearError = useCallback(() => {
    setState((prev) => ({ ...prev, error: null }));
  }, []);

  const hasRole = useCallback(
    (role: UserRole): boolean => {
      return state.user?.role === role;
    },
    [state.user?.role],
  );

  const hasAnyRole = useCallback(
    (roles: UserRole[]): boolean => {
      return state.user ? roles.includes(state.user.role) : false;
    },
    [state.user],
  );

  const updateUser = useCallback((userData: Partial<User>) => {
    setState((prev) => {
      if (!prev.user) return prev;

      const updatedUser = { ...prev.user, ...userData };

      // Update localStorage
      localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(updatedUser));

      return {
        ...prev,
        user: updatedUser,
      };
    });
  }, []);

  const setCurrentSystem = useCallback(
    (system: SystemType) => {
      // Check if user has access to this system
      if (
        state.user?.role &&
        ROLE_PERMISSIONS[state.user.role].systems.includes(system)
      ) {
        setState((prev) => ({
          ...prev,
          currentSystem: system,
        }));
        localStorage.setItem(STORAGE_KEYS.CURRENT_SYSTEM, system);
      } else {
        console.warn(
          `User role ${state.user?.role} does not have access to system ${system}`,
        );
      }
    },
    [state.user?.role],
  );

  const getGlobalState = useCallback((): GlobalContextState | null => {
    if (!state.user || !state.isAuthenticated) {
      return null;
    }

    return {
      user: {
        id: state.user.id,
        name: state.user.name,
        email: state.user.email,
        role: state.user.role,
        isActive: state.user.isActive,
      },
      isAuthenticated: state.isAuthenticated,
      currentSystem: state.currentSystem,
    };
  }, [state.user, state.isAuthenticated, state.currentSystem]);

  // Auto-logout on token expiration
  useEffect(() => {
    let timeoutId: NodeJS.Timeout;

    if (state.user?.token) {
      // Check token expiration every 5 minutes
      timeoutId = setInterval(
        async () => {
          try {
            const isValid = await authService.verifyToken(state.user.token);
            if (!isValid) {
              logout();
            }
          } catch (error) {
            console.error("Token verification error:", error);
          }
        },
        5 * 60 * 1000,
      ); // 5 minutes
    }

    return () => {
      if (timeoutId) {
        clearInterval(timeoutId);
      }
    };
  }, [state.user?.token, logout]);

  const value: AuthContextType = {
    user: state.user,
    isAuthenticated: state.isAuthenticated,
    currentSystem: state.currentSystem,
    isLoading: state.isLoading,
    error: state.error,
    login,
    logout,
    register,
    clearError,
    hasRole,
    hasAnyRole,
    updateUser,
    setCurrentSystem,
    getGlobalState,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}

// Custom hook for role-based access
export function useRoleAccess(requiredRole: UserRole | UserRole[]) {
  const { user, hasRole, hasAnyRole } = useAuth();

  const hasAccess = Array.isArray(requiredRole)
    ? hasAnyRole(requiredRole)
    : hasRole(requiredRole);

  return {
    hasAccess,
    user,
    userRole: user?.role,
  };
}

// Custom hook for permission-based access
export function usePermission(
  resource: string,
  permission: keyof (typeof ROLE_PERMISSIONS)[UserRole] = "canView",
) {
  const { user } = useAuth();

  const hasPermission = user?.role
    ? ROLE_PERMISSIONS[user.role]?.[permission]?.includes(resource) ||
      ROLE_PERMISSIONS[user.role]?.[permission]?.includes("*")
    : false;

  return {
    hasPermission,
    userRole: user?.role,
  };
}

// Custom hook for system access
export function useSystemAccess(system: SystemType) {
  const { user, currentSystem } = useAuth();

  const hasSystemAccess = user?.role
    ? ROLE_PERMISSIONS[user.role].systems.includes(system)
    : false;

  const isCurrentSystem = currentSystem === system;

  return {
    hasSystemAccess,
    isCurrentSystem,
    userRole: user?.role,
  };
}

// Custom hook to get the global context state structure
export function useGlobalState() {
  const { getGlobalState } = useAuth();
  return getGlobalState();
}

// Helper function to determine default system based on role
function getDefaultSystemForRole(role: UserRole): SystemType {
  const systemsForRole = ROLE_PERMISSIONS[role].systems;

  // Priority order for default systems
  const priorityOrder: SystemType[] = [
    "panel",
    "mlm",
    "ecommerce",
    "development",
  ];

  for (const system of priorityOrder) {
    if (systemsForRole.includes(system)) {
      return system;
    }
  }

  return "development"; // fallback
}
