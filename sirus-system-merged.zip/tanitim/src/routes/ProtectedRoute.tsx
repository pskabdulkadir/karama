import { ReactNode } from "react";
import { Navigate, useLocation } from "react-router-dom";
import { UserRole } from "../auth/types";
import { useAuth } from "../auth/AuthContext";
import { RoleGuard } from "../auth/RoleGuard";
import { ROUTES } from "../constants";

interface ProtectedRouteProps {
  children: ReactNode;
  allowedRoles?: UserRole | UserRole[];
  requireAuth?: boolean;
  redirectTo?: string;
}

/**
 * ProtectedRoute wrapper for protecting entire routes
 */
export function ProtectedRoute({
  children,
  allowedRoles,
  requireAuth = true,
  redirectTo = ROUTES.LOGIN,
}: ProtectedRouteProps) {
  const { isAuthenticated, isLoading } = useAuth();
  const location = useLocation();

  // Show loading spinner while checking authentication
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-white">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-brand-teal border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-brand-purple font-medium">
            Kimlik doğrulanıyor...
          </p>
        </div>
      </div>
    );
  }

  // If authentication is required but user is not authenticated
  if (requireAuth && !isAuthenticated) {
    return (
      <Navigate
        to={redirectTo}
        state={{
          from: location.pathname,
          message: "Bu sayfayı görüntülemek için giriş yapmanız gerekiyor.",
        }}
        replace
      />
    );
  }

  // If specific roles are required, use RoleGuard
  if (allowedRoles) {
    return (
      <RoleGuard allowedRoles={allowedRoles} requireAuth={requireAuth}>
        {children}
      </RoleGuard>
    );
  }

  // If no specific roles required but auth is required, just check authentication
  if (requireAuth && isAuthenticated) {
    return <>{children}</>;
  }

  // If no authentication required, render children
  if (!requireAuth) {
    return <>{children}</>;
  }

  // Fallback - should not reach here
  return (
    <Navigate to={redirectTo} state={{ from: location.pathname }} replace />
  );
}

/**
 * Public route that redirects authenticated users to dashboard
 */
interface PublicRouteProps {
  children: ReactNode;
  redirectIfAuthenticated?: string;
}

export function PublicRoute({
  children,
  redirectIfAuthenticated = ROUTES.HOME,
}: PublicRouteProps) {
  const { isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-white">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-brand-teal border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-brand-purple font-medium">Yükleniyor...</p>
        </div>
      </div>
    );
  }

  if (isAuthenticated) {
    return <Navigate to={redirectIfAuthenticated} replace />;
  }

  return <>{children}</>;
}

/**
 * Role-based route component for different user dashboards
 */
interface RoleBasedRouteProps {
  children: ReactNode;
  roleRoutes: Partial<Record<UserRole, string>>;
  defaultRoute?: string;
}

export function RoleBasedRoute({
  children,
  roleRoutes,
  defaultRoute = ROUTES.HOME,
}: RoleBasedRouteProps) {
  const { user, isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-white">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-brand-teal border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-brand-purple font-medium">Yönlendiriliyor...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Navigate to={ROUTES.LOGIN} replace />;
  }

  if (user?.role && roleRoutes[user.role]) {
    return <Navigate to={roleRoutes[user.role]!} replace />;
  }

  return <Navigate to={defaultRoute} replace />;
}

/**
 * Admin-only route wrapper
 */
export function AdminRoute({ children }: { children: ReactNode }) {
  return <ProtectedRoute allowedRoles="admin">{children}</ProtectedRoute>;
}

/**
 * MLM-only route wrapper
 */
export function MLMRoute({ children }: { children: ReactNode }) {
  return <ProtectedRoute allowedRoles="mlm">{children}</ProtectedRoute>;
}

/**
 * Psychologist-only route wrapper
 */
export function PsychologistRoute({ children }: { children: ReactNode }) {
  return (
    <ProtectedRoute allowedRoles="psychologist">{children}</ProtectedRoute>
  );
}

/**
 * Merchant-only route wrapper
 */
export function MerchantRoute({ children }: { children: ReactNode }) {
  return <ProtectedRoute allowedRoles="merchant">{children}</ProtectedRoute>;
}
