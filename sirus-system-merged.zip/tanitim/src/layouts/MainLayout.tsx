import { ReactNode } from "react";
import { Header } from "../components/Header";
import { Footer } from "../components/Footer";

interface MainLayoutProps {
  children: ReactNode;
  onNavigate?: (section: string) => void;
}

export function MainLayout({ children, onNavigate }: MainLayoutProps) {
  return (
    <div className="min-h-screen bg-white">
      <Header onNavigate={onNavigate} />
      <main className="pt-16">{children}</main>
      <Footer />
    </div>
  );
}
