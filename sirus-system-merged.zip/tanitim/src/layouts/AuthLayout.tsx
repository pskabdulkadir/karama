import { ReactNode } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { APP_CONFIG, ROUTES } from "../constants";

interface AuthLayoutProps {
  children: ReactNode;
  title: string;
  subtitle?: string;
}

export function AuthLayout({ children, title, subtitle }: AuthLayoutProps) {
  return (
    <div className="min-h-screen bg-white flex items-center justify-center px-4 py-20">
      <div className="w-full max-w-md">
        {/* Back Button */}
        <div className="mb-6">
          <Link
            to={ROUTES.HOME}
            className="inline-flex items-center text-brand-purple/80 hover:text-brand-purple transition-colors"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Ana Sayfaya Dön
          </Link>
        </div>

        {/* Logo */}
        <div className="text-center mb-8">
          <Link to={ROUTES.HOME}>
            <h1 className="mystical-logo brand-text-gradient text-3xl">
              {APP_CONFIG.name}
            </h1>
          </Link>
          <p className="text-muted-foreground text-sm mt-2">
            {APP_CONFIG.description}
          </p>
        </div>

        {children}

        {/* Footer */}
        <div className="mt-6 text-center space-y-2">
          <Link
            to={ROUTES.KUTBUL_ZAMAN}
            className="block text-muted-foreground hover:text-brand-purple transition-colors text-sm"
          >
            Kutbu'l Zaman Sayfası
          </Link>
          <p className="text-muted-foreground text-xs">
            © 2024 {APP_CONFIG.name}. Tüm hakları saklıdır.
          </p>
        </div>
      </div>
    </div>
  );
}
