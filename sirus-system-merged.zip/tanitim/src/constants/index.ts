export const APP_CONFIG = {
  name: import.meta.env.VITE_APP_NAME || "Kutbu'l Zaman",
  description: "Manevi Gelişim & Kişisel Rehberlik",
  apiUrl: import.meta.env.VITE_API_URL || "https://api.kutbulzaman.com",
  systemMode: import.meta.env.VITE_SYSTEM_MODE || "development",
  contact: {
    phone: "+90 (555) 123 45 67",
    email: "info@kutbulzaman.com",
    whatsapp: "+905551234567",
    address: "Atatürk Mah. Barış Sokak No:15/3 Kadıköy/İstanbul",
  },
  social: {
    instagram: "https://instagram.com/kutbulzaman",
    youtube: "https://youtube.com/@kutbulzaman",
    facebook: "https://facebook.com/kutbulzaman",
  },
} as const;

export const ROUTES = {
  HOME: "/",
  KUTBUL_ZAMAN: "/kutbulzaman",
  LOGIN: "/giris",
  REGISTER: "/uye-ol",
  PROFILE: "/profil",
  NOTIFICATIONS: "/bildirimler",
  // System Routes
  PANEL: "/panel",
  MLM: "/mlm",
  SHOP: "/shop",
  SELF: "/self",
  ADMIN: "/admin",
  PORTAL: "/portal",
} as const;

export const SERVICES = [
  {
    id: "kuantum-donusum",
    title: "Kuantum Dönüşüm",
    description: "Bilinç seviyenizi yükselterek yaşamsal dönüşüm",
    category: "spiritual",
  },
  {
    id: "aile-dizimi",
    title: "Aile Dizimi",
    description: "Nesiller arası enerji temizliği ve şifa",
    category: "therapy",
  },
  {
    id: "enerji-temizligi",
    title: "Enerji/Aura Temizliği",
    description: "Negatif enerjilerden arınma ve korunma",
    category: "energy",
  },
  {
    id: "havas-ilmi",
    title: "Havas İlmi",
    description: "Kutsal harflerin gücüyle manevi destek",
    category: "spiritual",
  },
  {
    id: "ruya-tabiri",
    title: "Rüya Tabiri",
    description: "Rüyalarınızdaki manevi mesajları anlama",
    category: "analysis",
  },
  {
    id: "spiritüel-danismanlik",
    title: "Spiritüel Danışmanlık",
    description: "Manevi yolculuğunuzda rehberlik",
    category: "counseling",
  },
] as const;

export const VIDEO_CATEGORIES = [
  "Tümü",
  "Manevi Sohbetler",
  "Kuantum Bilinç",
  "Rüya Tabirleri",
  "Enerji Çalışması",
] as const;

export const BLOG_CATEGORIES = [
  "Bilinç Gelişimi",
  "Enerji Çalışması",
  "Rüya Tabiri",
  "Manevi Gelişim",
  "Kuantum Koçluk",
  "Aile Dizimi",
] as const;

export const STORAGE_KEYS = {
  USER: "kutbulzaman_user",
  AUTH_TOKEN: "kutbulzaman_auth_token",
  CURRENT_SYSTEM: "kutbulzaman_current_system",
  THEME: "kutbulzaman_theme",
  LANGUAGE: "kutbulzaman_language",
} as const;

export const API_ENDPOINTS = {
  DEMO: "/api/demo",
  LOGIN: "/api/auth/login",
  REGISTER: "/api/auth/register",
  CONTACT: "/api/contact",
} as const;
