import "./styles/global.css";

import { Toaster } from "@/components/ui/toaster";
import { createRoot } from "react-dom/client";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { ErrorBoundary } from "./components/ErrorBoundary";
import { AuthProvider } from "./auth/AuthContext";
import Index from "./pages/Index";
import KutbulZaman from "./pages/KutbulZaman";
import Login from "./pages/Login";
import Register from "./pages/Register";
import NotFound from "./pages/NotFound";
import Portal from "./pages/Portal";
import Panel from "./pages/Panel";
import MLM from "./pages/MLM";
import Shop from "./pages/Shop";
import Self from "./pages/Self";
import Admin from "./pages/Admin";

const queryClient = new QueryClient();

const App = () => (
  <ErrorBoundary>
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <BrowserRouter>
          <Toaster />
          <Sonner />
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/kutbulzaman" element={<KutbulZaman />} />
            <Route path="/giris" element={<Login />} />
            <Route path="/uye-ol" element={<Register />} />
            {/* System Routes */}
            <Route path="/portal" element={<Portal />} />
            <Route path="/panel" element={<Panel />} />
            <Route path="/mlm" element={<MLM />} />
            <Route path="/shop" element={<Shop />} />
            <Route path="/self" element={<Self />} />
            <Route path="/admin" element={<Admin />} />
            {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </AuthProvider>
    </QueryClientProvider>
  </ErrorBoundary>
);

createRoot(document.getElementById("root")!).render(<App />);
