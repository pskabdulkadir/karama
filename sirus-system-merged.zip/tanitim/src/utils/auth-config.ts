import { UserRole } from "../auth/types";

// System access configuration based on user roles
export const SYSTEM_ACCESS = {
  panel: {
    roles: ["user", "admin", "mlm", "psychologist", "merchant"] as UserRole[],
    title: "Kullanıcı Paneli",
    description: "Genel kullanıcı yönetim paneli",
  },
  mlm: {
    roles: ["mlm", "admin"] as UserRole[],
    title: "Network Sistemi",
    description: "MLM ve network yönetimi",
  },
  shop: {
    roles: ["merchant", "admin", "user"] as UserRole[],
    title: "Alışveriş",
    description: "E-ticaret ve satış sistemi",
  },
  self: {
    roles: ["psychologist", "admin", "user"] as UserRole[],
    title: "Kişisel Gelişim",
    description: "Psikoloji ve terapi hizmetleri",
  },
  admin: {
    roles: ["admin"] as UserRole[],
    title: "Yönetim",
    description: "Sistem yönetimi ve ayarları",
  },
  portal: {
    roles: ["user", "admin", "mlm", "psychologist", "merchant"] as UserRole[],
    title: "Portal",
    description: "Merkezi yönlendirme sayfası",
  },
} as const;

export function getUserAccessibleSystems(userRole?: UserRole) {
  if (!userRole) return [];

  return Object.entries(SYSTEM_ACCESS)
    .filter(([_, config]) => config.roles.includes(userRole))
    .map(([system, config]) => ({
      system,
      ...config,
    }));
}

export function hasSystemAccess(
  system: keyof typeof SYSTEM_ACCESS,
  userRole?: UserRole,
): boolean {
  if (!userRole) return false;
  return SYSTEM_ACCESS[system]?.roles.includes(userRole) ?? false;
}

// Environment-based system mode checking
export function getSystemModeFromEnv(): string {
  return import.meta.env.VITE_SYSTEM_MODE || "development";
}

// Check if current system mode requires authentication
export function requiresAuth(systemMode?: string): boolean {
  const mode = systemMode || getSystemModeFromEnv();
  return ["mlm", "ecommerce", "self", "admin"].includes(mode);
}
