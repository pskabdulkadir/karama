export const validation = {
  email: (email: string): boolean => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  },

  phone: (phone: string): boolean => {
    const phoneRegex = /^[\+]?[0-9\s\-\(\)]{10,}$/;
    return phoneRegex.test(phone);
  },

  password: (password: string): { isValid: boolean; message?: string } => {
    if (password.length < 6) {
      return { isValid: false, message: "Şifre en az 6 karakter olmalıdır." };
    }
    return { isValid: true };
  },

  required: (value: string): boolean => {
    return value.trim().length > 0;
  },

  name: (name: string): boolean => {
    return name.trim().length >= 2;
  },

  passwordMatch: (password: string, confirmPassword: string): boolean => {
    return password === confirmPassword;
  },
};

export const sanitize = {
  input: (input: string): string => {
    return input.trim().replace(/[<>]/g, "");
  },

  phone: (phone: string): string => {
    return phone.replace(/[^\d\+\-\s\(\)]/g, "");
  },

  email: (email: string): string => {
    return email.trim().toLowerCase();
  },
};
