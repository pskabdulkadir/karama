import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  User,
  Mail,
  Lock,
  Eye,
  EyeOff,
  AlertCircle,
  UserPlus,
  LogIn,
  Shield,
  Star,
  Zap,
  Chrome,
  Facebook,
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { toast } from "@/hooks/use-toast";
import KutbulHeader from "@/components/KutbulHeader";

// User roles for the system
const USER_ROLES = {
  user: "Kullanıcı",
  admin: "Admin",
  bayi: "Bayi",
  network: "Network",
  customer: "Müşteri",
  guest: "Misafir",
};

// Mock user database
const MOCK_USERS = {
  "admin@kutbulzaman.com": {
    role: "admin",
    name: "Network Admin",
    password: "admin123",
  },
  "bayi@kutbulzaman.com": {
    role: "bayi",
    name: "Market Satıcı",
    password: "bayi123",
  },
  "user@kutbulzaman.com": {
    role: "user",
    name: "Rehberlik Kullanıcısı",
    password: "user123",
  },
  "customer@kutbulzaman.com": {
    role: "customer",
    name: "Market Müşterisi",
    password: "customer123",
  },
  "network@kutbulzaman.com": {
    role: "network",
    name: "Network Kullanıcı",
    password: "network123",
  },
};

interface ForgotPasswordModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

function ForgotPasswordModal({ open, onOpenChange }: ForgotPasswordModalProps) {
  const [email, setEmail] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) {
      toast({
        title: "E-posta gerekli",
        description: "Lütfen e-posta adresinizi girin.",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000));

    toast({
      title: "Şifre sıfırlama e-postası gönderildi",
      description: `${email} adresine şifre sıfırlama talimatları gönderildi.`,
    });

    setIsLoading(false);
    setEmail("");
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-center">Şifremi Unuttum</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleResetPassword} className="space-y-4">
          <div>
            <Label htmlFor="reset-email">E-posta Adresi</Label>
            <Input
              id="reset-email"
              type="email"
              placeholder="E-posta adresinizi girin"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          <Button type="submit" className="w-full" disabled={isLoading}>
            {isLoading
              ? "Gönderiliyor..."
              : "Şifre Sıfırlama Bağlant��sı Gönder"}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}

interface RegisterModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

function RegisterModal({ open, onOpenChange }: RegisterModalProps) {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
    role: "customer",
  });
  const [isLoading, setIsLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    // Validation
    if (!formData.name || !formData.email || !formData.password) {
      toast({
        title: "Eksik bilgi",
        description: "Lütfen tüm alanları doldurun.",
        variant: "destructive",
      });
      setIsLoading(false);
      return;
    }

    if (formData.password !== formData.confirmPassword) {
      toast({
        title: "Şifreler eşleşmiyor",
        description: "Lütfen şifrenizi tekrar kontrol edin.",
        variant: "destructive",
      });
      setIsLoading(false);
      return;
    }

    if (formData.password.length < 6) {
      toast({
        title: "Şifre çok kısa",
        description: "Şifre en az 6 karakter olmalıdır.",
        variant: "destructive",
      });
      setIsLoading(false);
      return;
    }

    // Check if email already exists
    if (MOCK_USERS[formData.email as keyof typeof MOCK_USERS]) {
      toast({
        title: "E-posta zaten kayıtlı",
        description: "Bu e-posta adresi zaten sistemde kayıtlı.",
        variant: "destructive",
      });
      setIsLoading(false);
      return;
    }

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1500));

    toast({
      title: "Kayıt başarılı!",
      description: `Hoş geldiniz ${formData.name}! Hesabınız oluşturuldu.`,
    });

    // Reset form
    setFormData({
      name: "",
      email: "",
      password: "",
      confirmPassword: "",
      role: "customer",
    });

    setIsLoading(false);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-center">Yeni Hesap Oluştur</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleRegister} className="space-y-4">
          <div>
            <Label htmlFor="register-name">Ad Soyad</Label>
            <Input
              id="register-name"
              placeholder="Adınız ve soyadınız"
              value={formData.name}
              onChange={(e) =>
                setFormData({ ...formData, name: e.target.value })
              }
              required
            />
          </div>

          <div>
            <Label htmlFor="register-email">E-posta</Label>
            <Input
              id="register-email"
              type="email"
              placeholder="ornek@kutbulzaman.com"
              value={formData.email}
              onChange={(e) =>
                setFormData({ ...formData, email: e.target.value })
              }
              required
            />
          </div>

          <div>
            <Label htmlFor="register-role">Hesap Türü</Label>
            <Select
              value={formData.role}
              onValueChange={(value) =>
                setFormData({ ...formData, role: value })
              }
            >
              <SelectTrigger>
                <SelectValue placeholder="Hesap türünüzü seçin" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="customer">Müşteri</SelectItem>
                <SelectItem value="user">Kullanıcı</SelectItem>
                <SelectItem value="bayi">Bayi</SelectItem>
                <SelectItem value="network">Network</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="register-password">Şifre</Label>
            <div className="relative">
              <Input
                id="register-password"
                type={showPassword ? "text" : "password"}
                placeholder="En az 6 karakter"
                value={formData.password}
                onChange={(e) =>
                  setFormData({ ...formData, password: e.target.value })
                }
                required
              />
              <Button
                type="button"
                variant="ghost"
                size="sm"
                className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                onClick={() => setShowPassword(!showPassword)}
              >
                {showPassword ? (
                  <EyeOff className="h-4 w-4" />
                ) : (
                  <Eye className="h-4 w-4" />
                )}
              </Button>
            </div>
          </div>

          <div>
            <Label htmlFor="register-confirm-password">Şifre Tekrar</Label>
            <Input
              id="register-confirm-password"
              type="password"
              placeholder="Şifrenizi tekrar girin"
              value={formData.confirmPassword}
              onChange={(e) =>
                setFormData({ ...formData, confirmPassword: e.target.value })
              }
              required
            />
          </div>

          <Button type="submit" className="w-full" disabled={isLoading}>
            {isLoading ? "Hesap oluşturuluyor..." : "Hesap Oluştur"}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}

export default function Index() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("login");
  const [loginData, setLoginData] = useState({
    email: "",
    password: "",
  });
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [forgotPasswordOpen, setForgotPasswordOpen] = useState(false);
  const [registerOpen, setRegisterOpen] = useState(false);

  const handleSocialLogin = async (provider: "google" | "facebook") => {
    setIsLoading(true);

    // Simulate social login API call
    await new Promise((resolve) => setTimeout(resolve, 1500));

    // Mock successful social login
    const mockSocialUser = {
      email: `user@${provider}.com`,
      role: "user",
      name: `${provider.charAt(0).toUpperCase() + provider.slice(1)} Kullanıcısı`,
      loginTime: Date.now(),
    };

    // Store in localStorage as requested
    localStorage.setItem("kutbulzamanAuth", JSON.stringify(mockSocialUser));

    // Also store in sessionStorage for consistency
    sessionStorage.setItem(
      "kutbulzamanSession",
      JSON.stringify(mockSocialUser),
    );

    toast({
      title: `${provider.charAt(0).toUpperCase() + provider.slice(1)} ile giriş başarılı!`,
      description: "Rehberlik paneline yönlendiriliyorsunuz...",
    });

    setIsLoading(false);
    navigate("/profile");
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setIsLoading(true);

    // Validation
    if (!loginData.email || !loginData.password) {
      setError("Lütfen tüm alanları doldurun");
      setIsLoading(false);
      return;
    }

    if (!loginData.email.includes("@")) {
      setError("Geçerli bir e-posta adresi girin");
      setIsLoading(false);
      return;
    }

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000));

    // Check credentials
    const userData = MOCK_USERS[loginData.email as keyof typeof MOCK_USERS];

    if (!userData) {
      setError("Bu e-posta adresi sistemde kayıtlı değil");
      setIsLoading(false);
      return;
    }

    if (userData.password !== loginData.password) {
      setError("Hatalı şifre girdiniz");
      setIsLoading(false);
      return;
    }

    // Create session
    const userSession = {
      email: loginData.email,
      role: userData.role,
      name: userData.name,
      loginTime: Date.now(),
    };

    // Store in localStorage as requested
    localStorage.setItem("kutbulzamanAuth", JSON.stringify(userSession));

    // Also store in sessionStorage for consistency
    sessionStorage.setItem("kutbulzamanSession", JSON.stringify(userSession));

    // Success notification
    toast({
      title: "Giriş başarılı!",
      description: `Hoş geldiniz ${userData.name}! Yönlendiriliyorsunuz...`,
    });

    // Role-based routing to specific paths
    let targetRoute = "/dashboard";
    switch (userData.role) {
      case "admin":
        targetRoute = "/admin"; // Network Admin Panel
        break;
      case "bayi":
        targetRoute = "/market"; // Market Satıcı Paneli
        break;
      case "user":
        targetRoute = "/profile"; // Rehberlik Paneli
        break;
      case "customer":
        targetRoute = "/market"; // Market (for customers)
        break;
      default:
        targetRoute = "/dashboard";
    }

    setIsLoading(false);

    // Clear form
    setLoginData({ email: "", password: "" });

    // Navigate with SPA routing
    navigate(targetRoute);
  };

  const handleGuestAccess = () => {
    toast({
      title: "Misafir girişi",
      description: "Alışveriş sayfasına yönlendiriliyorsunuz...",
    });
    navigate("/alisveris");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-kutbul-purple via-kutbul-teal to-kutbul-purple-light">
      {/* Header */}
      <KutbulHeader currentPage="login" />

      {/* Background Pattern */}
      <div className="absolute inset-0 bg-black/5">
        <div className="absolute inset-0 bg-gradient-to-r from-kutbul-purple/10 to-kutbul-teal/10" />
      </div>

      <div className="relative container mx-auto px-4 py-8 flex items-center justify-center min-h-[calc(100vh-4rem)]">
        <div className="w-full max-w-md">
          {/* Welcome Section */}
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-20 h-20 bg-kutbul-white/20 backdrop-blur-sm rounded-xl mb-6 shadow-md">
              <Shield className="w-10 h-10 text-kutbul-white" />
            </div>
            <h1 className="font-mystical text-4xl font-bold text-kutbul-white mb-2 drop-shadow-lg">
              Hoş Geldiniz
            </h1>
            <p className="text-kutbul-white/90 text-lg drop-shadow-md">
              Merkezi Giriş Sistemi
            </p>
            <p className="text-kutbul-white/70 text-sm mt-2">
              Tüm sistemlerin ortak kullanıcı girişi
            </p>
          </div>

          {/* Main Login Card */}
          <Card className="backdrop-blur-sm bg-kutbul-white/95 shadow-md border-0 rounded-xl">
            <CardHeader className="text-center pb-4">
              <CardTitle className="text-2xl font-bold text-kutbul-purple">
                Giriş Yapın
              </CardTitle>
              <CardDescription className="text-kutbul-purple/70">
                Hesabınızla giriş yapın veya yeni hesap oluşturun
              </CardDescription>
            </CardHeader>

            <CardContent>
              <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="grid w-full grid-cols-2 mb-6">
                  <TabsTrigger
                    value="login"
                    className="flex items-center gap-2"
                  >
                    <LogIn className="w-4 h-4" />
                    Giriş Yap
                  </TabsTrigger>
                  <TabsTrigger
                    value="features"
                    className="flex items-center gap-2"
                  >
                    <Star className="w-4 h-4" />
                    Özellikler
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="login" className="space-y-4">
                  <form onSubmit={handleLogin} className="space-y-4">
                    <div>
                      <Label htmlFor="email">E-posta</Label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-3 h-4 w-4 text-kutbul-purple/50" />
                        <Input
                          id="email"
                          type="email"
                          placeholder="ornek@kutbulzaman.com"
                          value={loginData.email}
                          onChange={(e) =>
                            setLoginData({
                              ...loginData,
                              email: e.target.value,
                            })
                          }
                          className="pl-10 rounded-xl border-kutbul-gray focus:border-kutbul-teal focus:ring-kutbul-teal"
                          required
                        />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="password">Şifre</Label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-3 h-4 w-4 text-kutbul-purple/50" />
                        <Input
                          id="password"
                          type={showPassword ? "text" : "password"}
                          placeholder="Şifrenizi girin"
                          value={loginData.password}
                          onChange={(e) =>
                            setLoginData({
                              ...loginData,
                              password: e.target.value,
                            })
                          }
                          className="pl-10 pr-10 rounded-xl border-kutbul-gray focus:border-kutbul-teal focus:ring-kutbul-teal"
                          required
                        />
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent rounded-xl"
                          onClick={() => setShowPassword(!showPassword)}
                        >
                          {showPassword ? (
                            <EyeOff className="h-4 w-4 text-kutbul-purple/50" />
                          ) : (
                            <Eye className="h-4 w-4 text-kutbul-purple/50" />
                          )}
                        </Button>
                      </div>
                    </div>

                    {error && (
                      <div className="flex items-center gap-2 text-destructive text-sm bg-red-50 p-3 rounded-xl">
                        <AlertCircle className="w-4 h-4" />
                        {error}
                      </div>
                    )}

                    <Button
                      type="submit"
                      className="w-full bg-kutbul-teal hover:bg-kutbul-teal-light text-kutbul-white rounded-xl shadow-md"
                      disabled={isLoading}
                      size="lg"
                    >
                      {isLoading ? "Giriş yapılıyor..." : "Giriş Yap"}
                    </Button>
                  </form>

                  <div className="my-4">
                    <Separator className="my-4" />
                    <p className="text-center text-sm text-kutbul-purple/60 -mt-3 bg-kutbul-white px-3">
                      veya
                    </p>
                  </div>

                  {/* Social Login Buttons */}
                  <div className="space-y-3">
                    <Button
                      variant="outline"
                      className="w-full border-red-300 hover:bg-red-50 text-red-700 rounded-xl"
                      onClick={() => handleSocialLogin("google")}
                      disabled={isLoading}
                    >
                      <Chrome className="w-4 h-4 mr-2" />
                      Google ile Giriş
                    </Button>

                    <Button
                      variant="outline"
                      className="w-full border-blue-300 hover:bg-blue-50 text-blue-700 rounded-xl"
                      onClick={() => handleSocialLogin("facebook")}
                      disabled={isLoading}
                    >
                      <Facebook className="w-4 h-4 mr-2" />
                      Facebook ile Giriş
                    </Button>
                  </div>

                  <div className="space-y-3 mt-4">
                    <Button
                      variant="outline"
                      className="w-full border-kutbul-gray hover:bg-kutbul-gray/20 text-kutbul-purple rounded-xl"
                      onClick={() => setForgotPasswordOpen(true)}
                    >
                      Şifre Sıfırlama
                    </Button>

                    <Button
                      variant="outline"
                      className="w-full border-kutbul-purple hover:bg-kutbul-purple/10 text-kutbul-purple rounded-xl"
                      onClick={() => setRegisterOpen(true)}
                    >
                      <UserPlus className="w-4 h-4 mr-2" />
                      Yeni Üyelik Kaydı
                    </Button>
                  </div>

                  <Separator className="my-4" />

                  <Button
                    variant="ghost"
                    className="w-full text-kutbul-purple/70 hover:text-kutbul-purple hover:bg-kutbul-purple/5 rounded-xl"
                    onClick={handleGuestAccess}
                  >
                    <User className="w-4 h-4 mr-2" />
                    Misafir olarak devam et
                  </Button>
                </TabsContent>

                <TabsContent value="features" className="space-y-4">
                  <div className="space-y-4">
                    <div className="flex items-start gap-3 p-3 bg-blue-50 rounded-lg">
                      <Shield className="w-5 h-5 text-blue-600 mt-1" />
                      <div>
                        <h4 className="font-semibold text-blue-900">
                          Güvenli Giriş
                        </h4>
                        <p className="text-sm text-blue-700">
                          Tüm verileriniz güvenle korunur
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start gap-3 p-3 bg-purple-50 rounded-lg">
                      <Zap className="w-5 h-5 text-purple-600 mt-1" />
                      <div>
                        <h4 className="font-semibold text-purple-900">
                          Hızlı Erişim
                        </h4>
                        <p className="text-sm text-purple-700">
                          Tek giriş ile tüm panellere erişim
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start gap-3 p-3 bg-green-50 rounded-lg">
                      <Star className="w-5 h-5 text-green-600 mt-1" />
                      <div>
                        <h4 className="font-semibold text-green-900">
                          Rol Bazlı Sistem
                        </h4>
                        <p className="text-sm text-green-700">
                          Rolünüze özel içerik ve özellikler
                        </p>
                      </div>
                    </div>
                  </div>

                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={() => setActiveTab("login")}
                  >
                    Giriş Yapmaya Dön
                  </Button>
                </TabsContent>
              </Tabs>

              {/* Test Accounts */}
              <div className="mt-6 p-3 bg-kutbul-gray/30 rounded-xl text-xs text-kutbul-purple/80">
                <p className="font-medium mb-2 text-center">
                  Test Hesapları (Şifre: xxxxx123):
                </p>
                <div className="space-y-1 text-center">
                  <p>admin@kutbulzaman.com → Network Admin Panel (/admin)</p>
                  <p>bayi@kutbulzaman.com → Market Satıcı Paneli (/market)</p>
                  <p>user@kutbulzaman.com → Rehberlik Paneli (/profile)</p>
                  <p>customer@kutbulzaman.com → Market (/market)</p>
                </div>
                <p className="text-center mt-2 font-medium text-kutbul-teal">
                  📱 localStorage ile kimlik bilgisi saklanır
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Footer */}
          <div className="text-center mt-6 text-kutbul-white/70 text-sm">
            <p className="font-mystical">
              © 2024 Kutbul Zaman - Tüm hakları saklıdır
            </p>
          </div>
        </div>
      </div>

      {/* Modals */}
      <ForgotPasswordModal
        open={forgotPasswordOpen}
        onOpenChange={setForgotPasswordOpen}
      />

      <RegisterModal open={registerOpen} onOpenChange={setRegisterOpen} />
    </div>
  );
}
