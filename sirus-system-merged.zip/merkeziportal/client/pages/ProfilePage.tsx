import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  User,
  Home,
  LogOut,
  Book,
  Heart,
  Star,
  Calendar,
  MessageCircle,
  TrendingUp,
} from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "@/hooks/use-toast";
import KutbulHeader from "@/components/KutbulHeader";

export default function ProfilePage() {
  const navigate = useNavigate();
  const [userData, setUserData] = useState<any>(null);

  useEffect(() => {
    // Load user data from localStorage
    const authData = localStorage.getItem("kutbulzamanAuth");
    const sessionData = sessionStorage.getItem("kutbulzamanSession");

    if (!authData && !sessionData) {
      toast({
        title: "Oturum bulunamadı",
        description: "Lütfen giriş yapın.",
        variant: "destructive",
      });
      navigate("/");
      return;
    }

    const user = authData ? JSON.parse(authData) : JSON.parse(sessionData!);
    setUserData(user);
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem("kutbulzamanAuth");
    sessionStorage.removeItem("kutbulzamanSession");
    toast({
      title: "Çıkış yapıldı",
      description: "kutbulzaman sisteminden başarıyla çıkış yaptınız.",
    });
    navigate("/");
  };

  if (!userData) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-mystical-gradient-from via-mystical-gradient-via to-mystical-gradient-to flex items-center justify-center">
        <div className="text-center text-white">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-white mx-auto mb-4"></div>
          <p>Yükleniyor...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-kutbul-purple via-kutbul-teal to-kutbul-purple-light">
      {/* Header */}
      <KutbulHeader currentPage="profile" />

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Welcome Card */}
          <Card className="md:col-span-2 lg:col-span-3 bg-kutbul-white/95 backdrop-blur-sm border-kutbul-gray shadow-md rounded-xl">
            <CardHeader>
              <CardTitle className="text-2xl text-kutbul-purple font-semibold">
                Hoş Geldiniz, {userData.name}!
              </CardTitle>
              <CardDescription className="text-kutbul-purple/70">
                Kişisel gelişim ve rehberlik hizmetleriniz
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-kutbul-purple/60 mb-4">
                Bu panelde kişisel gelişim programlarınız, rehberlik
                seanslarınız ve ilerleme takibinizi gerçekleştirebilirsiniz.
              </p>
              <div className="flex gap-4">
                <Button className="bg-kutbul-teal hover:bg-kutbul-teal-light text-kutbul-white rounded-xl shadow-md">
                  Seanslarım
                </Button>
                <Button
                  variant="outline"
                  className="border-kutbul-purple/20 text-kutbul-purple hover:bg-kutbul-purple/10 rounded-xl"
                >
                  Market'e Git
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Personal Development Cards */}
          <Card className="bg-white/95 backdrop-blur-sm border-mystical-purple/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Book className="w-5 h-5 text-mystical-purple" />
                Eğitim Programları
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-mystical-purple mb-2">
                5
              </div>
              <p className="text-sm text-muted-foreground mb-4">
                Aktif program
              </p>
              <Button
                variant="outline"
                className="w-full border-mystical-purple/20 text-mystical-purple hover:bg-mystical-purple/10"
              >
                Programları Görüntüle
              </Button>
            </CardContent>
          </Card>

          <Card className="bg-white/95 backdrop-blur-sm border-mystical-blue/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="w-5 h-5 text-mystical-blue" />
                Rehberlik Seansları
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-mystical-blue mb-2">
                3
              </div>
              <p className="text-sm text-muted-foreground mb-4">Bu hafta</p>
              <Button
                variant="outline"
                className="w-full border-mystical-blue/20 text-mystical-blue hover:bg-mystical-blue/10"
              >
                Randevu Al
              </Button>
            </CardContent>
          </Card>

          <Card className="bg-white/95 backdrop-blur-sm border-mystical-indigo/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-mystical-indigo" />
                İlerleme Takibi
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-mystical-indigo mb-2">
                78%
              </div>
              <p className="text-sm text-muted-foreground mb-4">
                Genel ilerleme
              </p>
              <Button
                variant="outline"
                className="w-full border-mystical-indigo/20 text-mystical-indigo hover:bg-mystical-indigo/10"
              >
                Detayları Gör
              </Button>
            </CardContent>
          </Card>

          {/* Additional Features */}
          <Card className="bg-white/95 backdrop-blur-sm border-green-500/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageCircle className="w-5 h-5 text-green-500" />
                Mesajlarım
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-green-500 mb-2">7</div>
              <p className="text-sm text-muted-foreground mb-4">
                Okunmamış mesaj
              </p>
              <Button
                variant="outline"
                className="w-full border-green-500/20 text-green-500 hover:bg-green-500/10"
              >
                Mesajları Oku
              </Button>
            </CardContent>
          </Card>

          <Card className="bg-white/95 backdrop-blur-sm border-yellow-500/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Star className="w-5 h-5 text-yellow-500" />
                Başarılarım
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-yellow-500 mb-2">12</div>
              <p className="text-sm text-muted-foreground mb-4">
                Elde edilen rozet
              </p>
              <Button
                variant="outline"
                className="w-full border-yellow-500/20 text-yellow-500 hover:bg-yellow-500/10"
              >
                Başarıları Gör
              </Button>
            </CardContent>
          </Card>

          <Card className="bg-white/95 backdrop-blur-sm border-pink-500/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Heart className="w-5 h-5 text-pink-500" />
                Favori Kaynaklar
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-pink-500 mb-2">24</div>
              <p className="text-sm text-muted-foreground mb-4">
                Kayıtlı kaynak
              </p>
              <Button
                variant="outline"
                className="w-full border-pink-500/20 text-pink-500 hover:bg-pink-500/10"
              >
                Kaynaklara Git
              </Button>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
