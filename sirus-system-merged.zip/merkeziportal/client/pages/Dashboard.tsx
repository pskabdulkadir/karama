import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "@/hooks/use-toast";

export default function Dashboard() {
  const navigate = useNavigate();

  useEffect(() => {
    // Check for kutbulzaman session (localStorage or sessionStorage)
    const authData = localStorage.getItem("kutbulzamanAuth");
    const sessionData = sessionStorage.getItem("kutbulzamanSession");
    const userSessionStr = authData || sessionData;

    if (!userSessionStr) {
      toast({
        title: "Oturum bulunamadı",
        description: "Lütfen kutbulzaman giriş sistemi ile giriş yapın.",
        variant: "destructive",
      });
      navigate("/");
      return;
    }

    try {
      const userSession = JSON.parse(userSessionStr);
      const { role, name } = userSession;

      // Check if session is still valid (24 hours)
      const sessionAge = Date.now() - userSession.loginTime;
      const maxSessionAge = 24 * 60 * 60 * 1000; // 24 hours

      if (sessionAge > maxSessionAge) {
        // Clean both storage locations
        localStorage.removeItem("kutbulzamanAuth");
        sessionStorage.removeItem("kutbulzamanSession");
        toast({
          title: "Oturum süresi dolmuş",
          description: "Güvenlik için tekrar giriş yapmanız gerekiyor.",
          variant: "destructive",
        });
        navigate("/");
        return;
      }

      // kutbulzaman role-based automatic distribution (new paths)
      let targetPanel = "";
      let panelName = "";

      switch (role) {
        case "admin":
          targetPanel = "/admin";
          panelName = "Network Admin Panel";
          break;
        case "bayi":
          targetPanel = "/market";
          panelName = "Market Satıcı Paneli";
          break;
        case "user":
          targetPanel = "/profile";
          panelName = "Rehberlik Paneli";
          break;
        case "customer":
          targetPanel = "/market";
          panelName = "Market";
          break;
        case "network":
          targetPanel = "/panel/mlm";
          panelName = "MLM Network Paneli";
          break;
        default:
          // Default to dashboard for unknown roles
          targetPanel = "/dashboard";
          panelName = "Dashboard";
      }

      // Navigate to the appropriate panel
      toast({
        title: `Hoş geldiniz, ${name}!`,
        description: `${panelName}'ne yönlendiriliyorsunuz.`,
      });

      navigate(targetPanel, { replace: true });
    } catch (error) {
      console.error("Error parsing kutbulzaman session:", error);
      // Clean both storage locations
      localStorage.removeItem("kutbulzamanAuth");
      sessionStorage.removeItem("kutbulzamanSession");
      toast({
        title: "Oturum hatası",
        description: "Lütfen tekrar giriş yapın.",
        variant: "destructive",
      });
      navigate("/");
    }
  }, [navigate]);

  // Loading screen while redirecting
  return (
    <div className="min-h-screen bg-gradient-to-br from-mystical-gradient-from via-mystical-gradient-via to-mystical-gradient-to flex items-center justify-center">
      <div className="text-center text-white">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-white mx-auto mb-4"></div>
        <h2 className="text-2xl font-semibold mb-2">Yönlendiriliyor...</h2>
        <p className="text-white/80">
          Rolünüze uygun panele yönlendiriliyorsunuz.
        </p>
      </div>
    </div>
  );
}
