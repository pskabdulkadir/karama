import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Store,
  Home,
  LogOut,
  ShoppingCart,
  Heart,
  Star,
  Plus,
  Minus,
  X,
  ZoomIn,
  ChevronLeft,
  ChevronRight,
  Package,
  CreditCard,
  Banknote,
  Settings,
  Edit,
  Trash2,
  Search,
  Filter,
  Eye,
} from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "@/hooks/use-toast";

// Mock Data
const categories = [
  { id: 1, name: "Kozmetik", icon: "✨", count: 45 },
  { id: 2, name: "G��da", icon: "🍎", count: 123 },
  { id: 3, name: "Spiritüel", icon: "🔮", count: 67 },
  { id: 4, name: "Kitap", icon: "📚", count: 89 },
  { id: 5, name: "Takı", icon: "💎", count: 34 },
  { id: 6, name: "Ev & Yaşam", icon: "🏠", count: 56 },
];

const featuredProducts = [
  {
    id: 1,
    name: "Organik Lavanta Yağı",
    price: 89.99,
    oldPrice: 119.99,
    image: "/placeholder.svg",
    category: "Kozmetik",
    rating: 4.8,
    reviews: 234,
    stock: 15,
    description:
      "Doğal organik lavanta yağı. Rahatlatıcı ve uyku kalitesini artırır.",
    featured: true,
  },
  {
    id: 2,
    name: "Himalaya Tuzu",
    price: 45.99,
    image: "/placeholder.svg",
    category: "Gıda",
    rating: 4.6,
    reviews: 156,
    stock: 8,
    description: "Saf Himalaya kristal tuzu. Mineraller açısından zengin.",
    featured: true,
  },
  {
    id: 3,
    name: "Kristal Terapi Seti",
    price: 199.99,
    oldPrice: 249.99,
    image: "/placeholder.svg",
    category: "Spiritüel",
    rating: 4.9,
    reviews: 89,
    stock: 5,
    description: "7 chakra kristali ile tam terapi seti.",
    featured: true,
  },
  {
    id: 4,
    name: "Mindfulness Rehberi",
    price: 79.99,
    image: "/placeholder.svg",
    category: "Kitap",
    rating: 4.7,
    reviews: 167,
    stock: 12,
    description: "Günlük yaşamda mindfulness pratiği için kapsamlı rehber.",
    featured: false,
  },
  {
    id: 5,
    name: "Ametist Kolye",
    price: 129.99,
    oldPrice: 159.99,
    image: "/placeholder.svg",
    category: "Takı",
    rating: 4.8,
    reviews: 67,
    stock: 3,
    description: "Doğal ametist taşlı gümüş kolye.",
    featured: false,
  },
];

const mockOrders = [
  {
    id: "ORD-2024-001",
    date: "2024-01-15",
    customerName: "Ayşe Yılmaz",
    customerEmail: "ayse@example.com",
    total: 299.99,
    status: "Teslim Edildi",
    items: [
      { name: "Organik Lavanta Yağı", quantity: 2, price: 89.99 },
      { name: "Himalaya Tuzu", quantity: 1, price: 45.99 },
    ],
  },
  {
    id: "ORD-2024-002",
    date: "2024-01-14",
    customerName: "Mehmet Kaya",
    customerEmail: "mehmet@example.com",
    total: 199.99,
    status: "Kargoda",
    items: [{ name: "Kristal Terapi Seti", quantity: 1, price: 199.99 }],
  },
];

type ViewMode = "home" | "product" | "cart" | "checkout" | "admin";

export default function MagazaPanel() {
  const navigate = useNavigate();
  const [currentView, setCurrentView] = useState<ViewMode>("home");
  const [selectedProduct, setSelectedProduct] = useState<any>(null);
  const [cartItems, setCartItems] = useState<any[]>([]);
  const [favorites, setFavorites] = useState<number[]>([1, 3]);
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isAdmin, setIsAdmin] = useState(false);

  const handleLogout = () => {
    sessionStorage.removeItem("kutbulzamanSession");
    toast({
      title: "Çıkış yapıldı",
      description: "kutbulzaman sisteminden başarıyla çıkış yaptınız.",
    });
    navigate("/");
  };

  // Cart functions
  const addToCart = (product: any, quantity = 1) => {
    const existingItem = cartItems.find((item) => item.id === product.id);
    if (existingItem) {
      setCartItems(
        cartItems.map((item) =>
          item.id === product.id
            ? { ...item, quantity: item.quantity + quantity }
            : item,
        ),
      );
    } else {
      setCartItems([...cartItems, { ...product, quantity }]);
    }
    toast({
      title: "Sepete eklendi!",
      description: `${product.name} sepetinize eklendi.`,
    });
  };

  const updateCartQuantity = (id: number, newQuantity: number) => {
    if (newQuantity === 0) {
      setCartItems(cartItems.filter((item) => item.id !== id));
    } else {
      setCartItems(
        cartItems.map((item) =>
          item.id === id ? { ...item, quantity: newQuantity } : item,
        ),
      );
    }
  };

  const toggleFavorite = (productId: number) => {
    setFavorites((prev) =>
      prev.includes(productId)
        ? prev.filter((id) => id !== productId)
        : [...prev, productId],
    );
  };

  const cartTotal = cartItems.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0,
  );

  const filteredProducts = featuredProducts.filter((product) => {
    const matchesCategory =
      selectedCategory === "all" || product.category === selectedCategory;
    const matchesSearch = product.name
      .toLowerCase()
      .includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  // Auto-slide for featured products
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) =>
        prev === featuredProducts.filter((p) => p.featured).length - 1
          ? 0
          : prev + 1,
      );
    }, 4000);
    return () => clearInterval(timer);
  }, []);

  // Header Component
  const Header = () => (
    <header className="bg-white shadow-sm border-b">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-blue-600 flex items-center justify-center">
              <Store className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-semibold text-gray-800">
                kutbulzaman Mağaza
              </h1>
              <p className="text-sm text-gray-600">E-Ticaret Sistemi</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            {currentView !== "home" && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentView("home")}
              >
                <Home className="w-4 h-4 mr-2" />
                Ana Sayfa
              </Button>
            )}
            <Button
              variant="outline"
              size="sm"
              className="relative"
              onClick={() => setCurrentView("cart")}
            >
              <ShoppingCart className="w-4 h-4 mr-2" />
              Sepet
              {cartItems.length > 0 && (
                <Badge className="absolute -top-2 -right-2 bg-blue-600 text-white">
                  {cartItems.length}
                </Badge>
              )}
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setIsAdmin(!isAdmin)}
            >
              <Settings className="w-4 h-4 mr-2" />
              {isAdmin ? "Müşteri" : "Admin"}
            </Button>
            <Button variant="outline" size="sm" onClick={handleLogout}>
              <LogOut className="w-4 h-4 mr-2" />
              Çıkış
            </Button>
          </div>
        </div>
      </div>
    </header>
  );

  // Featured Products Slider
  const FeaturedSlider = () => {
    const featured = featuredProducts.filter((p) => p.featured);
    return (
      <div className="relative mb-8 bg-white rounded-lg shadow-sm overflow-hidden">
        <div
          className="flex transition-transform duration-500 ease-in-out"
          style={{ transform: `translateX(-${currentSlide * 100}%)` }}
        >
          {featured.map((product) => (
            <div key={product.id} className="min-w-full relative">
              <div className="flex flex-col md:flex-row items-center p-8 bg-gradient-to-r from-blue-50 to-white">
                <div className="md:w-1/2 mb-6 md:mb-0">
                  <Badge className="mb-4 bg-red-500 text-white">
                    Öne Çıkan Ürün
                  </Badge>
                  <h2 className="text-3xl font-bold text-gray-800 mb-4">
                    {product.name}
                  </h2>
                  <p className="text-gray-600 mb-6">{product.description}</p>
                  <div className="flex items-center gap-4 mb-6">
                    <span className="text-3xl font-bold text-blue-600">
                      ₺{product.price}
                    </span>
                    {product.oldPrice && (
                      <span className="text-xl text-gray-400 line-through">
                        ₺{product.oldPrice}
                      </span>
                    )}
                  </div>
                  <div className="flex gap-3">
                    <Button
                      size="lg"
                      className="bg-blue-600 hover:bg-blue-700"
                      onClick={() => {
                        setSelectedProduct(product);
                        setCurrentView("product");
                      }}
                    >
                      İncele
                    </Button>
                    <Button
                      size="lg"
                      variant="outline"
                      onClick={() => addToCart(product)}
                    >
                      Sepete Ekle
                    </Button>
                  </div>
                </div>
                <div className="md:w-1/2 flex justify-center">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-64 h-64 object-cover rounded-lg shadow-lg"
                  />
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Slider Controls */}
        <Button
          variant="outline"
          size="sm"
          className="absolute left-4 top-1/2 transform -translate-y-1/2"
          onClick={() =>
            setCurrentSlide((prev) =>
              prev === 0 ? featured.length - 1 : prev - 1,
            )
          }
        >
          <ChevronLeft className="w-4 h-4" />
        </Button>
        <Button
          variant="outline"
          size="sm"
          className="absolute right-4 top-1/2 transform -translate-y-1/2"
          onClick={() =>
            setCurrentSlide((prev) =>
              prev === featured.length - 1 ? 0 : prev + 1,
            )
          }
        >
          <ChevronRight className="w-4 h-4" />
        </Button>

        {/* Dots */}
        <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex gap-2">
          {featured.map((_, index) => (
            <button
              key={index}
              className={`w-3 h-3 rounded-full ${
                index === currentSlide ? "bg-blue-600" : "bg-gray-300"
              }`}
              onClick={() => setCurrentSlide(index)}
            />
          ))}
        </div>
      </div>
    );
  };

  // Categories Section
  const CategoriesSection = () => (
    <div className="mb-8">
      <h2 className="text-2xl font-bold text-gray-800 mb-6">Kategoriler</h2>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        {categories.map((category) => (
          <Card
            key={category.id}
            className={`cursor-pointer transition-all hover:shadow-md ${
              selectedCategory === category.name
                ? "ring-2 ring-blue-600 bg-blue-50"
                : ""
            }`}
            onClick={() => setSelectedCategory(category.name)}
          >
            <CardContent className="p-4 text-center">
              <div className="text-3xl mb-2">{category.icon}</div>
              <h3 className="font-medium text-gray-800">{category.name}</h3>
              <p className="text-sm text-gray-500">{category.count} ürün</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );

  // Product Grid
  const ProductGrid = () => (
    <div className="mb-8">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-gray-800">
          {selectedCategory === "all" ? "Tüm Ürünler" : selectedCategory}
        </h2>
        <div className="flex gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Ürün ara..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 w-64"
            />
          </div>
          <Button variant="outline" onClick={() => setSelectedCategory("all")}>
            <Filter className="w-4 h-4 mr-2" />
            Tümü
          </Button>
        </div>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredProducts.map((product) => (
          <Card
            key={product.id}
            className="overflow-hidden hover:shadow-lg transition-shadow"
          >
            <div className="relative">
              <img
                src={product.image}
                alt={product.name}
                className="w-full h-48 object-cover cursor-pointer"
                onClick={() => {
                  setSelectedProduct(product);
                  setCurrentView("product");
                }}
              />
              <Button
                size="sm"
                variant="secondary"
                className="absolute top-2 right-2"
                onClick={() => toggleFavorite(product.id)}
              >
                <Heart
                  className={`w-4 h-4 ${
                    favorites.includes(product.id)
                      ? "fill-red-500 text-red-500"
                      : ""
                  }`}
                />
              </Button>
              {product.oldPrice && (
                <Badge className="absolute top-2 left-2 bg-red-500">
                  %
                  {Math.round(
                    ((product.oldPrice - product.price) / product.oldPrice) *
                      100,
                  )}{" "}
                  İndirim
                </Badge>
              )}
              {product.stock <= 5 && (
                <Badge className="absolute bottom-2 left-2 bg-orange-500">
                  Son {product.stock} adet!
                </Badge>
              )}
            </div>
            <CardContent className="p-4">
              <Badge variant="secondary" className="mb-2">
                {product.category}
              </Badge>
              <h3 className="font-semibold text-gray-800 mb-2">
                {product.name}
              </h3>
              <div className="flex items-center gap-1 mb-3">
                <div className="flex">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-4 h-4 ${
                        i < Math.floor(product.rating)
                          ? "fill-yellow-400 text-yellow-400"
                          : "text-gray-300"
                      }`}
                    />
                  ))}
                </div>
                <span className="text-sm text-gray-500">
                  ({product.reviews})
                </span>
              </div>
              <div className="flex justify-between items-center mb-3">
                <div>
                  <span className="text-xl font-bold text-blue-600">
                    ₺{product.price}
                  </span>
                  {product.oldPrice && (
                    <span className="text-sm text-gray-400 line-through ml-2">
                      ₺{product.oldPrice}
                    </span>
                  )}
                </div>
                <span
                  className={`text-sm ${product.stock > 10 ? "text-green-600" : "text-orange-600"}`}
                >
                  Stok: {product.stock}
                </span>
              </div>
              <div className="flex gap-2">
                <Button
                  size="sm"
                  className="flex-1 bg-blue-600 hover:bg-blue-700"
                  onClick={() => addToCart(product)}
                  disabled={product.stock === 0}
                >
                  <ShoppingCart className="w-4 h-4 mr-2" />
                  Sepete Ekle
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => {
                    setSelectedProduct(product);
                    setCurrentView("product");
                  }}
                >
                  <Eye className="w-4 h-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );

  // Product Detail View
  const ProductDetailView = () => {
    if (!selectedProduct) return null;

    return (
      <div className="max-w-6xl mx-auto">
        <Button
          variant="outline"
          className="mb-6"
          onClick={() => setCurrentView("home")}
        >
          <ChevronLeft className="w-4 h-4 mr-2" />
          Geri Dön
        </Button>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Product Image */}
          <div className="relative">
            <img
              src={selectedProduct.image}
              alt={selectedProduct.name}
              className="w-full rounded-lg shadow-lg cursor-zoom-in"
              onClick={() =>
                toast({
                  title: "Zoom özelliği",
                  description: "Ürün resmi zoom yapılabilir.",
                })
              }
            />
            <Button
              size="sm"
              className="absolute top-4 right-4"
              onClick={() =>
                toast({
                  title: "Zoom",
                  description: "Resim büyütülüyor...",
                })
              }
            >
              <ZoomIn className="w-4 h-4" />
            </Button>
          </div>

          {/* Product Info */}
          <div>
            <Badge variant="secondary" className="mb-4">
              {selectedProduct.category}
            </Badge>
            <h1 className="text-3xl font-bold text-gray-800 mb-4">
              {selectedProduct.name}
            </h1>

            {/* Rating */}
            <div className="flex items-center gap-2 mb-4">
              <div className="flex">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`w-5 h-5 ${
                      i < Math.floor(selectedProduct.rating)
                        ? "fill-yellow-400 text-yellow-400"
                        : "text-gray-300"
                    }`}
                  />
                ))}
              </div>
              <span className="text-gray-600">
                {selectedProduct.rating} ({selectedProduct.reviews}{" "}
                değerlendirme)
              </span>
            </div>

            {/* Price */}
            <div className="flex items-center gap-4 mb-6">
              <span className="text-4xl font-bold text-blue-600">
                ₺{selectedProduct.price}
              </span>
              {selectedProduct.oldPrice && (
                <div>
                  <span className="text-xl text-gray-400 line-through">
                    ₺{selectedProduct.oldPrice}
                  </span>
                  <Badge className="ml-2 bg-red-500">
                    %
                    {Math.round(
                      ((selectedProduct.oldPrice - selectedProduct.price) /
                        selectedProduct.oldPrice) *
                        100,
                    )}{" "}
                    İndirim
                  </Badge>
                </div>
              )}
            </div>

            {/* Stock Status */}
            <div className="mb-6">
              <div
                className={`inline-flex items-center px-3 py-1 rounded-full text-sm ${
                  selectedProduct.stock > 10
                    ? "bg-green-100 text-green-800"
                    : selectedProduct.stock > 0
                      ? "bg-orange-100 text-orange-800"
                      : "bg-red-100 text-red-800"
                }`}
              >
                <Package className="w-4 h-4 mr-2" />
                {selectedProduct.stock > 0
                  ? `Stokta ${selectedProduct.stock} adet`
                  : "Stokta yok"}
              </div>
            </div>

            {/* Description */}
            <div className="mb-8">
              <h3 className="text-lg font-semibold mb-3">Ürün Açıklaması</h3>
              <p className="text-gray-600 leading-relaxed">
                {selectedProduct.description}
              </p>
            </div>

            {/* Actions */}
            <div className="flex gap-4">
              <Button
                size="lg"
                className="flex-1 bg-blue-600 hover:bg-blue-700"
                onClick={() => addToCart(selectedProduct)}
                disabled={selectedProduct.stock === 0}
              >
                <ShoppingCart className="w-5 h-5 mr-2" />
                Sepete Ekle
              </Button>
              <Button
                size="lg"
                variant="outline"
                onClick={() => toggleFavorite(selectedProduct.id)}
              >
                <Heart
                  className={`w-5 h-5 ${
                    favorites.includes(selectedProduct.id)
                      ? "fill-red-500 text-red-500"
                      : ""
                  }`}
                />
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
  };

  // Cart View
  const CartView = () => (
    <div className="max-w-4xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-gray-800">Alışveriş Sepeti</h1>
        <Button variant="outline" onClick={() => setCurrentView("home")}>
          <ChevronLeft className="w-4 h-4 mr-2" />
          Alışverişe Devam
        </Button>
      </div>

      {cartItems.length === 0 ? (
        <Card>
          <CardContent className="p-8 text-center">
            <ShoppingCart className="w-16 h-16 mx-auto text-gray-400 mb-4" />
            <h3 className="text-xl font-semibold mb-2">Sepetiniz boş</h3>
            <p className="text-gray-600 mb-4">
              Alışverişe başlamak için ürünleri inceleyin
            </p>
            <Button onClick={() => setCurrentView("home")}>
              Ürünleri İncele
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Cart Items */}
          <div className="lg:col-span-2">
            <Card>
              <CardContent className="p-6">
                <div className="space-y-4">
                  {cartItems.map((item) => (
                    <div
                      key={item.id}
                      className="flex gap-4 p-4 border rounded-lg"
                    >
                      <img
                        src={item.image}
                        alt={item.name}
                        className="w-20 h-20 object-cover rounded"
                      />
                      <div className="flex-1">
                        <h4 className="font-semibold">{item.name}</h4>
                        <p className="text-sm text-gray-600">{item.category}</p>
                        <p className="font-bold text-blue-600">₺{item.price}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() =>
                            updateCartQuantity(item.id, item.quantity - 1)
                          }
                        >
                          <Minus className="w-3 h-3" />
                        </Button>
                        <span className="w-12 text-center">
                          {item.quantity}
                        </span>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() =>
                            updateCartQuantity(item.id, item.quantity + 1)
                          }
                        >
                          <Plus className="w-3 h-3" />
                        </Button>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold">
                          ₺{(item.price * item.quantity).toFixed(2)}
                        </p>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => updateCartQuantity(item.id, 0)}
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Order Summary */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle>Sipariş Özeti</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span>Ara Toplam:</span>
                    <span>₺{cartTotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Kargo:</span>
                    <span>{cartTotal > 150 ? "Ücretsiz" : "₺15.00"}</span>
                  </div>
                  <Separator />
                  <div className="flex justify-between font-bold text-lg">
                    <span>Toplam:</span>
                    <span>
                      ₺{(cartTotal + (cartTotal > 150 ? 0 : 15)).toFixed(2)}
                    </span>
                  </div>
                  <Button
                    className="w-full bg-blue-600 hover:bg-blue-700"
                    size="lg"
                    onClick={() => setCurrentView("checkout")}
                  >
                    Satın Al
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      )}
    </div>
  );

  // Checkout View
  const CheckoutView = () => {
    const [formData, setFormData] = useState({
      name: "",
      email: "",
      phone: "",
      address: "",
      city: "",
      paymentMethod: "credit-card",
    });

    const handleSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      toast({
        title: "Sipariş alındı!",
        description: "Siparişiniz başarıyla oluşturuldu.",
      });
      setCartItems([]);
      setCurrentView("home");
    };

    return (
      <div className="max-w-4xl mx-auto">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold text-gray-800">Sipariş Ver</h1>
          <Button variant="outline" onClick={() => setCurrentView("cart")}>
            <ChevronLeft className="w-4 h-4 mr-2" />
            Sepete Dön
          </Button>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="grid lg:grid-cols-3 gap-6">
            {/* User Information */}
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle>Kullanıcı Bilgileri</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="name">Ad Soyad</Label>
                      <Input
                        id="name"
                        required
                        value={formData.name}
                        onChange={(e) =>
                          setFormData({ ...formData, name: e.target.value })
                        }
                      />
                    </div>
                    <div>
                      <Label htmlFor="email">E-posta</Label>
                      <Input
                        id="email"
                        type="email"
                        required
                        value={formData.email}
                        onChange={(e) =>
                          setFormData({ ...formData, email: e.target.value })
                        }
                      />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="phone">Telefon</Label>
                    <Input
                      id="phone"
                      required
                      value={formData.phone}
                      onChange={(e) =>
                        setFormData({ ...formData, phone: e.target.value })
                      }
                    />
                  </div>
                  <div>
                    <Label htmlFor="address">Teslimat Adresi</Label>
                    <Textarea
                      id="address"
                      required
                      value={formData.address}
                      onChange={(e) =>
                        setFormData({ ...formData, address: e.target.value })
                      }
                    />
                  </div>
                  <div>
                    <Label htmlFor="city">Şehir</Label>
                    <Select
                      value={formData.city}
                      onValueChange={(value) =>
                        setFormData({ ...formData, city: value })
                      }
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Şehir seçin" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="istanbul">İstanbul</SelectItem>
                        <SelectItem value="ankara">Ankara</SelectItem>
                        <SelectItem value="izmir">İzmir</SelectItem>
                        <SelectItem value="bursa">Bursa</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </CardContent>
              </Card>

              {/* Payment Method */}
              <Card className="mt-6">
                <CardHeader>
                  <CardTitle>Ödeme Yöntemi</CardTitle>
                </CardHeader>
                <CardContent>
                  <RadioGroup
                    value={formData.paymentMethod}
                    onValueChange={(value) =>
                      setFormData({ ...formData, paymentMethod: value })
                    }
                  >
                    <div className="flex items-center space-x-2 p-4 border rounded-lg">
                      <RadioGroupItem value="credit-card" id="credit-card" />
                      <Label
                        htmlFor="credit-card"
                        className="flex items-center gap-2 cursor-pointer"
                      >
                        <CreditCard className="w-5 h-5" />
                        Kredi Kartı (Placeholder)
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2 p-4 border rounded-lg">
                      <RadioGroupItem
                        value="bank-transfer"
                        id="bank-transfer"
                      />
                      <Label
                        htmlFor="bank-transfer"
                        className="flex items-center gap-2 cursor-pointer"
                      >
                        <Banknote className="w-5 h-5" />
                        Havale/EFT
                      </Label>
                    </div>
                  </RadioGroup>

                  {formData.paymentMethod === "bank-transfer" && (
                    <div className="mt-4 p-4 bg-blue-50 rounded-lg">
                      <h4 className="font-semibold mb-2">
                        Havale/EFT Bilgileri
                      </h4>
                      <p className="text-sm text-gray-600">
                        Banka: Ziraat Bankası
                        <br />
                        IBAN: TR12 0001 0000 0000 0000 0000 00
                        <br />
                        Hesap Sahibi: E-Ticaret Mağaza Ltd. Şti.
                        <br />
                        <strong>Önemli:</strong> Havale açıklamasına sipariş
                        numaranızı yazınız.
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Order Summary */}
            <div>
              <Card>
                <CardHeader>
                  <CardTitle>Sipariş Özeti</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {cartItems.map((item) => (
                      <div
                        key={item.id}
                        className="flex justify-between text-sm"
                      >
                        <span>
                          {item.name} x{item.quantity}
                        </span>
                        <span>₺{(item.price * item.quantity).toFixed(2)}</span>
                      </div>
                    ))}
                    <Separator />
                    <div className="flex justify-between">
                      <span>Ara Toplam:</span>
                      <span>₺{cartTotal.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Kargo:</span>
                      <span>{cartTotal > 150 ? "Ücretsiz" : "₺15.00"}</span>
                    </div>
                    <Separator />
                    <div className="flex justify-between font-bold text-lg">
                      <span>Toplam:</span>
                      <span>
                        ₺{(cartTotal + (cartTotal > 150 ? 0 : 15)).toFixed(2)}
                      </span>
                    </div>
                    <Button
                      type="submit"
                      className="w-full bg-blue-600 hover:bg-blue-700"
                      size="lg"
                    >
                      Siparişi Onayla
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </form>
      </div>
    );
  };

  // Admin Panel
  const AdminPanel = () => {
    const [newProduct, setNewProduct] = useState({
      name: "",
      price: "",
      category: "",
      stock: "",
      description: "",
    });

    const handleAddProduct = (e: React.FormEvent) => {
      e.preventDefault();
      toast({
        title: "Ürün eklendi!",
        description: `${newProduct.name} başarıyla eklendi.`,
      });
      setNewProduct({
        name: "",
        price: "",
        category: "",
        stock: "",
        description: "",
      });
    };

    return (
      <div className="max-w-6xl mx-auto">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold text-gray-800">Admin Paneli</h1>
          <Button variant="outline" onClick={() => setCurrentView("home")}>
            <ChevronLeft className="w-4 h-4 mr-2" />
            Mağazaya Dön
          </Button>
        </div>

        <div className="grid lg:grid-cols-2 gap-6">
          {/* Add Product */}
          <Card>
            <CardHeader>
              <CardTitle>Yeni Ürün Ekle</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleAddProduct} className="space-y-4">
                <div>
                  <Label htmlFor="product-name">Ürün Adı</Label>
                  <Input
                    id="product-name"
                    required
                    value={newProduct.name}
                    onChange={(e) =>
                      setNewProduct({ ...newProduct, name: e.target.value })
                    }
                  />
                </div>
                <div>
                  <Label htmlFor="product-price">Fiyat</Label>
                  <Input
                    id="product-price"
                    type="number"
                    step="0.01"
                    required
                    value={newProduct.price}
                    onChange={(e) =>
                      setNewProduct({ ...newProduct, price: e.target.value })
                    }
                  />
                </div>
                <div>
                  <Label htmlFor="product-category">Kategori</Label>
                  <Select
                    value={newProduct.category}
                    onValueChange={(value) =>
                      setNewProduct({ ...newProduct, category: value })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Kategori seçin" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map((cat) => (
                        <SelectItem key={cat.id} value={cat.name}>
                          {cat.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="product-stock">Stok</Label>
                  <Input
                    id="product-stock"
                    type="number"
                    required
                    value={newProduct.stock}
                    onChange={(e) =>
                      setNewProduct({ ...newProduct, stock: e.target.value })
                    }
                  />
                </div>
                <div>
                  <Label htmlFor="product-description">Açıklama</Label>
                  <Textarea
                    id="product-description"
                    value={newProduct.description}
                    onChange={(e) =>
                      setNewProduct({
                        ...newProduct,
                        description: e.target.value,
                      })
                    }
                  />
                </div>
                <Button
                  type="submit"
                  className="w-full bg-blue-600 hover:bg-blue-700"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Ürün Ekle
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Product Management */}
          <Card>
            <CardHeader>
              <CardTitle>Ürün Yönetimi</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {featuredProducts.slice(0, 5).map((product) => (
                  <div
                    key={product.id}
                    className="flex justify-between items-center p-3 border rounded"
                  >
                    <div>
                      <p className="font-medium">{product.name}</p>
                      <p className="text-sm text-gray-600">
                        Stok: {product.stock}
                      </p>
                    </div>
                    <div className="flex gap-2">
                      <Button size="sm" variant="outline">
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button size="sm" variant="outline">
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Orders Management */}
        <Card className="mt-6">
          <CardHeader>
            <CardTitle>Sipariş Listesi</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {mockOrders.map((order) => (
                <div
                  key={order.id}
                  className="flex justify-between items-start p-4 border rounded"
                >
                  <div>
                    <p className="font-medium">{order.id}</p>
                    <p className="text-sm text-gray-600">
                      {order.customerName} - {order.customerEmail}
                    </p>
                    <p className="text-sm text-gray-600">{order.date}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-bold">₺{order.total}</p>
                    <Badge
                      variant={
                        order.status === "Teslim Edildi"
                          ? "default"
                          : "secondary"
                      }
                    >
                      {order.status}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />

      <main className="container mx-auto px-4 py-8">
        {isAdmin && currentView === "home" ? (
          <AdminPanel />
        ) : currentView === "home" ? (
          <>
            <FeaturedSlider />
            <CategoriesSection />
            <ProductGrid />
          </>
        ) : currentView === "product" ? (
          <ProductDetailView />
        ) : currentView === "cart" ? (
          <CartView />
        ) : currentView === "checkout" ? (
          <CheckoutView />
        ) : currentView === "admin" ? (
          <AdminPanel />
        ) : null}
      </main>
    </div>
  );
}
