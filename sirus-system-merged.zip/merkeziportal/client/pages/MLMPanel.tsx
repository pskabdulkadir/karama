import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Network,
  Home,
  LogOut,
  TrendingUp,
  Users,
  DollarSign,
  Award,
} from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "@/hooks/use-toast";

export default function MLMPanel() {
  const navigate = useNavigate();

  const handleLogout = () => {
    sessionStorage.removeItem("kutbulzamanSession");
    toast({
      title: "Çıkış yapıldı",
      description: "kutbulzaman sisteminden başarıyla çıkış yaptınız.",
    });
    navigate("/");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-mystical-gradient-from via-mystical-gradient-via to-mystical-gradient-to">
      {/* Header */}
      <header className="bg-white/95 backdrop-blur-sm border-b border-mystical-indigo/20">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-gradient-to-r from-mystical-indigo to-mystical-blue flex items-center justify-center">
                <Network className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-semibold bg-gradient-to-r from-mystical-blue to-mystical-purple bg-clip-text text-transparent">
                  MLM / Network Paneli
                </h1>
                <p className="text-sm text-muted-foreground">
                  kutbulzaman sistemi
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Link to="/">
                <Button
                  variant="outline"
                  size="sm"
                  className="border-mystical-indigo/20 text-mystical-indigo hover:bg-mystical-indigo/10"
                >
                  <Home className="w-4 h-4 mr-2" />
                  Ana Giriş
                </Button>
              </Link>
              <Button
                variant="outline"
                size="sm"
                className="border-destructive/20 text-destructive hover:bg-destructive/10"
                onClick={handleLogout}
              >
                <LogOut className="w-4 h-4 mr-2" />
                Çıkış
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Welcome Card */}
          <Card className="md:col-span-2 lg:col-span-3 bg-white/95 backdrop-blur-sm border-mystical-indigo/20">
            <CardHeader>
              <CardTitle className="text-2xl bg-gradient-to-r from-mystical-blue to-mystical-purple bg-clip-text text-transparent">
                MLM Yönetim Paneli
              </CardTitle>
              <CardDescription>
                Ekibinizi yönetin, bonuslarınızı takip edin ve network'ünüzü
                büyütün
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground mb-4">
                Bu panelde sponsorluk aktivitelerinizi, ekip performansınızı ve
                bonus sisteminizi yönetebilirsiniz.
              </p>
              <div className="flex gap-4">
                <Button className="bg-gradient-to-r from-mystical-indigo to-mystical-blue hover:from-mystical-indigo/90 hover:to-mystical-blue/90 text-white">
                  Ekibimi Görüntüle
                </Button>
                <Button
                  variant="outline"
                  className="border-mystical-indigo/20 text-mystical-indigo hover:bg-mystical-indigo/10"
                >
                  Rapor Al
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Stats Cards */}
          <Card className="bg-white/95 backdrop-blur-sm border-mystical-indigo/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5 text-mystical-indigo" />
                Ekip Üyeleri
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-mystical-indigo mb-2">
                24
              </div>
              <p className="text-sm text-muted-foreground">
                Aktif ekip üyesi sayısı
              </p>
            </CardContent>
          </Card>

          <Card className="bg-white/95 backdrop-blur-sm border-mystical-blue/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <DollarSign className="w-5 h-5 text-mystical-blue" />
                Bu Ay Kazanç
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-mystical-blue mb-2">
                ₺15,750
              </div>
              <p className="text-sm text-muted-foreground">
                %23 artış geçen aya göre
              </p>
            </CardContent>
          </Card>

          <Card className="bg-white/95 backdrop-blur-sm border-mystical-purple/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-mystical-purple" />
                Performans
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-mystical-purple mb-2">
                87%
              </div>
              <p className="text-sm text-muted-foreground">
                Hedef tamamlanma oranı
              </p>
            </CardContent>
          </Card>

          {/* Action Cards */}
          <Card className="bg-white/95 backdrop-blur-sm border-mystical-indigo/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Award className="w-5 h-5 text-mystical-indigo" />
                Sponsorluk
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                Yeni üye sponsor edin
              </p>
              <Button
                variant="outline"
                className="w-full border-mystical-indigo/20 text-mystical-indigo hover:bg-mystical-indigo/10"
              >
                Sponsor Ol
              </Button>
            </CardContent>
          </Card>

          <Card className="bg-white/95 backdrop-blur-sm border-mystical-blue/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Network className="w-5 h-5 text-mystical-blue" />
                Network Haritası
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                Ekip yapınızı görüntüleyin
              </p>
              <Button
                variant="outline"
                className="w-full border-mystical-blue/20 text-mystical-blue hover:bg-mystical-blue/10"
              >
                Haritayı Görüntüle
              </Button>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
