import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Settings,
  Home,
  LogOut,
  Users,
  Package,
  BarChart3,
  Shield,
  Database,
  Bell,
} from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "@/hooks/use-toast";

export default function AdminPanel() {
  const navigate = useNavigate();

  const handleLogout = () => {
    sessionStorage.removeItem("kutbulzamanSession");
    toast({
      title: "Çıkış yapıldı",
      description: "kutbulzaman sisteminden başarıyla çıkış yaptınız.",
    });
    navigate("/");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-mystical-gradient-from via-mystical-gradient-via to-mystical-gradient-to">
      {/* Header */}
      <header className="bg-white/95 backdrop-blur-sm border-b border-red-500/20">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-gradient-to-r from-red-500 to-red-600 flex items-center justify-center">
                <Shield className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-semibold bg-gradient-to-r from-red-500 to-red-600 bg-clip-text text-transparent">
                  kutbulzaman Admin
                </h1>
                <p className="text-sm text-muted-foreground">
                  Merkezi Yönetim Sistemi
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Link to="/">
                <Button
                  variant="outline"
                  size="sm"
                  className="border-red-500/20 text-red-500 hover:bg-red-500/10"
                >
                  <Home className="w-4 h-4 mr-2" />
                  Ana Giriş
                </Button>
              </Link>
              <Button
                variant="outline"
                size="sm"
                className="border-destructive/20 text-destructive hover:bg-destructive/10"
                onClick={handleLogout}
              >
                <LogOut className="w-4 h-4 mr-2" />
                Çıkış
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Welcome Card */}
          <Card className="md:col-span-2 lg:col-span-3 bg-white/95 backdrop-blur-sm border-red-500/20">
            <CardHeader>
              <CardTitle className="text-2xl bg-gradient-to-r from-red-500 to-red-600 bg-clip-text text-transparent">
                Admin Kontrol Merkezi
              </CardTitle>
              <CardDescription>
                Tüm sistemleri buradan yönetin ve kontrol edin
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground mb-4">
                Bu panelde tüm sistem yönetimi, kullanıcı kontrolü ve sistem
                ayarlarını gerçekleştirebilirsiniz.
              </p>
              <div className="flex gap-4">
                <Button className="bg-gradient-to-r from-red-500 to-red-600 hover:from-red-500/90 hover:to-red-600/90 text-white">
                  Sistem Durumu
                </Button>
                <Button
                  variant="outline"
                  className="border-red-500/20 text-red-500 hover:bg-red-500/10"
                >
                  Ayarlar
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* System Management */}
          <Card className="bg-white/95 backdrop-blur-sm border-red-500/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5 text-red-500" />
                Kullanıcı Yönetimi
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-red-500 mb-2">1,234</div>
              <p className="text-sm text-muted-foreground mb-4">
                Aktif kullanıcı sayısı
              </p>
              <Button
                variant="outline"
                className="w-full border-red-500/20 text-red-500 hover:bg-red-500/10"
              >
                Kullanıcıları Yönet
              </Button>
            </CardContent>
          </Card>

          <Card className="bg-white/95 backdrop-blur-sm border-orange-500/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Package className="w-5 h-5 text-orange-500" />
                Ürün Yönetimi
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-orange-500 mb-2">567</div>
              <p className="text-sm text-muted-foreground mb-4">
                Toplam ürün sayısı
              </p>
              <Button
                variant="outline"
                className="w-full border-orange-500/20 text-orange-500 hover:bg-orange-500/10"
              >
                Ürünleri Yönet
              </Button>
            </CardContent>
          </Card>

          <Card className="bg-white/95 backdrop-blur-sm border-blue-500/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="w-5 h-5 text-blue-500" />
                Analitik & Raporlar
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-blue-500 mb-2">98.5%</div>
              <p className="text-sm text-muted-foreground mb-4">
                Sistem performansı
              </p>
              <Button
                variant="outline"
                className="w-full border-blue-500/20 text-blue-500 hover:bg-blue-500/10"
              >
                Raporları Görüntüle
              </Button>
            </CardContent>
          </Card>

          {/* System Controls */}
          <Card className="bg-white/95 backdrop-blur-sm border-green-500/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database className="w-5 h-5 text-green-500" />
                Sistem Yedekleme
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                Son yedek: 2 saat önce
              </p>
              <Button
                variant="outline"
                className="w-full border-green-500/20 text-green-500 hover:bg-green-500/10"
              >
                Yedek Al
              </Button>
            </CardContent>
          </Card>

          <Card className="bg-white/95 backdrop-blur-sm border-purple-500/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="w-5 h-5 text-purple-500" />
                Sistem Ayarları
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                Genel sistem konfigürasyonu
              </p>
              <Button
                variant="outline"
                className="w-full border-purple-500/20 text-purple-500 hover:bg-purple-500/10"
              >
                Ayarları Düzenle
              </Button>
            </CardContent>
          </Card>

          <Card className="bg-white/95 backdrop-blur-sm border-yellow-500/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bell className="w-5 h-5 text-yellow-500" />
                Sistem Bildirimleri
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-yellow-500 mb-2">3</div>
              <p className="text-sm text-muted-foreground mb-4">
                Bekleyen bildirim
              </p>
              <Button
                variant="outline"
                className="w-full border-yellow-500/20 text-yellow-500 hover:bg-yellow-500/10"
              >
                Bildirimleri Gör
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="mt-8">
          <Card className="bg-white/95 backdrop-blur-sm border-red-500/20">
            <CardHeader>
              <CardTitle className="text-red-500">Hızlı İşlemler</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-4 gap-4">
                <Button className="bg-red-500 hover:bg-red-600 text-white">
                  Kullanıcı Ekle
                </Button>
                <Button className="bg-orange-500 hover:bg-orange-600 text-white">
                  Ürün Ekle
                </Button>
                <Button className="bg-blue-500 hover:bg-blue-600 text-white">
                  Rapor Oluştur
                </Button>
                <Button className="bg-green-500 hover:bg-green-600 text-white">
                  Sistem Kontrolü
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
