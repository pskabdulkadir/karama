import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Store,
  Home,
  LogOut,
  ShoppingCart,
  Package,
  TrendingUp,
  DollarSign,
  Users,
  BarChart3,
  Plus,
} from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "@/hooks/use-toast";
import KutbulHeader from "@/components/KutbulHeader";

export default function MarketPage() {
  const navigate = useNavigate();
  const [userData, setUserData] = useState<any>(null);

  useEffect(() => {
    // Load user data from localStorage
    const authData = localStorage.getItem("kutbulzamanAuth");
    const sessionData = sessionStorage.getItem("kutbulzamanSession");

    if (!authData && !sessionData) {
      toast({
        title: "Oturum bulunamadı",
        description: "Lütfen giriş yapın.",
        variant: "destructive",
      });
      navigate("/");
      return;
    }

    const user = authData ? JSON.parse(authData) : JSON.parse(sessionData!);
    setUserData(user);
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem("kutbulzamanAuth");
    sessionStorage.removeItem("kutbulzamanSession");
    toast({
      title: "Çıkış yapıldı",
      description: "kutbulzaman sisteminden başarıyla çıkış yaptınız.",
    });
    navigate("/");
  };

  if (!userData) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-600 via-purple-600 to-indigo-800 flex items-center justify-center">
        <div className="text-center text-white">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-white mx-auto mb-4"></div>
          <p>Yükleniyor...</p>
        </div>
      </div>
    );
  }

  const isSeller = userData.role === "bayi";

  return (
    <div className="min-h-screen bg-gradient-to-br from-kutbul-purple via-kutbul-teal to-kutbul-purple-light">
      {/* Header */}
      <KutbulHeader currentPage="market" />

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Welcome Card */}
          <Card className="md:col-span-2 lg:col-span-3 bg-white/95 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-2xl text-gray-800">
                Hoş Geldiniz, {userData.name}!
              </CardTitle>
              <CardDescription>
                {isSeller
                  ? "Ürünlerinizi yönetin ve satışlarınızı takip edin"
                  : "kutbulzaman market'e hoş geldiniz"}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-4">
                {isSeller
                  ? "Bu panelde ürün ekleme, stok yönetimi, sipariş takibi ve satış analizlerinizi gerçekleştirebilirsiniz."
                  : "Kaliteli ürünleri keşfedin, sepetinizi yönetin ve güvenle alışveriş yapın."}
              </p>
              <div className="flex gap-4">
                <Button className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white">
                  {isSeller ? "Ürün Ekle" : "Ürünleri İncele"}
                </Button>
                <Button
                  variant="outline"
                  className="border-blue-500/20 text-blue-600 hover:bg-blue-50"
                >
                  {isSeller ? "Satış Raporları" : "Kategoriler"}
                </Button>
              </div>
            </CardContent>
          </Card>

          {isSeller ? (
            // Seller Dashboard
            <>
              <Card className="bg-white/95 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Package className="w-5 h-5 text-blue-600" />
                    Ürünlerim
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-blue-600 mb-2">
                    23
                  </div>
                  <p className="text-sm text-gray-600 mb-4">Aktif ürün</p>
                  <Button
                    variant="outline"
                    className="w-full border-blue-500/20 text-blue-600 hover:bg-blue-50"
                  >
                    Ürünleri Yönet
                  </Button>
                </CardContent>
              </Card>

              <Card className="bg-white/95 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <DollarSign className="w-5 h-5 text-green-600" />
                    Bu Ay Kazanç
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-green-600 mb-2">
                    ₺12,450
                  </div>
                  <p className="text-sm text-gray-600 mb-4">%15 artış</p>
                  <Button
                    variant="outline"
                    className="w-full border-green-500/20 text-green-600 hover:bg-green-50"
                  >
                    Detaylı Rapor
                  </Button>
                </CardContent>
              </Card>

              <Card className="bg-white/95 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="w-5 h-5 text-purple-600" />
                    Siparişler
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-purple-600 mb-2">
                    47
                  </div>
                  <p className="text-sm text-gray-600 mb-4">Bu ay</p>
                  <Button
                    variant="outline"
                    className="w-full border-purple-500/20 text-purple-600 hover:bg-purple-50"
                  >
                    Siparişleri Gör
                  </Button>
                </CardContent>
              </Card>

              <Card className="bg-white/95 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="w-5 h-5 text-orange-600" />
                    Müşteriler
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-orange-600 mb-2">
                    156
                  </div>
                  <p className="text-sm text-gray-600 mb-4">Aktif müşteri</p>
                  <Button
                    variant="outline"
                    className="w-full border-orange-500/20 text-orange-600 hover:bg-orange-50"
                  >
                    Müşteri Listesi
                  </Button>
                </CardContent>
              </Card>

              <Card className="bg-white/95 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3 className="w-5 h-5 text-indigo-600" />
                    Analitik
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-indigo-600 mb-2">
                    92%
                  </div>
                  <p className="text-sm text-gray-600 mb-4">
                    Müşteri memnuniyeti
                  </p>
                  <Button
                    variant="outline"
                    className="w-full border-indigo-500/20 text-indigo-600 hover:bg-indigo-50"
                  >
                    Analiz Raporları
                  </Button>
                </CardContent>
              </Card>

              <Card className="bg-white/95 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Plus className="w-5 h-5 text-teal-600" />
                    Hızlı İşlemler
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <Button className="w-full bg-teal-600 hover:bg-teal-700 text-white">
                      Yeni Ürün Ekle
                    </Button>
                    <Button
                      variant="outline"
                      className="w-full border-teal-500/20 text-teal-600 hover:bg-teal-50"
                    >
                      Stok Güncelle
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </>
          ) : (
            // Customer Dashboard
            <>
              <Card className="bg-white/95 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <ShoppingCart className="w-5 h-5 text-blue-600" />
                    Alışverişim
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-blue-600 mb-2">0</div>
                  <p className="text-sm text-gray-600 mb-4">Sepetteki ürün</p>
                  <Button
                    variant="outline"
                    className="w-full border-blue-500/20 text-blue-600 hover:bg-blue-50"
                  >
                    Alışverişe Başla
                  </Button>
                </CardContent>
              </Card>

              <Card className="bg-white/95 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Package className="w-5 h-5 text-green-600" />
                    Siparişlerim
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-green-600 mb-2">
                    3
                  </div>
                  <p className="text-sm text-gray-600 mb-4">Aktif sipariş</p>
                  <Button
                    variant="outline"
                    className="w-full border-green-500/20 text-green-600 hover:bg-green-50"
                  >
                    Siparişleri Görüntüle
                  </Button>
                </CardContent>
              </Card>

              <Card className="bg-white/95 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="w-5 h-5 text-purple-600" />
                    Favorilerim
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-purple-600 mb-2">
                    8
                  </div>
                  <p className="text-sm text-gray-600 mb-4">Favori ürün</p>
                  <Button
                    variant="outline"
                    className="w-full border-purple-500/20 text-purple-600 hover:bg-purple-50"
                  >
                    Favorileri Gör
                  </Button>
                </CardContent>
              </Card>
            </>
          )}
        </div>
      </main>
    </div>
  );
}
