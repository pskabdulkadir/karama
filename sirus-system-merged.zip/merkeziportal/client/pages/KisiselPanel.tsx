import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Brain, Home, LogOut, Calendar, Book, Users } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "@/hooks/use-toast";

export default function KisiselPanel() {
  const navigate = useNavigate();

  const handleLogout = () => {
    sessionStorage.removeItem("kutbulzamanSession");
    toast({
      title: "Çıkış yapıldı",
      description: "kutbulzaman sisteminden başarıyla çıkış yaptınız.",
    });
    navigate("/");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-mystical-gradient-from via-mystical-gradient-via to-mystical-gradient-to">
      {/* Header */}
      <header className="bg-white/95 backdrop-blur-sm border-b border-mystical-purple/20">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-gradient-to-r from-mystical-purple to-mystical-indigo flex items-center justify-center">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-semibold bg-gradient-to-r from-mystical-blue to-mystical-purple bg-clip-text text-transparent">
                  Kişisel Gelişim Paneli
                </h1>
                <p className="text-sm text-muted-foreground">
                  kutbulzaman sistemi
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Link to="/">
                <Button
                  variant="outline"
                  size="sm"
                  className="border-mystical-purple/20 text-mystical-purple hover:bg-mystical-purple/10"
                >
                  <Home className="w-4 h-4 mr-2" />
                  Ana Giriş
                </Button>
              </Link>
              <Button
                variant="outline"
                size="sm"
                className="border-destructive/20 text-destructive hover:bg-destructive/10"
                onClick={handleLogout}
              >
                <LogOut className="w-4 h-4 mr-2" />
                Çıkış
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Welcome Card */}
          <Card className="md:col-span-2 lg:col-span-3 bg-white/95 backdrop-blur-sm border-mystical-purple/20">
            <CardHeader>
              <CardTitle className="text-2xl bg-gradient-to-r from-mystical-blue to-mystical-purple bg-clip-text text-transparent">
                Hoş Geldiniz!
              </CardTitle>
              <CardDescription>
                Kişisel gelişim yolculuğunuza devam etmeye hazır mısınız?
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground mb-4">
                Bu panelde kuantum, psikoloji ve danışmanlık hizmetlerine
                erişebilir, kişisel gelişim programlarınızı takip edebilirsiniz.
              </p>
              <Button className="bg-gradient-to-r from-mystical-blue to-mystical-purple hover:from-mystical-blue/90 hover:to-mystical-purple/90 text-white">
                Programlarımı Görüntüle
              </Button>
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <Card className="bg-white/95 backdrop-blur-sm border-mystical-purple/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="w-5 h-5 text-mystical-purple" />
                Randevularım
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                Yaklaşan danışmanlık seanslarınız
              </p>
              <Button
                variant="outline"
                className="w-full border-mystical-purple/20 text-mystical-purple hover:bg-mystical-purple/10"
              >
                Randevu Al
              </Button>
            </CardContent>
          </Card>

          <Card className="bg-white/95 backdrop-blur-sm border-mystical-blue/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Book className="w-5 h-5 text-mystical-blue" />
                Eğitim Materyalleri
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                Kişisel gelişim kaynaklarınız
              </p>
              <Button
                variant="outline"
                className="w-full border-mystical-blue/20 text-mystical-blue hover:bg-mystical-blue/10"
              >
                Materyalleri Görüntüle
              </Button>
            </CardContent>
          </Card>

          <Card className="bg-white/95 backdrop-blur-sm border-mystical-indigo/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5 text-mystical-indigo" />
                Topluluk
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                Diğer katılımcılarla bağlantı kurun
              </p>
              <Button
                variant="outline"
                className="w-full border-mystical-indigo/20 text-mystical-indigo hover:bg-mystical-indigo/10"
              >
                Topluluğa Katıl
              </Button>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
