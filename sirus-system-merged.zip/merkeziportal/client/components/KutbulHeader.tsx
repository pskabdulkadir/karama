import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import {
  User,
  Bell,
  LogOut,
  Menu,
  X,
  Home,
  Info,
  UserPlus,
  LogIn,
} from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "@/hooks/use-toast";

interface KutbulHeaderProps {
  currentPage?: string;
}

export default function KutbulHeader({ currentPage }: KutbulHeaderProps) {
  const navigate = useNavigate();
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userData, setUserData] = useState<any>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    // Check authentication status
    const authData = localStorage.getItem("kutbulzamanAuth");
    const sessionData = sessionStorage.getItem("kutbulzamanSession");

    if (authData || sessionData) {
      setIsLoggedIn(true);
      const user = authData ? JSON.parse(authData) : JSON.parse(sessionData!);
      setUserData(user);
    } else {
      setIsLoggedIn(false);
      setUserData(null);
    }
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("kutbulzamanAuth");
    sessionStorage.removeItem("kutbulzamanSession");
    setIsLoggedIn(false);
    setUserData(null);
    toast({
      title: "Çıkış yapıldı",
      description: "Kutbul Zaman sisteminden başarıyla çıkış yaptınız.",
    });
    navigate("/");
  };

  const handleLogin = () => {
    navigate("/");
  };

  const handleRegister = () => {
    navigate("/?register=true");
  };

  const navItems = isLoggedIn
    ? [
        { label: "Profilim", href: "/profile", icon: User },
        { label: "Bildirimler", href: "/notifications", icon: Bell },
      ]
    : [
        { label: "Ana Sayfa", href: "/", icon: Home },
        { label: "Hakkımızda", href: "/about", icon: Info },
        { label: "Giriş", href: "/", icon: LogIn, action: handleLogin },
        {
          label: "Üye Ol",
          href: "/register",
          icon: UserPlus,
          action: handleRegister,
        },
      ];

  return (
    <header className="sticky top-0 z-50 w-full border-b border-kutbul-gray bg-kutbul-white/95 backdrop-blur supports-[backdrop-filter]:bg-kutbul-white/60">
      <div className="container mx-auto px-4">
        <div className="flex h-16 items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-2">
            <div className="flex items-center">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-kutbul-purple to-kutbul-teal flex items-center justify-center shadow-md">
                <span className="text-white font-bold text-lg">K</span>
              </div>
              <div className="ml-3">
                <h1 className="font-mystical text-2xl font-semibold text-kutbul-purple">
                  Kutbul Zaman
                </h1>
                <p className="text-xs text-kutbul-purple/70 -mt-1">
                  Merkezi Portal
                </p>
              </div>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-6">
            {navItems.map((item) => {
              const IconComponent = item.icon;
              return (
                <Button
                  key={item.label}
                  variant="ghost"
                  className="text-kutbul-purple hover:text-kutbul-teal hover:bg-kutbul-teal/10 rounded-xl"
                  onClick={item.action || (() => navigate(item.href))}
                >
                  <IconComponent className="w-4 h-4 mr-2" />
                  {item.label}
                </Button>
              );
            })}
          </nav>

          {/* User Menu (Desktop) */}
          {isLoggedIn && (
            <div className="hidden md:flex items-center space-x-4">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="outline"
                    className="rounded-xl border-kutbul-gray hover:border-kutbul-teal"
                  >
                    <User className="w-4 h-4 mr-2" />
                    {userData?.name || "Kullanıcı"}
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-56 rounded-xl shadow-md">
                  <DropdownMenuItem
                    onClick={() => navigate("/profile")}
                    className="rounded-lg"
                  >
                    <User className="w-4 h-4 mr-2" />
                    Profilim
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    onClick={() => navigate("/notifications")}
                    className="rounded-lg"
                  >
                    <Bell className="w-4 h-4 mr-2" />
                    Bildirimler
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem
                    onClick={handleLogout}
                    className="text-destructive rounded-lg"
                  >
                    <LogOut className="w-4 h-4 mr-2" />
                    Çıkış
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          )}

          {/* Mobile Menu Button */}
          <Button
            variant="ghost"
            size="sm"
            className="md:hidden rounded-xl"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? (
              <X className="w-5 h-5" />
            ) : (
              <Menu className="w-5 h-5" />
            )}
          </Button>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t border-kutbul-gray bg-kutbul-white/95 backdrop-blur-sm">
            <nav className="flex flex-col space-y-1 p-4">
              {navItems.map((item) => {
                const IconComponent = item.icon;
                return (
                  <Button
                    key={item.label}
                    variant="ghost"
                    className="justify-start text-kutbul-purple hover:text-kutbul-teal hover:bg-kutbul-teal/10 rounded-xl"
                    onClick={() => {
                      setMobileMenuOpen(false);
                      if (item.action) {
                        item.action();
                      } else {
                        navigate(item.href);
                      }
                    }}
                  >
                    <IconComponent className="w-4 h-4 mr-2" />
                    {item.label}
                  </Button>
                );
              })}

              {isLoggedIn && (
                <>
                  <div className="border-t border-kutbul-gray my-2" />
                  <Button
                    variant="ghost"
                    className="justify-start text-destructive hover:bg-red-50 rounded-xl"
                    onClick={() => {
                      setMobileMenuOpen(false);
                      handleLogout();
                    }}
                  >
                    <LogOut className="w-4 h-4 mr-2" />
                    Çıkış
                  </Button>
                </>
              )}
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}
